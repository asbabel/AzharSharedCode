#
# Script Name:   AddStaffwareOdbcConnection.ps1
# Date Written:  14/11/2017
# Description:   Adds an ODBC connection to the Staffware database.
#
# Audit History: 
#
#  Change Date   Author    Description
#  14/11/2017    PHH       Initial Version.
#

$odbcName = "Staffware"
$odbcType = "System"
$odbcPlat = "32-bit"
$odbcDriver = "SQL Server Native Client 11.0"
$odbcProperties = @(
	"Server=${sql.server.addr},${sql.server.port}",
	"Database=${sql.database.wfl.name}",
	"Trusted_Connection=Yes",
	"MultiSubnetFailover=Yes"
)

Write-Output "---------------------------"
Write-Output "Creating ODBC connection..."
Write-Output "---------------------------"
Write-Output "Details:"
Write-Output "  Name:       $odbcName"
Write-Output "  DSN Type:   $odbcType"
Write-Output "  Platform:   $odbcPlat"
Write-Output "  Driver:     $odbcDriver"
Write-Output "  Properties: $($odbcProperties -join "	$([Environment]::NewLine)              ")"
Write-Output ""

if ((Get-OdbcDsn -Name $odbcName -DsnType $odbcType -Platform $odbcPlat -ErrorAction Ignore)) {
    Write-Output "Replacing existing $odbcName ODBC connection"
    try {
		# Remove the existing ODBC connection
        Remove-OdbcDsn -Name $odbcName -DsnType System -Platform $odbcPlat -ErrorAction Stop
    } catch {
        Write-Output "ERROR: Failed to remove existing connection : $($_.Exception.Message)"
    }
} else {
    Write-Output "Creating new $odbcName ODBC connection"
}

try {
	# Add the ODBC connection
    Add-OdbcDsn -Name $odbcName -DriverName $odbcDriver -DsnType $odbcType -Platform $odbcPlat -SetPropertyvalue $odbcProperties
    Write-Output "------------------------"
    Write-Output "ODBC connection created."
    Write-Output "------------------------"
	
} catch {
    Write-Output "ERROR: Failed to create new connection : $($_.Exception.Message)"
}

exit $Error.Count
