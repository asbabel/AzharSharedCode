Param (
	[Parameter(Mandatory=$False)][Switch] $StopOnly = $False
)

"Stopping Staffware Service"
$staffwareServiceName = "iProcesssw_africaProcessSentinels"
try {
	Stop-Service $staffwareServiceName -Force -ErrorAction Stop
	"Staffware Service stopped successfully"
}
catch {
	"Error stopping Staffware Service, killing processes"
	Get-Process | Where-Object {
		$_.Path -like "*swserver*"
	} | ForEach-Object {
		$_.Kill()
	}
}

if (-not $StopOnly) {
	Set-Service $staffwareServiceName  -StartupType Disabled
}