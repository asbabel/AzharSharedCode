<#  
.SYNOPSIS  
    One off script specifically for a WFL server in order to grant share permissions to Util and PAY Monitors
.DESCRIPTION  
    This script sets up a share for the D:\Temp path in order to allow external monitors (Util and PAY) 
    to check the running state of the PaymentMonitor.
#>

$sharePath = "D:\Temp"
$shareName = "Temp"
$shareWithNetworkUsers = @("${env.type.sys.domain}\${env.type.sys.acc.prefix}${env.type.sys.acc}eBXUtilMon","${env.type.sys.domain}\${env.type.sys.acc.prefix}${env.type.sys.acc}eBXPayMon")

if ((Test-Path -Path $sharePath -PathType Container -ErrorAction Ignore)) {
    Write-Host "Creating share for $sharePath..."
    if ((Get-SmbShare -Name $shareName -ErrorAction Ignore)) {
        Remove-SmbShare -Name $shareName -Force -Confirm:$false
    }
    New-SmbShare -Name $shareName -Path $sharePath -Confirm:$false -Description "Share used by Monitoring applications - DO NOT REMOVE!" -FolderEnumerationMode AccessBased
    Grant-SmbShareAccess -Name $shareName -AccountName $shareWithNetworkUsers -AccessRight Read -Force -Confirm:$false

    $shareWithNetworkUsers | Foreach {
        $accessRule = New-Object Security.AccessControl.FileSystemAccessRule "$_", 
	        ([Security.AccessControl.FileSystemRights]::ReadAndExecute),
	        ([Security.AccessControl.InheritanceFlags]::ContainerInherit.value__ + [Security.AccessControl.InheritanceFlags]::ObjectInherit.value__),
	        ([Security.AccessControl.PropagationFlags]::None),
	        ([Security.AccessControl.AccessControlType]::Allow)

        try {
            $acl = Get-Acl -Path $sharePath
	        $acl.AddAccessRule($AccessRule)
            Set-Acl -Path $sharePath -AclObject $acl
        } catch {
            Write-Error "Failed to add access rule to path [$sharePath] with error: $($_.Exception.Message)"
        }
    }
} else {
    Write-Error "This script can only be executed when $sharePath path exists"
}
