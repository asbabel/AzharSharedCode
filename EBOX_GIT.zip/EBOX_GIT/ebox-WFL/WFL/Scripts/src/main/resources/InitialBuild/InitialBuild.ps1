﻿#
# Script Name:  InitialBuild.ps1
# Date Written: 17/01/2017
# Author:       Jim E C Ley
# Description:  One off script to be run after initial deployment to new server.
#
# Audit History: 
#
#  Change Date   Author    Description
#  17/01/2017    JECL      Initial version.
# 

<#  
.SYNOPSIS  
    One off script to be run after initial deployment to new server
.DESCRIPTION  
    This script does some initial setup required when deploying to a new UTL server
    Adds users/user groups to the local administrators group
    Grants full access for the application service accounts to required folders
    Adds directories that aren't included as part of the normal deploy
    Sets up shares to required folders
    Grants additional rights to certain users
#>

Import-Module -Name ".\InitialBuild.psm1" -Force

<#
.SYNOPSIS
    Grants permissions for the application users
.DESCRIPTION
    Grants full control to a list of directories for the application users
.PARAMETER User
    The name of the user or group to grant permissions to
.PARAMETER Directories
    The directories to grant the permissions to
#>
function Grant-FolderAccess {
    param (
        [Parameter(Mandatory=$true)]
        [String]$User,
        [Parameter(Mandatory=$true)]
        [String[]]$Directories
    )

	Write-Output "------------------------------------------"
	Write-Output "Add Folder Permissions for System Accounts"
	Write-Output "------------------------------------------"
		
    $accessRule = New-Object Security.AccessControl.FileSystemAccessRule $User, 
        ([Security.AccessControl.FileSystemRights]::FullControl),
	    ([Security.AccessControl.InheritanceFlags]::ContainerInherit.value__ + [Security.AccessControl.InheritanceFlags]::ObjectInherit.value__),
	    ([Security.AccessControl.PropagationFlags]::None),
        ([Security.AccessControl.AccessControlType]::Allow)

    $Directories | ForEach-Object {
        New-Directory $_
        Add-AccessRule $_ $accessRule
    }
}

<#
.SYNOPSIS
    Adds an ODBC connection to the Staffware database.
.DESCRIPTION    
#>
function Add-StaffwareOdbcDsn
{    

	Write-Output "-----------------------------------"
	Write-Output "Add an ODBC connection to Staffware"
	Write-Output "-----------------------------------"
	
    Add-OdbcDsn -Name Staffware -DriverName "SQL Server Native Client 11.0" `
            -DsnType System -Platform 32-bit `
            -SetPropertyvalue @("Server=${sql.server.addr},${sql.server.port}", "Database=${sql.database.wfl.name}","Trusted_Connection=Yes", "MultiSubnetFailover=Yes") `
            -ErrorAction Ignore
          
}

[XML]$Config = Get-Content "$PSScriptRoot\config.xml"
if(Assert-XmlIsValid $Config "$PSScriptRoot\config.xsd") {
    Add-StaffwareOdbcDsn
    Add-ToLocalGroups $Config.Settings.LocalGroups
    Grant-FolderAccess (Get-ServiceUserGroup $Config.Settings.ServiceUserGroup) $Config.Settings.GrantAccessToServiceAccounts.Directory
    Add-Profiles $Config.Settings.Profiles
    Add-TrustedCertificates $Config.Settings.TrustedCertificates.Certificate
	Disable-DHEAlgorithm
    Set-TimeZone -TimeZoneFriendlyName "UTC" 
    Create-TempShare
}