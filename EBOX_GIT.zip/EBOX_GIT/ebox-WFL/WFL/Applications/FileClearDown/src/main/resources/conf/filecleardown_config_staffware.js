// *******************************
// * THESE BITS ARE CONFIGURABLE *
// *******************************
//
// Changes: 
// Date         Author   Comments
// 23/01/2017   RM       Altered to run on new WFL configuration.
// 26/05/2017	LT		 Updated WFL configuration to clear down 
//						 release zips and folders.
// 08/09/2017	RM		 Updated to look for different file patterns
//						 in test and production builds.

// The amount of compression to use (more = slower) (0-9)
var compressionFactor = 1;
// Should we pretend (i.e. don't do anything)
var pretend = false;
//Is this a production build or a test build
var environment = "${env.type.sys.acc}"

// MOVE/RENAME/DELETE OLD FILES functionality
var fileOperations = new Array(



	// ------------------------------------------------------------
	// Deleting very old zip files from the "deleted" directories
	{	SourceDirectory:"D:\\Backups\\deleted",
		Description:"release zips",
		CutOffDays:10,
		ActionFiles:true,
		ActionFolders:false,
		Pattern:(environment=='P'?/^Release.*\.zip$/i:/.*\.zip$/i),
		Operation:"delete"
	},
	{	SourceDirectory:"D:\\Backups\\deleted",
		Description:"Release deployment zips",
		CutOffDays:10,
		ActionFiles:true,
		ActionFolders:false,
		Pattern:(environment=='P'?/^deploy_Release.*\.zip$/i:/^deploy_.*\.zip$/i),
		Operation:"delete"
	},
	{	SourceDirectory:"D:\\HouseKeptLogs\\deleted",
		Description:"log zips",
		CutOffDays:69,
		ActionFiles:true,
		ActionFolders:false,
		Pattern:/^sw_.*\.zip$/i,
		Operation:"delete"
	},

	// ------------------------------------------------------------
	// Moving old zip files to the "deleted" directories

	{	SourceDirectory:"D:\\Backups",
		Description:"release zips",
		CutOffDays:7,
		ActionFiles:true,
		ActionFolders:false,
		Pattern:(environment=='P'?/^Release.*\.zip$/i:/.*\.zip$/i),
		Operation:"move",
		DestinationDirectory:"D:\\Backups\\deleted"
	},
	{	SourceDirectory:"D:\\Backups",
		Description:"release deployment zips",
		CutOffDays:7,
		ActionFiles:true,
		ActionFolders:false,
		Pattern:(environment=='P'?/^deploy_Release.*\.zip$/i:/^deploy_.*\.zip$/i),
		Operation:"move",
		DestinationDirectory:"D:\\Backups\\deleted"
	},
	{	SourceDirectory:"D:\\HouseKeptLogs",
		Description:"log zips",
		CutOffDays:62,
		ActionFiles:true,
		ActionFolders:false,
		Pattern:/^sw_.*\.zip$/i,		
		Operation:"move",
		DestinationDirectory:"D:\\HouseKeptLogs\\deleted"
	},

	// ------------------------------------------------------------
	// Moving patch zip files to the "D:\Backups"

	{	SourceDirectory:"D:\\Releases",
		Description:"release zips",
		CutOffDays:1,
		ActionFiles:true,
		ActionFolders:false,
		Pattern:(environment=='P'?/^Release.*\.zip$/i:/.*\.zip$/i),
		Operation:"move",
		DestinationDirectory:"D:\\Backups"
	},

	// ------------------------------------------------------------
	// Zipping patch deployment folders to "D:\Backups" with "deploy_" at the start

	{	SourceDirectory:"D:\\Releases",
		Description:"release deployment folders",
		CutOffDays:1,
		ActionFiles:false,
		ActionFolders:true,
		Pattern:(environment=='P'?/^Release.*-WFL$/i:/^(?!deploy_).*-WFL*./i),
		Operation:"rename",
		RenameTo:"deploy_*"
	},
	{	SourceDirectory:"D:\\Releases",
		Description:"release deployment folders",
		CutOffDays:1,
		ActionFiles:false,
		ActionFolders:true,
		Pattern:(environment=='P'?/^deploy_Release.*-WFL$/i:/^deploy_.*-WFL*./i),
		Operation:"zip",
		DestinationDirectory:"D:\\Backups"
	},

	// ------------------------------------------------------------
	// Zipping log files to "D:\Houselogs"

	{	SourceDirectory:"D:\\swserver\\sw_africa\\logs",
		Description:"Staffware Logs",
		CutOffDays:7,
		Operation:"zipWildcards",
		ZipBasePath:"D:\\HouseKeptLogs\\sw_",
		Exclusions:["swjmx_java.log"],
		ZipSplit:"100-200"
	}
);
