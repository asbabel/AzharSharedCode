package com.barclays.staffware.plugin.util;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

public class ValidateSwiftTest {
	@Test 
	@Ignore // because this test will only pass when current year is a leap year.
	public void validateDateTime_0229_MMdd() throws Exception {
		invokeValidation("0229","MMdd");
	}

	@Test
	public void validateDateTime_160229_yyMMdd() throws Exception {
		invokeValidation("160229","yyMMdd");
	}

	@Test (expected = Exception.class)
	public void validateDateTime_0230_MMdd_shouldThrowException() throws Exception  {
		invokeValidation(/*30 feb*/"0230", "MMdd");
	}

	@Test (expected = Exception.class)
	public void validateDateTime_150229_yyMMdd_shouldThrowException() throws Exception  {
		invokeValidation(/*2015 is non leap year*/"150229", "yyMMdd");
	}

	@Test 
	public void validateDateTime_1359_HHmm() throws Exception  {
		invokeValidation(/*time passed in*/"1359", "HHmm");
	}
	
	private void invokeValidation(String dateStr, String pattern) throws Exception {
		String returnDate = ValidateSwift.validateDateTime(dateStr, pattern);
		
		// this method call always returns the date string that was passed in.
		Assert.assertEquals(returnDate, dateStr);		
	}

}
