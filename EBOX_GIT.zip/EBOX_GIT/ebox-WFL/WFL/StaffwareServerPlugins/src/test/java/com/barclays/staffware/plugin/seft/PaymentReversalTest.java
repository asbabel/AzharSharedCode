package com.barclays.staffware.plugin.seft;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;

import com.barclays.staffware.plugin.PaymentReversal;
import com.barclays.staffware.plugin.mq.StaffwareFieldHelper;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.NonFatalPluginException;

public class PaymentReversalTest {

	private static final Properties PROPERTIES = new Properties();
	private static final String PROPFILE = "testeaijavaplugin.properties";
	List<Field> inputList;
	List<Field> outputList;
	
	/**
	 * Sets up the input data to the plugin
	 */
	@Before
	public void setup() {
		
		//Create the input fields
		inputList = new ArrayList<Field>();
		inputList.add(StaffwareFieldHelper.mockedField("GROUP_ID", "300651312"));
		inputList.add(StaffwareFieldHelper.mockedField("ITEM_NUMBER", "1"));
		inputList.add(StaffwareFieldHelper.mockedField("REV_CHARGE_IND", "true"));
		
		//Create empty output fields
		outputList = new ArrayList<Field>();
		outputList.add(StaffwareFieldHelper.mockedField("STATUSCODE", ""));
		outputList.add(StaffwareFieldHelper.mockedField("STATUSDESC", ""));
		outputList.add(StaffwareFieldHelper.mockedField("ERRORCODE", ""));
		outputList.add(StaffwareFieldHelper.mockedField("ERRORDESC", ""));
	}
	
	@Test
	public void excecuteTest() throws IOException, FatalPluginException, NonFatalPluginException {
		
		PaymentReversal paymentReversal = new PaymentReversal();
		
		//Initialise
		PROPERTIES.load(PaymentReversalTest.class.getClassLoader()
                .getResourceAsStream(PROPFILE));
		paymentReversal.initialize(PROPERTIES);
		
		//Execute
		paymentReversal.execute(null, outputList, inputList);
		
		//Display result
		for (Field field : outputList) {
			System.out.println("Fields name: " + field.getName() + ", Value: " + field.getValue() + ", Type: " + field.getType());
		}
		
	}
}
