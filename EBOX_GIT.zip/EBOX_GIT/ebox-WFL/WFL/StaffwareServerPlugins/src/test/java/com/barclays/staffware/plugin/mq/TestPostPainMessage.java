package com.barclays.staffware.plugin.mq;


import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.junit.Before;
import org.junit.Test;

import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.staffware.plugin.pain.*;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.NonFatalPluginException;

public class TestPostPainMessage {

	
	private static final Properties PROPERTIES = new Properties();
	private static final String PROPFILE = "C:/testeaijavaplugin.properties";
	List<Field> inputList;
	List<Field> outputList;
	
	@Before

	public void setUp() throws Exception 
	{
		inputList = new ArrayList<Field>();
		outputList = new ArrayList<Field>();
		
		//Set up Dummy Inputs
		inputList.add(StaffwareFieldHelper.mockedField("EBOX_ACT_REF", "SCOUT000000110"));
		inputList.add(StaffwareFieldHelper.mockedField("GROUP_ID", "300650531"));
		inputList.add(StaffwareFieldHelper.mockedField("SW_CASENUM", "27524004"));
        inputList.add(StaffwareFieldHelper.mockedField("SW_PRONAME", "DOMOUT"));
        inputList.add(StaffwareFieldHelper.mockedField("COUNTRY", "SC"));
		
		//Pass in Blank Outputs 
		outputList.add(StaffwareFieldHelper.mockedField("STATUSCODE", ""));
		outputList.add(StaffwareFieldHelper.mockedField("STATUSDESC", ""));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void PostPainMessage() throws FatalPluginException, NonFatalPluginException, DataAccessException, IOException
	{
		PostPainMessage objPostPain = new PostPainMessage();
		InputStream input = new FileInputStream(PROPFILE);
		PROPERTIES.load(input);
		objPostPain.initialize(PROPERTIES);
		Map result = objPostPain.execute("", outputList, inputList);
		String StatusCode = (String)result.get("STATUSCODE");
		String StatusDesc = (String) result.get("STATUSDESC");
		assertEquals("0", StatusCode);
		assertEquals("SUCCESS", StatusDesc);
	}
}
