package com.barclays.staffware.plugin.mq;

import com.staffware.eaijava.Field;

public final class StaffwareFieldHelper {

	public static Field mockedField(final String fName, final String fValue) {

		Field field = new Field() {

			private static final long serialVersionUID = 1L;

			public String fieldValue = fValue;

			public String fieldName = fName;

			@Override
			public String getValue() {

				return fieldValue;
			}

			@Override
			public char getType() {

				return 0;
			}

			@Override
			public String getName() {

				return fieldName;
			}

			@Override
			public int getLength() {

				return 0;
			}

			@Override
			public int getDecimalPlaces() {

				return 0;
			}
		};

		return field;
	}
}
