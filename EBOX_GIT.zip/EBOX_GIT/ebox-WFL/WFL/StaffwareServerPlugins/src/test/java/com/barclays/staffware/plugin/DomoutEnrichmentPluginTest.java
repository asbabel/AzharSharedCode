package com.barclays.staffware.plugin;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;

import com.barclays.staffware.plugin.mq.StaffwareFieldHelper;
import com.barclays.staffware.plugin.mq.TestPostPainMessage;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.NonFatalPluginException;

public class DomoutEnrichmentPluginTest {

    private static final Properties PROPERTIES = new Properties();
    private static final String PROPFILE = "testeaijavaplugin.properties";
    List<Field> inputList;
    List<Field> outputList;

    @Before
    public void setUp() {
        try {
            PROPERTIES.load(TestPostPainMessage.class.getClassLoader().getResourceAsStream(
                    PROPFILE));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        inputList = new ArrayList<Field>();
        outputList = new ArrayList<Field>();

        inputList.add(StaffwareFieldHelper.mockedField("GROUP_ID", "300654246"));
        inputList.add(StaffwareFieldHelper.mockedField("EBOX_ACT_REF",
                "SCDOM000000263"));
        inputList.add(StaffwareFieldHelper.mockedField("ITEM_NUMBER", "1"));
        inputList.add(StaffwareFieldHelper.mockedField("PAYMENT_TYPE",
                "LOCALBILLPAYT"));
    }

    @Test
    public void test() throws FatalPluginException, NonFatalPluginException {
        DomoutDataEnrichmentPlugin enrich = new DomoutDataEnrichmentPlugin();
        enrich.initialize(PROPERTIES);
        Map<String, Object> result = enrich.execute("", outputList, inputList);
        assertNotNull(result);

        for (Map.Entry<String, Object> entry : result.entrySet()) {
            System.out.println("Key : " + entry.getKey() + ", Value : "
                    + entry.getValue());
            assertNotNull(entry.getValue());
        }
    }
}
