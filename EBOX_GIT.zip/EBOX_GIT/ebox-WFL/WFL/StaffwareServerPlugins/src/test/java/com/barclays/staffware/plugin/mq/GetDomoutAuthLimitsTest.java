package com.barclays.staffware.plugin.mq;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;

import com.barclays.staffware.plugin.DomoutGetAuthLimits;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.NonFatalPluginException;

public class GetDomoutAuthLimitsTest {

	private static final Properties PROPERTIES = new Properties();
	private static final String PROPFILE = "testeaijavaplugin.properties";
	List<Field> inputList;
	List<Field> outputList;
	
	static
	{
		try {
            PROPERTIES.load(TestPostPainMessage.class.getClassLoader()
                .getResourceAsStream(PROPFILE));
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
	}
	
	@Before
	public void setUp() {
		inputList = new ArrayList<Field>();
		outputList = new ArrayList<Field>();
		
		inputList.add(StaffwareFieldHelper.mockedField("COUNTRY", "SYC"));
	}
	
	@Test
	public void executeTest() throws FatalPluginException, NonFatalPluginException {
		DomoutGetAuthLimits getLimits = new DomoutGetAuthLimits();
		getLimits.initialize(PROPERTIES);
		Map<String, Object> result = getLimits.execute("", outputList, inputList);
		assertNotNull(result);
		
		for (Map.Entry<String, Object> entry : result.entrySet()) {
			System.out.println("Key : " + entry.getKey() + ", Value : " + entry.getValue());
		}
	}
}
