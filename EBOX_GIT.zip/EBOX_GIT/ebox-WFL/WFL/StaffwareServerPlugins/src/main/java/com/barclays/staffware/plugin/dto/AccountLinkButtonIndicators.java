package com.barclays.staffware.plugin.dto;

import java.io.Serializable;

/**
 * @author GX
 *
 * OLEReplacementPhase3 - Account Details
 */
/*
 * DATE     REFERENCE		WHO     VERSION			COMMENTS
 * -------	---------		---     ------------	-------------------------------
 * 22Dec11  OLERP3          GX		1a              Created
 * 12May15	WP654			PLC		1.1				Implement Comparable for Java 7
 * 
 */
public class AccountLinkButtonIndicators 
	implements Serializable, Comparable<AccountLinkButtonIndicators> {

	private static final long serialVersionUID = -5705698488117146660L;
	
	private Boolean hasRoles;
	private Boolean hasStoppedChqs;
	private Boolean hasStdOrders;
	private Boolean hasFixedDepplcs;
	private Boolean hasAutoTfrs;
	private Boolean hasGroups;

	public AccountLinkButtonIndicators(Boolean indicator) {
		super();
		this.hasRoles = indicator;
		this.hasStoppedChqs = indicator;
		this.hasStdOrders = indicator;
		this.hasFixedDepplcs = indicator;
		this.hasAutoTfrs = indicator;
		this.hasGroups = indicator;
	}
	
	public Boolean getHasRoles() {
		return hasRoles;
	}
	public void setHasRoles(Boolean hasRoles) {
		this.hasRoles = hasRoles;
	}
	public Boolean getHasStoppedChqs() {
		return hasStoppedChqs;
	}
	public void setHasStoppedChqs(Boolean hasStoppedChqs) {
		this.hasStoppedChqs = hasStoppedChqs;
	}
	public Boolean getHasStdOrders() {
		return hasStdOrders;
	}
	public void setHasStdOrders(Boolean hasStdOrders) {
		this.hasStdOrders = hasStdOrders;
	}
	public Boolean getHasFixedDepplcs() {
		return hasFixedDepplcs;
	}
	public void setHasFixedDepplcs(Boolean hasFixedDepplcs) {
		this.hasFixedDepplcs = hasFixedDepplcs;
	}
	public Boolean getHasAutoTfrs() {
		return hasAutoTfrs;
	}
	public void setHasAutoTfrs(Boolean hasAutoTfrs) {
		this.hasAutoTfrs = hasAutoTfrs;
	}
	public Boolean getHasGroups() {
		return hasGroups;
	}
	public void setHasGroups(Boolean hasGroups) {
		this.hasGroups = hasGroups;
	}

	@Override
	public int compareTo(AccountLinkButtonIndicators albi) {
		// Method has been implemented as simply as possible due to "Comparable"
		// interface being required for TreeMap.java in Java 1.7. 
		return this.hasRoles.compareTo(albi.hasRoles);
	}
}
