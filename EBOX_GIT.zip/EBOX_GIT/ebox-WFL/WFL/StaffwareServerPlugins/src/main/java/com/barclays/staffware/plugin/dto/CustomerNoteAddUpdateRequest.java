package com.barclays.staffware.plugin.dto;

/**
 * Represents a request to add or update a Customer Note
 * 
 * @author HUNTI
 */
/*
 *
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 05Oct06  -          ILH    1.0      Created 
 * 17Oct06  PAT01765   ILH    1a       Made to extend new Note class
 * 14Feb08  PAT02404   KEMPD  3        Note is now serializable.
 */
public class CustomerNoteAddUpdateRequest
    extends Note
{    
    private static final long serialVersionUID = -3308208423119778532L;
    
    private int customerNumber;
    private int versionNumber;
    private String country;
    private boolean offshore;
    
    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }
    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }
    /**
     * @return the offshore
     */
    public boolean isOffshore() {
        return offshore;
    }
    /**
     * @param offshore the offshore to set
     */
    public void setOffshore(boolean offshore) {
        this.offshore = offshore;
    }
    /**
     * @return the customerNumber
     */
    public int getCustomerNumber() {
        return customerNumber;
    }
    /**
     * @param customerNumber the customerNumber to set
     */
    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }
    /**
     * @return the versionNumber
     */
    public int getVersionNumber() {
        return versionNumber;
    }
    /**
     * @param versionNumber the versionNumber to set
     */
    public void setVersionNumber(int versionNumber) {
        this.versionNumber = versionNumber;
    }    
}
