package com.barclays.staffware.plugin.util;

import com.barclays.generic.math.Decimal;
import com.ibm.math.BigDecimal;

/**
 * Class which holds maths functions for use in Expression Language 
 * 
 */
/* 
 * DATE     REFERENCE   WHO   VERSION  COMMENTS
 * -------  ---------   ---   -------  -----------------------------------------
 * 31/07/06 -           BE     	       Created
 */
public class MathOperator {
	
	public static BigDecimal reciprocate(BigDecimal value){
		BigDecimal zero = new BigDecimal("0");
		if(value == null || zero.compareTo(value) == 0) return null;
		BigDecimal one = new BigDecimal("1");
		return one.divide(value, Decimal.SCALE, BigDecimal.ROUND_HALF_UP);
	}
	
	public static BigDecimal reciprocateString(String value){
		if(value == null || value.length() == 0) return null;
		BigDecimal divisor = new BigDecimal(value);
        if (divisor.compareTo(BigDecimal.valueOf(0)) == 0) return null;
		BigDecimal one = new BigDecimal("1");
		return one.divide(divisor, Decimal.SCALE, BigDecimal.ROUND_HALF_UP);
	}
	
	/**
	 * An amendment to the Object.equals method that ensures that BigDecimals
	 * are compared correctly 
	 * @param value1 The first value
	 * @param value2 The second value
	 * @return Returns true if : They are both null; They are both BigDecimals and are numerically equal; One or more is not BigDecimal and value1.equals(value2)
	 */
	public static boolean bigDecimalEquals(Object value1, Object value2) {
		if (value1 == null && value2 == null) {
			return true;
		}
		if (value1 != null && value2 == null) {
			return false;
		}
		if (value1 == null && value2 != null) {
			return false;
		}
		if (value1 instanceof BigDecimal && value2 instanceof BigDecimal) {
			return (((BigDecimal) value1).compareTo((BigDecimal) value2) == 0);
		}
		return value1.equals(value2);
	}
}
