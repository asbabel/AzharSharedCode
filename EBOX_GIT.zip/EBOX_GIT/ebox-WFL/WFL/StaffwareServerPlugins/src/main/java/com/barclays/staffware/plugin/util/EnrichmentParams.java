package com.barclays.staffware.plugin.util;

public class EnrichmentParams {

    // Properties constants
    public static final String DB_DRIVER = "db_driver";

    // Stored Procedures
    public static final String SP_GET_DOMOUT_DETAILS = "sfw_getDomOutDetails";

    // Staffware Fields
    public static final String SW_SENDERS_REF = "SENDERS_REF";
    public static final String SW_OP_CODE = "OP_CODE";
    public static final String SW_LOCATION_CODE = "LOCATION_CODE";
    public static final String SW_VALUE_DATE = "VALUE_DATE";
    public static final String SW_SAME_DAY_VALUE = "SAME_DAY_VALUE";
    public static final String SW_SETTLE_AMT = "SETTLEMENT_AMT";
    public static final String SW_SETTLE_CUR = "SETTLE_CUR";
    public static final String SW_INST_AMT = "INST_AMT";
    public static final String SW_INST_CUR = "INST_CUR";
    public static final String SW_MARKET_SEGMENT = "MARKET_SEGMENT";
    public static final String SW_ORDERING_ACC = "ORDERING_ACC";
    public static final String SW_ORDERING_NAME = "ORDERING_NAME";
    public static final String SW_ORDERING_ADDR1 = "ORDERING_ADDR_1";
    public static final String SW_ORDERING_ADDR2 = "ORDERING_ADDR_2";
    public static final String SW_ORDERING_ADDR3 = "ORDERING_ADDR_3";
    public static final String SW_ACC_WITH = "ACC_WITH";
    public static final String SW_PREFERRED_INT = "PREFERRED_INT";
    public static final String SW_BENEF_BANK = "BENEF_BANK";
    public static final String SW_BENEF_ACC = "BENEF_ACC";
    public static final String SW_BENEF_NAME = "BENEF_NAME";
    public static final String SW_BENEF_ADDR1 = "BENEF_ADDR_1";
    public static final String SW_BENEF_ADDR2 = "BENEF_ADDR_2";
    public static final String SW_BENEF_ADDR3 = "BENEF_ADDR_3";
    public static final String SW_REM_INFO1 = "REM_INFO1";
    public static final String SW_REM_INFO2 = "REM_INFO2";
    public static final String SW_REM_INFO3 = "REM_INFO3";
    public static final String SW_REM_INFO4 = "REM_INFO4";
    public static final String SW_CHARGES = "CHARGES";
    public static final String SW_ML_CHECK = "ML_CHECK";
    public static final String SW_ORIG_CUR = "ORIG_CUR";
    public static final String SW_ORIG_BRANCH = "ORIG_BRANCH";
    public static final String SW_ORIG_ACC = "ORIG_ACC";
    public static final String SW_ORIG_TRANS_AMT = "ORIG_TRANS_AMT";
    public static final String SW_ORIG_LOCAL_AMT = "ORIG_LOCAL_AMT";
    public static final String SW_ORIG_REM_INFO = "ORIG_REM_INFO";
    public static final String SW_SUSP_CUR = "SUSP_CUR";
    public static final String SW_SUSP_TRANS_AMT = "SUSP_TRANS_AMT";
    public static final String SW_SUSP_LOCAL_AMT = "SUSP_LOCAL_AMT";
    public static final String SW_COUN_LOCAL_AMT = "COUN_LOCAL_AMT";
    public static final String SW_BANK_NAME = "BANK_NAME";
    public static final String SW_BANK_ADDR_1 = "BANK_ADDR_1";
    public static final String SW_BANK_ADDR_2 = "BANK_ADDR_2";
    public static final String SW_BANK_ADDR_3 = "BANK_ADDR_3";
    public static final String SW_DISPLAY_CODE = "DISPLAY_CODE";
    public static final String SW_BIC_BENEFICIARY = "BIC_BENEFICIARY";
    public static final String SW_SEND_TO_REC1 = "SEND_TO_REC1";

    // Database fields
    public static final String DB_SENDERS_REF = "SendersReference";
    public static final String DB_LOCATION_CODE = "LocationCode";
    public static final String DB_POST_DATE = "PostDate";
    public static final String DB_SAME_DAY_VALUE = "SameDayValueInd";
    public static final String DB_ORIG_LOCAL_AMT = "OriginatorLocalAmount";
    public static final String DB_COUNTER_CUR = "CounterpartyCurrency";
    public static final String DB_MARKET_SEGMENT = "MarketSegment";
    public static final String DB_IBAN_NUMBER = "IBANNumber";
    public static final String DB_ORIG_BRANCH_ID = "OriginatorBranchId";
    public static final String DB_ORIG_ACC_NUM = "OriginatorAccountNumber";
    public static final String DB_ORIG_NAME = "OriginatorName";
    public static final String DB_ORIG_ADDR1 = "OriginatorAddress1";
    public static final String DB_ORIG_ADDR2 = "OriginatorAddress2";
    public static final String DB_ORIG_ADDR3 = "OriginatorAddress3";

    // Errors
    public static final String ERR_INIT_1 = "Error initialising ";
    public static final String ERR_INIT_2 = ". Details: ";
    public static final String DB_ERR = "Error retrieving data from the database.  Details are ";

    private EnrichmentParams() {
    }
}
