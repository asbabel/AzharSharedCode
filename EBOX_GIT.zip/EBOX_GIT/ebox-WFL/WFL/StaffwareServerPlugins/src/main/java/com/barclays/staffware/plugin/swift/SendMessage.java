package com.barclays.staffware.plugin.swift;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.dstx.MapInvoke;
import com.barclays.middleware.dstx.staffware.SWMapInvoke;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.mq.MQConnection;
import com.barclays.staffware.data.IMWDBAccess;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TagHelper;
import com.barclays.swift.StoreMessage;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.constants.MQConstants;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * EAI java plugin for sending SWIFT message (putting into MQ and storing)
 * 
 * @author LEES
 */
/*
 * DATE     REFERENCE     WHO     VERSION     COMMENTS 
 * ----     ---------     ---     -------     --------
 * 24MAR14  WP669         SL      1.0         Created
 * 13OCT14  WP668         SL      1.01        SMxx enhancement
 * 28SEP15  WP695         AK      1.02        Modified code as part of Zambia RTGS payment fix for INC0030143712
 * 10JAN17  WP711         PHH     1.03        Fixed MQ put retries and added error logging
 * 17Jan17  WP715         LeyJ    -           Refactored data access to MWDB.
 */

public class SendMessage implements ImmediateReleasePluginSDK {

    private static final int SIX = 6;

    private static final int POSITION_TWO = 2;

    private IMWDBAccess dataAccess;

    private StoreMessage storeMessage;
    private MapInvoke wtx;

    private String country;
    private String messageType;
    private String swiftMessage;
    private int swMainCase;
    private String swMainProc;
    private String messageId;
    private String stepname;
    private String targetCountry;
    private String sentDate;
    private String mqParams;
    private String msgData;
    private String lastAuthoriser;

    private boolean hasTag103 = false;

    private int retryLimit = 3;

    public static final String MSG_TYPE = "REQUEST";
    public static final String FORMAT = "SWIFT";
    public static final String PROJECT_ID = "IOPAY";
    public static final String ACCOUNTING_TOKEN = "STAFFWARE";
    public static final String SOURCE_APPL_NAME = "STAFFWARE";
    private static final String MQ_SECURE_ROW = "MQ-WFL";

    private static final LoggerConnection logger = new LoggerConnection(SendMessage.class);

    private final String initializationFailed = SwiftParams.initializationFailed(SendMessage.class.getName());

    /**
     * Sets data access interface
     * 
     * @param dataAccess
     */
    public void setDataAccess(IMWDBAccess dataAccess) {
        this.dataAccess = dataAccess;
    }

    /**
     * Gets data access interface
     * 
     * @return dataAccess
     */
    public IMWDBAccess getDataAccess() {
        return this.dataAccess;
    }

    /**
     * Gets Country
     * 
     * @return COUNTRY
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets COUNTRY
     * 
     * @param country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets messageType
     * 
     * @return messageType
     */
    public String getMessageType() {
        return messageType;
    }

    /**
     * Sets messageType
     * 
     * @param messageType
     */
    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    /**
     * Gets SWIFT Message
     * 
     * @return swift message
     * @throws NonFatalPluginException if swift message is not present
     */
    public String getSwiftMessage() throws Exception { // NOSONAR
        if (swiftMessage == null || swiftMessage.trim().isEmpty()) {
            throw new Exception(SwiftParams.MISSING_SWIFT_MESSAGE);// NOSONAR
        }
        return swiftMessage;
    }

    /**
     * Sets SWIFT Message
     * 
     * @param swiftMessage
     */
    public void setSwiftMessage(String swiftMessage) {
        this.swiftMessage = swiftMessage;
    }

    /**
     * Gets SW_MAINCASE
     * 
     * @return swMainCase
     */
    public int getSwMainCase() {
        return swMainCase;
    }

    /**
     * Sets SW_MAINCASE
     * 
     * @param swMainCase
     * @throws Exception if SW_MAINCASE is not present
     */
    public void setSwMainCase(String swMainCase) throws Exception {// NOSONAR
        if (swMainCase == null || swMainCase.trim().isEmpty()) {
            throw new Exception(SwiftParams.MISSING_SW_MAINCASE);// NOSONAR
        }
        this.swMainCase = Integer.parseInt(swMainCase);
    }

    /**
     * Gets SW_MAINPROC
     * 
     * @return swMainProc
     */
    public String getSwMainProc() {
        return swMainProc;
    }

    /**
     * Sets SW_MAINPROC
     * 
     * @param swMainProc
     * @throws Exception if SW_MAINPROC is not present
     */
    public void setSwMainProc(String swMainProc) throws Exception {// NOSONAR
        if (swMainProc == null || swMainProc.trim().isEmpty()) {
            throw new Exception(SwiftParams.MISSING_SW_MAINPROC);// NOSONAR
        }
        this.swMainProc = swMainProc.trim();
    }

    /**
     * Gets MESSAGEID
     * 
     * @return messageId
     */
    public String getMessageId() {
        if (messageId == null || messageId.trim().isEmpty()) {
            return StaffwareHelper.newMessageId();
        }
        return messageId;
    }

    /**
     * Sets MESSAGEID
     * 
     * @param messageId
     */
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    /**
     * Gets STEPNAME
     * 
     * @return stepname
     */
    public String getStepname() {
        return stepname;
    }

    /**
     * Sets stepname
     * 
     * @param stepname
     */
    public void setStepname(String stepname) {
        this.stepname = stepname;
    }

    /**
     * Gets for transaction id
     */
    public String getTransactionId() {
        return "SW-" + getSwMainCase();
    }

    /**
     * Gets for new message id
     * 
     * @return new message id
     * @throws SQLException If SQL connection fails
     */
    public String getMsgId() {
        try {
            return this.dataAccess.getNewMessageId();
        } catch (SQLException e) {// NOSONAR
            return "0";
        }
    }

    /**
     * Gets target country
     * 
     * @return target country
     */
    public String getTargetCountry() {
        return this.targetCountry;
    }

    /**
     * Sets target country
     * 
     * @throws SQLException if SQL connection fails
     */
    public void setTargetCountry() throws SQLException {
        this.targetCountry = this.dataAccess.getTargetCountry(getCountry(), 0).substring(0, POSITION_TWO);
    }

    /**
     * Sets current date and time
     */
    public void setSentDate(String sentDate) {
        this.sentDate = sentDate;
    }

    /**
     * Gets sent date
     * 
     * @return sentDate
     */
    public String getSentDate() {
        return this.sentDate;
    }

    /**
     * Gets MQ parameters
     * 
     * @return mqParams
     */
    public String getMqParams() {
        return this.mqParams;
    }

    /**
     * Gets MsgData
     * 
     * @return msgData
     */
    public String getMsgData() {
        return this.msgData;
    }

    /**
     * Gets LAST_AUTHORISER (a value passed in by Staffware)
     * 
     * @return lastAuthoriser
     */
    public String getLastAuthoriser() {
        return this.lastAuthoriser;
    }

    /**
     * Returns true if SWIFT message has tag103
     */
    public boolean hasTag103() {
        return hasTag103;
    }

    /**
     * Gets retry limit
     * 
     * @return retryLimit
     */
    public int getRetryLimit() {
        return this.retryLimit;
    }

    /**
     * Gets logger connection
     * 
     * @return logger
     */
    public LoggerConnection getLogger() {
        return logger;
    }

    /**
     * Method is called by Staffware before each execute (unless a caching
     * option is selected in Staffware) Loads properties file
     * 
     * @param properties contents of eaijava properties file in
     * root:/swserver/sw_africa/eaijava
     */
    public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {
        wtx = new SWMapInvoke();
        wtx.setHostname(properties.getProperty("ib_hostname"));
        wtx.setPort(Integer.parseInt(properties.getProperty("ib_port")));
        wtx.setTimeout(Integer.parseInt(properties.getProperty("ib_timeout")));
        try {
// Modified by ashish
            ClassPathResource resource = new ClassPathResource(properties.getProperty("swiftSendMsgLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());
            // till here
        	logger.debug(this.getClass().toString() + "test log write!");
        	BrainsSocketConnectionFactory.getInstance().useSecure(properties);
            //Modified by ashish for sql connection
        	DataSourceDirectory.getInstance().basePluginDS();
           // Class.forName(properties.getProperty("db_driver"));
            this.mqParams = properties.getProperty("mq_params");


        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
            }
        setDataAccess(new MWDBAccess());
    }

    /**
     * Method Staffware calls in eaijava step
     * 
     * @param staticData a string hardcoded in Staffware, this is ignored in the
     * processing for MT900 and MT910 and used for the other message types
     * @param outputFields a list of Staffware field objects which Staffware
     * expects to be returned
     * @param inputFields a list of Staffware field objects which Staffware
     * provides (with values)
     * @return the name value pairs returned to Staffware
     */
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {
        logger.info("--Executing SendMessage Plugin execute method--");

        Map<String, Object> result = new HashMap<String, Object>(outputFields.size());
        StaffwareHelper.initialiseReturnValues(outputFields, result);
        try {
            setClassProperties(inputFields);
            if (logger.isDebugEnabled()) {
                logger.debug("Arguments received from Staffware: ");
                for (Iterator<?> i = inputFields.iterator(); i.hasNext();) {
                    Field field = (Field) i.next();
                    logger.debug(field.getName() + " = " + field.getValue());
                }
            }
            // if not one of the listed messages, call WTX map
            if ("199".equals(getMessageType())
                    // SMxx enhancement - send MT103 and 202 using this plugin
                    || "103".equals(getMessageType()) || "202".equals(getMessageType())
                    || "900".equals(getMessageType()) || "910".equals(getMessageType())
                    || "941".equals(getMessageType()) || "940".equals(getMessageType())
                    || "942".equals(getMessageType()) || "950".equals(getMessageType())) {
                if (!skipFurtherProcessing()) {
                    logger.info("--Executing updateStaffwareStepname method with mainProc:"+getSwMainProc()+",MainCase:"+getSwMainCase()+",stepname: "+getStepname());
                    this.dataAccess.updateStaffwareStepname(getSwMainProc(), getSwMainCase(), getStepname());
                    setTargetCountry();
                    // update authoriser for 103 message only.
                    if (getLastAuthoriser() != null && !getLastAuthoriser().isEmpty()
                            && SwiftParams.MESSAGE_103.equals(getMessageType())) {
                        swiftMessage = swiftMessage.replace("^AUTH^", getLastAuthoriser());
                    }

                    // SMxx enhancement - MT103
                    this.msgData = StaffwareHelper.formatMsgData(formatMWMH(), getSwiftMessage());

                    // store message
                    storeMessage =
                            new StoreMessage(this.msgData, getSwMainProc(), String.valueOf(getSwMainCase()), 'O', 'N');

                    SQLConnection conn = null;
                    try {
                        conn = MWDBAccess.getDatabaseConnection();
                        try {
                            conn.setAutoCommit(false);
                            logger.info("--Executing SendMessage Plugin store method--");
                            storeMessage.store(conn);
                            // put message in MQ
                            if (putInMQ(getMsgData(), conn)) {
                                conn.commit();
                                result.put(SwiftParams.STATUSCODE, "0");
                                result.put(SwiftParams.STATUSDESC, "SUCCESS");
                            }
                        } catch (SQLException e) {
                            StaffwareHelper.rollbackSQLTransaction(conn, e, getLogger(), SwiftParams.SP_ERROR);
                        } catch (ParseException e) {
                            StaffwareHelper.rollbackSQLTransaction(conn, e, getLogger(), SwiftParams.PARSE_ERROR);
                        } catch (MQException e) {
                            StaffwareHelper.rollbackSQLTransaction(conn, e, getLogger(), SwiftParams.MQ_ERROR);
                        } catch (Exception e) { // NOSONAR
                            StaffwareHelper.rollbackSQLTransaction(conn, e, getLogger(), "Unexpected Error");
                        } finally {
                            if (conn != null) {
                                conn.setAutoCommit(true);
                                conn.close();
                            }
                        }
                    } catch (SQLException e) {
                        getLogger().error(SwiftParams.DB_ERROR + ". Details: " + e.getMessage(), e);
                    }
                }
            } else {
                return wtx.execute(staticData, outputFields, inputFields);
            }

        } catch (Exception e) {
            getLogger().error(SwiftParams.FAIL_APP + ". Details: " + e.toString(), e);
            StaffwareHelper.setErrorMessage(e, result, "-1", SwiftParams.FAIL_APP);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Returning values to Staffware: ");
            List<String> keys = new ArrayList<String>(result.keySet());
            Collections.sort(keys);
            for (Iterator<?> i = keys.iterator(); i.hasNext();) {
                String key = (String) i.next();
                logger.debug(key + " <- " + result.get(key));
            }
        }
        return result;
    }

    /**
     * Method to close MQ queue and queue manager connections
     * 
     * @param mqQueue Connection to a specific queue
     * @param mqConn General MQ connection
     * @throws MQException if MQ connection fails
     */
    private void closeMQConnections(MQQueue mqQueue, MQConnection mqConn) throws MQException {
        try {
            if (mqQueue != null) {
                mqQueue.close();
            }
        } finally {
            if (mqConn != null) {
                mqConn.disconnect();
            }
        }
    }

    /**
     * Method for putting message into MQ
     * 
     * @param mwmh Message data for MQ
     * @return true if put message is successful, false otherwise
     * @throws SQLException if SQL connection fails
     * @throws MQException if MQ connection fails
     * @throws IOException if fail to write string into the message buffer
     */
    private boolean putInMQ(String mwmh, SQLConnection conn) throws SQLException, IOException, MQException {
        boolean success = false;
        MQConnection mqConn = new MQConnection();
        MQQueue mqQueue = null;
        try {
            logger.info("---Executing putInMQ method--");
            logger.info("---request param for putInMQ method ,  MQ_SECURE_ROW: "+MQ_SECURE_ROW+", getMqParams:"+getMqParams()+",MQOO_OUTPUT:"+MQConstants.MQOO_OUTPUT);
            mqQueue = mqConn.getQueue(MQ_SECURE_ROW, getMqParams(), MQConstants.MQOO_OUTPUT, conn);
            // check if mqQueue is null since MQConnection class currently eats any MQException (does log it though)
            logger.info("---getQueue method completed --");
            if (mqQueue != null) {
                // Define a simple Websphere MQ message
                MQMessage msg = new MQMessage();
                // specify the message options
                MQPutMessageOptions pmo = new MQPutMessageOptions();
                // write text to MQ message
                msg.writeString(mwmh);

                try {
                    logger.info("---adding msg and pmo in mq, msg:"+msg+",pmo:"+pmo);
                    mqQueue.put(msg, pmo);
                    success = true;
                } catch (MQException e) { // NOSONAR
                    success = false;
                    if (getRetryLimit() <= 0) {
                        // log error if all retries have been attempted
                        logger.error("Failed to put message on queue", e);
                    }
                }
            } else {
                success = false;
                // don't retry as we only do this when the actual put fails
                retryLimit = 0;
            }
        } finally {
            closeMQConnections(mqQueue, mqConn);
        }
        
        if (!success && getRetryLimit() > 0) {
            // handle put message retry
            retryLimit--;
            success = putInMQ(mwmh, conn);
        }

        return success;
    }

    /**
     * Method for formatting MWMH
     * 
     * @return MWMH string
     */
    private String formatMWMH() {
        return StaffwareHelper.formatXMLTag("MWMH", StaffwareHelper.formatXMLTag("MWMH1",
                StaffwareHelper.formatXMLTag("MsgType", "REQUEST") + StaffwareHelper.formatXMLTag("Format", "SWIFT")
                        + StaffwareHelper.formatXMLTag("TransactionId", getTransactionId())
                        + StaffwareHelper.formatXMLTag("MsgId", getMessageId())
                        + StaffwareHelper.formatXMLTag("AccountingToken", ACCOUNTING_TOKEN)
                        + StaffwareHelper.formatXMLTag("SourceApplName", SOURCE_APPL_NAME)
                        + StaffwareHelper.formatXMLTag("SourceApplFunc", "")
                        + StaffwareHelper.formatXMLTag("SentDate", getSentDate())
                        + StaffwareHelper.formatXMLTag("TargetCountry", getTargetCountry())
                        + StaffwareHelper.formatXMLTag("ProjectId", PROJECT_ID)));
    }

    /**
     * Method for setting class properties
     * 
     * @param inputFields
     * @throws Exception
     */
    private void setClassProperties(List<?> inputFields) throws Exception { // NOSONAR
        for (Object inputField : inputFields) {
            Field field = (Field) inputField;
            String name = field.getName();
            String value = field.getValue();
            for (String mt : SwiftParams.SWIFT_MESSAGES) {
                if (fieldNameFound(name, mt) && isNotNullAndNotEmpty(value)) {
                    setSwiftMessage(TagHelper.squeezeValue(value.trim()));
                    setMessageType(mt.substring(SIX));
                    break;
                }
            }
            if (SwiftParams.SW_MAINCASE.equalsIgnoreCase(name)) {
                setSwMainCase(value);
            } else if (SwiftParams.SW_MAINPROC.equalsIgnoreCase(name)) {
                setSwMainProc(value);
            } else if (SwiftParams.MESSAGEID.equalsIgnoreCase(name)) {
                setMessageId(value);
            } else if (SwiftParams.STEPNAME.equalsIgnoreCase(name)) {
                setStepname(value);
            } else if (SwiftParams.COUNTRY.equalsIgnoreCase(name)) {
                setCountry(value);
            } else if ("LAST_AUTHORISER".equalsIgnoreCase(name)) {
                lastAuthoriser = value;
            }
        }
        setSentDate(StaffwareHelper.newSentDate());
        if ("202".equals(getMessageType()) && getSwiftMessage().contains("{103:")) {
            hasTag103 = true;
        }
    }

    private boolean isNotNullAndNotEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private boolean fieldNameFound(String name, String mt) {
        return mt.equalsIgnoreCase(name.trim());
    }

    /**
     * Method looks up the payment and collections status for MT103 and MT202
     * 
     * @return true if status = EXTRACTED
     * @throws SQLException if SQL connection fails
     */
    private Boolean skipFurtherProcessing() throws SQLException {
        logger.info("--Executing skipFurtherProcessing method with MessageType:"+getMessageType());
        if ("103".equals(getMessageType()) || "202".equals(getMessageType())) {
            String status = this.dataAccess.getPACStatus(getSwMainCase(), getSwMainProc());
            logger.info("--status value:"+status);
            if ("EXTRACTED".equalsIgnoreCase(status)) {
                return true;
            }
        }
        return false;
    }
}
