package com.barclays.staffware.plugin.dto;

import com.ibm.math.BigDecimal;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Encapsulates all of the data to do with a customer.
 * 
 * @author SHARPEP
 */
/*
 *
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 23Nov04  PAT01378   PRS    1a       Created.
 * ...   
 * 05Oct06             ILH    1a       Added gender, chargePackage, ratePackage,
 *                                        kycStatus, drivingLicenceNumber,
 *                                        residency, incomeTaxNumber,
 *                                        creditCheck*
 *                                     Removed Vetoable change
 * ...                                    
 * 09Nov07  PAT02281   AJWK   1z       Card & PIN (external): added
 *                                        `getAccount(...)'.
 * 06Apr11  R1M3	GoodlifW	WP354CR (Kamls1.3) Added prohibitedAccountStatus 
 * 										and isAddedToKamls
 * 03Jul13	WP616CMSE  PGJ	  2			WP616: Added preferredMethodOfContact 
 * 27DEC20	WP812	Priyanka  3         WP812: Added rtsReferenceNumber
 */
public class Customer implements Comparable<Customer>, java.io.Serializable
{
    private static final long serialVersionUID = -592562675343625512L;

    protected static class ContactComparator
        implements
            java.util.Comparator<Contact>,
            java.io.Serializable
    {
        /**
         * appease the serialisation gods
         */
        private static final long serialVersionUID = 9100502916006813322L;

        public int compare(Contact c1, Contact c2)
        {
            int r = (c1.isPrimary()?0:1) - (c2.isPrimary()?0:1);
            return (r != 0)
                    ? r
                    : c1.getSequenceNumber() - c2.getSequenceNumber();
        }
    }
    /**
     * Holds value of property country.
     */
    private String country;

    /**
     * Holds value of property customerNumber.
     */
    private int customerNumber=-1;

    /**
     * Holds value of property familyName.
     */
    private String familyName=null;

    /**
     * Holds value of property vatNumber.
     */
    private String vatNumber=null;

    /**
     * Holds value of property companyRegNo.
     */
    private String companyRegNo=null;

    /**
     * Holds value of property companyName.
     */
    private String companyName=null;

    /**
     * Holds value of property passportNumber.
     */
    private String passportNumber=null;

    /**
     * Holds value of property businessType.
     */
    private String businessType;

    /**
     * Holds value of property natureOfBusiness.
     */
    private String natureOfBusiness;

    /**
     * Holds value of property address.
     */
    private String[] address={null,null,null};

    /**
     * Holds value of property gcisId.
     */
    private String gcisId;

    /**
     * Holds value of property icaId.
     */
    private String icaId;

    /**
     * Holds value of property title.
     */
    private String title;

    /**
     * Holds value of property firstName.
     */
    private String firstName;

    /**
     * Holds value of property idCardNumber.
     */
    private String idCardNumber;

    /**
     * Holds value of property vatClassification
     */
    private String vatClassification;

    /**
     * Holds value of property statusDate.
     */
    private Date statusDate;

    /**
     * Holds value of property marketingOptOut.
     */
    private boolean marketingOptOut=false;

    /**
     * Holds value of property preferredMethodOfContact.
     */
    private String preferredMethodOfContact;

    private boolean internetBankingAccess = false;

    /**
     * Holds value of property accounts.
     */
    private final SortedSet<Account> accounts=new TreeSet<Account>();

    /**
     * Holds value of property propositionType.
     */
    private char propositionType;

    /**
     * Holds value of property relationshipNote.
     */
    private String relationshipNote=null;

    /**
     * Holds value of property businessEstablishedDate.
     */
    private Date businessEstablishedDate=null;

    /**
     * Holds value of property relationshipEstablishedDate.
     */
    private Date relationshipEstablishedDate=null;

    /**
     * Holds value of property marketSegment.
     */
    private String marketSegment=null;

    /**
     * Holds value of property referStream.
     */
    private int referStream;

    /**
     * Holds value of property status.
     */
    private String status = null;

    /**
     * Holds value of property referDescription.
     */
    private String referDescription = null;

    /**
     * Holds value of property displayName.
     */
    private String displayName;

    private Map<String, Card> cards = new HashMap<String, Card>();

    //WP261 stores ISO code of country for following 3 fields. we need now country name and code both.
    private String nationality;
    private String residency;
    private String countryOfRegistration;
    private String nationalityCode;
    private String residencyCode;
    private String countryOfRegistrationCode;

    private String gender;
    private String chargePackage;
    private String ratePackage;
    private String kycStatus;
    private String drivingLicenceNumber;
    private String incomeTaxNumber;
    private BigDecimal turnover;

    private String creditCheckResult;
    private String creditCheckReference;
    private Date creditCheckDate;

    /**
     * Holds value of property contacts
     */
    private final SortedSet<Contact> contacts = new TreeSet<Contact>(
            new ContactComparator());

    private String primaryAccountNumber;
    private BigDecimal unadvisedLimit;
    private String pepInd;

    private int[] relatedCustomerNumbers;

 // Version 261
    private String tradingName;
    private String nobAdditionalInfo;
    private String geographicalStatus;
    private String operatingStatus;
    private String solicitationChannel;
    private String initialDeposit;
    private String entityType;
    private String complexStructure;
    private String currentAccount;
    private String savingAccount;
    private String termDeposit;
    private String invMgmt;
    private String securedLoanOrFinancing;
    private String unsecuredLoanOrFinancing;
    private String tradePlanOrProducts;
    private String securedLoanCurrentFinance;
    private String[] relationships;
    private int[] shareholdings;
    private String[] inverseRelationships;
    private String riskScore;
    private String riskLevel;
    private String[] expectedTransToCountries;
    private String[] countriesOfOperations;
    private String[] countriesTradedWith;
    private String expectedCashVolume;

    private String prohibitedAccountStatus;
    private String isAddedToKamls;
    //WP812
    private String rtsReferenceNumber; 

	//WP812
    private boolean enableRiskBasedKYC;
    private String lastRefreshDate;
	private String nextRefreshDate;
    private String[] sourceOfIncome;
    private String[] sourceOfFunds;
    private String[] sourceOfWealth;
    private String highRiskIndustries;
    private String specialCustomerType;
    
    private String otherFundsTxt;
    private String otherWealthTxt;
    private String otherIncomeTxt;
	
	private String mEAACashDepositVolume;
    private String mEAACashDepositAmount;
    private String mEAACashWithdrawalVolume;
    private String mEAACashWithdrawalAmount;
    
    private String mEAAChequeDepositVolume;
    private String mEAAChequeDepositAmount;
    private String mEAAChequeWithdrawalVolume;
    private String mEAAChequeWithdrawalAmount;
    
    private String mEAAOtherInstrumentsDepositVolume;
    private String mEAAOtherInstrumentsDepositAmount;
    private String mEAAOtherInstrumentsWithdrawalVolume;
    private String mEAAOtherInstrumentsWithdrawalAmount;
    
    private String mEAAFundTransfersDepositVolume;
    private String mEAAFundTransfersDepositAmount;
    private String mEAAFundTransfersWithdrawalVolume;
    private String mEAAFundTransfersWithdrawalAmount;
    
    private String mEAATotalDepositVolume;
    private String mEAATotalDepositAmount;
    private String mEAATotalWithdrawalVolume;
    private String mEAATotalWithdrawalAmount;
    
    //WP812 : FATCA / CRS
    private String fCcountryOfTaxResidency;
    private String fCcountryISOTaxResidency;
    private String fCTin;
    private String fCGiin;
    private String fCreasonForNoTin;
    private String fCclassificationFatca;
    private String fCclassificationCrs;
    private String idCardExpiry;
    private boolean fatcaReportable;
    private boolean crsReportable;
    private List<String[]> controllingPersonsData;
    private String[] controllingPersonForeNameData;
    private String[] controllingPersonLastNameData;
    private String[] controllingPersonDobData;
    private String[] controllingPersonCityData;
    private String[] controllingPersonCountryOfAddressData;
    private String[] controllingPersonTaxIdNumberData;
    private String[] controllingPersonTaxIdCountryData;
    private String[] controllingPersonTypeData;
    private String controllingPersonsDataSize;
    //Detailed Products
    private String[] detailedProducts;
	

	public String[] getDetailedProducts() {
		return detailedProducts;
	}

	public void setDetailedProducts(Object[] detailedProducts) {
		if (detailedProducts == null || detailedProducts.length == 0) {
			this.detailedProducts = new String[] {};
		} else {
			String[] values = new String[detailedProducts.length];
			for (int i = 0; i < detailedProducts.length; ++i) {
				values[i] = String.valueOf(detailedProducts[i].toString());
			}
			this.detailedProducts = values;
		}
	}
	public String getLastRefreshDate() {
		return lastRefreshDate;
	}
	public void setLastRefreshDate(String lastRefreshDate) {
		this.lastRefreshDate = lastRefreshDate;
	}
	public String getNextRefreshDate() {
		return nextRefreshDate;
	}
	public void setNextRefreshDate(String nextRefreshDate) {
		this.nextRefreshDate = nextRefreshDate;
	}
	public String getControllingPersonsDataSize() {
		return controllingPersonsDataSize;
	}
	public void setControllingPersonsDataSize(String controllingPersonsDataSize) {
		this.controllingPersonsDataSize = controllingPersonsDataSize;
	}
	public String getHighRiskIndustries() {
		return highRiskIndustries;
	}
	public void setHighRiskIndustries(String highRiskIndustries) {
		this.highRiskIndustries = highRiskIndustries;
	}
	
	public String getSpecialCustomerType() {
		return specialCustomerType;
	}
	public void setSpecialCustomerType(String specialCustomerType) {
		this.specialCustomerType = specialCustomerType;
	}
	
	public String[] getSourceOfIncome() {
		return sourceOfIncome;
	}
	public void setSourceOfIncome(Object[] sourceOfIncome) {
		if(sourceOfIncome == null || sourceOfIncome.length == 0) {
            this.sourceOfIncome = new String[] {};
        } else {
        	String[] values = new String[sourceOfIncome.length];
            for(int i = 0; i < sourceOfIncome.length; ++i) {
                values[i] = String.valueOf(sourceOfIncome[i].toString());
            }
            this.sourceOfIncome = values;
        }
	}
	
	public String[] getSourceOfFunds() {
		return sourceOfFunds;
	}

	public void setSourceOfFunds(Object[] sourceOfFunds) {
		if(sourceOfFunds == null || sourceOfFunds.length == 0) {
            this.sourceOfFunds = new String[] {};
        } else {
        	String[] values = new String[sourceOfFunds.length];
            for(int i = 0; i < sourceOfFunds.length; ++i) {
                values[i] = String.valueOf(sourceOfFunds[i].toString());
            }
            this.sourceOfFunds = values;
        }
	}

	public String[] getSourceOfWealth() {
		return sourceOfWealth;
	}

	public void setSourceOfWealth(Object[] sourceOfWealth) {
		if(sourceOfWealth == null || sourceOfWealth.length == 0) {
            this.sourceOfWealth = new String[] {};
        } else {
        	String[] values = new String[sourceOfWealth.length];
            for(int i = 0; i < sourceOfWealth.length; ++i) {
                values[i] = String.valueOf(sourceOfWealth[i].toString());
            }
            this.sourceOfWealth = values;
        }
	}

   public String getmEAACashDepositVolume() {
		return mEAACashDepositVolume;
	}

	public void setmEAACashDepositVolume(String mEAACashDepositVolume) {
		this.mEAACashDepositVolume = mEAACashDepositVolume;
	}

	public String getmEAACashDepositAmount() {
		return mEAACashDepositAmount;
	}

	public void setmEAACashDepositAmount(String mEAACashDepositAmount) {
		this.mEAACashDepositAmount = mEAACashDepositAmount;
	}

	public String getmEAACashWithdrawalVolume() {
		return mEAACashWithdrawalVolume;
	}

	public void setmEAACashWithdrawalVolume(String mEAACashWithdrawalVolume) {
		this.mEAACashWithdrawalVolume = mEAACashWithdrawalVolume;
	}

	public String getmEAACashWithdrawalAmount() {
		return mEAACashWithdrawalAmount;
	}

	public void setmEAACashWithdrawalAmount(String mEAACashWithdrawalAmount) {
		this.mEAACashWithdrawalAmount = mEAACashWithdrawalAmount;
	}

	public String getmEAAChequeDepositVolume() {
		return mEAAChequeDepositVolume;
	}

	public void setmEAAChequeDepositVolume(String mEAAChequeDepositVolume) {
		this.mEAAChequeDepositVolume = mEAAChequeDepositVolume;
	}

	public String getmEAAChequeDepositAmount() {
		return mEAAChequeDepositAmount;
	}

	public void setmEAAChequeDepositAmount(String mEAAChequeDepositAmount) {
		this.mEAAChequeDepositAmount = mEAAChequeDepositAmount;
	}

	public String getmEAAChequeWithdrawalVolume() {
		return mEAAChequeWithdrawalVolume;
	}

	public void setmEAAChequeWithdrawalVolume(String mEAAChequeWithdrawalVolume) {
		this.mEAAChequeWithdrawalVolume = mEAAChequeWithdrawalVolume;
	}

	public String getmEAAChequeWithdrawalAmount() {
		return mEAAChequeWithdrawalAmount;
	}

	public void setmEAAChequeWithdrawalAmount(String mEAAChequeWithdrawalAmount) {
		this.mEAAChequeWithdrawalAmount = mEAAChequeWithdrawalAmount;
	}

	public String getmEAAOtherInstrumentsDepositVolume() {
		return mEAAOtherInstrumentsDepositVolume;
	}

	public void setmEAAOtherInstrumentsDepositVolume(String mEAAOtherInstrumentsDepositVolume) {
		this.mEAAOtherInstrumentsDepositVolume = mEAAOtherInstrumentsDepositVolume;
	}

	public String getmEAAOtherInstrumentsDepositAmount() {
		return mEAAOtherInstrumentsDepositAmount;
	}

	public void setmEAAOtherInstrumentsDepositAmount(String mEAAOtherInstrumentsDepositAmount) {
		this.mEAAOtherInstrumentsDepositAmount = mEAAOtherInstrumentsDepositAmount;
	}

	public String getmEAAOtherInstrumentsWithdrawalVolume() {
		return mEAAOtherInstrumentsWithdrawalVolume;
	}

	public void setmEAAOtherInstrumentsWithdrawalVolume(String mEAAOtherInstrumentsWithdrawalVolume) {
		this.mEAAOtherInstrumentsWithdrawalVolume = mEAAOtherInstrumentsWithdrawalVolume;
	}

	public String getmEAAOtherInstrumentsWithdrawalAmount() {
		return mEAAOtherInstrumentsWithdrawalAmount;
	}

	public void setmEAAOtherInstrumentsWithdrawalAmount(String mEAAOtherInstrumentsWithdrawalAmount) {
		this.mEAAOtherInstrumentsWithdrawalAmount = mEAAOtherInstrumentsWithdrawalAmount;
	}

	public String getmEAAFundTransfersDepositVolume() {
		return mEAAFundTransfersDepositVolume;
	}

	public void setmEAAFundTransfersDepositVolume(String mEAAFundTransfersDepositVolume) {
		this.mEAAFundTransfersDepositVolume = mEAAFundTransfersDepositVolume;
	}

	public String getmEAAFundTransfersDepositAmount() {
		return mEAAFundTransfersDepositAmount;
	}

	public void setmEAAFundTransfersDepositAmount(String mEAAFundTransfersDepositAmount) {
		this.mEAAFundTransfersDepositAmount = mEAAFundTransfersDepositAmount;
	}

	public String getmEAAFundTransfersWithdrawalVolume() {
		return mEAAFundTransfersWithdrawalVolume;
	}

	public void setmEAAFundTransfersWithdrawalVolume(String mEAAFundTransfersWithdrawalVolume) {
		this.mEAAFundTransfersWithdrawalVolume = mEAAFundTransfersWithdrawalVolume;
	}

	public String getmEAAFundTransfersWithdrawalAmount() {
		return mEAAFundTransfersWithdrawalAmount;
	}

	public void setmEAAFundTransfersWithdrawalAmount(String mEAAFundTransfersWithdrawalAmount) {
		this.mEAAFundTransfersWithdrawalAmount = mEAAFundTransfersWithdrawalAmount;
	}

	public String getmEAATotalDepositVolume() {
		return mEAATotalDepositVolume;
	}
	public void setmEAATotalDepositVolume(String mEAATotalDepositVolume) {
		this.mEAATotalDepositVolume = mEAATotalDepositVolume;
	}
	public String getmEAATotalDepositAmount() {
		return mEAATotalDepositAmount;
	}
	public void setmEAATotalDepositAmount(String mEAATotalDepositAmount) {
		this.mEAATotalDepositAmount = mEAATotalDepositAmount;
	}
	public String getmEAATotalWithdrawalVolume() {
		return mEAATotalWithdrawalVolume;
	}
	public void setmEAATotalWithdrawalVolume(String mEAATotalWithdrawalVolume) {
		this.mEAATotalWithdrawalVolume = mEAATotalWithdrawalVolume;
	}
	public String getmEAATotalWithdrawalAmount() {
		return mEAATotalWithdrawalAmount;
	}
	public void setmEAATotalWithdrawalAmount(String mEAATotalWithdrawalAmount) {
		this.mEAATotalWithdrawalAmount = mEAATotalWithdrawalAmount;
	}
	public String getOtherFundsTxt() {
		return otherFundsTxt;
	}

	public void setOtherFundsTxt(String otherFundsTxt) {
		this.otherFundsTxt = otherFundsTxt;
	}

	public String getOtherWealthTxt() {
		return otherWealthTxt;
	}

	public void setOtherWealthTxt(String otherWealthTxt) {
		this.otherWealthTxt = otherWealthTxt;
	}

	public String getOtherIncomeTxt() {
		return otherIncomeTxt;
	}

	public void setOtherIncomeTxt(String otherIncomeTxt) {
		this.otherIncomeTxt = otherIncomeTxt;
	}
	
	public String getfCcountryOfTaxResidency() {
		return fCcountryOfTaxResidency;
	}
	public void setfCcountryOfTaxResidency(String fCcountryOfTaxResidency) {
		this.fCcountryOfTaxResidency = fCcountryOfTaxResidency;
	}
	public String getfCcountryISOTaxResidency() {
		return fCcountryISOTaxResidency;
	}
	public void setfCcountryISOTaxResidency(String fCcountryISOTaxResidency) {
		this.fCcountryISOTaxResidency = fCcountryISOTaxResidency;
	}
	public String getfCTin() {
		return fCTin;
	}
	public void setfCTin(String fCTin) {
		this.fCTin = fCTin;
	}
	public String getfCGiin() {
		return fCGiin;
	}
	public void setfCGiin(String fCGiin) {
		this.fCGiin = fCGiin;
	}
	public String getfCreasonForNoTin() {
		return fCreasonForNoTin;
	}
	public void setfCreasonForNoTin(String fCreasonForNoTin) {
		this.fCreasonForNoTin = fCreasonForNoTin;
	}
	public String getfCclassificationFatca() {
		return fCclassificationFatca;
	}
	public void setfCclassificationFatca(String fCclassificationFatca) {
		this.fCclassificationFatca = fCclassificationFatca;
	}
	public String getfCclassificationCrs() {
		return fCclassificationCrs;
	}
	public void setfCclassificationCrs(String fCclassificationCrs) {
		this.fCclassificationCrs = fCclassificationCrs;
	}
	public String getIdCardExpiry() {
		return idCardExpiry;
	}
	public void setIdCardExpiry(String idCardExpiry) {
		this.idCardExpiry = idCardExpiry;
	}
	public boolean isFatcaReportable() {
		return fatcaReportable;
	}
	public void setFatcaReportable(boolean fatcaReportable) {
		this.fatcaReportable = fatcaReportable;
	}
	public boolean isCrsReportable() {
		return crsReportable;
	}
	public void setCrsReportable(boolean crsReportable) {
		this.crsReportable = crsReportable;
	}
	/** WP812 : RBA FATCA / CRS Changes
     *  Getter and Setters for controlling persons' data
     * @return
     */
    
    public String[] getControllingPersonForeNameData() {
		return controllingPersonForeNameData;
	}
    
    public void setControllingPersonForeNameData(Object[] controllingPersonForeNameData) {
		if(controllingPersonForeNameData == null || controllingPersonForeNameData.length == 0) {
            this.controllingPersonForeNameData = new String[] {};
        } else {
        	String[] values = new String[controllingPersonForeNameData.length];
            for(int i = 0; i < controllingPersonForeNameData.length; ++i) {
                values[i] = String.valueOf(controllingPersonForeNameData[i].toString());
            }
            this.controllingPersonForeNameData = values;
        }
	}

	public String[] getControllingPersonDobData() {
		return controllingPersonDobData;
	}
	public void setControllingPersonDobData(Object[] controllingPersonDobData) {
		if(controllingPersonDobData == null || controllingPersonDobData.length == 0) {
            this.controllingPersonDobData = new String[] {};
        } else {
        	String[] values = new String[controllingPersonDobData.length];
            for(int i = 0; i < controllingPersonDobData.length; ++i) {
                values[i] = String.valueOf(controllingPersonDobData[i].toString());
            }
            this.controllingPersonDobData = values;
        }
	}
	public String[] getControllingPersonCityData() {
		return controllingPersonCityData;
	}
	public void setControllingPersonCityData(Object[] controllingPersonCityData) {
		if(controllingPersonCityData == null || controllingPersonCityData.length == 0) {
            this.controllingPersonCityData = new String[] {};
        } else {
        	String[] values = new String[controllingPersonCityData.length];
            for(int i = 0; i < controllingPersonCityData.length; ++i) {
                values[i] = String.valueOf(controllingPersonCityData[i].toString());
            }
            this.controllingPersonCityData = values;
        }
	}
	public String[] getControllingPersonCountryOfAddressData() {
		return controllingPersonCountryOfAddressData;
	}
	public void setControllingPersonCountryOfAddressData(Object[] controllingPersonCountryOfAddressData) {
		if(controllingPersonCountryOfAddressData == null || controllingPersonCountryOfAddressData.length == 0) {
            this.controllingPersonCountryOfAddressData = new String[] {};
        } else {
        	String[] values = new String[controllingPersonCountryOfAddressData.length];
            for(int i = 0; i < controllingPersonCountryOfAddressData.length; ++i) {
                values[i] = String.valueOf(controllingPersonCountryOfAddressData[i].toString());
            }
            this.controllingPersonCountryOfAddressData = values;
        }
	}
	public String[] getControllingPersonTaxIdNumberData() {
		return controllingPersonTaxIdNumberData;
	}
	public void setControllingPersonTaxIdNumberData(Object[] controllingPersonTaxIdNumberData) {
		if(controllingPersonTaxIdNumberData == null || controllingPersonTaxIdNumberData.length == 0) {
            this.controllingPersonTaxIdNumberData = new String[] {};
        } else {
        	String[] values = new String[controllingPersonTaxIdNumberData.length];
            for(int i = 0; i < controllingPersonTaxIdNumberData.length; ++i) {
                values[i] = String.valueOf(controllingPersonTaxIdNumberData[i].toString());
            }
            this.controllingPersonTaxIdNumberData = values;
        }
	}
	public String[] getControllingPersonTaxIdCountryData() {
		return controllingPersonTaxIdCountryData;
	}
	public void setControllingPersonTaxIdCountryData(Object[] controllingPersonTaxIdCountryData) {
		if(controllingPersonTaxIdCountryData == null || controllingPersonTaxIdCountryData.length == 0) {
            this.controllingPersonTaxIdCountryData = new String[] {};
        } else {
        	String[] values = new String[controllingPersonTaxIdCountryData.length];
            for(int i = 0; i < controllingPersonTaxIdCountryData.length; ++i) {
                values[i] = String.valueOf(controllingPersonTaxIdCountryData[i].toString());
            }
            this.controllingPersonTaxIdCountryData = values;
        }
	}
	public String[] getControllingPersonTypeData() {
		return controllingPersonTypeData;
	}
	public void setControllingPersonTypeData(Object[] controllingPersonTypeData) {
		if(controllingPersonTypeData == null || controllingPersonTypeData.length == 0) {
            this.controllingPersonTypeData = new String[] {};
        } else {
        	String[] values = new String[controllingPersonTypeData.length];
            for(int i = 0; i < controllingPersonTypeData.length; ++i) {
                values[i] = String.valueOf(controllingPersonTypeData[i].toString());
            }
            this.controllingPersonTypeData = values;
        }
	}

	public String[] getControllingPersonLastNameData() {
		return controllingPersonLastNameData;
	}

	public void setControllingPersonLastNameData(Object[] controllingPersonLastNameData) {
		if(controllingPersonLastNameData == null || controllingPersonLastNameData.length == 0) {
            this.controllingPersonLastNameData = new String[] {};
        } else {
        	String[] values = new String[controllingPersonLastNameData.length];
            for(int i = 0; i < controllingPersonLastNameData.length; ++i) {
                values[i] = String.valueOf(controllingPersonLastNameData[i].toString());
            }
            this.controllingPersonLastNameData = values;
        }
	}

	public List<String[]> getControllingPersonsData() {
		return controllingPersonsData;
	}
	public void setControllingPersonsData(List<String[]> controllingPersonsData) {
		this.controllingPersonsData = controllingPersonsData;
	}

    public String getRtsReferenceNumber() {
		return rtsReferenceNumber;
	}
	public void setRtsReferenceNumber(String rtsReferenceNumber) {
		this.rtsReferenceNumber = rtsReferenceNumber;
	}
	public String getIsAddedToKamls() {
		return isAddedToKamls;
	}
	public void setIsAddedToKamls(String isAddedToKamls) {
		this.isAddedToKamls = isAddedToKamls;
	}
	public String getProhibitedAccountStatus() {
		return prohibitedAccountStatus;
	}
	public void setProhibitedAccountStatus(String prohibitedAccountStatus) {
		this.prohibitedAccountStatus = prohibitedAccountStatus;
	}

	public String getRiskScore() {
		return riskScore;
	}
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	public String getRiskLevel() {
		return riskLevel;
	}
	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}
	/** Creates a new instance of CustomerBean */
    public Customer() {
        super();
        this.setStatus("NEW");
    }
    /** Creates a new instance of CustomerBean */
    public Customer(String country, int customerNumber) {
        super();
        this.setStatus("NEW");
        this.setCustomerNumber(customerNumber);
        this.setCountry(country);
    }

    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.<p>
     *
     */
    public int compareTo(Customer o) {
        return new Integer(this.getCustomerNumber()).compareTo(Integer.valueOf(o.getCustomerNumber()));
    }


    /**
     * Getter for property country.
     * @return Value of property country.
     */
    public String getCountry() {
        return this.country;
    }

    /**
     * Setter for property country.
     * @param country New value of property country.
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Getter for property customerNumber.
     * @return Value of property customerNumber.
     */
    public int getCustomerNumber() {
        return this.customerNumber;
    }

    /**
     * Setter for property customerNumber.
     * @param customerNumber New value of property customerNumber.
     */
    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }

    /**
     * Getter for property familyName.
     * @return Value of property familyName.
     */
    public String getFamilyName() {
        return this.familyName;
    }

    /**
     * Setter for property familyName.
     * @param familyName New value of property familyName.
     */
    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    /**
     * Getter for property vatNumber.
     * @return Value of property vatNumber.
     */
    public String getVatNumber() {
        return this.vatNumber;
    }

    /**
     * Setter for property vatNumber.
     * @param vatNumber New value of property vatNumber.
     */
    public void setVatNumber(String vatNumber) {
        this.vatNumber = vatNumber;
    }

    /**
     * Getter for property companyRegNo.
     * @return Value of property companyRegNo.
     */
    public String getCompanyRegNo() {
        return this.companyRegNo;
    }

    /**
     * Setter for property companyRegNo.
     * @param companyRegNo New value of property companyRegNo.
     */
    public void setCompanyRegNo(String companyRegNo) {
        this.companyRegNo = companyRegNo;
    }

    /**
     * Getter for property companyName.
     * @return Value of property companyName.
     */
    public String getCompanyName() {
        return this.companyName;
    }

    /**
     * Setter for property companyName.
     * @param companyName New value of property companyName.
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     * Getter for property passport.
     * @return Value of property passport.
     */
    public String getPassportNumber() {
        return this.passportNumber;
    }

    /**
     * Setter for property passport.
     * @param passportNumber New value of property passport.
     */
    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    /**
     * Getter for property businessType.
     * @return Value of property businessType.
     */
    public String getBusinessType() {
        return this.businessType;
    }

    /**
     * Setter for property businessType.
     * @param businessType New value of property businessType.
     */
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    /**
     * Getter for property natureOfBusiness.
     * @return Value of property natureOfBusiness.
     */
    public String getNatureOfBusiness() {
        return this.natureOfBusiness;
    }

    /**
     * Setter for property natureOfBusiness.
     * @param natureOfBusiness New value of property natureOfBusiness.
     */
    public void setNatureOfBusiness(String natureOfBusiness) {
        this.natureOfBusiness = natureOfBusiness;
    }

    /**
     * Indexed getter for property address.
     * @param index Index of the property.
     * @return Value of the property at <CODE>index</CODE>.
     */
    public String getAddress(int index) {
        if(index<0 || index>=this.address.length) return null;
        return this.address[index-1];
    }

    /**
     * Indexed getter for property address.
     * @return Value of the property at <CODE>0</CODE>.
     */
    public String getAddress() {
        return this.address[0];
    }

    /**
     * Indexed setter for property address.
     * @param index Index of the property.
     * @param address New value of the property at <CODE>index</CODE>.
     *
     * @throws IndexOutOfBoundsException If the index supplied is outside that allowed
     */
    public void setAddress(int index, String address) throws IndexOutOfBoundsException {
        if(index<0 || index>=this.address.length) throw new IndexOutOfBoundsException("index should be between 1 and "+this.address.length+" inclusive");
        this.address[index] = address;
    }

    /**
     * Getter for property gcisId.
     * @return Value of property gcisId.
     */
    public String getGcisId() {
        return this.gcisId;
    }

    /**
     * Setter for property gcisId.
     * @param gcisId New value of property gcisId.
     */
    public void setGcisId(String gcisId) {
        this.gcisId = gcisId;
    }

    /**
     * Getter for property icaId.
     * @return Value of property icaId.
     */
    public String getIcaId() {
        return this.icaId;
    }

    /**
     * Setter for property icaId.
     * @param icaId New value of property icaId.
     */
    public void setIcaId(String icaId) {
        this.icaId = icaId;
    }

    /**
     * Getter for property title.
     * @return Value of property title.
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * Setter for property title.
     * @param title New value of property title.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Getter for property firstName.
     * @return Value of property firstName.
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     * Setter for property firstName.
     * @param firstName New value of property firstName.
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Getter for property idCard.
     * @return Value of property idCard.
     */
    public String getIdCardNumber() {
        return this.idCardNumber;
    }

    /**
     * Setter for property idCard.
     * @param idCardNumber New value of property idCard.
     */
    public void setIdCardNumber(String idCardNumber) {
        this.idCardNumber = idCardNumber;
    }

    /**
     * Getter for property vatClassification.
     * @return Value of property vatClassification.
     */
    public String getVatClassification() {
        return this.vatClassification;
    }

    /**
     * Setter for property vatClassification.
     * @param vatClassification New value of property vatClassification.
     */
    public void setVatClassification(String vatClassification) {
        this.vatClassification = vatClassification;
    }

    /**
     * Getter for property statusDate.
     * @return Value of property statusDate.
     */
    public Date getStatusDate() {
        return this.statusDate;
    }

    /**
     * Setter for property statusDate.
     * @param statusDate New value of property statusDate.
     */
    public void setStatusDate(Date statusDate) {
        this.statusDate = statusDate;
    }
    
    /**
     * Getter for property marketingOptOut.
     * @return Value of property marketingOptOut.
     */
    public boolean isMarketingOptOut() {
        return this.marketingOptOut;
    }
    
    /**
     * Setter for property marketingOptOut.
     * @param marketingOptOut New value of property marketingOptOut.
     */
    public void setMarketingOptOut(boolean marketingOptOut) {
        this.marketingOptOut = marketingOptOut;
    }
    
    /**
     * Getter for property preferredMethodOfContact.
     * @return Value of property preferredMethodOfContact.
     */
    public String getPreferredMethodOfContact() {
    	return preferredMethodOfContact;
    }
    
    /**
     * Setter for property preferredMethodOfContact.
     * @param preferredMethodOfContact New value of property preferredMethodOfContact.
     */
    public void setPreferredMethodOfContact(String preferredMethodOfContact) {
    	this.preferredMethodOfContact = preferredMethodOfContact;
    }
    
    /**
     * Allows an account to be added to a customer.  This will also set the customer property
     * on the account to point to the customer.  If the account is already attached to the
     * customer, the function will return with no error.
     * @param account
     */
    public void addAccount(final Account account)
    {
        if(this.accounts.contains(account)) return;
        this.accounts.add(account);
        account.setCustomer(this);
    }
    
    public void addContact(final Contact contact) {
        if(this.contacts.contains(contact)) return;
        this.contacts.add(contact);
        contact.setCustomer(this);
    }
    public SortedSet<Contact> getContacts() {
        return this.contacts;
    }
        
    /**
     * @param account
     */
    public boolean removeAccount(final Account account)
    {
        if(this.accounts.remove(account)) {
            account.setCustomer(null);
            return true;
        }
        return false;
    }
    
    public SortedSet<Account> getAccounts() {
        return this.accounts;
    }
    
    /**
     * The specified account, or <code>null</code> if it is not associated
     * with this customer.
     */
    public Account getAccount(
        String fullAccountNumber)
    {
        Account result = null;
        for (Iterator<Account> i = accounts.iterator(); i.hasNext() && result == null; )
        {
            Account account = i.next();
            if (account.getFullAccountNumber().equals(fullAccountNumber))
            {
                result = account;
            }
        }
        return result;
    }
    
    /**
     * Getter for property propositionType.
     * @return Value of property propositionType.
     */
    public char getPropositionType() {
        return this.propositionType;
    }
    
    /**
     * Setter for property propositionType.
     * @param propositionType New value of property propositionType.
     *
     * @throws Exception if the character is not L, C, S or P
     */
    public void setPropositionType(char propositionType) throws Exception {
        if (propositionType != 'C' && propositionType != 'L' &&
                propositionType != 'S' && propositionType != 'P') {
            throw new Exception ("PropositionType must be L, C, S or P");
        }
        this.propositionType = propositionType;
    }
    
    /**
     * Getter for property relationshipNote.
     * @return Value of property relationshipNote.
     */
    public String getRelationshipNote() {
        return this.relationshipNote;
    }
    
    /**
     * Setter for property relationshipNote.
     * @param relationshipNote New value of property relationshipNote.
     */
    public void setRelationshipNote(String relationshipNote) {
        this.relationshipNote = relationshipNote;
    }
    
    /**
     * Getter for property businessEstablishedDate.
     * @return Value of property businessEstablishedDate.
     */
    public Date getBusinessEstablishedDate() {
        return this.businessEstablishedDate;
    }
    
    /**
     * Setter for property businessEstablishedDate.
     * @param businessEstablishedDate New value of property businessEstablishedDate.
     */
    public void setBusinessEstablishedDate(Date businessEstablishedDate) {
        this.businessEstablishedDate = businessEstablishedDate;
    }
    
    /**
     * Getter for property relationshipEstablishedDate.
     * @return Value of property relationshipEstablishedDate.
     */
    public Date getRelationshipEstablishedDate() {
        return this.relationshipEstablishedDate;
    }
    
    /**
     * Setter for property relationshipEstablishedDate.
     * @param relationshipEstablishedDate New value of property relationshipEstablishedDate.
     */
    public void setRelationshipEstablishedDate(Date relationshipEstablishedDate) {
        this.relationshipEstablishedDate = relationshipEstablishedDate;
    }
    
    /**
     * Getter for property marketSegment.
     * @return Value of property marketSegment.
     */
    public String getMarketSegment() {
        return this.marketSegment;
    }
    
    /**
     * Setter for property marketSegment.
     * @param marketSegment New value of property marketSegment.
     */
    public void setMarketSegment(String marketSegment) {
        this.marketSegment = marketSegment;
    }
    
    /**
     * Getter for property referStream.
     * @return Value of property referStream.
     */
    public int getReferStream() {
        return this.referStream;
    }
    
    /**
     * Setter for property referStream.
     * @param referStream New value of property referStream.
     */
    public void setReferStream(int referStream) {
        this.referStream = referStream;
    }
    
    /**
     * Getter for property status.
     * @return Value of property status.
     */
    public String getStatus() {
        return this.status;
    }
    
    /**
     * Setter for property status.
     * @param status New value of property status.
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
    /**
     * Getter for property referDescription.
     * @return Value of property referDescription.
     */
    public String getReferDescription() {
        return this.referDescription;
    }
    
    /**
     * Setter for property referDescription.
     * @param referDescription New value of property referDescription.
     */
    public void setReferDescription(String referDescription) {
        this.referDescription = referDescription;
    }
    
    /**
     * <p>Primary account number.</p>
     * <p>A three digit branch number followed by a seven digit account number.
     * The two values are separated by a single space.</p>
     */
    public String getPrimaryAccountNumber()
    {
        return primaryAccountNumber;
    }
    
    public void setPrimaryAccountNumber(
        String value)
    {
        if (value != null && !value.matches("\\d{3} \\d{7}"))
            throw new IllegalArgumentException();
        primaryAccountNumber = value;
    }
    
    /**
     * Unadvised limit.
     */
    public BigDecimal getUnadvisedLimit()
    {
        return unadvisedLimit;
    }
    
    /**
     * Set the unadvised limit.
     */
    public void setUnadvisedLimit(
        BigDecimal value)
    {
        unadvisedLimit = value;
    }
    
    /**
     * The primary account.<p>
     * 
     * Only available if the customer has a primary account number and it
     * corresponds to an account listed in the <tt>accounts</tt> property.
     * Otherwise <tt>null</tt>.
     */
    public Account getPrimaryAccount()
    {
        Account result = null;
        if (primaryAccountNumber != null) {
            int branch = Integer.parseInt(primaryAccountNumber.substring(0, 3));
            int account = Integer.parseInt(primaryAccountNumber.substring(4));
            
            for (
                    Iterator<Account> i = accounts.iterator();
                    result == null && i.hasNext(); ) 
            {
                Account a = i.next();
                if (a.getBranchNumber() == branch 
                        && a.getAccountNumber() == account)
                    result = a;
            }
        }
        return result;
    }
    
    // TO DO get proper method from Phil
    public int getNumberOfAccounts() {
        return accounts.size();
    }
    
    /**
     * Getter for property displayName.
     * @return Value of property displayName.
     */
    public String getDisplayName() {
        return this.displayName;
    }
    
    /**
     * Setter for property displayName.
     * @param displayName New value of property displayName.
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    /**
     * Getter for customers cards Hash Map
     * Hold details of cards owned by this customer
     */
    public Map<String, Card> getCards() {
        return cards;
    }
    
    public String getNationality() {
        return nationality;
    }
    public void setNationality(String nationality) {
        this.nationality = nationality;
    }
    /**
     * @return Returns the gender.
     */
    public String getGender() {
        return gender;
    }
    /**
     * @param gender The gender to set. Valid values are "M" and "F"
     */
    public void setGender(String gender) {
        this.gender = gender;
    }
    /**
     * @return Returns the chargePackage.
     */
    public String getChargePackage() {
        return chargePackage;
    }
    /**
     * @param chargePackage The chargePackage to set.
     */
    public void setChargePackage(String chargePackage) {
        this.chargePackage = chargePackage;
    }
    /**
     * @return Returns the ratePackage.
     */
    public String getRatePackage() {
        return ratePackage;
    }
    /**
     * @param ratePackage The ratePackage to set.
     */
    public void setRatePackage(String ratePackage) {
        this.ratePackage = ratePackage;
    }
    /**
     * @return Returns the kycStatus.
     */
    public String getKycStatus() {
        return kycStatus;
    }
    /**
     * @param kycStatus The kycStatus to set.
     */
    public void setKycStatus(String kycStatus) {
        this.kycStatus = kycStatus;
    }
    /**
     * @return Returns the drivingLicenceNumber.
     */
    public String getDrivingLicenceNumber() {
        return drivingLicenceNumber;
    }
    /**
     * @param drivingLicenceNumber The drivingLicenceNumber to set.
     */
    public void setDrivingLicenceNumber(String drivingLicenceNumber) {
        this.drivingLicenceNumber = drivingLicenceNumber;
    }
    /**
     * @return Returns the residency.
     */
    public String getResidency() {
        return residency;
    }
    /**
     * @param residency The residency to set.
     */
    public void setResidency(String residency) {
        this.residency = residency;
    }
    /**
     * @return Returns the incomeTaxNumber.
     */
    public String getIncomeTaxNumber() {
        return incomeTaxNumber;
    }
    /**
     * @param incomeTaxNumber The incomeTaxNumber to set.
     */
    public void setIncomeTaxNumber(String incomeTaxNumber) {
        this.incomeTaxNumber = incomeTaxNumber;
    }
    /**
     * @return Returns the creditCheckDate.
     */
    public Date getCreditCheckDate() {
        return creditCheckDate;
    }
    /**
     * @param creditCheckDate The creditCheckDate to set.
     */
    public void setCreditCheckDate(Date creditCheckDate) {
        this.creditCheckDate = creditCheckDate;
    }
    /**
     * @return Returns the creditCheckReference.
     */
    public String getCreditCheckReference() {
        return creditCheckReference;
    }
    /**
     * @param creditCheckReference The creditCheckReference to set.
     */
    public void setCreditCheckReference(String creditCheckReference) {
        this.creditCheckReference = creditCheckReference;
    }
    /**
     * @return Returns the creditCheckResult.
     */
    public String getCreditCheckResult() {
        return creditCheckResult;
    }
    /**
     * @param creditCheckResult The creditCheckResult to set.
     */
    public void setCreditCheckResult(String creditCheckResult) {
        this.creditCheckResult = creditCheckResult;
    }
    /**
     * @return the turnover
     */
    public BigDecimal getTurnover() {
        return turnover;
    }
    /**
     * @param turnover the turnover to set
     */
    public void setTurnover(BigDecimal turnover) {
        this.turnover = turnover;
    }
    /**
     * @return the internetBankingAccess
     */
    public boolean isInternetBankingAccess() {
        return internetBankingAccess;
    }
    /**
     * @param internetBankingAccess the internetBankingAccess to set
     */
    public void setInternetBankingAccess(boolean internetBankingAccess) {
        this.internetBankingAccess = internetBankingAccess;
    }
    /**
     * @return the countryOfRegistration
     */
    public String getCountryOfRegistration() {
        return countryOfRegistration;
    }
    /**
     * @param countryOfRegistration the countryOfRegistration to set
     */
    public void setCountryOfRegistration(String countryOfRegistration) {
        this.countryOfRegistration = countryOfRegistration;
    }
    
    /**
     * @return the PepIndicator
     */
    public String getPepInd() {
        return pepInd;
    }
    /**
     * @param pepInd the PepIndicator to set
     */
    public void setPepInd(String pepInd) {
        this.pepInd = pepInd;
    }
    
    /**
     * Gets the customer numbers of related customers
     * @return
     */
    public int[] getRelatedCustomerNumbers() {
        return this.relatedCustomerNumbers;
    }
    
    /**
     * Sets the customer numbers of related customers
     * @param relatedCustomerNumbers
     */
    public void setRelatedCustomerNumbers(int[] relatedCustomerNumbers) {
        this.relatedCustomerNumbers = relatedCustomerNumbers;
    }
    
    /**
     * Sets the customer numbers of related customers
     * @param relatedCustomerNumbers
     */
    public void setRelatedCustomerNumbers(Object[] relatedCustomerNumbers) {
        if(relatedCustomerNumbers == null || relatedCustomerNumbers.length == 0) {
            this.relatedCustomerNumbers = new int[] {};
        } else {
            int[] values = new int[relatedCustomerNumbers.length];
            for(int i = 0; i < relatedCustomerNumbers.length; ++i) {
                values[i] = Integer.parseInt(relatedCustomerNumbers[i].toString());
            }
            this.relatedCustomerNumbers = values;
        }
    }
	public String getTradingName() {
		return tradingName;
	}
	public void setTradingName(String tradingName) {
		this.tradingName = tradingName;
	}
	public String getNobAdditionalInfo() {
		return nobAdditionalInfo;
	}
	public void setNobAdditionalInfo(String nobAdditionalInfo) {
		this.nobAdditionalInfo = nobAdditionalInfo;
	}
	public String getGeographicalStatus() {
		return geographicalStatus;
	}
	public void setGeographicalStatus(String geographicalStatus) {
		this.geographicalStatus = geographicalStatus;
	}
	public String getOperatingStatus() {
		return operatingStatus;
	}
	public void setOperatingStatus(String operatingStatus) {
		this.operatingStatus = operatingStatus;
	}
	public String getSolicitationChannel() {
		return solicitationChannel;
	}
	public void setSolicitationChannel(String solicitationChannel) {
		this.solicitationChannel = solicitationChannel;
	}
	public String getInitialDeposit() {
		return initialDeposit;
	}
	public void setInitialDeposit(String initialDeposit) {
		this.initialDeposit = initialDeposit;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getComplexStructure() {
		return complexStructure;
	}
	public void setComplexStructure(String complexStructure) {
		this.complexStructure = complexStructure;
	}
	public String getCurrentAccount() {
		return currentAccount;
	}
	public void setCurrentAccount(String currentAccount) {
		this.currentAccount = currentAccount;
	}
	public String getSavingAccount() {
		return savingAccount;
	}
	public void setSavingAccount(String savingAccount) {
		this.savingAccount = savingAccount;
	}
	public String getTermDeposit() {
		return termDeposit;
	}
	public void setTermDeposit(String termDeposit) {
		this.termDeposit = termDeposit;
	}
	public String getInvMgmt() {
		return invMgmt;
	}
	public void setInvMgmt(String invMgmt) {
		this.invMgmt = invMgmt;
	}
	public String getSecuredLoanOrFinancing() {
		return securedLoanOrFinancing;
	}
	public void setSecuredLoanOrFinancing(String securedLoanOrFinancing) {
		this.securedLoanOrFinancing = securedLoanOrFinancing;
	}
	public String getUnsecuredLoanOrFinancing() {
		return unsecuredLoanOrFinancing;
	}
	public void setUnsecuredLoanOrFinancing(String unsecuredLoanOrFinancing) {
		this.unsecuredLoanOrFinancing = unsecuredLoanOrFinancing;
	}
	public String getTradePlanOrProducts() {
		return tradePlanOrProducts;
	}
	public void setTradePlanOrProducts(String tradePlanOrProducts) {
		this.tradePlanOrProducts = tradePlanOrProducts;
	}
	public String getSecuredLoanCurrentFinance() {
		return securedLoanCurrentFinance;
	}
	public void setSecuredLoanCurrentFinance(String securedLoanCurrentFinance) {
		this.securedLoanCurrentFinance = securedLoanCurrentFinance;
	}
	public String[] getRelationships() {
		return relationships;
	}
	public void setRelationships(Object[] relationship) {
		if(relationship == null || relationship.length == 0) {
            this.relationships = new String[] {};
        } else {
        	String[] values = new String[relationship.length];
            for(int i = 0; i < relationship.length; ++i) {
                values[i] = String.valueOf(relationship[i].toString());
            }
            this.relationships = values;
        }
	}
	public int[] getShareholdings() {
		return shareholdings;
	}
	public void setShareholdings(Object[] shareholding) {
		if(shareholding == null || shareholding.length == 0) {
            this.shareholdings = new int[] {};
        } else {
            int[] values = new int[shareholding.length];
            for(int i = 0; i < shareholding.length; ++i) {
                values[i] = Integer.parseInt(shareholding[i].toString());
            }
            this.shareholdings = values;
        }
	}
	
	public String[] getInverseRelationships() {
		return inverseRelationships;
	}
	public void setInverseRelationships(Object[] inverseRelationship) {
		if(inverseRelationship == null || inverseRelationship.length == 0) {
            this.inverseRelationships = new String[] {};
        } else {
        	String[] values = new String[inverseRelationship.length];
            for(int i = 0; i < inverseRelationship.length; ++i) {
                values[i] = String.valueOf(inverseRelationship[i].toString());
            }
            this.inverseRelationships = values;
        }
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public void setAddress(String[] address) {
		this.address = address;
	}
	public void setCards(Map<String, Card> cards) {
		this.cards = cards;
	}
	public String[] getExpectedTransToCountries() {
		return expectedTransToCountries;
	}
	public void setExpectedTransToCountries(Object[] expectedTransToCountries) {
		if(expectedTransToCountries == null || expectedTransToCountries.length == 0) {
            this.expectedTransToCountries = new String[] {};
        } else {
        	String[] values = new String[expectedTransToCountries.length];
            for(int i = 0; i < expectedTransToCountries.length; ++i) {
                values[i] = String.valueOf(expectedTransToCountries[i].toString());
            }
            this.expectedTransToCountries = values;
        }
	}
    
	public String[] getCountriesOfOperations() {
		return countriesOfOperations;
	}
	public void setCountriesOfOperations(Object[] countriesOfOperations) {
		if(countriesOfOperations == null || countriesOfOperations.length == 0) {
            this.countriesOfOperations = new String[] {};
        } else {
        	String[] values = new String[countriesOfOperations.length];
            for(int i = 0; i < countriesOfOperations.length; ++i) {
                values[i] = String.valueOf(countriesOfOperations[i].toString());
            }
            this.countriesOfOperations = values;
        }
	}
	
	public String[] getCountriesTradedWith() {
		return countriesTradedWith;
	}
	public void setCountriesTradedWith(Object[] countriesTradedWith) {
		if(countriesTradedWith == null || countriesTradedWith.length == 0) {
            this.countriesTradedWith = new String[] {};
        } else {
        	String[] values = new String[countriesTradedWith.length];
            for(int i = 0; i < countriesTradedWith.length; ++i) {
                values[i] = String.valueOf(countriesTradedWith[i].toString());
            }
            this.countriesTradedWith = values;
        }
	}
	public String getNationalityCode() {
		return nationalityCode;
	}
	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}
	public String getResidencyCode() {
		return residencyCode;
	}
	public void setResidencyCode(String residencyCode) {
		this.residencyCode = residencyCode;
	}
	public String getCountryOfRegistrationCode() {
		return countryOfRegistrationCode;
	}
	public void setCountryOfRegistrationCode(String countryOfRegistrationCode) {
		this.countryOfRegistrationCode = countryOfRegistrationCode;
	}
	public String getExpectedCashVolume() {
		return expectedCashVolume;
	}
	public void setExpectedCashVolume(String expectedCashVolume) {
		this.expectedCashVolume = expectedCashVolume;
	}	
	  
	public boolean isEnableRiskBasedKYC() {
			return enableRiskBasedKYC;
		}

	public void setEnableRiskBasedKYC(boolean enableRiskBasedKYC) {
			this.enableRiskBasedKYC = enableRiskBasedKYC;
		}
	
    /**
     * 
     * @param contacts
     * @return
     */
    public static SortedSet<Contact> getSortedContactList(Contact[] contacts) {
    	SortedSet<Contact> retVal = new TreeSet<Contact>(new ContactComparator());
    	for (Contact c : contacts) {
    		retVal.add(c);
    	}
    	return retVal;
    }
}