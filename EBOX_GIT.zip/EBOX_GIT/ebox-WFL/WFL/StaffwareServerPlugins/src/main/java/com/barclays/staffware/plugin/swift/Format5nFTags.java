package com.barclays.staffware.plugin.swift;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TagHelper;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * This EAI Java plugin formats SWIFT tags 50F and 59F for 101, 202, 103 and
 * 202COV swift messages.
 * 
 * @author Yogesh
 */
/*
 * DATE 	REFERENCE   	WHO 	VERSION COMMENTS 
 * ------- --------- 		--- 	------- ------------------------------
 * 04Aug15  WP695			Yogesh  1.0 	Created.
 * 18Sep15  WP695			Yogesh	1.1		Added formatting of Tag50F
 * 14Jun16	EBXWORKLOG-114  Yogesh  1.2     Using ORDERING_ACC staffware field to populate tag 50F
 * 											instead of ORIG_BRANCH + ORIG_ACC.
 */

public class Format5nFTags implements ImmediateReleasePluginSDK {
	
	private static final LoggerConnection logger = new LoggerConnection(
			Format5nFTags.class);

	private final String initializationFailed = 
			SwiftParams.initializationFailed(Format5nFTags.class.getName());
	
	private static final String TAG_VALIDATION_FAILED = "Invalid tag values for 50F/59F options.";

	private static final String TAG_VALIDATION_SUCCESSFUL = "Successfully validated 50F/59F options.";
	
	private static final String MSG_TYPE_103 = "103";
	
	private static final String SWIFT_X_CHARACTER_SET = "[^\\w\\ \\/\\-\\?\\:\\(\\)\\.\\,\\'\\+]";
	

	private static final String VALID_SWIFT_CHARACTER_SET = "[^\\w\\ \\/\\-\\?\\:\\(\\)\\.\\,\\'\\+]";
	private static final String PATTERN_33_CHARACTERS = "^.{1,33}$";
	
	private static final String PATTERN_34_CHARACTERS = "^.{1,34}$";
	
	/**
	 * Method is called by Staffware before each execute (unless a caching
	 * option is selected in Staffware
	 * 
	 * @param properties
	 * 			contents of eaijava properties file in 
	 * 			root:/swserver/sw_africa/eaijava
	 */
	@Override
	public void initialize(Properties properties)
			throws FatalPluginException,
			NonFatalPluginException {
		try {
			//DataSourceDirectory.getInstance().configure(properties);
			//LoggerConnection.configureWFL(properties.getProperty("swiftFormMsgLog"));
			// Modified By ashish
			ClassPathResource resource = new ClassPathResource(properties.getProperty("swiftFormMsgLog"));
			LoggerContext context = (LoggerContext) LogManager.getContext(false);
			context.setConfigLocation(resource.getURI());

			DataSourceDirectory.getInstance().basePluginDS();
			//Class.forName(properties.getProperty("db_driver"));
			logger.debug(this.getClass().toString() + "test log write!");
		} catch (Exception e) {
			logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
			}
		}

	/**
	 * Method Staffware calls in eaijava step FORMTAGS for formatting 50# and
	 * 59# Tags in Swift message
	 * 
	 * @param staticData
	 * 			a string hardcoded in Staffware, message type like '103' or 
	 * 			'202' will be passed
	 * @param outputFields
	 * 			a list of Staffware field objects which Staffware expects to 
	 * 			be returned
	 * @param inputFields
	 * 			a list of Staffware field objects which Staffware provides 
	 * 			(with values)
	 * @return the name value pairs returned to Staffware
	 */
	@Override
	public Map<String, String> execute(String staticData, List outputFields, List inputFields)
			throws com.staffware.eaijava.FatalPluginException,
			com.staffware.eaijava.NonFatalPluginException {
		try {
			Map<String, String> resultMap = new java.util.HashMap<String, String>();

			if (logger.isDebugEnabled()) {
				logger.debug("Arguments received from Staffware:");
				for (Iterator i = inputFields.iterator(); i.hasNext();) {
					Field f = (Field) i.next();
					logger.debug(f.getName() + " = " + f.getValue());
				}
			}

			try {
				
				if(staticData.equals(MSG_TYPE_103)){
					String ordCusName1 = TagHelper.getFieldValue(inputFields, "ORD_CUS_NAME_1");
					String orderingParty = TagHelper.getFieldValue(inputFields, "ORDERING_PARTY");
					String orderingAcc = TagHelper.getFieldValue(inputFields, "ORDERING_ACC");
					
					//Populate 50F tag only if ORD_CUS_NAME_1 and either of ORDERING_PARTY
					//or ORDERING_ACC is not null.
					if((ordCusName1 != null && !ordCusName1.isEmpty())
							&& ((orderingParty != null && !orderingParty.isEmpty())
							|| (orderingAcc != null && !orderingAcc.isEmpty()))){
						
						boolean canPopulateCustAdd = false;
						
						if(orderingParty != null && !orderingParty.isEmpty()){
							//stripping all the invalid characters from string
							orderingParty = orderingParty.replaceAll(SWIFT_X_CHARACTER_SET,"");
							
							if(!orderingParty.matches("^[A-Z]{4}/[A-Z]{2}/.{1,27}$")){
								throw new Exception("Party Identifier " + orderingParty + " does not comply with SWIFT format rules for tag option 50F. Must be in either in '4!a/2!a/27x' or '34x' format.");
							}
							
							String [] idList = {"ARNU","CCPT","CUST","DRLC","EMPL","NIDN","SOSE","TXID"};
							if(!Arrays.asList(idList).contains(orderingParty.substring(0,4))){
								throw new Exception("Invalid party identifier code for tag option 50F.");
							}
							
							resultMap.put("TAG_50F_ID", orderingParty);
							canPopulateCustAdd = true;
							
						} else {
							orderingAcc = orderingAcc.replaceAll(SWIFT_X_CHARACTER_SET,"");
							
							if(!orderingAcc.matches(PATTERN_34_CHARACTERS)){
								throw new Exception("Party Identifier " + orderingAcc + " does not comply with SWIFT format rules for tag option 50F. Must be in either in '4!a/2!a/27x' or '34x' format.");
							}
							
							resultMap.put("TAG_50F_ID", "/" + orderingAcc);
						}
						
						
						ordCusName1 = ordCusName1.replaceAll(SWIFT_X_CHARACTER_SET,"");
						
						if(!ordCusName1.matches(PATTERN_33_CHARACTERS)){
							throw new Exception("Ordering Customer Name 1 " + ordCusName1 + " does not comply with SWIFT format rules for tag option 50F. Must be in '33x' format.");
						}
						
						resultMap.put("TAG_50F_ADDR_1", "1/" + ordCusName1);
												
						String [] addrFields = {"TAG_50F_ADDR_2", "TAG_50F_ADDR_3", "TAG_50F_ADDR_4"};
						String [] formFields = {"ORD_CUS_NAME_2", "ORD_CUS_NAME_3", "ORD_CUS_NAME_4", "ORD_CUS_ADDR_1",
								"ORD_CUS_ADDR_2", "ORD_CUS_CNTRY", "ORD_CUS_TOWN_1", "ORD_CUS_TOWN_2", "ORD_CUS_TOWN_3",
								"ORD_CUS_DOB", "ORD_CUS_POB", "ORD_CUS_COB", "ORD_CUS_IDCTRY", "ORD_CUS_IDISS", "ORD_CUS_IDNO",
								"ORD_CUS_NIDCTRY", "ORD_CUS_NIDNO", "ORD_CUST_ADD"};
						
						int formFieldIndex = 0;
						int addrFieldIndex = 0;
						
						String country = TagHelper.getFieldValue(inputFields, "ORD_CUS_CNTRY").replaceAll(SWIFT_X_CHARACTER_SET,"");
						String town1 = TagHelper.getFieldValue(inputFields, "ORD_CUS_TOWN_1").replaceAll(SWIFT_X_CHARACTER_SET,"");
						String addr2 = TagHelper.getFieldValue(inputFields, "ORD_CUS_ADDR_2").replaceAll(SWIFT_X_CHARACTER_SET,"");
						
						for(String addrField : addrFields){
							for( ; formFieldIndex < formFields.length; formFieldIndex++){
							String formField = TagHelper.getFieldValue(inputFields, formFields[formFieldIndex]);
								if(!formField.isEmpty()){
									formField = formField.replaceAll(SWIFT_X_CHARACTER_SET,"");
									if(formField.matches(PATTERN_33_CHARACTERS)){
										String fieldName = formFields[formFieldIndex];
										if(fieldName.equals("ORD_CUS_ADDR_1") || fieldName.equals("ORD_CUS_ADDR_2")){
											if(!validateAddrField(fieldName.substring(8,14), addrFieldIndex, country, town1, addr2.isEmpty() || addr2 == null)){
												throw new Exception("'2/'Address Line cannot be used without '3/'Country and Town and the first occurrence of '3/' must include detail of the Town as well as Country for tag option 50F.");
											}
										}
										
										if(fieldName.equals("ORD_CUS_CNTRY")){
											if(formField.length() != 2){
												throw new Exception("The first occurrence of '3/' must contain a valid ISO Country Code for tag option 50F.");
											}
											if(!town1.isEmpty()){
												String countryTown1 = country + "/" + town1;
												if(!countryTown1.matches(PATTERN_33_CHARACTERS)){
													throw new Exception("/" + countryTown1 + " does not comply with SWIFT format rules for tag option 50F. Must be in '33x' format.");
												}
												resultMap.put(addrField, "3/" + countryTown1);
												formFieldIndex++;
												break;
											}
										}
											
										if(formFieldIndex > 4 && formFieldIndex < 9 && country.isEmpty()){
											throw new Exception("The first occurrence of '3/' must contain a valid ISO Country Code for tag option 50F.");
										}
										
										if(fieldName.equals("ORD_CUS_DOB") && (addrFieldIndex > 1
												|| TagHelper.getFieldValue(inputFields, "ORD_CUS_POB").replaceAll(SWIFT_X_CHARACTER_SET,"").isEmpty())){
											throw new Exception("4/Date of Birth cannot be used without 5/Place of Birth for tag option 50F.");
										}
										
										if(fieldName.equals("ORD_CUS_POB")){
											String ordCusDob = TagHelper.getFieldValue(inputFields, "ORD_CUS_DOB").replaceAll(SWIFT_X_CHARACTER_SET,"");
											if(ordCusDob.isEmpty() || ordCusDob == null){
												throw new Exception("5/Place of Birth cannot be used without 4/Date of Birth for tag option 50F.");
											}
											
											String ordCusCob = TagHelper.getFieldValue(inputFields, "ORD_CUS_COB").replaceAll(SWIFT_X_CHARACTER_SET,"");
											formField = ordCusCob + "/" + formField;
											
											if(!formField.matches("^[A-Z]{2}/.{1,30}$")){
												throw new Exception("5/Place of Birth must contain a valid ISO country code and the place of birth separated by a '/' for tag option 50F.");
											}
											formFieldIndex++;
										}
											
										if(fieldName.equals("ORD_CUS_IDCTRY") || fieldName.equals("ORD_CUS_IDISS") || fieldName.equals("ORD_CUS_IDNO")){
											String idCountry = TagHelper.getFieldValue(inputFields, "ORD_CUS_IDCTRY").replaceAll(SWIFT_X_CHARACTER_SET,"");
											String idIss = TagHelper.getFieldValue(inputFields, "ORD_CUS_IDISS").replaceAll(SWIFT_X_CHARACTER_SET,"");
											String idNo = TagHelper.getFieldValue(inputFields, "ORD_CUS_IDNO").replaceAll(SWIFT_X_CHARACTER_SET,"");
											
											if(idCountry.isEmpty() || idIss.isEmpty() || idNo.isEmpty()){
												throw new Exception("'6/' must contain the ISO country code of the issuer of the number, the issuer of the number and the Customer Identification Number each separated by '/' for tag option 50F.");
											}
											
											if(idCountry.length() != 2){
												throw new Exception("'6/' must start with a valid ISO Country Code followed by '/' for tag option 50F.");
											}
											
											String idCountryIdIssIdNo = idCountry + "/" + idIss + "/" + idNo;
											if(!idCountryIdIssIdNo.matches(PATTERN_33_CHARACTERS)){
												throw new Exception("/" + idCountryIdIssIdNo + " does not comply with SWIFT format rules for tag option 50F. Must be in '33x' format.");
											}
											resultMap.put(addrField, "6/" + idCountry + "/" + idIss + "/" + idNo);
											formFieldIndex = formFieldIndex + 2;
											canPopulateCustAdd = true;
											break;
										}
											
										if(fieldName.equals("ORD_CUS_NIDCTRY") || fieldName.equals("ORD_CUS_NIDNO")){
											String nIdCountry = TagHelper.getFieldValue(inputFields, "ORD_CUS_NIDCTRY").replaceAll(SWIFT_X_CHARACTER_SET,"");
											String nIdNo = TagHelper.getFieldValue(inputFields, "ORD_CUS_NIDNO").replaceAll(SWIFT_X_CHARACTER_SET,"");
											
											if(nIdCountry.isEmpty() || nIdNo.isEmpty()){
												throw new Exception("'7/' must contain a valid ISO country code and the National Identity Number separated by a '/' for tag option 50F.");
											}
											
											if(nIdCountry.length() != 2 || nIdNo.length() > 30){
												throw new Exception("'7/' must contain a valid ISO country code and the National Identity Number separated by a '/' for tag option 50F.");
											}
											
											resultMap.put(addrField, "7/" + nIdCountry + "/" + nIdNo);
											formFieldIndex++;
											canPopulateCustAdd = true;
											break;
										}
											
										if(fieldName.equals("ORD_CUST_ADD") && !canPopulateCustAdd){
											throw new Exception("'8/' must only be used where one of the following has been used: Party Identifier (Code)(Country Code)(Identifier), Customer Identification Number or National Identity Number for tag option 50F.");
										}
										
										resultMap.put(addrField, getPrefix(formFieldIndex) + formField);
										
										break;
									} else {
										throw new Exception("/" + formField + " does not comply with SWIFT format rules for tag option 50F. Must be in '33x' format.");
									}
								} else {
									continue;
								}
							}
							
							formFieldIndex++;
							addrFieldIndex++;
						}
					}
				}
						
				//Formatting 59F Tag
			
				String benCusName = TagHelper.getFieldValue(inputFields, "BEN_CUS_NAME_1");
				String benCusAccount = TagHelper.getFieldValue(inputFields, "BEN_CUS_ACCOUNT");
					
				if(!benCusName.isEmpty()){
					if(!benCusAccount.isEmpty()){
						//stripping all the invalid characters from string
						benCusAccount = benCusAccount.replaceAll(SWIFT_X_CHARACTER_SET,"");
						
						if(benCusAccount.matches(PATTERN_34_CHARACTERS)){
							resultMap.put("TAG_59F_ACC", "/" + benCusAccount);
						} else {
							throw new Exception("Account /" + benCusAccount + " does not comply with SWIFT format rules for tag option 59F.");
						}
					}
					
					benCusName = benCusName.replaceAll(SWIFT_X_CHARACTER_SET,"");
					if(benCusName.matches(PATTERN_33_CHARACTERS)){
						resultMap.put("TAG_59F_ADDR_1", "1/" + benCusName);
					} else {
						throw new Exception("Beneficiary Customer Name 1/" + benCusName + " does not comply with " +
								"SWIFT format rules for tag option 59F. Must be in '33x' format.");
					}
						
					String [] addrFields = {"TAG_59F_ADDR_2", "TAG_59F_ADDR_3", "TAG_59F_ADDR_4"};
					String [] formFields = {"BEN_CUS_NAME_2", "BEN_CUS_NAME_3", "BEN_CUS_NAME_4", "BEN_CUS_ADDR_1",
							"BEN_CUS_ADDR_2", "BEN_CUS_COUNTRY", "BEN_CUS_TOWN_1", "BEN_CUS_TOWN_2", "BEN_CUS_TOWN_3"};
					int formFieldIndex = 0;
					int addrFieldIndex = 0;
					
					String country = TagHelper.getFieldValue(inputFields, "BEN_CUS_COUNTRY").replaceAll(SWIFT_X_CHARACTER_SET,"");
					String town1 = TagHelper.getFieldValue(inputFields, "BEN_CUS_TOWN_1").replaceAll(SWIFT_X_CHARACTER_SET,"");
					String addr2 = TagHelper.getFieldValue(inputFields, "BEN_CUS_ADDR_2").replaceAll(SWIFT_X_CHARACTER_SET,"");
					
					for(String addrField : addrFields){
						for( ; formFieldIndex < formFields.length; formFieldIndex++){
							String formField = TagHelper.getFieldValue(inputFields, formFields[formFieldIndex]);
							if(!formField.isEmpty()){
								formField = formField.replaceAll(SWIFT_X_CHARACTER_SET,"");
								if(formField.matches(PATTERN_33_CHARACTERS)){
									String fieldName = formFields[formFieldIndex];
										
									if(fieldName.equals("BEN_CUS_ADDR_1") || fieldName.equals("BEN_CUS_ADDR_2")){
										if(!validateAddrField(fieldName.substring(8,14), addrFieldIndex, country, town1, addr2.isEmpty() || addr2 == null)){
											throw new Exception("'2/'Address Line cannot be used without '3/'Country and Town and the first occurrence of '3/' must include detail of the Town as well as Country for tag option 59F.");
										}
									}
										
									if(fieldName.equals("BEN_CUS_COUNTRY")){
										if(formField.length() != 2){
											throw new Exception("The first occurrence of '3/' must contain a valid ISO Country Code for tag option 59F.");
										}
										if(!town1.isEmpty()){
											if(town1.matches(PATTERN_33_CHARACTERS)){
												String countryTown1 = country + "/" + town1;
												if(!countryTown1.matches(PATTERN_33_CHARACTERS)){
													throw new Exception("/" + countryTown1 + " does not comply with SWIFT format rules for tag option 50F. Must be in '33x' format.");
												}
												resultMap.put(addrField, "3/" + countryTown1);
												formFieldIndex++;
												break;
											} else {
												throw new Exception("/" + town1 + " does not comply with SWIFT format rules for tag option 59F.");
											}
											
										}
									}
										
									if(formFieldIndex > 4 && country.isEmpty()){
										throw new Exception("The first occurrence of '3/' must contain a valid ISO Country Code for tag option 59F.");
									}
									resultMap.put(addrField, getPrefix(formFieldIndex) + formField);
									
									break;
								} else {
									throw new Exception("/" + formField + " does not comply with SWIFT format rules for tag option 59F.");
								}
							} else {
								continue;
								}
						}
					
						formFieldIndex++;
						addrFieldIndex++;
					}
				}

				
				resultMap.put("STATUSCODE", "0");
				resultMap.put("ERRORCODE", "0");
				resultMap.put("ERRORDESC", TAG_VALIDATION_SUCCESSFUL);
				
			} catch (Exception e) {
				
				logger.error(TAG_VALIDATION_FAILED, e);
				
				resultMap.put("STATUSCODE", "-1");
				resultMap.put("STATUSDESC", " ");
				resultMap.put("ERRORCODE", "-1");
				resultMap.put("ERRORDESC", TAG_VALIDATION_FAILED
						+ " Details: " + e.toString());
			}
			 //resultMap = filterOutput(resultMap, outputFields);
			if (logger.isDebugEnabled()) {
				logger.debug("Returning values to Staffware:");
				List<String> keys = new java.util.ArrayList<String>(resultMap.keySet());
				Collections.sort(keys);
				for (Iterator<String> i = keys.iterator(); i.hasNext();) {
					String key = (String) i.next();
					logger.debug(key + " <- " + resultMap.get(key));
				}
			}
			return resultMap;
		} catch (java.lang.Exception e) {
			logger.fatal(e);
			throw new FatalPluginException(TAG_VALIDATION_FAILED);
		}
	}
	
	/***
	 * return the prefix to add before tag field value
	 * @param formFieldIndex - index of current input field being processes
	 * @return prefix string
	 */
	private String getPrefix(int formFieldIndex){
		if(formFieldIndex < 3) {
			return "1/";
		} else if(formFieldIndex < 5){
			return "2/";
		} else if(formFieldIndex < 9){
			return "3/";
		} else if(formFieldIndex < 10){
			return "4/";
		} else if(formFieldIndex < 12){
			return "5/";
		} else if(formFieldIndex < 15){
			return "6/";
		} else if(formFieldIndex < 17){
			return "7/";
		} else {
			return "8/";
		}
	}
	
	/***
	 * It validates the address fields related validations
	 * @param fieldName - name of current input field
	 * @param addrFieldIndex - index of current output field
	 * @param country - value of input field country
	 * @param town1 - value of input field town 1
	 * @param isAddr2Empty - flag to determine whether BEN_CUS_ADDR_2 input 
	 * field is empty or not.
	 * @return - flag to indicate whether validation was successful or not.
	 */
	private boolean validateAddrField(String fieldName, int addrFieldIndex, 
			String country, String town1, boolean isAddr2Empty){
		boolean result = true;
		
		if(fieldName.equals("ADDR_1") && isAddr2Empty && addrFieldIndex > 1){
			result = false;
		}
		
		if(fieldName.equals("ADDR_1") && !isAddr2Empty && addrFieldIndex > 0){
			result = false;
		}
		
		if(fieldName.equals("ADDR_2") && !isAddr2Empty && addrFieldIndex > 1){
			result = false;
		}
			
		if(country.isEmpty() || town1.isEmpty()){
			result = false;
		}
		
		return result;
	}
}
