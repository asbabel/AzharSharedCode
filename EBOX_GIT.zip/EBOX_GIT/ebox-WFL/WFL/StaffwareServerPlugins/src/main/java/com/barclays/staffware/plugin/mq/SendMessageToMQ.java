package com.barclays.staffware.plugin.mq;

import java.io.IOException;
import java.sql.SQLException;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.mq.MQConnection;
import com.barclays.staffware.plugin.util.PainParams;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.constants.MQConstants;

/**
 * Generic Class that should be used for sending messages to MQ.
 * 
 * @author Shahir.Hiralal
 * 
 */

/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 25Jan16  SEFTP2     SRH    1a       Created. 
 * 10JAN17  WP711      PHH    1b       Fixed MQ put retries and added error logging
 */
public class SendMessageToMQ {
    private static final String MQ_SECURE_ROW = "MQ-WFL";
    private static final LoggerConnection LOG = new LoggerConnection(SendMessageToMQ.class);
    private String mqParams;
    private int retryLimit = 3;

    /**
     * Gets MQ parameters
     * 
     * @return mqParams
     */
    public String getMqParams() {
        return this.mqParams;
    }

    /**
     * sets the MqParams limit
     * 
     * @param mqParams
     */
    public void setMqParams(String mqParams) {
        this.mqParams = mqParams;
    }

    /**
     * Gets retry limit
     * 
     * @return retryLimit
     */
    public int getRetryLimit() {
        return this.retryLimit;
    }
    
    /**
     * Method to close MQ queue and queue manager connections
     * 
     * @param mqQueue Connection to a specific queue
     * @param mqConn General MQ connection
     * @throws MQException if MQ connection fails
     */
    private void closeMQConnections(MQQueue mqQueue, MQConnection mqConn) throws MQException {
        try {
            if (mqQueue != null) {
                mqQueue.close();
            }
        } finally {
            if (mqConn != null) {
                mqConn.disconnect();
            }
        }
    }

    /**
     * Method for putting message into MQ
     * 
     * @param mwmh Message data for MQ
     * @return true if put message is successful, false otherwise
     * @throws SQLException if SQL connection fails
     * @throws MQException if MQ connection fails
     * @throws IOException if fail to write string into the message buffer
     */
    public boolean putInMQ(String mwmh, SQLConnection conn) throws SQLException, IOException, MQException {
        boolean success = false;
        MQConnection mqConn = new MQConnection();
        MQQueue mqQueue = null;
        try {
            mqQueue = mqConn.getQueue(MQ_SECURE_ROW, getMqParams(), MQConstants.MQOO_OUTPUT, conn);
            // check if mqQueue is null since MQConnection class currently eats any MQException (does log it though)
            if (mqQueue != null) {
                // Define a simple Websphere MQ message
                MQMessage msg = new MQMessage();
                // specify the message options
                MQPutMessageOptions pmo = new MQPutMessageOptions();
                // write text to MQ message
                msg.writeString(mwmh);

                try {
                    mqQueue.put(msg, pmo);
                    success = true;
                } catch (MQException e) { // NOSONAR
                    success = false;
                    if (getRetryLimit() <= 0) {
                        // log error if all retries have been attempted
                        LOG.error("Failed to put pain message on queue", e);
                    }
                }
            } else {
                success = false;
                // don't retry as we only do this when the actual put fails
                retryLimit = 0;
            }
        } finally {
            closeMQConnections(mqQueue, mqConn);
        }
        
        if (!success && getRetryLimit() > 0) {
            // handle put message retry
            retryLimit--;
            success = putInMQ(mwmh, conn);
        }

        return success;
    }
}
