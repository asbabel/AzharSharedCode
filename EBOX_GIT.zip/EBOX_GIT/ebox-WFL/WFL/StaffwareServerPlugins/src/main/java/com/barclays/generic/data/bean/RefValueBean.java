/*
 * RefValue.java
 *
 * This class is used to Holde data relating to a Risk Referral held in the database.
 *
 * DATE     REFERENCE   WHO  VERSION  COMMENTS
 * -------  ---------   ---  -------  ---------------------------------------------------
 * 17DEC04  -          MJW   1.0a     Created
 * 
 */

package com.barclays.generic.data.bean;

import java.io.Serializable;

public class RefValueBean implements Serializable, Comparable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -8611946399060698802L;
	private String domain;
    private String code;
    private String decsription;

    public static final String MARKET_SEG="MKTSEG";
    public static final String BUSINESS_TYPE="BUSTYP"; 
    public static final String PROPOSITION_TYPE="CUSTYP"; 
    public static final String VAT_STATUS="VATSTS";
    public static final String PREFERRED_METHOD_OF_CONTACT="MTDCNT";
    /** Creates a new instance of RefValue */
    public RefValueBean() {
    }
    
    /**
     * Getter for property domain.
     * @return Value of property domain.
     */
    public String getDomain() {
        return this.domain;
    }
    
    /**
     * Setter for property domain.
     * @param domain New value of property domain.
     */
    public void setDomain(String domain) {
        this.domain = domain;
    }
    
    /**
     * Getter for property code.
     * @return Value of property code.
     */
    public String getCode() {
        return this.code;
    }
    
    /**
     * Setter for property code.
     * @param code New value of property code.
     */
    public void setCode(String code) {
        this.code = code;
    }
    
    /**
     * Getter for property decsription.
     * @return Value of property decsription.
     */
    public String getDecsription() {
        return this.decsription;
    }
    
    /**
     * Setter for property decsription.
     * @param decsription New value of property decsription.
     */
    public void setDecsription(String decsription) {
        this.decsription = decsription;
    }
    
    public int compareTo(Object o) {
        if(!(o instanceof RefValueBean)) throw new ClassCastException();
        int result;
        String thisDomain=this.getDomain();
        String thatDomain=((RefValueBean)o).getDomain();
        if((result=thisDomain.compareTo(thatDomain))==0) {
            String thisCode=this.getCode();
            String thatCode=((RefValueBean)o).getCode();
            result=thisCode.compareTo(thatCode);
        }
        return result;

    }
}
