package com.barclays.staffware.plugin.swift;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.data.IMWDBAccess;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TagHelper;
import com.barclays.staffware.plugin.util.ValidateSwift;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

/**
 * EAI java plugin for creating SWIFT message MT202COV
 * 
 * @author LEES
 * 
 */

/*
 * DATE 	REFERENCE 	WHO 	VERSION 	COMMENTS 
 * ---- 	--------- 	--- 	------- 	--------
 * 25APR14 	WP668 		SL 		1.00 		Created for RTGS01
 * 29OCT14	Fix			SL		1.01		Defect fix for #22
 * 16MAR15	WP668		SL		1.02		PCA defect #75 fix
 * 14AUG15	WP695		YA		1.03		Added code to populate tag 59F
 * 03SEP18  WP774		PC		1.09		Updated logic to populate UETR if come blank or empty
 */

public class MT202COV extends SwiftMessage implements ImmediateReleasePluginSDK {

	private final LoggerConnection logger =
			new LoggerConnection(MT202COV.class);

	private final String INITIALIZATION_FAILED =
			SwiftParams.initializationFailed(MT202COV.class.getName());
	
	private final String SWIFT_GPI_MEMBER = "SWIFT GPI Member";

	private String country;
	private String offshoreInd;
	private IMWDBAccess dataAccess;
	private int datastoreId;
	
	public void setDataAccess(IMWDBAccess dataAccess){
		this.dataAccess = dataAccess;
	}
	
	/**
	 * Getter for COUNTRY
	 * @return country
	 */
	public String getCountry() throws Exception{
		if (country == null || country.trim().isEmpty()){
			throw new Exception(SwiftParams.COUNTRY_ERROR);
		}
		return country;
	}
	
	/**
	 * Getter for OFFSHORE_IND
	 * @return offshoreInd
	 */
	public String getOffshoreInd() throws Exception{
		if (offshoreInd == null || offshoreInd.trim().isEmpty()){
			throw new Exception(SwiftParams.OFFSHORE_IND_ERROR);
		}
		return offshoreInd;
	}
	
	/**
	 * Method is called by Staffware before each execute (unless a caching
	 * option is selected in Staffware
	 * 
	 * @param properties
	 * 			contents of eaijava properties file in 
	 * 			root:/swserver/sw_africa/eaijava
	 */
	@Override
	public void initalizeCustomStep(){
		setDataAccess(new MWDBAccess());
	}
	
	/**
	 * Method Staffware calls in eaijava step
	 * 
	 * @param staticData
	 *            a string hardcoded in Staffware, this is ignored in this
	 *            method
	 * @param outputFields
	 *            a list of Staffware field objects which Staffware expects to
	 *            be returned
	 * @param inputFields
	 *            a list of Staffware field objects which Staffware provides
	 *            (with values)
	 * @return the name value pairs returned to Staffware
	 */
	@Override
	public Map executeProcess(String staticData, List outputFields, List inputFields)
			throws FatalPluginException,
			NonFatalPluginException {
		Map<String, Object> result =
				new HashMap<String, Object>(outputFields.size());
		StaffwareHelper.initialiseReturnValues(outputFields, result);
		try {
			setMessageType("202");
			if (logger.isDebugEnabled()) {
				logger.debug("Arguements received from Staffware: ");
				for (Iterator<?> i = inputFields.iterator(); i.hasNext();) {
					Field field = (Field) i.next();
					logger.debug(field.getName() + " = " + field.getValue());
				}
			}
			setSender(getFieldValue(inputFields, "SENDER"));
			setReceiver(getFieldValue(inputFields, "RECEIVER"));
			setClassProperties(inputFields);
			StringBuffer swiftMessage = new StringBuffer();

			// ideally, swift tags should be validated here
			basicHeaderBlock(swiftMessage, getSender());
			applicationHeaderBlock(swiftMessage, getMessageType(),
					getReceiver());
			
			String tag111 = null;
			String tag121 = null;
			boolean GPIMember = dataAccess.getCountryAttribute(
					getCountry(), getOffshoreInd(), SWIFT_GPI_MEMBER);
			if(datastoreId != 0){
				Map<String, String> swiftProperties = dataAccess.getSwiftMessageProperties(datastoreId);
				tag111 = swiftProperties.get("111");
				tag121 = swiftProperties.get("121");
			} 
			
			if(null == tag111){
				tag111 = "001";
			}
			if(StringUtils.isBlank(tag121)){
				tag121 = UUID.randomUUID().toString();
			}
			
			appendUserHeaderBlock(swiftMessage,
					TagHelper.formatCOVHeader(getFieldValue(inputFields,
							"TAG_103"), true, true, tag111, tag121, GPIMember));
			messageBlock(swiftMessage, formatMessageTags(inputFields));
			result.put("STATUSCODE", "0");
			result.put("SWIFT_" + getMessageType(), swiftMessage);
			if (logger.isDebugEnabled()) {
				logger.debug("Returning values to Staffware: ");
				List<String> keys = new ArrayList<String>(result.keySet());
				Collections.sort(keys);
				for (Iterator<?> i = keys.iterator(); i.hasNext();) {
					String key = (String) i.next();
					logger.debug(key + " <- " + result.get(key));
				}
			}
		} catch (Exception e) {
			String executeFailed =
					SwiftParams.cannotFormMessage(getMessageType());
			if (logger.isErrorEnabled()) {
				logger.error(executeFailed + ". Details: " + e.getMessage(), e);
			}
			StaffwareHelper.setErrorMessage(e, result, "-1", executeFailed);
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see com.barclays.staffware.plugin.swift.SwiftMessage#formatMessageTags(java.util.List)
	 */
	@Override
	protected StringBuffer formatMessageTags(List<?> inputFields)
			throws Exception {
		StringBuffer tags = new StringBuffer();
		// Sequence A
		appendMandatoryTag(tags, 
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_20"), 16), 
				"20", SwiftParams.TAG_20_ERROR);

		appendMandatoryTag(tags, 
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_21"), 16), 
				"21", SwiftParams.TAG_21_ERROR);

		appendOptionalTag(tags, 
				ValidateSwift.validateTimeIndication(
						getFieldValue(inputFields, "TAG_13C")),
				"13C");

		appendMandatoryTag(
				tags,
				ValidateSwift.validateDateCurrencyAmount(
						getFieldValue(inputFields, "TAG_32A")), 
				"32A", SwiftParams.TAG_32A_ERROR);

		appendOptionalTag(tags, 
				ValidateSwift.validateIdBIC(
						getFieldValue(inputFields, "TAG_52A_BIC")),
				"52A");

		appendOptionalTag(tags, 
				ValidateSwift.validateIdBIC(
						getFieldValue(inputFields, "TAG_53A")),
				"53A");

		appendOptionalTag(tags, 
				ValidateSwift.validateIdBIC(
						getFieldValue(inputFields, "TAG_54A")),
				"54A");

		String tag58 = getFieldValue(inputFields, "TAG_58A_BIC");
		if (tag58 != null && !tag58.trim().isEmpty()) {
			appendOptionalTag(tags,
					ValidateSwift.validateIdBIC(TagHelper.formatPartyIdBIC(
							getFieldValue(inputFields, "TAG_58A_ID"), tag58)),
					"58A");
		} else {
			Map<String, Object> tag58d = new HashMap<String, Object>();
			TagHelper.setGroupTags(tag58d, inputFields, "TAG_58_");
			appendMandatoryTag(tags,
					ValidateSwift.validateIdNameAddress(
							TagHelper.formatPartyAddrTag(
									tag58d, "TAG_58_", "TAG_58A_ID")),
					"58D", SwiftParams.TAG_58AD_ERROR);
		}

		appendGroupTag(tags, inputFields, "72", "TAG_72_", 6, 35);

		// Sequence B
		String tag50 = getFieldValue(inputFields, "TAG_50A_BIC");
		if (tag50 != null && !tag50.trim().isEmpty()) {
			appendOptionalTag(
					tags,
					ValidateSwift.validateAccountBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_50A_ACC"), 
									tag50)),
					"50A");
		} else {
			tag50 = getFieldValue(inputFields, "TAG_50F_ID");
			if (tag50 != null && !tag50.trim().isEmpty()) {
				Map<String, Object> tag50f = new HashMap<String, Object>();
				TagHelper.setGroupTags(tag50f, inputFields, "TAG_50F_");
				appendOptionalTag(tags,
						ValidateSwift.validateTag50F(
								TagHelper.formatTagAddress(
										tag50f, "TAG_50F_", "ID")),
						"50F");
			} else {
				Map<String, Object> tag50k = new HashMap<String, Object>();
				TagHelper.setGroupTags(tag50k, inputFields, "TAG_50K_");
				appendMandatoryTag(tags,
						ValidateSwift.validateAccountNameAddress(
								TagHelper.formatTagAddress(
										tag50k, "TAG_50K_", "ACC")),
						"50K", SwiftParams.TAG_50AFK_ERROR);
			}
		}

		String tag52 = getFieldValue(inputFields, "TAG_52A_BIC_B");
		if (tag52 != null && !tag52.trim().isEmpty()) {
			appendOptionalTag(
					tags,
					ValidateSwift.validateIdBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_52A_ID"), 
									tag52)),
					"52A");
		} else {
			tag52 = getFieldValue(inputFields, "TAG_52D_ADDR_1");
			if (tag52 != null && !tag52.trim().isEmpty()) {
				Map<String, Object> tag52d = new HashMap<String, Object>();
				TagHelper.setGroupTags(tag52d, inputFields, "TAG_52D_");
				appendOptionalTag(tags,
						ValidateSwift.validateIdNameAddress(
								TagHelper.formatTagAddress(
										tag52d, "TAG_52D_", "ID")),
						"52D");
			}
		}

		String tag56 = getFieldValue(inputFields, "TAG_56A_BIC");
		if (tag56 != null && !tag56.trim().isEmpty()) {
			appendOptionalTag(
					tags,
					ValidateSwift.validateIdNameAddress(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_56A_ID"), 
									tag56)),
					"56A");
		} else {
			tag56 = getFieldValue(inputFields, "TAG_56C");
			if (tag56 != null && !tag56.trim().isEmpty()) {
				appendOptionalTag(tags, ValidateSwift.validateAccount(tag56), "56C");
			} else {
				Map<String, Object> tag56d = new HashMap<String, Object>();
				TagHelper.setGroupTags(tag56d, inputFields, "TAG_56D_");
				appendOptionalTag(tags,
						ValidateSwift.validateIdNameAddress(
								TagHelper.formatTagAddress(
										tag56d, "TAG_56D_", "ID")),
						"56D");
			}
		}

		String tag57 = getFieldValue(inputFields, "TAG_57A_BIC");
		if (tag57 != null && !tag57.trim().isEmpty()) {
			appendOptionalTag(
					tags,
					ValidateSwift.validateIdBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_57_ID"), 
									tag57)),
					"57A");
		} else {
			tag57 = getFieldValue(inputFields, "TAG_57B_LOC");
			if (tag57 != null && !tag57.trim().isEmpty()) {
				appendOptionalTag(
						tags,
						ValidateSwift.validateIdLocation(
								TagHelper.formatPartyIdBIC(
										getFieldValue(inputFields, "TAG_57B_ID"), 
										tag57)),
						"57B");
			} else {
				tag57 = getFieldValue(inputFields, "TAG_57C");
				if (tag57 != null && !tag57.trim().isEmpty()) {
					appendOptionalTag(tags, 
							ValidateSwift.validateAccount(tag57), "57C");
				} else {
					Map<String, Object> tag57d = new HashMap<String, Object>();
					TagHelper.setGroupTags(tag57d, inputFields, "TAG_57D_");
					appendOptionalTag(
							tags,
							ValidateSwift.validateIdNameAddress(
									TagHelper.formatTagAddress(
											tag57d, "TAG_57D_", "ID")),
							"57D");
				}
			}
		}
		
		Map<String, Object> tag59 = new HashMap<String, Object>();
		TagHelper.setGroupTags(tag59, inputFields, "TAG_59_");
		String tag59acc = getFieldValue(inputFields, "TAG_59_ACC");
		String tag59Addr1 = getFieldValue(inputFields, "TAG_59F_ADDR_1");
		if(tag59Addr1 != null && !tag59Addr1.isEmpty()){
			appendOptionalTag(tags,
					TagHelper.format59FTag(inputFields), "59F");
		} else if (tag59acc != null && !tag59acc.isEmpty()){
			appendOptionalTag(tags,
					ValidateSwift.validateIdNameAddress(
							TagHelper.formatTagAddress(
									tag59, "TAG_59_", "ACC")), "59");
		} else {
			appendMandatoryTag(tags, 
					ValidateSwift.validateAccountBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_59A_ACC"),
									getFieldValue(inputFields, "TAG_59A_BIC"))), 
					"59A", SwiftParams.TAG_59_ERROR);
		}

		appendGroupTag(tags, inputFields, "70", "TAG_70_", 4, 35);
		appendGroupTag(tags, inputFields, "72", "TAG_72_", 6, 35);
		appendOptionalTag(tags, ValidateSwift.validateCurrencyAmount(
				getFieldValue(inputFields, "TAG_33B")), "33B");

		return tags;
	}
	
	/**
	 * Method for setting some of the class properties
	 * @param inputFields
	 * 			Inputs from Staffware
	 */
	private void setClassProperties(List<?> inputFields) throws Exception {
		for (Object inputField : inputFields){
			Field field = (Field) inputField;
			String name = field.getName().trim();
			String value = field.getValue().trim();
			if ("COUNTRY".equalsIgnoreCase(name)){
				country = value;
				
			} else if ("OFFSHORE_IND".equalsIgnoreCase(name)){
				offshoreInd = value;
			} else if ("SW_CASEDESC".equalsIgnoreCase(name)){
				datastoreId = dataAccess.getDatastoreIdByCaseDescription(value);
			} 
		}
	}

}
