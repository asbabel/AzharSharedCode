package com.barclays.staffware.plugin.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.plugin.swift.SwiftMessage;
import com.staffware.eaijava.Field;

/**
 * Helper class with generic methods for handling tags
 * 
 * @author LEES
 */
/*
 * DATE     REFERENCE   WHO VERSION COMMENTS 
 * ----     ---------   --- ------- --------
 * 24MAR14  WP669       SL  1.00    Created
 * 24FEB15  WP668       SL  1.01    Added '/' check for party id
 * 13MAR15  WP668       SL  1.02    PCA defect #75 fix tag 119 is mandatory for a 202 cover message
 * 11AUG15  WP695       YA  1.03    Added getFieldValue method
 * 28SEP15  WP668       AK  1.04    Modified code as part of Zambia RTGS payment fix for INC0030143712
 * 28OCT15  WP695       YA  1.05    Added new method format50FTag
 */
public class TagHelper {
    protected static final LoggerConnection logger = new LoggerConnection(TagHelper.class);

    private static final String YY_M_MDD = "yyMMdd";
    private static final int FIFTEEN = 15;
    private static final String NAME = "NAME";
    private static final String ADDR_3 = "ADDR_3";
    private static final String ADDR_2 = "ADDR_2";
    private static final String ADDR_1 = "ADDR_1";
    private static final int TWENTY_FOUR = 24;
    private static final int SIX = 6;

    /**
     * private constructor to make this utility class non-instantiable
     */
    private TagHelper() {
    };

    /**
     * Method for formatting the tag string for the user header block for MT
     * 900, 910, 940, 942, and 950
     * 
     * @return formatted string
     */
    public static StringBuffer formatHeaderTag(String tag20) {
        StringBuffer tag = new StringBuffer();
        tag.append("{108:");
        tag.append(tag20);
        tag.append("}");
        return tag;
    }

    /**
     * Method for formatting the tag string for the user header block for MT 103
     * 
     * @param tag103 TAG_103 value </br>
     * Input from Staffware (not mandatory)
     * @param tag113 TAG_113 value </br>
     * hard coded value for tag 113
     * @param hasBlock3 determines if block 3 is formed
     * @return formatted string
     */
    public static StringBuffer formatHeaderTags(
            String tag103,
            String tag113,
            boolean hasBlock3,
            String country,
            String tag108,
            String tag111,
            String tag121,
            boolean GPIMember,
            String messageType) {
        StringBuffer tags = new StringBuffer();;
        if (hasBlock3) {
            if (tag103 == null || tag103.trim().isEmpty()) {
                tags.append("{113:");
                tags.append(tag113);
                tags.append("}");
            } else {
                tags.append("{103:");
                tags.append(tag103);
                tags.append("}");
                // Added code as part of INC0030143712. This was identified as
                // PCA issue
                // It seems Java plug-in code was missing when migrated from WTX
                if (SwiftParams.ZAMBIA.equals(country) && SwiftParams.MESSAGE_103.equals(messageType)) {
                    tags.append("{108:");
                    tags.append(tag108);
                    tags.append("}");
                }

            }
        }
        
        if(GPIMember){
        	 tags.append("{111:");
        	 tags.append(tag111);
        	 tags.append("}");
        }
       
        tags.append("{121:");
   	 	tags.append(tag121);
   	 	tags.append("}");
        
        return tags;
    }

    /**
     * Method for formatting the tag string for the user header block for MT202
     * cover messages
     * 
     * @param tag tag value to be added to block 3
     * @param isRTGS true if it is an RTGS message
     * @param isCoverMessage true is it is a cover message
     */
    public static StringBuffer formatCOVHeader(String tag, boolean isRTGS, boolean isCoverMessage,
    		String tag111, String tag121, boolean GPIMember) {
        StringBuffer tags = new StringBuffer();
        // PCA defect #75 fix to correct the ordering of tags in block 3
        if (isRTGS) {
            tags.append("{103:");
            tags.append(tag);
            tags.append("}");
        } else {
            tags.append("{113:");
            tags.append(tag);
            tags.append("}");
        }
        if (isCoverMessage) {
            tags.append("{119:COV}");
        }
        
        if(GPIMember){
       	 	tags.append("{111:");
       	 	tags.append(tag111);
       	 	tags.append("}");
        }
      
        tags.append("{121:");
  	 	tags.append(tag121);
  	 	tags.append("}");
        
        return tags;
    }

    /**
     * Method for formating tag 11S and 11R
     * 
     * @param tags Map containing values for the tag and date
     * @param type String specifying the tag ("S" or "R")
     * @return Formatted string
     * @throws Exception If date is not valid
     */
    public static String formatTag11(Map<String, Object> tags, String type) throws Exception { // NOSONAR
        String tag = "TAG_11" + type;
        String dateTag = "TAG_11" + type + "_DATE";
        String value = (String) tags.get(tag);
        String date = (String) tags.get(dateTag);
        String output = "";
        if (value.trim().length() > 0) {
            value = squeezeValue(value);
            output += squeezeValue(value);
            if (date != null && isValid(dateTag, date, YY_M_MDD)) {
                output += SwiftParams.NEW_LINE + date;
            }
        }
        return output;
    }

    /**
     * Method for formatting a tag with currency and D/C mark fields (e.g.
     * TAG_34F)
     * 
     * @param value tag value
     * @return formatted string
     */
    public static String formatCurrencyDCTag(String value) {
        if (value.length() < 3) {
            // Currency field (3 characters) needs to be present,
            // otherwise, return null
            return null;
        }
        String currency = value.substring(0, 3);
        String output = currency;
        String amount = "";
        if (value.length() > 3) {
            char dcMark = value.charAt(3);
            if (Character.isUpperCase(dcMark)) {
                output += dcMark;
                amount = value.substring(4);
            } else {
                amount = value.substring(3);
            }
            if (amount != null && !amount.trim().isEmpty()) {
                output += parseAmount(amount);
            }
        }
        return output;
    }

    /**
     * Method for formatting date time tags (e.g. TAG_13D)
     * <p>
     * Performs various checks to make sure that the fields within the tag are
     * in the correct format. If format is incorrect, either exception is
     * thrown, or null is returned.
     * 
     * @param key tag key
     * @param value tag value
     * @return formatted string
     * @throws Exception If date time field is not in the correct format
     */
    public static String formatDateTimeTag(String key, String value) throws Exception {
        if (value.length() != FIFTEEN) {
            // value needs to be 15 characters in length
            return null;
        }
        String output = "";
        String dateTime = value.substring(0, 10);
        if (isValid(key, dateTime, "yyMMddHHmm")) {
            output += dateTime;
        }
        char timeSign = value.charAt(10);
        if (timeSign == '+' || timeSign == '-') {
            output += timeSign;
        } else {
            throw new Exception("TAG_13D error: Incorrect time sign");
        }
        output += Integer.parseInt(value.substring(11));
        return output;
    }

    /**
     * Method for formatting tags with an integer suffix also replaces the first
     * character with a full stop if it is a colon / hyphen in the array index >
     * 0
     * 
     * @param tags Map containing values for the tag
     * @param tagPrefix Name of the tag
     * @param n Size of the array
     * @param maxChar maximum number of characters in field
     * @return Formatted string
     * @throws Exception
     */
    public static String formatTagN(Map<String, Object> tags, String tagPrefix, int n, int maxChar) throws Exception {
        List<String> tagList = new ArrayList<String>();
        for (int i = 1; i <= n; i++) {
            String value = (String) tags.get(tagPrefix + i);
            value = ValidateSwift.validateSwiftXCharacters(value, maxChar);
            if (value != null && !value.isEmpty()) {
                if (i == 1) {
                    tagList.add(value);
                } else {
                    replaceColonHyphen(value, tagList);
                }
            }
        }
        return formatTagArray(tagList);
    }

    /**
     * Method for formatting tags with values for account, name, address
     * 
     * @param tags Map containing values for the tag
     * @param tagPrefix Name of the tag
     * @return Formatted string
     */
    public static String formatTagAccNameAdd(Map<String, Object> tags, String tagPrefix) {
        List<String> tagList = new ArrayList<String>();
        String value = (String) tags.get(tagPrefix + "ACC");
        if (value != null && !value.trim().isEmpty()) {
            tagList.add(squeezeValue(value));
        } else {
            value = (String) tags.get(tagPrefix + "ID");
            if (value != null && !value.trim().isEmpty()) {
                tagList.add(squeezeValue(value));
            }
        }
        value = (String) tags.get(tagPrefix + NAME);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(tagPrefix + ADDR_1);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(tagPrefix + ADDR_2);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(tagPrefix + ADDR_3);
        replaceColonHyphen(value, tagList);
        return formatTagArray(tagList);
    }

    /**
     * Method for formatting tag 50 F / H with values for Party / Acc, Addr_1,
     * Addr_2, Addr_3, and Addr_4
     * 
     * @param tags Map containing values for the tag
     * @param tagPrefix Name of the tag
     * @return formatted string
     */
    public static String formatTagAddress(Map<String, Object> tags, String tagPrefix, String firstTag) {
        List<String> tagList = new ArrayList<String>();
        String value = (String) tags.get(tagPrefix + firstTag);
        if (value != null && !value.trim().isEmpty()) {
            value = value.trim();
            while (value.contains("''")) {
                value = value.replaceAll("''", "'");
            }
            tagList.add(squeezeValue(value));
        }
        String add1 = (String) tags.get(tagPrefix + ADDR_1);
        replaceColonHyphen(add1, tagList);
        String add2 = (String) tags.get(tagPrefix + ADDR_2);
        replaceColonHyphen(add2, tagList);
        String add3 = (String) tags.get(tagPrefix + ADDR_3);
        replaceColonHyphen(add3, tagList);
        String add4 = (String) tags.get(tagPrefix + "ADDR_4");
        replaceColonHyphen(add4, tagList);

        if ((add1 != null && !add1.isEmpty()) || (add2 != null && add2.isEmpty()) || (add3 != null && add3.isEmpty())
                || (add4 != null && add4.isEmpty())) {
            return formatTagArray(tagList);
        }
        return null;
    }

    /**
     * Method for formatting tag 58D for Party / Acc, Addr_1, Addr_2, Addr_3,
     * and Addr_4
     * 
     * @param tags Map containing values for the tag
     * @param tagPrefix Name of the tag
     * @return formatted string
     */
    public static String formatTag58D(Map<String, Object> tags, String addrTagPrefix, String firstTagId) {
        List<String> tagList = new ArrayList<String>();
        String value = (String) tags.get(firstTagId);
        if (value != null && !value.trim().isEmpty()) {
            value = value.trim();
            while (value.contains("''")) {
                value = value.replaceAll("''", "'");
            }
            tagList.add(squeezeValue(value));
        }
        value = (String) tags.get(addrTagPrefix + ADDR_1);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(addrTagPrefix + ADDR_2);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(addrTagPrefix + ADDR_3);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(addrTagPrefix + "ADDR_4");
        replaceColonHyphen(value, tagList);
        return formatTagArray(tagList);
    }

    /**
     * Method for validating tags with values for D/C mark, date, currency, and
     * amount
     * 
     * @param key tag key
     * @param value tag value
     * @return formatted string
     * @throws Exception if date field is not in the correct format
     */
    public static String validateDCDateCurrencyAmount(String key, String value) throws Exception { // NOSONAR
        if (value.isEmpty()) {
            return "";
        }
        char dcMark = value.charAt(0);
        String dateCurrencyAmount = validateCurrencyAmount(key, value.substring(1));
        return dcMark + dateCurrencyAmount;
    }

    /**
     * Method for validating date, currency, amount fields
     * 
     * @param key tag key
     * @param value tag value to be formatted and validated
     * @return validated string
     * @throws Exception If date is not in the format YYMMDD
     */
    public static String validateCurrencyAmount(String key, String value) throws Exception { // NOSONAR
        if (value.length() > TWENTY_FOUR) {
            value = value.substring(0, TWENTY_FOUR);
        }
        String date = value.substring(0, SIX);
        String currencyAmount = value.substring(SIX);
        String output = "";
        if (isValid(key, date, YY_M_MDD)) {
            output = date + currencyAmount;
        }
        // if date is invalid, exception will be thrown
        return output;
    }

    /**
     * Method for formatting tags for currency and amount
     * 
     * @param value tag value to be formatted
     * @return formatted string
     */
    public static String formatCurrencyAmount(String value) {
        if (value.length() > 18) {
            value = value.substring(0, 18);
        }
        return value;
    }

    /**
     * Method for formatting tag groups with party id and BIC / Location
     * 
     * @param partyId Party Id
     * @param value BIC or Location
     * @return Formatted string
     */
    public static String formatPartyIdBIC(String partyId, String value) {
        String output = null;
        if (partyId != null && !partyId.isEmpty() && partyId != SwiftParams.NO_DATA) {
            // added check for SMxx in case staffware already adds '/' to id
            // this is to mimic original WTX processing and to minimise
            // changes to existing functionality
            if (partyId.startsWith("/")) {
                output = squeezeValue(partyId);
            } else {
                output = "/" + squeezeValue(partyId);
            }
            if (value != null && !value.isEmpty()) {
                output += SwiftParams.NEW_LINE + squeezeValue(value);
            }
        } else {
            if (value != null && !value.isEmpty()) {
                output = squeezeValue(value);
            }
        }
        return output;
    }

    /**
     * Method for parsing Instruction values
     * 
     * @param value String to be parsed
     * @return parsed string
     */
    public static String parseInstruction(String value) {
        String output;
        String[] fields = value.split("!");
        if (fields.length > 1) {
            String code = fields[0];
            String info = "/" + fields[1];
            output = code + info;
        } else {
            output = fields[0];
        }
        return output;
    }

    /**
     * Method for parsing Statement Number Sequence
     * 
     * @param value string to be parsed
     * @return parsed string
     */
    public static String parseStatementNumberSequence(String value) {
        String output = "";
        String[] tagField = value.split("/");
        if (tagField.length > 1) {
            for (int i = 0; i < 2; i++) {
                if (tagField[i] != null && !tagField[i].trim().isEmpty()) {
                    output += Integer.parseInt(tagField[i].trim()) + "/";
                } else {
                    if (i == 0) {
                        return null;
                    }
                }
            }
            output = output.substring(0, output.length() - 1);
        } else {
            if (tagField[0] != null && !tagField[0].trim().isEmpty()) {
                output += Integer.parseInt(tagField[0].trim());
            }
        }
        return output;
    }

    /**
     * Method for parsing Statement Lines
     * 
     * @param key tag key
     * @param value tag value
     * @return parsed string
     * @throws Exception if date fields are not in the correct format
     */
    public static String parseStatementLineAccInfo(String key, String value) throws Exception {

        String output = "";
        String[] tagField = value.split("<!!>");
        // defect fix for #256 in MT94x
        // - check for tagField.length == 9 changed to
        // (!(tagField.length > 9) && !(tagField.length < 5))
        // there are 5 mandatory fields in tag 61 with a maximum of 9 fields
        if (!(tagField.length > 9) && !(tagField.length < 5)) {
            for (int i = 0; i < tagField.length; i++) {
                if (tagField[i] != null && !tagField[i].trim().isEmpty()) {
                    if (i == 0) {
                        // append validated value date
                        output += ValidateSwift.validateDateTime(tagField[i], YY_M_MDD);
                    } else if (i == 1) {
                        // append validated entry date
                        output += ValidateSwift.validateDateTime(tagField[i], "MMdd");
                    } else if (i == 2 || i == 3) {
                        output += ValidateSwift.validateAlphabetic(tagField[i]);
                    } else if (i == 4) {
                        output += ValidateSwift.validateAmount(tagField[i]);
                    } else if (i == 5) {
                        // append transaction type field
                        output += ValidateSwift.validateAlphabetic(String.valueOf(tagField[i].charAt(0)))
                                + ValidateSwift.validateAlphaNumeric(tagField[i].substring(1, 4));
                    } else if (i == 6) {
                        output += ValidateSwift.validateSwiftXCharacters(tagField[i], 16);

                    } else if (i == 7) {
                        if (tagField[i].startsWith("//")) {
                            output += "//" + ValidateSwift.validateSwiftXCharacters(tagField[i].substring(2), 16);
                        } else {
                            throw new Exception(tagField[i] + " - is not in the correct format (//16x)");
                        }
                    } else if (i == 8) {
                        output += SwiftParams.NEW_LINE + ValidateSwift.validateSwiftXCharacters(tagField[i], 34);
                    }
                }
            }
        } else {
            throw new Exception(value + "is not in the correct Tag 61 format"); // NOSONAR
        }
        return output;
    }

    /**
     * Method sets the group tags and populates the output map
     * 
     * @param outputMap the map of tags to be populated
     * @param fields List of input fields
     * @param startOfKey string at the start of key (also the name of the group
     * of tags)
     */
    public static void setGroupTags(Map<String, Object> outputMap, List<?> fields, String startOfKey) {
        for (Iterator<?> i = fields.iterator(); i.hasNext();) {
            Field field = (Field) i.next();
            String key = field.getName();
            String value = (String) field.getValue();
            value = squeezeValue(value);
            if (key.startsWith(startOfKey)) {
                if (value != null && !value.isEmpty()) {
                    outputMap.put(key, value);
                }
            }
        }
    }

    /**
     * Method for parsing the amount field in tags
     * 
     * @param output String to append the field to
     * @param value field value
     * @return parsed string
     */
    public static String parseAmount(String value) {
        String output = "";
        String[] amount = value.split(",");
        output += Integer.parseInt(amount[0]) + ",";
        // append amount field
        for (int i = 0; i < amount[1].length(); i++) {
            if (i < 3) {
                output += Integer.parseInt(amount[1].substring(i, i + 1));
            }
        }
        return output;
    }

    /**
     * Method for formatting the tag string in an array "/n" is used to delimit
     * the values in the array
     * 
     * @param tags List of tag values
     * @return formatted string
     */
    private static String formatTagArray(List<String> tags) {
        String output = "";
        int size = tags.size();
        if (size == 0) {
            return output;
        } else if (size > 1) {
            for (int i = 0; i < size; i++) {
                output += tags.get(i);
                if (i < size - 1) {
                    output += SwiftParams.NEW_LINE;
                }
            }
        } else {
            output = tags.get(0);
        }
        return output;
    }

    /**
     * Method replace colon / hyphen with full stop
     * 
     * @param output string to add the value to
     * @param value tag value for formatting
     */
    private static void replaceColonHyphen(String value, List<String> tag) {
        if (value != null && !value.trim().isEmpty()) {
            value = squeezeValue(value);
            char firstChar = value.charAt(0);
            if (firstChar == ':' || firstChar == '-') {
                value = "." + value.substring(1);
            }
            tag.add(value);
        }
    }

    /**
     * Method for checking if date is in the "yyMMdd" format
     * 
     * @param date Date to validate
     * @param tag Name of the tag
     * @return True if the date is valid
     * @throws Exception If date is not in the correct format
     */
    private static boolean isValid(String key, String date, String pattern) throws Exception { // NOSONAR
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        format.setLenient(false);
        try {
            format.parse(date);
        } catch (ParseException e) {
            throw new Exception(SwiftParams.incorrectFormat(date, pattern)); // NOSONAR
        }
        return true;
    }

    /**
     * Method replaces consecutive quotes with a single quote
     * 
     * @param value value to be evaluated
     * @return squeeze string
     */
    public static String squeezeValue(String value) {
        value = value.trim();
        while (value.contains("''")) {
            value = value.replaceAll("''", "'");
        }
        return value;
    }

    /**
     * Method for formatting Party / Acc, Addr_1, Addr_2, Addr_3, and Addr_4 tag
     * (e.g. TAG_58)
     * 
     * @param tags Map containing values for the tag
     * @param tagPrefix Name of the tag
     * @return formatted string
     */
    public static String formatPartyAddrTag(Map<String, Object> tags, String addrTagPrefix, String firstTagId) {
        List<String> tagList = new ArrayList<String>();
        String value = (String) tags.get(firstTagId);
        if (value != null && !value.trim().isEmpty()) {
            value = value.trim();
            while (value.contains("''")) {
                value = value.replaceAll("''", "'");
            }
            tagList.add(squeezeValue(value));
        }
        value = (String) tags.get(addrTagPrefix + ADDR_1);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(addrTagPrefix + ADDR_2);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(addrTagPrefix + ADDR_3);
        replaceColonHyphen(value, tagList);
        value = (String) tags.get(addrTagPrefix + "ADDR_4");
        replaceColonHyphen(value, tagList);
        return formatTagArray(tagList);
    }

    /**
     * Method for parsing information to account owner
     * 
     * @param key tag key
     * @param value tag value
     * @return parsed string
     * @throws Exception if value is invalid
     */
    // existing one
  /* public static String parseInformationToAccountOwner(String key, String value) throws Exception { // NOSONAR
        String output = "";
        String[] fields = value.split("<!!>");
        for (String field : fields) {
            if (field != null && !field.isEmpty()) {
                output += ValidateSwift.validateSwiftXCharacters(field, 65) + SwiftParams.NEW_LINE;
            }
        }
        return output.substring(0, output.length() - 2);
    }*/
 //nemish new changes
    public static String parseInformationToAccountOwner(String key, String value,Boolean trim) throws Exception { // NOSONAR
        logger.info("executing parseInformationToAccountOwner method");
        String output = "";
        String remitValue="";
        String[] fields = value.split("<!!>");
        for (String field : fields) {
            //WL682 Trim REMIT of Tag86 to 29 characters for ZMB
            if (field != null && !field.isEmpty() && field.contains("REMIT") && trim) {
                logger.info("checking INPUT Fields for REMIT");
                remitValue=ValidateSwift.validateSwiftXCharacters(field, 65);
                output += remitValue.length()>35?remitValue.substring(0,35):remitValue;
                output += SwiftParams.NEW_LINE;
            }else {
                logger.info("checking INPUT Fields other then REMIT");
                output += ValidateSwift.validateSwiftXCharacters(field, 65) + SwiftParams.NEW_LINE;
            }
        }
        return output.substring(0, output.length() - 2);
    }


    /**
     * Method gets the value of the named field from the given list
     * 
     * @param fields list of fields
     * @param key name of field of interest
     * @return value of given field
     */
    public static String getFieldValue(List<?> fields, String key) {
        for (Iterator<?> i = fields.iterator(); i.hasNext();) {
            Field field = (Field) i.next();
            if (key.equalsIgnoreCase(field.getName())) {
                String value = field.getValue();
                return value == null ? "" : value.trim();
            }
        }
        return "";
    }

    /***
     * This method formats the 59F tag.
     * 
     * @param inputFields - list of input fields
     * @return formatted 59F tag
     */
    public static String format59FTag(List<?> inputFields) {
        String tag59FAcc = getFieldValue(inputFields, "TAG_59F_ACC");
        String tag59FAddr1 = getFieldValue(inputFields, "TAG_59F_ADDR_1");
        String tag59FAddr2 = getFieldValue(inputFields, "TAG_59F_ADDR_2");
        String tag59FAddr3 = getFieldValue(inputFields, "TAG_59F_ADDR_3");
        String tag59FAddr4 = getFieldValue(inputFields, "TAG_59F_ADDR_4");

        StringBuilder tag59F = new StringBuilder("");

        if (tag59FAcc != null && !tag59FAcc.isEmpty()) {
            tag59F.append(tag59FAcc);
            tag59F.append(SwiftParams.NEW_LINE);
        }

        tag59F.append(tag59FAddr1);
        tag59F.append(SwiftParams.NEW_LINE);

        if (tag59FAddr2 != null && !tag59FAddr2.isEmpty()) {
            tag59F.append(tag59FAddr2);
            tag59F.append(SwiftParams.NEW_LINE);
        }

        if (tag59FAddr3 != null && !tag59FAddr3.isEmpty()) {
            tag59F.append(tag59FAddr3);
            tag59F.append(SwiftParams.NEW_LINE);
        }

        if (tag59FAddr4 != null && !tag59FAddr4.isEmpty()) {
            tag59F.append(tag59FAddr4);
            tag59F.append(SwiftParams.NEW_LINE);
        }

        return tag59F.toString();
    }

    /***
     * This method formats the 50F tag.
     * 
     * @param inputFields - list of input fields
     * @return formatted 50F tag
     */
    public static String format50FTag(List<?> inputFields, String tag50FId, String tag50FAddr1) {

        String tag50FAddr2 = getFieldValue(inputFields, "TAG_50F_ADDR_2");
        String tag50FAddr3 = getFieldValue(inputFields, "TAG_50F_ADDR_3");
        String tag50FAddr4 = getFieldValue(inputFields, "TAG_50F_ADDR_4");

        StringBuilder tag50F = new StringBuilder("");

        tag50F.append(tag50FId);
        tag50F.append(SwiftParams.NEW_LINE);

        tag50F.append(tag50FAddr1);
        tag50F.append(SwiftParams.NEW_LINE);

        if (tag50FAddr2 != null && !tag50FAddr2.isEmpty()) {
            tag50F.append(tag50FAddr2);
            tag50F.append(SwiftParams.NEW_LINE);
        }

        if (tag50FAddr3 != null && !tag50FAddr3.isEmpty()) {
            tag50F.append(tag50FAddr3);
            tag50F.append(SwiftParams.NEW_LINE);
        }

        if (tag50FAddr4 != null && !tag50FAddr4.isEmpty()) {
            tag50F.append(tag50FAddr4);
            tag50F.append(SwiftParams.NEW_LINE);
        }

        return tag50F.toString();
    }
}
