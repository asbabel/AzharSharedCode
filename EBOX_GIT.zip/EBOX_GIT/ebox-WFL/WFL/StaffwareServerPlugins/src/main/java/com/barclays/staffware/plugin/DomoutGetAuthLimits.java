package com.barclays.staffware.plugin;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.staffware.data.MWDBAccess;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;


/**
 * iProcess EAI Java Plugin to get the Authorization Limits for DOMOUT
 * 
 * @author ABMH709
 * 
 */
/*
 * DATE     REFERENCE   WHO     VERSION COMMENTS 
 * -------  ---------   -----   ------- -------- 
 * 04Feb16              ABMH709 1a      Created.
 * 17Jan17  WP715       LeyJ    -       Refactored data access to MWDB.
 */
public class DomoutGetAuthLimits implements ImmediateReleasePluginSDK {

	private static final LoggerConnection log = new LoggerConnection(DomoutGetAuthLimits.class);
	
	/**
     * Will be passed the contents of eaijava properties file in the
     * root:/swserver/sw_africa/eaijava/ folder Will be called by staffware
     * before each execute (unless a caching option is selected in staffware)
     */
	@Override
    public void initialize(Properties properties) throws FatalPluginException,
			NonFatalPluginException {
    	try {

            //DataSourceDirectory.getInstance().configure(properties);

            // load db driver (unsure if necessary)
            //Class.forName(properties.getProperty("db_driver"));
           // LoggerConnection.configureWFL(properties.getProperty("domOutLog"));
			ClassPathResource resource = new ClassPathResource(properties.getProperty("domOutLog"));
			LoggerContext context = (LoggerContext) LogManager.getContext(false);
			context.setConfigLocation(resource.getURI());

			DataSourceDirectory.getInstance().basePluginDS();
            log.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {

            log.error("Error initialising " + this.getClass().getName()
                    + ". Details: " + e.getMessage(), e);

            // raise exception to calling code, all exceptions considered fatal at
            // this time
            throw new FatalPluginException("Error initialising "
                    + this.getClass().getName() + ". Details: "
                    + e.getMessage());
        }
		
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Map execute(String arg0, List outputFields, List inputFields)
			throws FatalPluginException, NonFatalPluginException {
		
	    return getDatabaseAuthLimits(inputFields);
	}

	/**
	 * Get the Authorization Limits from the Database
	 * @param inputFields
	 * @return a resulSet containing the auth limits
	 * @throws SQLException 
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	private Map<String, Object> getDatabaseAuthLimits(List inputFields) throws FatalPluginException {
	    
	    HashMap<String, Object> swParams = null;
	    CallableStatement cs = null;
	    ResultSet results = null;
	    
	    try (SQLConnection conn = MWDBAccess.getDatabaseConnection();) {
    		SortedMap<String, String> args = new TreeMap<>();
    		for (int i = 0; i < inputFields.size(); i++) {
    			Field f = (Field) inputFields.get(i);
    			args.put(f.getName(), f.getValue());
    		}
    		
    		cs = conn.prepareCall("sfw_GetDomOutAuthLimits", args);
    		results = conn.executeQuery(cs, args);	
            
            if (results.next()) {
                swParams = new HashMap<>();
                
                swParams.put("FO_START_LEVEL1", results.getString("StartLevel1"));
                swParams.put("FO_START_LEVEL2", results.getString("StartLevel2"));
                swParams.put("FO_START_LEVEL3", results.getString("StartLevel3"));
                
                swParams.put("FO_END_LEVEL1", results.getString("EndLevel1"));
                swParams.put("FO_END_LEVEL2", results.getString("EndLevel2"));
                swParams.put("FO_END_LEVEL3", results.getString("EndLevel3"));
                
                String authRequired = results.getString("AuthRequired");
                if ("None".equals(authRequired)) {
                    swParams.put("FO_AUTH_REQ", "NO");
                } else {
                    swParams.put("FO_AUTH_REQ", "YES");
                }
            } else {
                throw new SQLException("No results returned from datbase.");
            }
        } catch (Exception e) {
            log.error("Error getting auth limits from the database", e);
            throw new FatalPluginException("Error getting auth limits from the database");
        }
	    
	    return swParams;
	}

}
