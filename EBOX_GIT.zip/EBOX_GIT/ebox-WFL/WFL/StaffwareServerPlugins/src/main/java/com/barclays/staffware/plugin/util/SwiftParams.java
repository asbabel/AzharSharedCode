package com.barclays.staffware.plugin.util;

/**
 * SwiftParams class holding constants for forming SWIFT messages
 * 
 * @author LEES
 * 
 */
/*
 * DATE     REFERENCE   WHO     VERSION COMMENTS 
 * ----     ---------   ---     ------- --------
 * 04FEB14  WP654WTX    LEES    1.00    Created
 * 20JAN15  WP668       LEES    1.01    Adding SWIFT_103 to enable sending 103
 * 30SEP15  WP668       AK      1.02    Added new constants for fixing incident INC0030143712
 */
public class SwiftParams {

    public static final String STATUSCODE = "STATUSCODE";
    public static final String ERRORCODE = "ERRORCODE";
    public static final String ERRORDESC = "ERRORDESC";
    public static final String STATUSDESC = "STATUSDESC";
    public static final String SW_MAINCASE = "SW_MAINCASE";
    public static final String SW_MAINPROC = "SW_MAINPROC";
    public static final String MESSAGEID = "MESSAGEID";
    public static final String STEPNAME = "STEPNAME";
    public static final String SWIFT = "SWIFT_";

    public static final String NEW_LINE = "\r\n";
    public static final String MESSAGE_TYPE = "MESSAGE_TYPE";
    public static final String PAYMENT_TYPE = "PAYMENT_TYPE";
    public static final String INST_CUR = "INST_CUR";
    public static final String COUNTRY = "COUNTRY";
    public static final String OFFSHORE_IND = "OFFSHORE_IND";
    public static final String PRODUCE_202 = "PRODUCE_202";

    public static final String YES = "YES";
    public static final String XBORDER = "XBORDER";
    public static final String NO_DATA = "@NO_DATA@";
    public static final String XXX = "XXX";

    public static final String MESSAGE_TYPE_ERROR = "MESSAGE_TYPE missing";
    public static final String SENDER_ERROR = "SENDER Tag missing or less than 8 characters";
    public static final String RECEIVER_ERROR = "RECEIVER Tag missing or less than 8 characters";
    public static final String PAYMENT_TYPE_ERROR = "PAYMENT_TYPE Tag missing";
    public static final String INST_CUR_ERROR = "INST_CUR Tag missing";
    public static final String PRODUCE_202_ERROR = "PRODUCE_202 Tag missing";
    public static final String COUNTRY_ERROR = "COUNTRY Tag missing";
    public static final String OFFSHORE_IND_ERROR = "OFFSHORE_IND Tag missing";
    public static final String TAG_11S_ERROR =
            "Mandatory object - Tag 11S - missing: MT and Date of Original Message information";
    public static final String TAG_13D_ERROR = "Mandatory object - Tag 13D - missing: Date / Time Indication";
    public static final String TAG_20_ERROR = "Mandatory object - Tag 20 - missing: Senders Reference";
    public static final String TAG_21_ERROR = "Mandatory object - Tag 21 - missing: Related reference information";
    public static final String TAG_23B_ERROR = "Mandatory object - Tag 23B - missing: Bank Operation Code";
    public static final String TAG_25_ERROR = "Mandatory object - Tag 25 - missing: Account Identification";
    public static final String TAG_28_ERROR = "Mandatory object - Tag 28 - missing: Statement Number / Sequence Number";
    public static final String TAG_28C_ERROR =
            "Mandatory object - Tag 28C - missing: Statement Number / Sequence Number";
    public static final String TAG_28D_ERROR = "Mandatory object - Tag 28D - missing: Message index / Total";
    public static final String TAG_30_ERROR = "Mandatory object - Tag 30 - missing: Requested Execution Date";
    public static final String TAG_32A_ERROR = "Mandatory object - Tag 32A - missing";
    public static final String TAG_32B_ERROR = "Mandatory object - Tag 32B - missing: Currency / Transaction Amount";
    public static final String TAG_34F_ERROR = "Mandatory object - Tag 34F - missing: Floor Limit Indicator";
    public static final String TAG_36_ERROR = "Invalid message - If field 33B is present and the currency code is "
            + "different from the currency code in field 32A, field 36 must be present";
    public static final String TAG_50K_ERROR = "Mandatory object - Tag 50K - missing:Ordering customer information";
    public static final String TAG_50AFK_ERROR =
            "Mandatory object - Tag 50A / F / K - missing: Ordering customer information";
    public static final String TAG_58A_ERROR =
            "Mandatory object - TAG 58A - missing: Beneficiary Institution information";
    public static final String TAG_58AD_ERROR =
            "Mandatory object - TAG 58A / D - missing: Beneficiary Customer information";
    public static final String TAG_59_ERROR = "Mandatory object - Tag 59 - missing: Beneficary customer information";
    public static final String TAG_59A_ERROR = "Mandatory object - Tag 59#A - missing: Beneficiary";
    public static final String TAG_60FM_ERROR = "Mandatory object - Tag 60FM - missing: Opening Balance";
    public static final String TAG_62F_ERROR = "Mandatory object - TAG 62F - missing: Book Balance";
    public static final String TAG_62FM_ERROR = "Mandatory object - Tag 62FM - missing: Closing Balance";
    public static final String TAG_71A_ERROR = "Mandatory object - Tag 71A - missing: Details of charges information";
    public static final String TAG_75_ERROR = "Mandatory object - Tag 75 - missing: Query information";
    public static final String TAG_76_ERROR = "Mandatory object - Tag 76 - missing: Response information";
    public static final String TAG_79_ERROR = "Mandatory object - Tag 79 - missing: Narrative information";

    public static final String MISSING_RELATED_REF = "Mandatory field missing: RELATED_REF";

    public static final String SENDER = "SENDER";
    public static final String RECEIVER = "RECEIVER";

    public static final String MISSING_CASENUM = "Mandatory field missing: SW_CASENUM";

    public static final String MISSING_PRONAME = "Mandatory field missing: SW_PRONAME";

    public static final String MISSING_STATUS = "Mandatory field missing: STATUS";

    public static final String MISSING_PAYMENT_TYPE = "Mandatory field missing: PAYMENT_TYPE";

    public static final String MISSING_GROUP_ID = "Mandatory field missing: GROUP_ID";

    public static final String INCORRECT_STATUS_FORMAT =
            "STATUS field must be alphabetic and not more than 10 characters in length";

    public static final String UPDATE_FAILED = "Cannot update payment status";

    public static String incorrectFormat(String value, String format) {
        return value + " - is not in the correct format (" + format + ")";
    }

    public static String initializationFailed(String className) {
        return "Error initializing " + className;
    }

    public static String cannotFormMessage(String messageType) {
        return "Cannot form SWIFT message (MT" + messageType + ")";
    }

    public static final String[] SWIFT_MESSAGES = { "SWIFT_199", "SWIFT_103", "SWIFT_202", "SWIFT_900", "SWIFT_910",
            "SWIFT_940", "SWIFT_941", "SWIFT_942", "SWIFT_950" };

    public static final String MISSING_SW_MAINPROC = "Mandatory Name Value pair missing: SW_MAINPROC";

    public static final String MISSING_SW_MAINCASE = "Mandatory Name Value pair missing: SW_MAINCASE";

    public static final String MISSING_STEPNAME = "Mandatory Name Value pair missing: STEPNAME";

    public static final String MISSING_SWIFT_MESSAGE = "Mandatory SWIFT MESSAGE missing";

    public static final String DB_ERROR = "Unable to connect to database";

    public static final String FAIL_APP = "FAIL function aborted application";

    public static final String MQ_ERROR = "Unable to put message on MQ";

    public static final String PARSE_ERROR = "Failed to parse sent date";

    public static final String SP_ERROR = "Error executing stored procedure";

    public static final String MESSAGE_103 = "103";

    public static final String ZAMBIA = "ZMB";

    public static final String RTGS = "RTGS";

    public static final String DOMAIN_103TTC = "103TTC";

    private SwiftParams() {
    }

}