package com.barclays.staffware.plugin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.BrainsConnectionException;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.middleware.util.LoggingExclusion;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.swift.SwiftMessage;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;


/**
 * This class is called by the staffware OUTPAY procedure if a failed payment occurs.
 * It calls a proc that updates the MWDB with a PaymentsAndCollections row using
 * identical details to the original, with the exception of some data changes.
 * @author  Anthony Simpson
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  ---------------------------------------------------
 * 13Jun06  -          ASIMP  1.0a     Created
 * 04Jun07  PAT01967   KEMPD  2        Removed logging configuration -- we now
 *                                      use Staffware's own eaijava log4j file.
 * 01DEC14	WP669		LEES	2.01	MTRegression defect 334 -- we now use 
 * 										the FailedPayments logger instead of 
 * 										the PostPayment logger. 
 * 17Jan17  WP715      LeyJ   -        Refactored data access to MWDB.
 */
public class FailedPayments implements ImmediateReleasePluginSDK  {
	
	private static final LoggerConnection logger=new LoggerConnection(FailedPayments.class);
	private final String initializationFailed = SwiftParams.initializationFailed(FailedPayments.class.getName());
    
	
	/**
	 * Method staffware calls in eaijava step
	 * @param staticData, a string hardcoded in staffware
	 * @param outputFields, a List of staffware Field objects which
	 * 			staffware expects to be returned 
	 * @param inputFields, a List of staffware Field objects which
	 * 			staffware provides (with values)
	 * @return Map, the name value pairs returned to staffware. Should
	 * 			only contain names of fields supplied in outputFields
	 */
	public Map execute(String staticData, List outputFields, List inputFields)
			throws FatalPluginException, NonFatalPluginException {
		HashMap returnValues = new HashMap();
		try{
			logger.debug("FailedPayments: start");
			updateMwdb(inputFields);
			logger.debug("FailedPayments: db updated");
			
		}
		catch(BrainsConnectionException e){
			// any connection errors are to go for retry
			setError(e, returnValues, "1");				
		}
		catch(Exception e){
			// any errors are returned to staffware in name value pair form
			// Staffware will be checking a StatusCode return value to 
			// see if there was an error
			setError(e, returnValues, "-1");
		}
		return returnValues;
	}
	/**
	 * Just logs as staffware expects no return values
	 * @param e
	 * @param map
	 * @param errorCode
	 */
	private void setError(Exception e, HashMap map, String errorCode){
		logger.error("Error Executing FailedPayments. Details: " 
    			+ e.toString(), e);
	}
	
	/**
	 * Will be passed the contents of eaijava properties file in the 
	 * root:/swserver/sw_africa/eaijava/ folder
	 * Will be called by staffware before each execute (unless a 
	 * caching option is selected in staffware) 
	 */
	public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {
		try {
			BrainsSocketConnectionFactory.getInstance().useSecure(properties);
            //DataSourceDirectory.getInstance().configure(properties);
			//Modified by ashish for sql connection
			DataSourceDirectory.getInstance().basePluginDS();
            // load db driver (unsure if necessary)
            //Class.forName(properties.getProperty("db_driver"));
            //LoggerConnection.configureWFL(properties.getProperty("failedPaymentsLog"));
			// Modified by ashish
			ClassPathResource resource = new ClassPathResource(properties.getProperty("failedPaymentsLog"));
			LoggerContext context = (LoggerContext) LogManager.getContext(false);
			context.setConfigLocation(resource.getURI());
            logger.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
	}

	/**
	 * Saves any changes in staffware back to MWDB
	 * Expects staffware to pass the only parameters going to pass on to sp call, 
	 * sp parameter names match staffware field names,
	 * if number of params or names don't match will get sql error
	 * 
	 * @param inputFields, input from staffware
	 */
	private void updateMwdb(List inputFields) throws Exception{
				
        SQLConnection db = MWDBAccess.getDatabaseConnection();
        LoggingExclusion exclude = new LoggingExclusion(); 
        try {
        	
        	HashMap args = new HashMap();
            for(int i = 0; i < inputFields.size(); i++){
    			Field f = (Field)inputFields.get(i);
    			logger.debug("param " + exclude.logNameValue(f.getName(), 
    					f.getValue()));
    			args.put(f.getName(), f.getValue());
    		}
            db.execute("dbo.sfw_PaymentsAndCollectionsFailed", args);
            
        } finally {
        	db.close();
        }
	}
}
