package com.barclays.staffware.plugin;


import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.middleware.brains.BrainsConnectionException;
import com.barclays.middleware.brains.EAR_D;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * This class is called by staffware to delete any earmark that has been added
 * once a payment is declined/has failed/is cancelled
 * @author  Bonner Earle
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 28Feb06  -          EARLB  1.0a     Created
 * 04Jun07  PAT01967   KEMPD  2        Removed logging configuration -- we now
 *                                      use Staffware's own eaijava log4j file.
 * 15May08  PAT02518	EARLEB			Java 6 upgrade changes
 */
public class DeleteEarmark implements ImmediateReleasePluginSDK  {
	
	private static final LoggerConnection logger=new LoggerConnection(DeleteEarmark.class);
	private boolean returnDesc = false;
	private boolean returnCode = false;
	private final String initializationFailed = SwiftParams.initializationFailed(DeleteEarmark.class.getName());
	
	
	/**
	 * Method staffware calls in eaijava step
	 * @param staticData, a string hardcoded in staffware
	 * @param outputFields, a List of staffware Field objects which
	 * 			staffware expects to be returned 
	 * @param inputFields, a List of staffware Field objects which
	 * 			staffware provides (with values)
	 * @return Map, the name value pairs returned to staffware. Should
	 * 			only contain names of fields supplied in outputFields
	 */
	public Map execute(String staticData, List outputFields, List inputFields)
			throws FatalPluginException, NonFatalPluginException {
		HashMap returnValues = new HashMap();
		// check if any return values, as might be called with none
		for(int i = 0; i < outputFields.size(); i++){
			Field f = (Field)outputFields.get(i);
			if(f.getName().equals("STATUS_DESC"))
				returnDesc = true;
			if(f.getName().equals("STATUS_CODE"))
				returnCode = true;
		}
			
		try{
			// the substring is because in staffware this field is 
			// declared as a numeric of length one. So it turns up as "0" or "1.0"
			boolean isOffshore = Integer.parseInt(
					getFieldValue(inputFields, "OFFSHORE_IND").substring(0,1)) == 1;
			// get info required from input param
			EAR_D earD = new EAR_D();
			earD.setCountry(getFieldValue(inputFields, "COUNTRY"));
			earD.setOffshore(isOffshore);
			earD.setAccountNumber(Integer.parseInt(getFieldValue(inputFields, "ORIG_ACC")));
			earD.setBranchId(Integer.parseInt(getFieldValue(inputFields, "ORIG_BRANCH")));
			earD.setAuthCode(Integer.parseInt(getFieldValue(inputFields, "GROUP_ID")));
			earD.setDeviceId(8888);
			earD.setDateAndTime(null);
			// set date and time to be todat with no time element
			earD.setDateAndTimeformat(EAR_D.getBrainsDateFormat());
			logger.debug("initiated delete earmark to brains");
			// execute delete earmark
			try{
				earD.execute();
				logger.debug("executed delete earmark to brains");
				if(returnCode)
					returnValues.put("STATUSCODE", "0");
				if(returnDesc)
					returnValues.put("STATUSDESC", " ");
			}
			catch(BrainsConnectionException e){
				setError(e, returnValues, "1");				
			}
		}
		catch(Exception e){
			// any errors are returned to staffware in name value pair form
			// Staffware will be checking a StatusCode return value to 
			// see if there was an error
			setError(e, returnValues, "-1");
		}
		return returnValues;
	}
	
	private void setError(Exception e, HashMap map, String errorCode){
		String errorMessage = null; 
    	if(e.getMessage()!=null)
			errorMessage = e.getMessage();
		else
			errorMessage = e.toString();
    	
    	logger.error("Error Executing PostPayment. Details: " 
    			+ errorMessage, e);
    	if(returnCode)
			map.put("STATUSCODE", errorCode);
    	if(returnDesc)
			map.put("STATUSDESC", "Error Executing PostPayment. Details: " 
					+ errorMessage);
	}
	
	/**
	 * Will be passed the contents of eaijava properties file in the 
	 * root:/swserver/sw_africa/eaijava/ folder
	 * Will be called by staffware before each execute (unless a 
	 * caching option is selected in staffware) 
	 */
	public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {
		try {
			BrainsSocketConnectionFactory.getInstance().useSecure(properties);
            //DataSourceDirectory.getInstance().configure(properties);
			//Modified by ashish for sql connection
			DataSourceDirectory.getInstance().basePluginDS();
            // load db driver (unsure if necessary)
            //Class.forName(properties.getProperty("db_driver"));
            //LoggerConnection.configureWFL(properties.getProperty("deleteEarmarkLog"));
			// Modified by ashish
			ClassPathResource resource = new ClassPathResource(properties.getProperty("deleteEarmarkLog"));
			LoggerContext context = (LoggerContext) LogManager.getContext(false);
			context.setConfigLocation(resource.getURI());
            logger.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
	}
	
	
	
	/**
	 * find the value of a input field
	 * @param list
	 * @param name
	 * @return
	 */
	private String getFieldValue(List list, String name){
		for(Iterator i = list.iterator(); i.hasNext(); ){
			Field f = (Field)i.next();
			if(f.getName().equalsIgnoreCase(name))
				return f.getValue();
		}
		return null;
	}
}
