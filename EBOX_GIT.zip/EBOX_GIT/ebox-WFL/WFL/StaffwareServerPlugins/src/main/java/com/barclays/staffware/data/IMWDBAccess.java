package com.barclays.staffware.data;

import java.sql.SQLException;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;

/**
 * Interface for accessing the database when forming SWIFT messages
 * 
 * @author LEES
 * 
 */
/*
 * DATE     REFERENCE   WHO     VERSION COMMENTS 
 * ----     ---------   ---     ------- --------
 * 13MAR14  WP654WTX    SL      1.00    Created for mocking data access in junit tests
 * 21NOV14  WP669       SL      1.01    SMxx enhancements
 * 30SEP15  WP668       AK      1.02    Modified code as part of Zambia RTGS payment fix for INC0030143712 
 */
public interface IMWDBAccess {

    /**
     * Method for getting the Correspondent Account Id for message type 103 &
     * 202 only Uses the "iop_GetCorrespAccId" stored procedure
     * 
     * @throws SQLException If SQL connection fails
     */
    public String getCorrespAccId(String tag53b, String paymentType, String instCur, String country, String offshoreInd)
            throws SQLException;

    /**
     * Method for getting the country attribute value for message type 202 only
     * Uses the "csc_getCountryAttributeValue" stored procedure
     * 
     * @param country Country code
     * @param offshoreInd Offshore indicator
     * @return true if output from stored
     * @throws SQLException If SQL connection fails
     */
    public Boolean getCountryAttribute(String country, String offshoreInd, String description) throws SQLException;

    /**
     * Method for getting the new message id for message sending swift message
     * Uses the "MW_NEW_MSGID" stored procedure
     * 
     * @return new message id
     * @throws SQLException if SQL connection fails
     */
    public String getNewMessageId() throws SQLException;

    /**
     * Method for updating the STEPNAME in the staffwarecase table
     * 
     * @param proname
     * @param casenum
     * @param stepname
     * @throws SQLException if SQL connection fails
     */
    public void updateStaffwareStepname(String proname, int casenum, String stepname) throws SQLException;

    /**
     * Method for encoding a 3 character country code to a 2 character code
     * 
     * @param country 3 letter country code
     * @throws SQLException if SQL connection fails
     */
    public String getTargetCountry(String country, int offshoreInd) throws SQLException;

    /**
     * Method for getting the status from the payment and collections table
     * 
     * @param swMainCase
     * @param swMainProc
     * @return status
     * @throws SQLException if SQL connection fails
     */
    public String getPACStatus(int swMainCase, String swMainProc) throws SQLException;

    /**
     * 
     * @param casenum
     * @param proname
     * @param status
     * @param errorCode
     * @param errorMessage
     * @param country
     * @param offshoreInd
     * @param insertProcessStatus
     * @param groupId
     * @throws SQLException
     */
    public void insertSwiftMessageProcessStatus(
            String casenum,
            String proname,
            String status,
            int errorCode,
            String errorMessage,
            String country,
            String offshoreInd,
            String mt199Status,
            int groupId) throws SQLException;

    /**
     * Method returns ItemValue of the tag </br>
     * Can only handle non-repeating tags with only one field
     * 
     * @param datastoreId
     * @param swiftTag (e.g. 70)
     * @param itemName (e.g. Remittance Information)
     * @return ItemValue
     * @throws SQLException
     */
    public String getSwiftItemValue(int datastoreId, String itemName) throws SQLException;

    /**
     * Method returns Datastore Id of the inward payment </br>
     * 
     * @param groupId
     * @return datastoreId
     * @throws SQLException
     */
    public int getDatastoreIdByGroupId(int groupId) throws SQLException;

    /**
     * Method returns senders charges of the tag </br>
     * 
     * @param datastoreId
     * @return
     */
    public Map<Integer, String> getSendersCharges(int datastoreId) throws SQLException;

    /**
     * Method returns a map of SwiftTag and ItemValue given datstoreId
     * 
     * @param datastoreId
     * @return
     * @throws SQLException
     */
    public Map<String, String> getOrderingCustomer(int datastoreId, int groupId) throws SQLException;

    /**
     * Method return the description from MW_RefValue table for given
     * domain,code,country and offshoreind
     * 
     * @param country
     * @param offshoreInd
     * @param domain
     * @param code
     * @return
     * @throws SQLException
     */
    public String getMwRefValueDescription(String country, String offshoreInd, String domain, String code)
            throws SQLException;

    /**
     * Method return the description from MW_RefValue table for domain ACCREC
     * and given account
     * 
     * @param country
     * @param offshoreInd
     * @param account
     * @return
     * @throws SQLException
     */

    public String getMwRefValueACCRECCode(String country, String offshoreInd, String account) throws SQLException;
    
    public Map<String, String> getSwiftMessageProperties(int datastoreId) throws SQLException;
    
    public int getDatastoreIdByCaseDescription(String caseDescription) throws SQLException;

}
