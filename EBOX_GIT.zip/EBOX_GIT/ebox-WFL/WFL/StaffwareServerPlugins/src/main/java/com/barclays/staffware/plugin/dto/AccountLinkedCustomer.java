package com.barclays.staffware.plugin.dto;

import java.io.Serializable;

/**
 * @author MICHAEL
 *
 *	Class to represent an individual account linked customer
 * OLEReplacementPhase3 - Account Details
 */
/*
 * DATE      REFERENCE      WHO           VERSION     COMMENTS
 * ---------   ----------------     ------------   ------------    ---------------------------
 * 05Dec11  OLERP3              MICHAEL    1a                  Created
 * 
 */
public class AccountLinkedCustomer implements Comparable<AccountLinkedCustomer>, Serializable {

	private static final long serialVersionUID = -212441014126452117L;
	
	private Integer customerNumber=-1;
	private String customerName;
	private String proposition;
	private String marketSegment=null;
	private String vatClassification;
	private String chargePackage;
	private String ratePackage;

	public Integer getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(Integer customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProposition() {
		return proposition;
	}

	public void setProposition(String proposition) {
		this.proposition = proposition;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getVatClassification() {
		return vatClassification;
	}

	public void setVatClassification(String vatClassification) {
		this.vatClassification = vatClassification;
	}

	public String getChargePackage() {
		return chargePackage;
	}

	public void setChargePackage(String chargePackage) {
		this.chargePackage = chargePackage;
	}

	public String getRatePackage() {
		return ratePackage;
	}

	public void setRatePackage(String ratePackage) {
		this.ratePackage = ratePackage;
	}

	@Override
	public int compareTo(AccountLinkedCustomer o) {
		int result = this.getCustomerNumber().compareTo(o.getCustomerNumber());
		if(0 == result) {
			if(this.getCustomerName() == null) {
				result = -1;
			}else if(o.getCustomerName() == null) {
				result = 1;
			}else {
				result =  getCustomerName().compareTo(o.getCustomerName());
			}
		}
		if(0 == result) {
			if(this.getProposition() == null) {
				result = -1;
			}else if(o.getProposition() == null) {
				result = 1;
			}else {
				result =  getProposition().compareTo(o.getProposition());
			}
		}
		if(0 == result) {
			if(this.getMarketSegment() == null) {
				result = -1;
			}else if(o.getMarketSegment() == null) {
				result = 1;
			}else {
				result =  getMarketSegment().compareTo(o.getMarketSegment());
			}
		}
		if(0 == result) {
			if(this.getVatClassification() == null) {
				result = -1;
			}else if(o.getVatClassification() == null) {
				result = 1;
			}else {
				result =  getVatClassification().compareTo(o.getVatClassification());
			}
		}
		
		return result;
	}

}
