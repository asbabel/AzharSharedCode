/*
 * AccountSignature.java
 *
 * Created on 01 December 2004, 10:29
 */

package com.barclays.staffware.plugin.dto;

import com.ibm.math.BigDecimal;

import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author  SHARPEP
 */
public class Signature implements Serializable, Comparable {
     
    
    /**
	 * appease the serialisation gods
	 */
	private static final long serialVersionUID = 5674196768086008308L;

	/**
     * Holds value of property account.
     */
    private Account account;
    
    private transient BufferedImage image;
    
    /**
     * Holds value of property accessLevel.
     */
    private int accessLevel;
    
    /**
     * Holds value of property openDate.
     */
    private Date openDate;
    
    /**
     * Holds value of property updateDate.
     */
    private Date updateDate;
    
    
    /**
     * Getter for property account.
     * @return Value of property account.
     */
    public Account getAccount() {
        return this.account;
    }
    
    /**
     * Setter for property account.
     * @param account New value of property account.
     */
    public void setAccount(Account account) {
        this.account = account;
    }
    
    public int compareTo(Object o) {
        if(!(o instanceof Signature)) throw new ClassCastException();
        Integer thisSequenceNumber=new Integer(this.getSequenceNumber());
        Integer thatSequenceNumber=new Integer(((Signature)o).getSequenceNumber());
        return thisSequenceNumber.compareTo(thatSequenceNumber);
    }
    
    /**
     * Getter for property accessLevel.
     * @return Value of property accessLevel.
     */
    public int getAccessLevel() {
        return this.accessLevel;
    }
    
    /**
     * Setter for property accessLevel.
     * @param accessLevel New value of property accessLevel.
     */
    public void setAccessLevel(int accessLevel) {
        this.accessLevel = accessLevel;
    }
    
    /**
     * Getter for property openDate.
     * @return Value of property openDate.
     */
    public Date getOpenDate() {
        return this.openDate;
    }
    
    /**
     * Setter for property openDate.
     * @param openDate New value of property openDate.
     */
    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }
    
    /**
     * Getter for property updateDate.
     * @return Value of property updateDate.
     */
    public Date getUpdateDate() {
        return this.updateDate;
    }
    
    /**
     * Setter for property updateDate.
     * @param updateDate New value of property updateDate.
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
    
    
    /**
     *
     */
    protected void finalize() throws Throwable {
        super.finalize();
        
    }
    
    /**
     * Holds value of property limit.
     */
    private BigDecimal limit;
    
    /**
     * Holds value of property name.
     */
    private String name;
    
    /**
     * Holds value of property updateAuthorisedBy.
     */
    private String updateAuthorisedBy;
    
    /**
     * Holds value of property mandate.
     */
    private String[] mandate={null,null,null};
    
    /**
     * Holds value of property updateUser.
     */
    private String updateUser;
    
    /**
     * Holds value of property isoCur.
     */
    private String isoCur;
    
    /**
     * Holds value of property poaDate.
     */
    private Date poaDate;
    
    /**
     * Holds value of property poaName.
     */
    private String poaName;
    
    /**
     * Holds value of property createAuthorisedBy.
     */
    private String createAuthorisedBy;
    
    /**
     * Holds value of property createDate.
     */
    private Date createDate;
    
    /**
     * Holds value of property sequenceNumber.
     */
    private int sequenceNumber;
    
    /**
     * Holds value of property poaFlag.
     */
    private char poaFlag;
    
    /**
     * Holds value of property recordType.
     */
    private char recordType;
    
        
    /**
     * Getter for property limit.
     * @return Value of property limit.
     */
    public BigDecimal getLimit() {
        return this.limit;
    }
    
    /**
     * Setter for property limit.
     * @param limit New value of property limit.
     */
    public void setLimit(BigDecimal limit) {
        this.limit = limit;
    }
    
    /**
     * Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return this.name;
    }
    
    /**
     * Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Getter for property updateAuthorisedBy.
     * @return Value of property updateAuthorisedBy.
     */
    public String getUpdateAuthorisedBy() {
        return this.updateAuthorisedBy;
    }
    
    /**
     * Setter for property updateAuthorisedBy.
     * @param updateAuthorisedBy New value of property updateAuthorisedBy.
     */
    public void setUpdateAuthorisedBy(String updateAuthorisedBy) {
        this.updateAuthorisedBy = updateAuthorisedBy;
    }
    
    /**
     * Indexed getter for property mandate.
     * @param index Index of the property.
     * @return Value of the property at <CODE>index</CODE>.
     */
    public String getMandate(int index) {
        if(index<0 || (index-1)>=this.mandate.length) return null;
        return this.mandate[index-1];
    }
    
    /**
     * Indexed setter for property mandate.
     * @param index Index of the property.
     * @param mandate New value of the property at <CODE>index</CODE>.
     */
    public void setMandate(int index, String mandate) throws Exception {
        if(index<0 || index>=this.mandate.length) throw new Exception("index should be between 0 and "+(this.mandate.length-1)+" inclusive",null);
        this.mandate[index] = mandate;
    }
    
    /**
     * Getter for property updateUser.
     * @return Value of property updateUser.
     */
    public String getUpdateUser() {
        return this.updateUser;
    }
    
    /**
     * Setter for property updateUser.
     * @param updateUser New value of property updateUser.
     */
    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }
    
    /**
     * Getter for property isoCur.
     * @return Value of property isoCur.
     */
    public String getIsoCur() {
        return this.isoCur;
    }
    
    /**
     * Setter for property isoCur.
     * @param isoCur New value of property isoCur.
     */
    public void setIsoCur(String isoCur) {
        this.isoCur = isoCur;
    }
    
    /**
     * Getter for property poaDate.
     * @return Value of property poaDate.
     */
    public Date getPoaDate() {
        return this.poaDate;
    }
    
    /**
     * Setter for property poaDate.
     * @param poaDate New value of property poaDate.
     */
    public void setPoaDate(Date poaDate) {
        this.poaDate = poaDate;
    }
    
    /**
     * Getter for property poaName.
     * @return Value of property poaName.
     */
    public String getPoaName() {
        return this.poaName;
    }
    
    /**
     * Setter for property poaName.
     * @param poaName New value of property poaName.
     */
    public void setPoaName(String poaName) {
        this.poaName = poaName;
    }
    
    /**
     * Getter for property createAuthorisedBy.
     * @return Value of property createAuthorisedBy.
     */
    public String getCreateAuthorisedBy() {
        return this.createAuthorisedBy;
    }
    
    /**
     * Setter for property createAuthorisedBy.
     * @param createAuthorisedBy New value of property createAuthorisedBy.
     */
    public void setCreateAuthorisedBy(String createAuthorisedBy) {
        this.createAuthorisedBy = createAuthorisedBy;
    }
    
    /**
     * Getter for property createDate.
     * @return Value of property createDate.
     */
    public Date getCreateDate() {
        return this.createDate;
    }
    
    /**
     * Setter for property createDate.
     * @param createDate New value of property createDate.
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    
    /**
     * Getter for property sequenceNumber.
     * @return Value of property sequenceNumber.
     */
    public int getSequenceNumber() {
        return this.sequenceNumber;
    }
    
    /**
     * Setter for property sequenceNumber.
     * @param sequenceNumber New value of property sequenceNumber.
     */
    public void setSequenceNumber(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }
    
    /**
     * Getter for property poaFlag.
     * @return Value of property poaFlag.
     */
    public char getPoaFlag() {
        return this.poaFlag;
    }
    
    /**
     * Setter for property poaFlag.
     * @param poaFlag New value of property poaFlag.
     */
    public void setPoaFlag(char poaFlag) {
        this.poaFlag = poaFlag;
    }
    
    /**
     * Getter for property recordType.
     * @return Value of property recordType.
     */
    public char getRecordType() {
        return this.recordType;
    }
    
    /**
     * Setter for property recordType.
     * @param recordType New value of property recordType.
     */
    public void setRecordType(char recordType)  {
        this.recordType = recordType;
    }
    
    public boolean equals(Object obj) {
        return (compareTo(obj)==0);
    }
    
    /** Creates a new instance of AccountSignature */
    public Signature() {
        super();
    }
    
    /** Creates a new instance of AccountSignature */
    public Signature(final Account account) {
        super();
        this.setAccount(account);
    }
    
    public BufferedImage getImage() {return image;}
    
    public void setImage(BufferedImage value) {image = value;}
    
}
