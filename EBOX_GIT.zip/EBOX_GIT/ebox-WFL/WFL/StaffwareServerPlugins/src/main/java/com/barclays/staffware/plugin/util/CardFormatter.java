package com.barclays.staffware.plugin.util;


/**
 * Provide method that can be used to format the results returned or data sent
 * to the Card system.
 * 
 * @author Matthew Williamson
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 08Mar04  -          MJW    1.0a     Created
 * 07Nov07  PAT02281   KEMPD  1b       Card & PIN (external):
 *                                        added `formatStatus(...)' method.       
 */
public class CardFormatter
{
	/**
         * Extract the brains account number from the account number returned from the 
         * cards system.
         * Is always the last 7 digits
	 * @param account    Account number passed from cards system. This is a
	 * combination of branch and account number with leading zeros
	 * 
	 */
	public static String accountNumberToBrains(String account){
            String returnString = "";
            if (account != null && !account.equals("")) {
                returnString = account.substring(account.length() - 7);
            }
		return returnString;
	}

	/**
         * Extract the brains branch number from the account number returned from the 
         * cards system.
         * Branch always starts at pos 5 and is 2 characters
	 * @param account    Account number passed from cards system. This is a
	 * combination of branch and account number with leading zeros
	 * 
	 */
	public static String branchNumberToBrains(String account){
            String returnString = "";
            if (account != null && !account.equals("")) {
                returnString = account.substring(4,6);
            }
		return returnString;
	}
        
        
        /**
         * Card numbers are returned from the card system with a padding of 3 zeros after the first 6 
         * characters. These zeros must be removed for display purposes.
         * e.g. 4290590001000013283 should be displayed as 4290591000013283 
         * @param fullCardNumber
         */
        public static String formatDisplayCardNumber(String fullCardNumber) {
            String returnString = "";
            if (fullCardNumber != null && !fullCardNumber.equals("")) {
                // check it needs section chopping out
                if(fullCardNumber.length()==19)
                    returnString = fullCardNumber.substring(0,6) + fullCardNumber.substring(9);
                else 
                    returnString = fullCardNumber;
            }
		return returnString;
            
        }
        
        /**
         * Text to display for the given card status.
         */
        public static String formatStatus(
            String status)
        {
            String result;
            if ("C".equals(status))
            {
                result = "Cold";
            }
            else if ("W".equals(status))
            {
                result = "Warm";
            }
            else if ("H".equals(status))
            {
                result = "Hot";
            }
            else
            {
                result = "Unknown";
            }
            return result;
        }
        
        /**
         * Format the expiry date obtained from the card system by inserting
         / a slash between the month and year
         * @param expiryDate
         */
        public static String formatDisplayExpiryDate(String expiryDate) {
            if (expiryDate == null || expiryDate.equals("")) {
                return "";
            } else {
                StringBuffer returnValue = new StringBuffer(expiryDate.substring(2));
                returnValue.append("/").append(expiryDate.substring(0,2));
                return (returnValue == null)? "" : returnValue.toString();            
            }
        }
        
}