package com.barclays.staffware.plugin.kamls;

import com.XAddress.www.Party.Ext.schema.XAddress;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.bean.Country;
import com.barclays.generic.data.bean.RefValueBean;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.kamls.kamlcompositebp.binding.KAMLCompositeBPBindingSOAPStub;
import com.barclays.kamls.managekycprofile.intf.schema.ManageKYC;
import com.barclays.kamls.managekycprofile.intf.schema.ManageKYCResponse;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.dto.Account;
import com.barclays.staffware.plugin.dto.Contact;
import com.barclays.staffware.plugin.dto.Customer;
import com.barclays.staffware.plugin.dto.CustomerEmployment;
import com.barclays.staffware.plugin.util.StringUtils;
import com.barclays.staffware.plugin.util.TokenHelper;
import com.barclays.www.Party.Ext.schema.XAddressGroup;
import com.customobj.www.kamlcustomrelationship.schema.CustomRelationship;
import com.customobj.www.kamlcustomvalue.schema.CustomerValues;
import com.custprod.www.kamlcustomerproduct.schema.CustProd;
import com.custprod.www.kamlcustomerproduct.schema.ProductType;
import com.custstatus.www.kamlcustomerstatus.schema.CdStatusCatTp;
import com.custstatus.www.kamlcustomerstatus.schema.CdStatusTp;
import com.custstatus.www.kamlcustomerstatus.schema.CustStatus;
import com.ibm.www.xmlns.prod.websphere.wcc.common.intf.schema.Control;
import com.ibm.www.xmlns.prod.websphere.wcc.common.schema.Message;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.AddressUsageType;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.AdminSystemType;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.CountyType;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.IdentificationType;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.IndustryType;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.NameUsageType;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.OrganizationName;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.OrganizationType;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.PartyAddress;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.PartyAdminSysKey;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.PartyIdentification;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.PersonName;
import com.ibm.www.xmlns.prod.websphere.wcc.party.schema.PrefixType;
import com.tcvwebservice.schema.barclays.www.CustProfileAttr;
import com.xorg.www.Party.Ext.schema.CdEntityLegalTp;
import com.xorg.www.Party.Ext.schema.CdHighRiskIndustryTp;
import com.xorg.www.Party.Ext.schema.CdSplCustomerTp;
import com.xorg.www.Party.Ext.schema.XOrg;
import com.xperson.www.Party.Ext.schema.CdDesignationTp;
import com.xperson.www.Party.Ext.schema.CdEmploymentTp;
import com.xperson.www.Party.Ext.schema.CdProfessionTp;
import com.xperson.www.Party.Ext.schema.CdSolicitChannelTp;
import com.xperson.www.Party.Ext.schema.XPerson;
import org.apache.axis.AxisFault;
import org.apache.axis.types.UnsignedShort;
import org.apache.axis.utils.XMLUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.regex.Pattern;

import javax.xml.datatype.DatatypeConfigurationException;

import static com.barclays.staffware.plugin.AddCustomerPlugin.STAFFWAREMAP_LOCATION_CODE;
import static com.barclays.staffware.plugin.AddCustomerPlugin.STAFFWAREMAP_USERNAME;

/**
 * KAMLS service helper.
 * 
 * @author Makhaus
 */
/*
 * DATE     REFERENCE   WHO       COMMENTS
 * -------  ----------  --------  ----------------------------------------------
 * 13Mar10	-			Makhaus	  Created.
 * 25Feb11  R001M003    GoodlifW  WP354: Kamls 1.3 update: Pass accounts that 
 * 								  	the customer has open and their  
 * 								  	ProhibitedAccountStatus to kamls.
 * 27Jul11  R002M003    GoodlifW  KAMLS Fix: if the customers occupation is
 * 									invalid then pass "OTHER". 
 * 10Sep13	WP623		Vaibhav	  Code to send individual Customer Contacts to KAMLS
 */
public class KamlsHelper {
	private static final ExecutorService executor = Executors.newCachedThreadPool();

	private static final String[] KAMLS_PRODUCT_TYPES = new String[] {
		"CA", "FNS", "FNU", "IP", "LNS", "LNU", "MF", "SA", "TD", "TF"
		};
	
	private static final String[] KAMLS_RELATIONSHIP_TYPES = new String[] {
		"DIRECT", "SIGNAT", "SIGSH0", "SIGSH1", "SIGSH2", "SIGSH3", "GUARAN", 
		"GUARDI", "POAHOL", "JTACCH"
		};
	private static final LoggerConnection logger = new LoggerConnection(KamlsHelper.class);

	public static HashMap<String, String> callKamlsRiskScoringService(final HashMap<String, Object> customerDetails) throws Message, DatatypeConfigurationException, Exception {
		logger.info("About to call KAMLS with customerDetails="+ customerDetails);

		HashMap<String, String> custRiskDetails = new HashMap<>();
		String riskScore = "";
		String riskLevel = "";
		String kycCompliance = "";
		Calendar cal=null;

		String url = getValue(customerDetails.get("kamlsUrl"));
        logger.info("KAMLS URL =" + url);
		URL endpointURL = new URL(url);

		String propositionType  = getValue(customerDetails.get("propositionType"));
		if("P".equalsIgnoreCase(propositionType) || "S".equalsIgnoreCase(propositionType)) {
			XPerson xp = new XPerson();
			CustomerValues[] cvalues =
				new CustomerValues[1];
			PartyAdminSysKey [] pask = new PartyAdminSysKey[1];
			pask[0]= new PartyAdminSysKey();
			pask[0].setAdminSysPartyId(getValue(customerDetails.get("customerNumber")));
			logger.info("customerNumber123--->"+getValue(customerDetails.get("customerNumber")));
			AdminSystemType ast = new AdminSystemType();
			String scEBoxCountry[] = (String[]) customerDetails.get("eBoxCountryName");
			ast.set_value(scEBoxCountry[0]);
			pask[0].setAdminSystemType(ast);
			xp.setAdminContEquiv(pask);

			PersonName[] pn = new PersonName[1];
			pn[0] = new PersonName();
			NameUsageType nut = new NameUsageType();
			nut.set_value("Individual Name");
			pn[0].setNameUsage(nut);
			pn[0].setGivenNameOne(getValue(customerDetails.get("firstName")));
			pn[0].setLastName(getValue(customerDetails.get("familyName")));
			PrefixType prefixtype = new PrefixType();
			prefixtype.set_value(getValue(customerDetails.get("title")));
			pn[0].setPrefix(prefixtype);
			xp.setName(pn);

			com.ibm.www.xmlns.prod.websphere.wcc.party.schema.CountryType ct =
				new com.ibm.www.xmlns.prod.websphere.wcc.party.schema.CountryType();
			ct.set_value(getValue(customerDetails.get("nationality")));
			xp.setCitizenship(ct);

			com.xperson.www.Party.Ext.schema.CountryType cor =
				new com.xperson.www.Party.Ext.schema.CountryType();
			cor.set_value(getValue(customerDetails.get("residency")));
			xp.setCountryOfResidence(cor);

			xp.setBirthDate((Date)(customerDetails.get("contactDateOfBirth")));

			PartyAddress[] customerContactsForKAMLS =
				(PartyAddress[]) customerDetails.get("customerContactsForKAMLS");
			xp.setAddress(customerContactsForKAMLS);

			cvalues[0] = new CustomerValues();
			cvalues[0].setExpectedTransactionToCountriesValue((String[])
					customerDetails.get("expectedTransToCountries"));
			xp.setCustomerValuesBObj(cvalues[0]);

			String scEmpType = getValue(customerDetails.get("employmentType"));
			CdEmploymentTp emptype = new CdEmploymentTp();
			emptype.set_value(scEmpType);
			xp.setEmployment(emptype);

			if("MINOR".equalsIgnoreCase(scEmpType)){
				xp.setMinor("Yes");
			}else {
				xp.setMinor("No");
			}

			xp.setProfession(getProfessionTp(customerDetails));

			com.xperson.www.Party.Ext.schema.IndustryType itype =
				new com.xperson.www.Party.Ext.schema.IndustryType();
			itype.set_value("".equalsIgnoreCase(getValue(customerDetails.get("empNatureOfBusiness"))) ?
					"NA" : getValue(customerDetails.get("empNatureOfBusiness")));
			xp.setBusinessIndustry(itype);

			// WP354 CR 1.3
			ArrayList<CustProd> prods = new ArrayList<CustProd>();
			ArrayList<String> productTypes = new ArrayList<String>();

			populateActualProducts(customerDetails, prods, productTypes);
			
			//WP812-Amit
			String detailedProductsStr[] = (String[]) customerDetails.get("detailedProductsIDsArr");			
				for(int i=0;i<detailedProductsStr.length;i++) {	
					if(!StringUtils.isNullOrEmpty(detailedProductsStr[i])){
						prods= populateDetailedProductTypes(detailedProductsStr[i], prods,productTypes,getValue(customerDetails.get("customerNumber")));
						CustProd[] custProds = new CustProd[prods.size()];
						xp.setCustProdBObj(prods.toArray(custProds));
					} else {				
						prods = populateIntendedProductTypes(customerDetails, prods, 
								productTypes, true);
						CustProd[] custProds = new CustProd[prods.size()];
						xp.setCustProdBObj(prods.toArray(custProds));
						
					}				
				
				}

			CdSolicitChannelTp solicitation = new CdSolicitChannelTp();
			solicitation.set_value(getValue(customerDetails.get("solicitationChannel")));
			xp.setSolicitationChannel(solicitation);

			CustStatus cs[] = new CustStatus[3];

			CdStatusCatTp cdstatuscategorytype  = new CdStatusCatTp();
			cdstatuscategorytype.set_value("Customer Geographic Status");
			CdStatusTp statustype = new CdStatusTp();
			statustype.set_value(getValue(customerDetails.get("geographicalStatus")));

			cs[0] = new CustStatus();
			cs[0].setCustStatusCategory(cdstatuscategorytype);
			cs[0].setCustStatus(statustype);

			CdStatusCatTp cdstatuscategorytype2  = new CdStatusCatTp();
			cdstatuscategorytype2.set_value("PEP Status");
			CdStatusTp statustype2 = new CdStatusTp();
			statustype2.set_value("N".equalsIgnoreCase(getValue(customerDetails.get("pepInd")))
					? "Non-PEP" : "PEP");

			cs[1] = new CustStatus();
			cs[1].setCustStatusCategory(cdstatuscategorytype2);
			cs[1].setCustStatus(statustype2);

			cs[2] = new CustStatus();
			CdStatusCatTp cdstatuscategorytype3  = new CdStatusCatTp();
			cdstatuscategorytype3.set_value("PROHIBITED Status");
			CdStatusTp statustype3 = new CdStatusTp();
			statustype3.set_value((getValue(customerDetails.get("prohibitedAccountStatus"))));
			cs[2].setCustStatusCategory(cdstatuscategorytype3);
			cs[2].setCustStatus(statustype3);
			xp.setCustStatusBObj(cs);

			xp.setIDASegLimInd("NOTEXC".equalsIgnoreCase(getValue(customerDetails.get("initialDeposit")))
					? "No" : "Yes");
			xp.setECVSegLimInd("EXCNO".equalsIgnoreCase(getValue(customerDetails.get("expectedCashVolume")))
					? "No" : "Yes");

			ManageKYC kycstatus = new ManageKYC();
			kycstatus.setCustomerID(getValue(customerDetails.get("customerNumber")));
			kycstatus.setKYCComplianceStatus(getValue(customerDetails.get("kycStatus")));

			//Add all related customers
			addRelatedCustomers(xp, customerDetails);

			PartyIdentification pidentification[] = new PartyIdentification[3];
			
			//WP812-Amit
			if(customerDetails.get("idCardExpiry")!=null && !getValue(customerDetails.get("idCardExpiry")).equals("")){
				Date idCardExpiryDate=new SimpleDateFormat("dd/MM/yyyy").parse(getValue(customerDetails.get("idCardExpiry"))); 
				cal=Calendar.getInstance();
				cal.setTime(idCardExpiryDate);
			}

			IdentificationType idtypepassport = new IdentificationType();
			idtypepassport.set_value("Passport Number");
			pidentification[0] = new PartyIdentification();
			pidentification[0].setType(idtypepassport);
			pidentification[0].setNumber(getValue(customerDetails.get("passportNumber")));
			if(cal!=null && !getValue(customerDetails.get("passportNumber")).equals(""))
			pidentification[0].setExpiryDate(cal);

			IdentificationType idtypedrivinglicence = new IdentificationType();
			idtypedrivinglicence.set_value("Driver's Licence Number");
			pidentification[1] = new PartyIdentification();
			pidentification[1].setType(idtypedrivinglicence);
			pidentification[1].setNumber(
			getValue(customerDetails.get("drivingLicenceNumber")));
			if(cal!=null && !getValue(customerDetails.get("drivingLicenceNumber")).equals(""))
			pidentification[1].setExpiryDate(cal);

			IdentificationType idtypeIdcard = new IdentificationType();
			idtypeIdcard.set_value("National Id");
			pidentification[2] = new PartyIdentification();
			pidentification[2].setType(idtypeIdcard);
			pidentification[2].setNumber(getValue(customerDetails.get("idCardNumber")));
			if(cal!=null && !getValue(customerDetails.get("idCardNumber")).equals(""))
			pidentification[2].setExpiryDate(cal);
			
			xp.setIdentification(pidentification);

			xp.setStaffInd("S".equalsIgnoreCase(propositionType)?"Yes":"No");
			xp.setRMName(getValue(customerDetails.get("referStreamName")));
			xp.setRMId(getValue(customerDetails.get("referStream")));
			xp.setBranch(getValue(customerDetails.get("customerbranch")));

			CdDesignationTp zDesignation = new CdDesignationTp();
			zDesignation.set_value(getValue(customerDetails.get("designation")));
			xp.setDesignation(zDesignation);

			if (getValue(customerDetails.get("designation")).equals("OTHER")) {
				xp.setDesignationOthers("Others");
			}

			//WP812-Amit			
			setRBAFieldsForIndividual(xp,customerDetails);
			
			// Call the KAMLS service here
			Control control = new Control();
			control.setRequesterName("eBox_" + getValue(customerDetails.get("eBoxUserCountryCode")));
			control.setRequesterRole(new String[]{getValue(customerDetails.get("eBoxUserCountryCode") + "_SYSTEM")});
			control.setRequestId(Long.parseLong(customerDetails.get("RequestId").toString()));
			control.setRequesterLanguage(new UnsignedShort(100));
			
			Callable<ManageKYCResponse> kamlsTask = new Callable<ManageKYCResponse>() {
				@Override
				public ManageKYCResponse call() throws Exception {
					logger.info("Connecting to KAMLS URL now...");
					KAMLCompositeBPBindingSOAPStub stub = new KAMLCompositeBPBindingSOAPStub(endpointURL,null);
					ManageKYCResponse kycresponse = null;
					try {
						kycresponse = stub.manageIndividualKYCProfile(control, xp);
					} catch (Message message) {
						throw new KamlsException(message);
					}
					return kycresponse;
				}
			};

			Future<ManageKYCResponse> task = executor.submit(kamlsTask);

			ManageKYC mkyc = getManageKYC(task);

			riskScore = mkyc.getRiskScore();
			riskLevel = mkyc.getRiskLevel();
			kycCompliance = mkyc.getKYCComplianceStatus();
			logger.info("Response from KAMLS: riskScore=" + riskScore+ "; riskLevel="+ riskLevel + "; kycCompliance="+ kycCompliance);

		}
		else
		{
			XOrg xo = new XOrg();

			PartyAdminSysKey [] pask = new PartyAdminSysKey[1];
			pask[0]= new PartyAdminSysKey();
			pask[0].setAdminSysPartyId(getValue(customerDetails.get("customerNumber")));
			AdminSystemType ast = new AdminSystemType();
			String scEBoxCountry[] = (String[]) customerDetails.get("eBoxCountryName");
			ast.set_value(scEBoxCountry[0]);
			pask[0].setAdminSystemType(ast);
			xo.setAdminContEquiv(pask);

			OrganizationName oname[] = new OrganizationName[2];
			oname[0] = new OrganizationName();
			oname[0].setName(getValue(customerDetails.get("companyName")));
			NameUsageType nut = new NameUsageType();
			nut.set_value("Registered Name");
			oname[0].setNameUsage(nut);
			oname[1] = new OrganizationName();
			oname[1].setName(getValue(customerDetails.get("tradingName")));
			NameUsageType nut1 = new NameUsageType();
			nut1.set_value("Trading/Brand Name");
			oname[1].setNameUsage(nut1);

			xo.setName(oname);

			PartyIdentification pidentification[] = new PartyIdentification[1];
			pidentification[0] = new PartyIdentification();
			IdentificationType itype = new IdentificationType();
			itype.set_value("UN");
			pidentification[0].setType(itype);
			pidentification[0].setNumber(getValue(customerDetails.get("companyRegNo")));
			xo.setIdentification(pidentification);

			OrganizationType otype = new OrganizationType();
			otype.set_value(getValue(customerDetails.get("entityType")));
			xo.setOrganizationType(otype);

			CdEntityLegalTp legaltype = new CdEntityLegalTp();
			legaltype.set_value(getValue(customerDetails.get("businessType")));
			xo.setEntityLegal(legaltype);

			IndustryType indtype = new IndustryType();
			indtype.set_value((String)customerDetails.get("natureOfBusiness"));
			xo.setIndustry(indtype);

			Calendar calendar = Calendar.getInstance();
			calendar.setTime((Date)(customerDetails.get("businessEstablishedDate")));
			xo.setDateOfRegistration(calendar);

			PartyAddress pa[] = new PartyAddress[2];
			pa[0] = new PartyAddress();
			XAddress addr = new XAddress();
			addr.setAddressLineOne(getValue(customerDetails.get("addressFirstLine")));
			addr.setBoxId(getValue(customerDetails.get("poBoxDetails")));
			addr.setCity(getValue(customerDetails.get("townCity")));
			addr.setZipPostalCode(getValue(customerDetails.get("postcodeZip")));
			CountyType countytype= new CountyType();
			countytype.set_value(getValue(customerDetails.get("districtRegion")));
			addr.setCounty(countytype);

			com.xorg.www.Party.Ext.schema.CountryType cor =
				new com.xorg.www.Party.Ext.schema.CountryType();
			cor.set_value(getValue(customerDetails.get("countryOfRegistration")));
			xo.setCountryOfRegistration(cor);

			com.ibm.www.xmlns.prod.websphere.wcc.party.schema.CountryType ctype =
				new com.ibm.www.xmlns.prod.websphere.wcc.party.schema.CountryType();
			ctype.set_value(getValue(customerDetails.get("countryOfRegistration")));
			addr.setCountry(ctype);
			pa[0].setAddress(addr);
			AddressUsageType aut = new AddressUsageType();
			aut.set_value("Mailing Address");
			pa[0].setUsage(aut);

			pa[1] = new PartyAddress();
			pa[1].setAddress(addr);
			AddressUsageType aut1 = new AddressUsageType();
			aut1.set_value("Registered Address");
			pa[1].setUsage(aut1);

			xo.setAddress(pa);

			CustomerValues cvalues =
				new CustomerValues();
			cvalues.setCountriesOfOperationsCode(
					(String[])customerDetails.get("countriesOfOperations"));
			cvalues.setCountriesTradedWithCode(
					(String[])customerDetails.get("countriesTradedWith"));

			xo.setCustomerValuesBObj(cvalues);

			// WP354 CR 1.3
			ArrayList<CustProd> prods = new ArrayList<CustProd>();
			ArrayList<String> productTypes = new ArrayList<String>();
			
			populateActualProducts(customerDetails, prods, productTypes);
			
			//WP812-Amit
			String detailedProductsStr[] = (String[]) customerDetails.get("detailedProductsIDsArr");			
				for(int i=0;i<detailedProductsStr.length;i++) {	
					if(!StringUtils.isNullOrEmpty(detailedProductsStr[i])){
						prods= populateDetailedProductTypes(detailedProductsStr[i], prods,productTypes,getValue(customerDetails.get("customerNumber")));
						CustProd[] custProds = new CustProd[prods.size()];
						xo.setCustProdBObj(prods.toArray(custProds));
					} else {				
						prods = populateIntendedProductTypes(customerDetails, prods, 
								productTypes, true);
						CustProd[] custProds = new CustProd[prods.size()];
						xo.setCustProdBObj(prods.toArray(custProds));
						
					}				
				
				}

			com.xorg.www.Party.Ext.schema.CdSolicitChannelTp solicitation =
				new com.xorg.www.Party.Ext.schema.CdSolicitChannelTp();
			solicitation.set_value(getValue(customerDetails.get("solicitationChannel")));
			xo.setSolicitationChannel(solicitation);

			CustStatus cs[] = new CustStatus[3];
			cs[0] = new CustStatus();
			CdStatusCatTp cdstatuscategorytype  = new CdStatusCatTp();
			cdstatuscategorytype.set_value("Customer Geographic Status");
			CdStatusTp statustype = new CdStatusTp();
			statustype.set_value(getValue(customerDetails.get("operatingStatus")));
			cs[0].setCustStatusCategory(cdstatuscategorytype);
			cs[0].setCustStatus(statustype);


			cs[1] = new CustStatus();
			CdStatusCatTp cdstatuscategorytype2  = new CdStatusCatTp();
			cdstatuscategorytype2.set_value("PEP Status");
			CdStatusTp statustype2 = new CdStatusTp();
			statustype2.set_value("N".equalsIgnoreCase(getValue(customerDetails.get("pepInd")))
					? "Non-PEP" : "PEP");
			cs[1].setCustStatusCategory(cdstatuscategorytype2);
			cs[1].setCustStatus(statustype2);

			cs[2] = new CustStatus();
			CdStatusCatTp cdstatuscategorytype3  = new CdStatusCatTp();
			cdstatuscategorytype3.set_value("PROHIBITED Status");
			CdStatusTp statustype3 = new CdStatusTp();
			statustype3.set_value((getValue(customerDetails.get("prohibitedAccountStatus"))));
			cs[2].setCustStatusCategory(cdstatuscategorytype3);
			cs[2].setCustStatus(statustype3);

			xo.setCustStatusBObj(cs);

			xo.setIDASegLimInd(
					"NOTEXC".equalsIgnoreCase(getValue(customerDetails.get("initialDeposit")))
					? "No" : "Yes");
			xo.setECVSegLimInd(
					"EXCNO".equalsIgnoreCase(getValue(customerDetails.get("expectedCashVolume")))
					? "No" : "Yes");

			ManageKYC kycstatus = new ManageKYC();
			kycstatus.setCustomerID(getValue(customerDetails.get("customerNumber")));
			kycstatus.setKYCComplianceStatus(getValue(customerDetails.get("kycStatus")));

			//Add all related customers
			addRelatedCustomers(xo, customerDetails);

			xo.setComplexStructure(
					"Y".equalsIgnoreCase(getValue(customerDetails.get("complexStructure")))
					? "Yes" : "No");

			xo.setRMName(getValue(customerDetails.get("referStreamName")));
			xo.setRMId(getValue(customerDetails.get("referStream")));

			xo.setBranch(getValue(customerDetails.get("customerbranch")));
			
			//WP812-Amit			
			setRBAFieldsForEntity(xo,customerDetails);
			
			// Call the KAMLS service here
			Control control = new Control();
			control.setRequesterName("eBox_" + getValue(customerDetails.get("eBoxUserCountryCode")));
			control.setRequesterRole(
					new String[]{getValue(customerDetails.get("eBoxUserCountryCode") + "_SYSTEM")});
			control.setRequestId(
					Long.parseLong(customerDetails.get("RequestId").toString()));
			control.setRequesterLanguage(new UnsignedShort(100));

			
			
			Callable<ManageKYCResponse> kamlsTask = new Callable<ManageKYCResponse>() {
				@Override
				public ManageKYCResponse call() throws Exception {
					logger.info("Connecting to KAMLS URL now...");
					KAMLCompositeBPBindingSOAPStub stub = new KAMLCompositeBPBindingSOAPStub(endpointURL,null);
					ManageKYCResponse kycresponse = null;
					try {
						kycresponse = stub.manageEntityKYCProfile(control, xo);
					} catch (Message message) {
						throw new KamlsException(message);
					}
					return kycresponse;
				}
			};

			Future<ManageKYCResponse> task = executor.submit(kamlsTask);

			ManageKYC mkyc = getManageKYC(task);

			riskScore = mkyc.getRiskScore();
			riskLevel = mkyc.getRiskLevel();
			kycCompliance = mkyc.getKYCComplianceStatus();

            logger.info("Response from KAMLS: riskScore=" + riskScore+ "; riskLevel="+ riskLevel + "; kycCompliance="+ kycCompliance);
		}

		custRiskDetails.put("riskScore", riskScore);
		custRiskDetails.put("riskLevel", getRiskLevel(riskLevel));
		custRiskDetails.put("kycCompliance", kycCompliance);

		return custRiskDetails ;
	}

	private static ManageKYC getManageKYC(Future<ManageKYCResponse> task) throws KamlsException {
		return getManageKYCResponse(task).getResponse();
	}

	private static ManageKYCResponse getManageKYCResponse(Future<ManageKYCResponse> task) throws KamlsException {
		ManageKYCResponse mkyc;
		try {
			mkyc = task.get(2, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			throw new KamlsException(e);
		} catch (ExecutionException e) {
			throw new KamlsException("Error calling KAMLS", e);
		} catch (TimeoutException e) {
			throw new KamlsException("Timeout calling KAMLS", e);
		} finally {
			task.cancel(true);
		}
		return mkyc;
	}

	/**
	 * Method to call KAMLS service before customer authorisation
	 * @param customerDetails
	 * @return HashMap which returns RiskScore, RiskLevel, KycCompliance
	 * @throws Message, Exception
	 */
	public static HashMap<String, String> callsKamlsKYCCompliance(HashMap<String, Object> customerDetails) throws Message, Exception {
		HashMap<String, String> custRiskDetails = new HashMap<String, String>();
		ManageKYCResponse kycresponse = null;

		String url = getValue(customerDetails.get("kamlsUrl"));
		URL endpointURL = new URL(url);
		
		// Prepare the kamls service.
		Control control = new Control();
		control.setRequesterName("eBox_" + getValue(customerDetails.get("eBoxUserCountryCode")));
		control.setRequesterRole(
				new String[]{getValue(customerDetails.get("eBoxUserCountryCode") + "_SYSTEM")});
		control.setRequestId(
				Long.parseLong(customerDetails.get("RequestId").toString()));
		control.setRequesterLanguage(new UnsignedShort(100));
		KAMLCompositeBPBindingSOAPStub stub = 
			new KAMLCompositeBPBindingSOAPStub(endpointURL,null);
		
		PartyAdminSysKey [] pask = new PartyAdminSysKey[1];
		pask[0]= new PartyAdminSysKey();
		pask[0].setAdminSysPartyId(
				customerDetails.get("customerNumber").toString());
		AdminSystemType ast = new AdminSystemType();
		String scEBoxCountry[] = 
			(String[]) customerDetails.get("eBoxCountryName");
		ast.set_value(scEBoxCountry[0]);
		pask[0].setAdminSystemType(ast); 
		
		String propositionType  = getValue(customerDetails.get("propositionType"));
		if ("P".equalsIgnoreCase(propositionType) || "S".equalsIgnoreCase(propositionType)) {
			XPerson xp = new XPerson();
			
			xp.setAdminContEquiv(pask);
			
			CustStatus cs[] = new CustStatus[1];
			cs[0] = new CustStatus();
			CdStatusCatTp cdstatuscategorytype2  = new CdStatusCatTp();
			cdstatuscategorytype2.set_value("Manual KYC Compliance Status");
			CdStatusTp statustype2 = new CdStatusTp();
			statustype2.set_value("Yes");
			cs[0].setCustStatusCategory(cdstatuscategorytype2);
			cs[0].setCustStatus(statustype2);
			xp.setCustStatusBObj(cs);
			
			xp.setBranch(getValue(customerDetails.get("customerbranch")));
			
			// Call the KAMLS service here

			Callable<ManageKYCResponse> kamlsTask = new Callable<ManageKYCResponse>() {
				@Override
				public ManageKYCResponse call() throws Exception {
					logger.info("Connecting to KAMLS URL now...");
					ManageKYCResponse kycresponse = null;
					try {
						kycresponse = stub.manageIndividualKYCProfile(control, xp);
					} catch (Message message) {
						throw new KamlsException(message);
					}
					return kycresponse;
				}
			};

			Future<ManageKYCResponse> task = executor.submit(kamlsTask);

			kycresponse = getManageKYCResponse(task);

			logger.info("Response from KAMLS: "+ kycresponse);
		} else {
			
			XOrg xo = new XOrg();

			xo.setAdminContEquiv(pask);

			CustStatus cs[] = new CustStatus[1];
			cs[0] = new CustStatus();
			CdStatusCatTp cdstatuscategorytype2  = new CdStatusCatTp();
			cdstatuscategorytype2.set_value("Manual KYC Compliance Status");
			CdStatusTp statustype2 = new CdStatusTp();
			statustype2.set_value("Yes");
			cs[0].setCustStatusCategory(cdstatuscategorytype2);
			cs[0].setCustStatus(statustype2);
			xo.setCustStatusBObj(cs);
			xo.setBranch(getValue(customerDetails.get("customerbranch")));
			
			// Call the KAMLS service here

			Callable<ManageKYCResponse> kamlsTask = new Callable<ManageKYCResponse>() {
				@Override
				public ManageKYCResponse call() throws Exception {
					logger.info("Connecting to KAMLS URL now...");
					ManageKYCResponse kycresponse = null;
					try {
						kycresponse = stub.manageEntityKYCProfile(control, xo);
					} catch (Message message) {
						throw new KamlsException(message);
					}
					return kycresponse;
				}
			};

			Future<ManageKYCResponse> task = executor.submit(kamlsTask);
			kycresponse = getManageKYCResponse(task);

			logger.info("Response from KAMLS: "+ kycresponse);
		}
		
		ManageKYC mkyc = kycresponse.getResponse();
		
		custRiskDetails.put("riskScore", mkyc.getRiskScore());
		custRiskDetails.put("riskLevel", getRiskLevel(mkyc.getRiskLevel())); 
		custRiskDetails.put("kycCompliance", mkyc.getKYCComplianceStatus());
		
		return custRiskDetails;
	}
	
	/**
	 * Returns a CdProfessionTp describing the occupation.
	 * 
	 * If the occupation does not exist in the drop down then pass OTHER.
	 * If the occupation is not filled in then passes NA.
	 * @throws DataAccessException 
	 * @throws SQLException 
	 **/
	protected static CdProfessionTp getProfessionTp(
			HashMap<String, Object>  customerDetails)
		throws SQLException, DataAccessException 
	{
		CdProfessionTp proftype = new CdProfessionTp();
		
		if ("".equalsIgnoreCase(getValue(customerDetails.get("empJobTitle")))) {
			// If the occupation is not set then pass not applicable.
			proftype.set_value("NA");
		} else {
			Map<String, String> occupations = TokenHelper.getMWRefValues(
					customerDetails.get("ISOCode").toString(), 
					Boolean.parseBoolean(customerDetails.get("offshore").toString()), 
					"OCCUP", 
					null);
			
			if (occupations.containsKey(customerDetails.get("empJobTitle"))) {
				proftype.set_value(getValue(customerDetails.get("empJobTitle")));
			} else {
				// If the occupation is not valid in the drop down then pass OTHER.
				// This happens because historically: the drop down used to be a
				// free text field, some customers still exist in brains with 
				// free text values.
				proftype.set_value("OTHER");
			}
		}
		
		return proftype;
	}
	
	
	/**
	 * Updates prods with details of each of the accounts that the customer  
	 * actually has open. 
	 * @param customerDetails
	 * @param prods
	 */
	protected static void populateActualProducts(
			HashMap<String, Object> customerDetails, 
			ArrayList<CustProd> prods, 
			ArrayList<String> productTypes) {
		
		@SuppressWarnings("unchecked")
		ArrayList<HashMap<String, String>> list = 
			(ArrayList<HashMap<String, String>>)customerDetails.get("accountsList");
		
		for (int i = 0; i < list.size(); i++) {
			HashMap<String, String> account = list.get(i);
			ProductType ptype = new ProductType();
			CustProd cprod = new CustProd();
			
			String productType = account.get("KAMLS_PRODUCT_TYPE");
			String accNumber = account.get("BRANCH_AND_ACCOUNT_NUMBER");
			
			if (ArrayUtils.contains(KAMLS_PRODUCT_TYPES, productType) && 
					!isDuplicateAccNumber(accNumber, prods)) {
				productTypes.add(productType);
				ptype.set_value(productType);
				cprod.setProd(ptype);
				cprod.setAcctNumber(accNumber);
				cprod.setAcctStatusDesc("Open");
				prods.add(cprod);
			}
		}
	}
	
	// Avoid sending duplicate account numbers to KAMLS.
	// KAMLS would return an error ("Update of the following failed: Agreement�.)
	private static boolean isDuplicateAccNumber (String accNumber,
			ArrayList<CustProd> prods) {
		if (accNumber  == null || "".equals(accNumber)) {
			return false;
		}
		for (CustProd custProd : prods) {
			if (accNumber.equals(custProd.getAcctNumber())) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Gets an ArrayList of CustProd objects for each of the products which the 
	 * customer intends to open, but hasn't actually got open. 
	 * @param customerDetails
	 * @return ArrayList<CustProd>
	 */
	protected static ArrayList<CustProd> populateIntendedProductTypes(
			HashMap<String, Object> customerDetails,
			ArrayList<CustProd> prodDetail,
			ArrayList<String> productTypes, 
			boolean isIndividual) {
		setProductType(customerDetails, "currentAccount", "CA", 
				prodDetail, productTypes);
		setProductType(customerDetails, "invMgmt", "MF", 
				prodDetail, productTypes);
		setProductType(customerDetails, "savingAccount", "SA",
				prodDetail, productTypes);
		setProductType(customerDetails, "termDeposit", "TD",
				prodDetail, productTypes);
		
		if (isIndividual) {
			setProductType(customerDetails, "securedLoanOrFinancing", "LNS", 
					prodDetail, productTypes);
			setProductType(customerDetails, "unsecuredLoanOrFinancing", "LNU", 
					prodDetail, productTypes);
			setProductType(customerDetails, "tradePlanOrProducts", "IP", 
					prodDetail, productTypes);
		} else {
			setProductType(customerDetails, "securedLoanOrFinancing", "FNS", 
					prodDetail, productTypes);
			setProductType(customerDetails, "unsecuredLoanOrFinancing", "FNU",
					prodDetail, productTypes);
			setProductType(customerDetails, "tradePlanOrProducts", "TF",
					prodDetail, productTypes);
		}
		
		return prodDetail;
	}
	
	/**
	 * Gets an ArrayList of CustProd objects for each of the products which the 
	 * detailed product to open, but hasn't actually got open. 
	 * @param customerDetails
	 * @param prodDetail
	 * @param productTypes
	 * @return ArrayList<CustProd>
	 */
	protected static ArrayList<CustProd> populateDetailedProductTypes(
			String kamlsProductCode,
			ArrayList<CustProd> prodDetail,
			ArrayList<String> productTypes, 
			String customerNumber) {			
			
			ProductType ptype = new ProductType();
			CustProd cprod = new CustProd();
			ptype.set_value(kamlsProductCode);
			
			// pass a dummy account number.
			if(kamlsProductCode!=null && !kamlsProductCode.equals("")) {
				cprod.setAcctNumber(customerNumber + kamlsProductCode.substring(0, 2));
			} else {
				 cprod.setAcctNumber(customerNumber);
			}
			
			if (!productTypes.contains(kamlsProductCode)) {
				// We intend to open an account of this type.
				cprod.setAcctStatusDesc("Open");
			} else {
				// We have opened an actual account of this type, close the intended.
				cprod.setAcctStatusDesc("Closed");
			}

			cprod.setProd(ptype);
			prodDetail.add(cprod);
			
		
		return prodDetail;
	}
	
	/**
	 * Adds the product type to the list if the customer intends to open it.
	 * @param customerDetails
	 * @param key
	 * @param kamlsProductCode
	 * @param prodDetail
	 */
	protected static void setProductType(
			HashMap<String, Object> customerDetails, 
			String key, String kamlsProductCode, 
			ArrayList<CustProd> prodDetail,
			ArrayList<String> productTypes) {
		String KeyValue = getValue(customerDetails.get(key));		
		
		if(!"".equals(KeyValue) && !"0".equals(KeyValue)){
			ProductType ptype = new ProductType();
			CustProd cprod = new CustProd();			
			ptype.set_value(kamlsProductCode);
			
			// pass a dummy account number.
			cprod.setAcctNumber(getIntendedAccountNumber(
					getValue(customerDetails.get("customerNumber")),
					kamlsProductCode));
			
			if (!productTypes.contains(kamlsProductCode)) {
				// We intend to open an account of this type.
				cprod.setAcctStatusDesc("Open");
			} else {
				// We have opened an actual account of this type, close the intended.
				cprod.setAcctStatusDesc("Closed");
			}

			cprod.setProd(ptype);
			prodDetail.add(cprod);
		}
	}
	
	/**
	 * Constructs a dummy account number for an intended account. 
	 **/
	private static String getIntendedAccountNumber(
			String customerNumber, 
			String kamlsProductCode) {
		Integer keyNumber = 0;
		
		for (int i = 0; i < KAMLS_PRODUCT_TYPES.length; i++) {
			if (kamlsProductCode.equals(KAMLS_PRODUCT_TYPES[i])) {
				keyNumber = (i + 1);
			}
		}
		
		return customerNumber + StringUtils.padLeft(keyNumber.toString(), '0', 2);
	}
	
	/**
	 * Adding related customers
	 * @param xp
	 * @param customerDetails
	 */
	protected static void addRelatedCustomers(
			XPerson xp, 
			HashMap<String, Object> customerDetails){
		CustomRelationship[] customRelationship = 
			getCustomRelationship(customerDetails);
		
		if (customRelationship != null){
			xp.setCustomRelationshipBObj(customRelationship); 
		}
	}
	
	/**
	 * Adding related customers
	 * @param xo
	 * @param customerDetails
	 */
	protected static void addRelatedCustomers(
			XOrg xo, 
			HashMap<String, Object> customerDetails) {
		
		CustomRelationship[] customRelationship = 
			getCustomRelationship(customerDetails);
		
		if (customRelationship != null){
			xo.setCustomRelationshipBObj(customRelationship); 
		}
	}
	
	/**
	 * Returns an array of CustomRelationship objects, if any kamls recognised 
	 * customer relationships exist, or null.
	 * @param customerDetails
	 */
	private static CustomRelationship[] getCustomRelationship(
			HashMap<String, Object> customerDetails){
		CustomRelationship[] customRelationship = null;
		
		int[] relatedCustomerNumbers = 
			(int[])customerDetails.get("relatedCustomerNumbers");
		String[] relatedCustomerTypes = 
			(String[]) customerDetails.get("relatedCustomerTypes");
		String[] inverseRelatedCustomerTypes = 
			(String[]) customerDetails.get("inverseRelatedCustomerTypes");

		int numOfRelatedCustomers = relatedCustomerNumbers.length;
		ArrayList<String> relatedCustomers = new ArrayList<String>();
		
		for (int i = 0; i < numOfRelatedCustomers; i++) {
			String relatedCustomerType = getValue(relatedCustomerTypes[i]) 
					 + "-" + getValue(inverseRelatedCustomerTypes[i]);
					 
			if (isValidKamlsRelatedCustomer(relatedCustomerType)){
				relatedCustomers.add(getValue(relatedCustomerNumbers[i]) 
						+ "/" + relatedCustomerType); 
			}
		}
		
		//Check the map now and set it to object
		int relCustomersSize = relatedCustomers.size();
		if (relCustomersSize > 0) {
			customRelationship = 
				new CustomRelationship[relCustomersSize];
			for (int i = 0; i < relCustomersSize; i++) {
				String relCustomers[] = relatedCustomers.get(i).split("/");
				customRelationship[i] = new CustomRelationship();
				customRelationship[i].setRelatedPartySourceId(relCustomers[0]);
				customRelationship[i].setRelationType(relCustomers[1]);
			}
		}
		
		return customRelationship;
	}
	
	/**
	 * Checks Related Customer Type
	 * @param relatedCustomerType
	 */
	protected static boolean isValidKamlsRelatedCustomer(String relatedCustomerType) {
		for (String type : KAMLS_RELATIONSHIP_TYPES) {
			if (relatedCustomerType.contains(type)) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Handling risk level value as Kamls sends different code for Standard
	 * @param riskLevel
	 * @return
	 */
	protected static String getRiskLevel(Object riskLevel) {
		String rsklvl = getValue(riskLevel);
		
		if ("standard".equalsIgnoreCase(rsklvl)) {
			rsklvl = "STAND";
		} else {
			rsklvl = rsklvl.toUpperCase();
		}
		
		return rsklvl;
	}


	public static Vector<HashMap<String, String>> parseData(Map<String, String> staffwareTransitionMap,
															String dataFieldName){
		Vector<HashMap<String, String>> records = new Vector<HashMap<String,String>>();
		String data = staffwareTransitionMap.get(dataFieldName);
		if(data == null) data = "";

		// First, split it down to pairs. May contain escaped pipes.
		// This matches a single pipe, followed by a non-pipe, optionally preceded by any number
		// of escaped pipes.
		String[] pairs = data.split("(\\|\\|)*\\|");
		// each pair should be of the form fieldName[index]value
		for (int i = 0; i < pairs.length; i++) {
			String pair = pairs[i];
			int leftBracket = pair.indexOf("[");
			int rightBracket = pair.indexOf("]");
			if(leftBracket!=-1 && rightBracket!=-1){
				String fieldName = pair.substring(0, leftBracket);
				// index is 1-based
				int index = Integer.parseInt(pair.substring(leftBracket + 1, rightBracket));
				String value = (rightBracket + 1 < pair.length()) ? pair.substring(rightBracket + 1) : "";
				if (records.size() < index) {
					records.setSize(index);
				}
				HashMap<String, String> map = records.get(index - 1);
				if (map == null) {
					map = new HashMap<String, String>();
					map.put("listIndex", Integer.toString(index));
					records.set(index - 1, map);
				}
				map.put(fieldName, value);
			}
		}
		return records;
	}

	public static List<HashMap<String, String>> parseContactsFromContactData(
			Map<String, String> staffwareTransitionMap, boolean includeDeleted) {
		Vector<HashMap<String, String>> records = parseData(staffwareTransitionMap, "customerContactData");

		// Need to put in customerNumber, as this is not passed back from the client
		String customerNumber = staffwareTransitionMap.get("customerNumber");
		for (HashMap<String, String> map : records) {
			map.put("customerNumber", customerNumber);
		}
		// Finally, get rid of the deleted ones
		if (!includeDeleted) {
			int currentIndex = 0;
			while (currentIndex < records.size()) {
				HashMap<String, String> record = records.get(currentIndex);
				String deleted = (String) record.get("deleted");
				if (deleted != null && deleted.equalsIgnoreCase("true")) {
					records.remove(currentIndex);
				} else {
					currentIndex++;
				}
			}
		}
		return records;
	}

	private static void populatePartyAddressListUsingContactData(
			Map<String, String> staffwareTransitionMap, Customer customer,
			ArrayList<XAddressGroup> customerContactsList)
	{
		List<HashMap<String, String>> records = parseContactsFromContactData(staffwareTransitionMap, false);
		XAddressGroup partyAddress, permPartyAddress = null;
		HashMap<String, String> contactRecordReside = null;
		String contactSeqNumber = null;
		long maxContactSeqNumber=0, resideContactSeqNumber=0;

		// identify the maximum sequence number
		for(HashMap<String, String> contactRecord : records)
		{
			contactSeqNumber = getValue(contactRecord.get("contactSequenceNo"));
			if (!"-1".equals(contactSeqNumber))
			{
				if (maxContactSeqNumber < Long.parseLong(contactSeqNumber))
				{
					maxContactSeqNumber = Long.parseLong(contactSeqNumber);
				}
			}
		}

		for(HashMap<String, String> contactRecord : records)
		{
			// Iterate only for RESIDE or CORRES contacts
			if (!(contactRecord.get("contactType").equalsIgnoreCase(
					"RESIDE")
					|| contactRecord.get("contactType")
					.equalsIgnoreCase(
							"CORRES")))
			{
				// if its a new contact other than RESIDE/CORRES, increment the sequence number
				if("-1".equals(getValue(contactRecord.get("contactSequenceNo"))))
				{
					++maxContactSeqNumber;
				}
				continue;
			}

			partyAddress = new XAddressGroup();

			// Populate the Address object
			partyAddress.setAddress(populateXAddress(contactRecord, customer.getResidencyCode()));
			if(partyAddress.getSequenceNo()==null || partyAddress.getSequenceNo().trim().equals(""))
			{
				//If it's a new address, increment max sequence number
				if("-1".equals(getValue(contactRecord.get("contactSequenceNo")))){
					partyAddress.setSequenceNo(++maxContactSeqNumber + "");
				}else{
					partyAddress.setSequenceNo(getValue(contactRecord.get("contactSequenceNo")));
				}
			}

			// Set the PreferredAddressIndicator using primaryContactIndicator
			if("Y".equalsIgnoreCase(getValue(contactRecord.get("primaryContactIndicator"))))
				partyAddress.setPreferredAddressIndicator(true);
			else
				partyAddress.setPreferredAddressIndicator(false);

			// Identify the KAMLS Address Type using eBOX Contact Type
			AddressUsageType addrType = new AddressUsageType();
			if (contactRecord.get("contactType").equalsIgnoreCase(
					"RESIDE"))
			{
				addrType.set_value("Residential Address");
				contactRecordReside = contactRecord;
				resideContactSeqNumber = Long.valueOf(partyAddress.getSequenceNo());
			}
			// it has to be CORRES
			else
			{
				addrType.set_value("Mailing Address");
			}
			partyAddress.setUsage(addrType);
			customerContactsList.add(partyAddress);
		}
		if (contactRecordReside != null)
		{
			permPartyAddress = new XAddressGroup();
			permPartyAddress.setAddress(populateXAddress(
					contactRecordReside, customer.getResidencyCode()));
			permPartyAddress.setSequenceNo(resideContactSeqNumber+"");
			permPartyAddress.setPreferredAddressIndicator(false);

			AddressUsageType addrType = new AddressUsageType();
			addrType.set_value("Permanent Address");
			permPartyAddress.setUsage(addrType);
			customerContactsList.add(permPartyAddress);
		}

		HashMap<String, String> contactRecord = new HashMap<String, String>();
		contactRecord.clear();
		contactRecord.put("addressFirstLine",	(String) staffwareTransitionMap.get("empAddressFirstLine"));
		contactRecord.put("poBoxDetails",		(String) staffwareTransitionMap.get("empPoBoxDetails"));
		contactRecord.put("townCity",			(String) staffwareTransitionMap.get("empTown"));
		contactRecord.put("postcodeZip",		(String) staffwareTransitionMap.get("empPostcode"));
		contactRecord.put("districtRegion",		(String) staffwareTransitionMap.get("empDistrict"));
		contactRecord.put("contactSequenceNo",	"1");
		contactRecord.put("residency", 			(String) staffwareTransitionMap.get("residency"));

		XAddressGroup workPartyAddress = populateWorkPartyAddress(contactRecord);
		if(workPartyAddress!=null)
		{
			customerContactsList.add(workPartyAddress);
		}
	}

	public static HashMap<String,Object> setValuesForKamls(Map<String,String> staffwareTransitionMap, String country, String offshoreInd) throws Exception {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		HashMap<String, Object> hMap = new HashMap<>();

		hMap.put("offshore", "1".equalsIgnoreCase(offshoreInd));
		hMap.put("ISOCode", country);

		String propositionType = staffwareTransitionMap.get("propositionType");
		hMap.put("propositionType", propositionType);
		hMap.put("eBoxUserName", staffwareTransitionMap.get(STAFFWAREMAP_USERNAME));
		
		Country userCountry = TokenHelper.fetchCountryDetails(country, offshoreInd);
		
		hMap.put("eBoxUserCountry", new String[]{userCountry.getTwoCharISOCode()});
		hMap.put("eBoxCountryName", new String[]{"EBOX " + userCountry.getCountryName().toUpperCase()});
		hMap.put("eBoxUserCountryCode", userCountry.getTwoCharISOCode());
		hMap.put("RequestId", staffwareTransitionMap.get("customerNumber"));
		hMap.put("customerbranch", staffwareTransitionMap.get(STAFFWAREMAP_LOCATION_CODE));

		hMap.put("customerNumber", staffwareTransitionMap.get("customerNumber"));
		hMap.put("addressFirstLine", staffwareTransitionMap.get("addressFirstLine"));
		hMap.put("poBoxDetails", staffwareTransitionMap.get("poBoxDetails"));
		hMap.put("townCity", staffwareTransitionMap.get("townCity"));
		hMap.put("postcodeZip", staffwareTransitionMap.get("postcodeZip"));
		hMap.put("districtRegion", staffwareTransitionMap.get("districtRegion"));

		hMap.put("prohibitedAccountStatus", staffwareTransitionMap.get("prohibitedAccountStatus"));

		// The cab does not have the customers accounts loaded, so load them.
		Customer bespokeCustomer = new Customer();

		bespokeCustomer.setCustomerNumber(Integer.parseInt(staffwareTransitionMap.get("customerNumber")));
		bespokeCustomer.setResidencyCode(staffwareTransitionMap.get("residency"));
		TokenHelper.fetchAccounts(bespokeCustomer,new Country(country, "1".equals(offshoreInd)), false);

		ArrayList<String> prods = addAccountsForKamls(bespokeCustomer, hMap);

		// For each of these, only add it if the customer does not
		// currently hold one like it!
		if (!prods.contains("LNS") && !prods.contains("FNS")) {
			hMap.put("securedLoanOrFinancing", staffwareTransitionMap.get("securedLoanOrFinancing"));
		}
		if (!prods.contains("TD")) {
			hMap.put("termDeposit", staffwareTransitionMap.get("termDeposit"));
		}
		if (!prods.contains("SA")) {
			hMap.put("savingAccount", staffwareTransitionMap.get("savingAccount"));
		}
		if (!prods.contains("MF")) {
			hMap.put("invMgmt", staffwareTransitionMap.get("invMgmt"));
		}
		if (!prods.contains("CA")) {
			hMap.put("currentAccount", staffwareTransitionMap.get("currentAccount"));
		}
		if (!prods.contains("IP") && !prods.contains("TF")) {
			hMap.put("tradePlanOrProducts", staffwareTransitionMap.get("tradePlanOrProducts"));
		}
		if (!prods.contains("LNU") && !prods.contains("FNU")) {
			hMap.put("unsecuredLoanOrFinancing", staffwareTransitionMap.get("unsecuredLoanOrFinancing"));
		}
		
		
		hMap.put("solicitationChannel", staffwareTransitionMap.get("solicitationChannel"));
		hMap.put("pepInd", staffwareTransitionMap.get("pepInd"));
		hMap.put("initialDeposit", staffwareTransitionMap.get("initialDeposit"));
		hMap.put("expectedCashVolume", staffwareTransitionMap.get("expectedCashVolume"));
		hMap.put("kycStatus", staffwareTransitionMap.get("kycStatus"));
		
		//WP812- Changes made to avoid execution of RBA fields when RBA flag is switched off
		if(TokenHelper.isRiskBasedKYCEnabled(country,offshoreInd)) {		
			hMap.put("cusSourceUniqueId", staffwareTransitionMap.get("rtsReferenceNumber"));
			hMap.put("cusSourceRefId", staffwareTransitionMap.get("rtsReferenceNumber")); 
			
			//lookup source of income code
			List<String> sourceofIncomeList = new ArrayList<String>();
			String sourceOfIncome = (String)staffwareTransitionMap.get("sourceOfIncome");
			String[] sourceOfIncomeStr = sourceOfIncome.split(",");
			for(int i=0;i<sourceOfIncomeStr.length;i++) {
					String code = getRefValueCode(country, offshoreInd, "SRCINC",sourceOfIncomeStr[i] );
					sourceofIncomeList.add(code);				
			}		
			hMap.put("sourceOfIncome",TokenHelper.removeBracketFromStringList(sourceofIncomeList));
			
			//lookup source of fund code
			List<String> sourceofFundList = new ArrayList<String>();
			String sourceOfFund = (String)staffwareTransitionMap.get("sourceOfFunds");
			String[] sourceOfFundStr = sourceOfFund.split(",");
			for(int i=0;i<sourceOfFundStr.length;i++) {
					String code = getRefValueCode(country, offshoreInd, "SRCFND",sourceOfFundStr[i] );
					sourceofFundList.add(code);				
			}
			hMap.put("sourceOfFunds",TokenHelper.removeBracketFromStringList(sourceofFundList));
			
			//lookup source of wealth code
			List<String> sourceofWealthList = new ArrayList<String>();
			String sourceOfWealth = (String)staffwareTransitionMap.get("sourceOfWealth");		
			String[] sourceOfWealthStr = sourceOfWealth.split(Pattern.quote("||"));		
			for(int i=0;i<sourceOfWealthStr.length;i++) {			
					String code = getRefValueCode(country, offshoreInd, "SRCWTH",sourceOfWealthStr[i] );
					sourceofWealthList.add(code);				
			}
			hMap.put("sourceOfWealth",TokenHelper.removeBracketFromStringList(sourceofWealthList));		
			
			hMap.put("sourceOfOtherIncome", staffwareTransitionMap.get("otherIncomeTxt"));
			hMap.put("sourceOfOtherFunds", staffwareTransitionMap.get("otherFundsTxt"));
			hMap.put("sourceOfOtherWealth", staffwareTransitionMap.get("otherWealthTxt"));
			
			hMap.put("mEAACashDepositAmount", staffwareTransitionMap.get("mEAACashDepositAmount"));
			hMap.put("mEAACashDepositVolume", staffwareTransitionMap.get("mEAACashDepositVolume"));
			hMap.put("mEAACashWithdrawalAmount", staffwareTransitionMap.get("mEAACashWithdrawalAmount"));
			hMap.put("mEAACashWithdrawalVolume", staffwareTransitionMap.get("mEAACashWithdrawalVolume"));
			
			hMap.put("mEAAChequeDepositAmount", staffwareTransitionMap.get("mEAAChequeDepositAmount"));
			hMap.put("mEAAChequeDepositVolume", staffwareTransitionMap.get("mEAAChequeDepositVolume"));
			hMap.put("mEAAChequeWithdrawalAmount", staffwareTransitionMap.get("mEAAChequeWithdrawalAmount"));
			hMap.put("mEAAChequeWithdrawalVolume", staffwareTransitionMap.get("mEAAChequeWithdrawalVolume"));
			
			hMap.put("mEAAInternationalTransferDepositAmount", staffwareTransitionMap.get("mEAAOtherInstrumentsDepositAmount"));
			hMap.put("mEAAInternationalTransferDepositVolume", staffwareTransitionMap.get("mEAAOtherInstrumentsDepositVolume"));
			hMap.put("mEAAInternationalTransferWithdrawalAmount", staffwareTransitionMap.get("mEAAOtherInstrumentsWithdrawalAmount"));
			hMap.put("mEAAInternationalTransferWithdrawalVolume", staffwareTransitionMap.get("mEAAOtherInstrumentsWithdrawalVolume"));
			
			hMap.put("mEAALocalFundsTransferDepositAmount", staffwareTransitionMap.get("mEAAFundTransfersDepositAmount"));
			hMap.put("mEAALocalFundsTransferDepositVolume", staffwareTransitionMap.get("mEAAFundTransfersDepositVolume"));
			hMap.put("mEAALocalFundsTransferWithdrawalAmount", staffwareTransitionMap.get("mEAAFundTransfersWithdrawalAmount"));
			hMap.put("mEAALocalFundsTransferWithdrawalVolume", staffwareTransitionMap.get("mEAAFundTransfersWithdrawalVolume"));
			
			hMap.put("idCardExpiry", staffwareTransitionMap.get("idCardExpiry"));
			hMap.put("specialCustomerType", staffwareTransitionMap.get("specialCustomerType"));
			hMap.put("highRiskIndustries", staffwareTransitionMap.get("highRiskIndustries"));
			hMap.put("customerNumber", staffwareTransitionMap.get("customerNumber"));
			
			//look up Detailed Product IDs
			String detailedProducts = getValue(staffwareTransitionMap.get("detailedProducts"));
			logger.info("detailedProducts chosen--->"+detailedProducts);
			String[] detailedProductsStr = detailedProducts.split(Pattern.quote("/"));
		    String[] detailedProductsIDsArr = TokenHelper.getDetailedProductIDsForKAMLS(detailedProductsStr, userCountry,
					staffwareTransitionMap.get("marketSegment"),propositionType );
		    for(int i=0;i<detailedProductsIDsArr.length;i++) {
		    	logger.info("detailedProductsIDsArr chosen code -->"+detailedProductsIDsArr[i]);
		    }
			hMap.put("detailedProductsIDsArr",detailedProductsIDsArr);			
			
			}
		String[] relatedCustomers = staffwareTransitionMap.get("relatedCustomerNumbers").split(" ");
		int[] relatedCustomerNumbers = new int[relatedCustomers.length];
		for (int i = 0; i < relatedCustomers.length; i++) {
			if (!org.apache.commons.lang.StringUtils.isBlank(relatedCustomers[i])) {
				relatedCustomerNumbers[i] = Integer.parseInt(relatedCustomers[i]);
			}
		}		

		hMap.put("relatedCustomerNumbers", relatedCustomerNumbers);
		hMap.put("relatedCustomerTypes", staffwareTransitionMap.get("relationships").split(" "));
		hMap.put("inverseRelatedCustomerTypes", staffwareTransitionMap.get("inverseRelationships").split(" "));

		hMap.put("referStreamName", getReferStreamDesc(country, offshoreInd, staffwareTransitionMap.get("referStream").toString()));
		hMap.put("referStream", staffwareTransitionMap.get("referStream"));
		hMap.put("kamlsUrl", getKamlsUrl(country, offshoreInd));

		if("P".equalsIgnoreCase(propositionType) || "S".equalsIgnoreCase(propositionType)) {
			hMap.put("firstName", staffwareTransitionMap.get("firstName"));
			hMap.put("familyName", staffwareTransitionMap.get("familyName"));
			hMap.put("title", getRefValueCode(country, offshoreInd, "TITLE", (String)staffwareTransitionMap.get("title")));
			hMap.put("nationality", staffwareTransitionMap.get("nationality"));

			if (staffwareTransitionMap.get("contactDateOfBirth") != null
					&& staffwareTransitionMap.get("contactDateOfBirth").trim().length() > 0) {
				hMap.put("contactDateOfBirth",
						dateFormat.parse(staffwareTransitionMap.get("contactDateOfBirth")));
			}
			hMap.put("placeOfBirth", staffwareTransitionMap.get("placeOfBirth"));

			hMap.put("residency", staffwareTransitionMap.get( "residency"));

			hMap.put("expectedTransToCountries",TokenHelper.getCountryCodes(staffwareTransitionMap.get("expectedTransToCountries").split("/")));

			hMap.put("employmentType", staffwareTransitionMap.get("employmentType"));
			hMap.put("empJobTitle", staffwareTransitionMap.get("empJobTitle"));
			hMap.put("empNatureOfBusiness", staffwareTransitionMap.get("empNatureOfBusiness"));
			hMap.put("geographicalStatus", staffwareTransitionMap.get("geographicalStatus"));

			hMap.put("designation", staffwareTransitionMap.get("designation"));

			hMap.put("passportNumber", staffwareTransitionMap.get("passportNumber"));
			hMap.put("drivingLicenceNumber", staffwareTransitionMap.get("drivingLicenceNumber"));
			hMap.put("idCardNumber", staffwareTransitionMap.get("idCardNumber"));
			hMap.put("detailedProducts", staffwareTransitionMap.get("detailedProducts"));
			

			ArrayList<XAddressGroup> customerContactsList = new ArrayList<>();
			// Below condition is modified to check Customer flow (Add/Amend) using isAdd attribute. CIT Defect 2667
//            if ((cab.getAction().equals(CustomerTabConstants.CUSTOMER_DISPLAY)
//                    || cab.getAction().equals(
//                    CustomerTabConstants.CUSTOMER_AUTH)) && cab.getBooleanValue("isAdd") == false)
// Kamls Issue Fix  condition is wrong according to prior csc kamls code implementation
			boolean isAddCustomerFlow = Boolean.parseBoolean(staffwareTransitionMap.get("isAdd"));
			if (!isAddCustomerFlow) {
				populatePartyAddressListUsingContactData(staffwareTransitionMap, bespokeCustomer, customerContactsList);
			}
			// For ADD action, make copies of customer address
			else
			{
				/*
				 * get the latest Customer Contact records to prepare KAMLS Address objects
				 */
				// TODO need to get from Brains? Seems to be coming back empty
				String contactType = (String) staffwareTransitionMap.get("contactType");
				HashMap<String, String> contactRecord = new HashMap<String, String>();
				XAddressGroup partyAddress, permPartyAddress=null;
				AddressUsageType addrUsageType=null, permAddrUsageType = null;

				// ContactType is empty incase of amendment in Add Customer senario. CIT Defect 2667
				if(contactType == null || contactType.isEmpty())
				{
					List<HashMap<String, String>> records = parseContactsFromContactData(staffwareTransitionMap, false);
					String contactSeqNumber;
					int maxSequenceNumber=-1;

					for(HashMap<String, String> curContactRecord : records)
					{
						contactSeqNumber = getValue(curContactRecord.get("contactSequenceNo"));

						/*
						 * Below is the fix using maxSequenceNumber for 2667 - inflight add customer applications
						 * which were sent back for amendment by authoriser before RAO deployment.
						 * If the contact type is changed (for eg. Trading to Corres), below fix is required.
						 */
						if(contactSeqNumber.equals("-1"))
						{
							if(maxSequenceNumber==-1)
							{
								maxSequenceNumber = 1;
							}
							else
							{
								maxSequenceNumber++;
							}
						}
						else if (maxSequenceNumber < Integer.parseInt(contactSeqNumber))
						{
							maxSequenceNumber = Integer.parseInt(contactSeqNumber);
						}

						partyAddress = new XAddressGroup();
						// Populate the Address object
						partyAddress.setAddress(populateXAddress(curContactRecord, bespokeCustomer.getResidencyCode()));
						if(contactSeqNumber.equals("-1"))
						{
							partyAddress.setSequenceNo(maxSequenceNumber+"");
						}
						else
						{
							partyAddress.setSequenceNo(contactSeqNumber);
						}
						addrUsageType = new AddressUsageType();

						if("Y".equalsIgnoreCase(getValue(curContactRecord.get("primaryContactIndicator"))))
							partyAddress.setPreferredAddressIndicator(true);
						else
							partyAddress.setPreferredAddressIndicator(false);

						if(curContactRecord.get("contactType").toString().equals("CORRES"))
						{
							addrUsageType.set_value("Mailing Address");
						}
						else if(curContactRecord.get("contactType").toString().equals("RESIDE"))
						{
							addrUsageType.set_value("Residential Address");

							permPartyAddress = new XAddressGroup();
							permPartyAddress.setAddress(populateXAddress(curContactRecord, bespokeCustomer.getResidencyCode()));
							if(contactSeqNumber.equals("-1"))    {
								permPartyAddress.setSequenceNo(maxSequenceNumber+"");
							} else {
								permPartyAddress.setSequenceNo(contactSeqNumber);
							}
							permPartyAddress.setPreferredAddressIndicator(false);
							permAddrUsageType = new AddressUsageType();
							permAddrUsageType.set_value("Permanent Address");
							permPartyAddress.setUsage(permAddrUsageType);
						}
						partyAddress.setUsage(addrUsageType);
						customerContactsList.add(partyAddress);
					}

					if(permPartyAddress!=null) {
						customerContactsList.add(permPartyAddress);
					}
				}
				else
				{
					contactRecord.put("addressFirstLine",	(String) staffwareTransitionMap.get("addressFirstLine"));
					contactRecord.put("poBoxDetails",		(String) staffwareTransitionMap.get("poBoxDetails"));
					contactRecord.put("townCity",			(String) staffwareTransitionMap.get("townCity"));
					contactRecord.put("postcodeZip",		(String) staffwareTransitionMap.get("postcodeZip"));
					contactRecord.put("districtRegion",		(String) staffwareTransitionMap.get("districtRegion"));
					contactRecord.put("contactSequenceNo",	"-1");

					partyAddress = new XAddressGroup();
					// Populate the Address object
					partyAddress.setAddress(populateXAddress(contactRecord, (String) staffwareTransitionMap.get("residency")));
					partyAddress.setSequenceNo("-1");
					addrUsageType = new AddressUsageType();
					addrUsageType.set_value("Residential Address");
					partyAddress.setUsage(addrUsageType);
					customerContactsList.add(partyAddress);

					// Make copy no 2 of same contact
					partyAddress = new XAddressGroup();
					// Populate the Address object
					partyAddress.setAddress(populateXAddress(contactRecord, (String) staffwareTransitionMap.get("residency")));
					partyAddress.setSequenceNo("-1");
					addrUsageType = new AddressUsageType();
					addrUsageType.set_value("Mailing Address");
					partyAddress.setUsage(addrUsageType);
					customerContactsList.add(partyAddress);

					// Make copy no 3 of same contact
					partyAddress = new XAddressGroup();
					// Populate the Address object
					partyAddress.setAddress(populateXAddress(contactRecord, (String) staffwareTransitionMap.get("residency")));
					partyAddress.setSequenceNo("-1");
					addrUsageType = new AddressUsageType();
					addrUsageType.set_value("Permanent Address");
					partyAddress.setUsage(addrUsageType);
					customerContactsList.add(partyAddress);

					if (contactType.equalsIgnoreCase("CORRES"))  {
						// RESIDE - Set the seq number as 2 & PreferredAddressIndicator to false
						customerContactsList.get(0).setSequenceNo("2");
						customerContactsList.get(0).setPreferredAddressIndicator(false);

						// CORRES - Set the seq number as 1 & PreferredAddressIndicator to true
						customerContactsList.get(1).setSequenceNo("1");
						customerContactsList.get(1).setPreferredAddressIndicator(true);

						// PERM - Set the seq number as 2 & PreferredAddressIndicator to false
						customerContactsList.get(2).setSequenceNo("2");
						customerContactsList.get(2).setPreferredAddressIndicator(false);
					}
					else
					{
						/**
						 * We have changed below the sequence number logic for Add Customer flow for CIT Defect 2657.
						 * If while adding customer, the Primary Contact is of any other type than CORRES/RESIDE
						 * then, RESIDE should have sequence number 2 & CORRES should have sequence number 3 else
						 * it should be 1 and 2 respectively.
						 */

						boolean isContactTypeReside = contactType
								.equalsIgnoreCase("RESIDE");
						int resideSeqNumber=0;

						if(isContactTypeReside)
						{
							resideSeqNumber = 1;
							customerContactsList.get(0).setPreferredAddressIndicator(true);
						}
						else
						{
							resideSeqNumber = 2;
							customerContactsList.get(0).setPreferredAddressIndicator(false);
						}

						// RESIDE - Set the seq number as 1 & PreferredAddressIndicator to true/false
						customerContactsList.get(0).setSequenceNo(resideSeqNumber+"");

						// CORRES - Set the seq number as 2 & PreferredAddressIndicator to false
						customerContactsList.get(1).setSequenceNo((resideSeqNumber+1)+"");
						customerContactsList.get(1).setPreferredAddressIndicator(false);
						// Set the seq number as 1 & PreferredAddressIndicator to false
						customerContactsList.get(2).setSequenceNo(resideSeqNumber+"");
						customerContactsList.get(2).setPreferredAddressIndicator(false);
					}
				}

				contactRecord.clear();
				contactRecord.put("addressFirstLine",	(String) staffwareTransitionMap.get("empAddressFirstLine"));
				contactRecord.put("poBoxDetails",		(String) staffwareTransitionMap.get("empPoBoxDetails"));
				contactRecord.put("townCity",			(String) staffwareTransitionMap.get("empTown"));
				contactRecord.put("postcodeZip",		(String) staffwareTransitionMap.get("empPostcode"));
				contactRecord.put("districtRegion",		(String) staffwareTransitionMap.get("empDistrict"));
				contactRecord.put("contactSequenceNo",	"1");
				contactRecord.put("residency", 			(String) staffwareTransitionMap.get("residency"));

				XAddressGroup workPartyAddress = populateWorkPartyAddress(contactRecord);
				if(workPartyAddress!=null)
				{
					customerContactsList.add(workPartyAddress);
				}
			}

			XAddressGroup partyAddresses[] = new XAddressGroup[customerContactsList.size()];
			customerContactsList.toArray(partyAddresses);
			hMap.put("customerContactsForKAMLS", partyAddresses);
		} else {
			hMap.put("companyName", staffwareTransitionMap.get("companyName"));
			hMap.put("tradingName", staffwareTransitionMap.get("tradingName"));
			hMap.put("companyRegNo", staffwareTransitionMap.get("companyRegNo"));
			hMap.put("businessType", staffwareTransitionMap.get("businessType"));
			hMap.put("entityType", staffwareTransitionMap.get("entityType"));
			hMap.put("natureOfBusiness", staffwareTransitionMap.get("natureOfBusiness"));
			hMap.put("businessEstablishedDate",dateFormat.parse(staffwareTransitionMap.get("businessEstablishedDate")));

			hMap.put("countryOfRegistration", staffwareTransitionMap.get("countryOfRegistration"));

			hMap.put("countriesOfOperations",TokenHelper.getCountryCodes(staffwareTransitionMap.get("countriesOfOperations").split("/")));
			hMap.put("countriesTradedWith",TokenHelper.getCountryCodes(staffwareTransitionMap.get("countriesTradedWith").split("/")));

			hMap.put("operatingStatus", staffwareTransitionMap.get("operatingStatus"));

			hMap.put("solicitationChannel", staffwareTransitionMap.get("solicitationChannel"));
			hMap.put("pepInd", staffwareTransitionMap.get("pepInd"));
			hMap.put("initialDeposit", staffwareTransitionMap.get("initialDeposit"));
			hMap.put("expectedCashVolume", staffwareTransitionMap.get("expectedCashVolume"));
			hMap.put("kycStatus", staffwareTransitionMap.get("kycStatus"));
			//WP812-Amit
			hMap.put("cusSourceUniqueId", staffwareTransitionMap.get("rtsReferenceNumber"));
			hMap.put("cusSourceRefId", staffwareTransitionMap.get("rtsReferenceNumber"));
			hMap.put("detailedProducts", staffwareTransitionMap.get("detailedProducts"));
			hMap.put("specialCustomerType", staffwareTransitionMap.get("specialCustomerType"));
			hMap.put("highRiskIndustries", staffwareTransitionMap.get("highRiskIndustries"));
			hMap.put("customerNumber", staffwareTransitionMap.get("customerNumber"));

			hMap.put("complexStructure", staffwareTransitionMap.get("complexStructure"));
		}

		if("MUS".equalsIgnoreCase(country) && "1".equalsIgnoreCase(offshoreInd))
		{
			hMap.put("eBoxCountryName", new String[]{"EBOX OBUMAUR"});
			hMap.put("eBoxUserCountryCode","MF");
		} else if ("TZA".equalsIgnoreCase(country))
		{
			hMap.put("eBoxCountryName", new String[]{"EBOX TANZANIA"});
		}

		return hMap;
	}

    public static String getRefValueCode(String country, String offshoreInd, String domain, String refValueDescription)
			throws Exception {
		String refValueCode = "" ;
		SortedSet<RefValueBean> dbValues = getMWRefValuesByDomain(country, "1".equals(offshoreInd), domain);

		for (RefValueBean value : dbValues) {
			if (refValueDescription.equalsIgnoreCase(value.getDecsription())){
				refValueCode = value.getCode();
				break;
			}
		}

		return refValueCode;
	}


	public static SortedSet<RefValueBean> getMWRefValuesByDomain (String isoCode, boolean offshoreIndicator, String domain) throws SQLException {

		SortedMap<String, Object> param = new TreeMap<>();
		param.put("country", isoCode);
		param.put("offshoreInd", offshoreIndicator);
		// convert domain empty string to null
		if(domain.equals("")) {
			param.put("domain", null);
		} else {
			param.put("domain", domain);
		}

		SortedSet<RefValueBean> result = new TreeSet<>();
		try (SQLConnection conn = MWDBAccess.getDatabaseConnection()) {
			CallableStatement cs = conn.prepareCall("dbo.wfe_MWRefValuesGet", param);
			ResultSet rs = conn.executeQuery(cs, param);

			while (rs.next()) {
				RefValueBean rvb = new RefValueBean();
				rvb.setCode(rs.getString("Code"));
				rvb.setDecsription(rs.getString("Description"));
				rvb.setDomain(rs.getString("Domain"));
				result.add(rvb);
			}
			if(rs != null) {
				rs.close();
			}
		}

		return result;
	}

	public static String getReferStreamDesc(String country, String offshoreInd, String referCode){
		String referStreamDesc = "" ;
		CallableStatement cs = null;
		ResultSet rs = null;
		try (SQLConnection conn = MWDBAccess.getDatabaseConnection())
		{
			SortedMap<String, Object> hMap = new TreeMap<String, Object>();
			hMap.put("Country", country);
			hMap.put("OffshoreInd", offshoreInd);
			hMap.put("referCode", referCode);
			cs = conn.prepareCall("dbo.csc_getRiskReferral", hMap);
			rs = conn.executeQuery(cs, hMap);
			if(rs.next()){
				referStreamDesc = rs.getString("ReferContact").trim();
			}
		}catch (Exception e) {
			logger.error("Error in calling referstream details :" + e.getMessage());
		}
		finally {
			try{
				if(rs != null) rs.close();
				if(cs != null) cs.close();
			}catch (Exception e) {
				logger.error("Error in calling referstream details :" + e.getMessage());
			}
		}
		return referStreamDesc;
	}

	protected static String getValue(Object keyValue) {
		String returnValue = "";

		if (keyValue != null) {
			returnValue = keyValue.toString().trim();
		}

		return returnValue;
	}

	protected static String getKamlsUrl(String country, String offshoreInd)
			throws Exception{
		IpAddress kamlsIpAddress = getIpAddress("KAMLS", new Country(country, "1".equalsIgnoreCase(offshoreInd)));
		return kamlsIpAddress.getConnectionString();
	}

	public static IpAddress getIpAddress(
			String engine,
			Country country) throws SQLException {
		SortedMap<String, Object> args = new TreeMap<>();
		args.put("engine", engine);

		SQLConnection conn = MWDBAccess.getDatabaseConnection();

		if (country == null) {
			args.put("country", "*");
			args.put("offshore", new Integer("0"));
		} else {
			args.put("country", country.getISOCode());
			args.put("offshore", country.isOffshore() ? 1 : 0);
		}

		CallableStatement cs = conn.prepareCall("dbo.wfe_EChannelConnectionGet", args);

		ResultSet rs = conn.executeQuery(cs, args);
		IpAddress result = null;
		if (rs.next()) {
			result = new IpAddress(
					rs.getString("hostname"),
					rs.getInt("port"),
					rs.getString("engine"),
					rs.getInt("timeout"),
					rs.getInt("nextsequencenumber"),
					rs.getBoolean("trace"),
					rs.getString("connectionstring"));
		}
		if(rs != null) {
			rs.close();
		}

		return result;
	}


	private static XAddress populateXAddress(HashMap<String, String> contactRecord, String residency)
	{
		XAddress addr = new XAddress();
		addr.setAddressLineOne(getValue(contactRecord.get("addressFirstLine")));
		addr.setBoxId(getValue(contactRecord.get("poBoxDetails")));
		addr.setCity(getValue(contactRecord.get("townCity")));
		addr.setZipPostalCode(getValue(contactRecord.get("postcodeZip")));
		CountyType countytype= new CountyType();
		countytype.set_value(getValue(contactRecord.get("districtRegion")));
		addr.setCounty(countytype);

		com.ibm.www.xmlns.prod.websphere.wcc.party.schema.CountryType ctype =
				new com.ibm.www.xmlns.prod.websphere.wcc.party.schema.CountryType();
		ctype.set_value(getValue(residency));
		addr.setCountry(ctype);
		return addr;
	}

	private static XAddressGroup populateWorkPartyAddress(HashMap<String, String> contactRecord)
	{
		XAddressGroup workPartyAddress = null;

		if((contactRecord.get("addressFirstLine")!=null && contactRecord.get("addressFirstLine").toString().trim().length()>0) ||
				(contactRecord.get("poBoxDetails")!=null && contactRecord.get("poBoxDetails").toString().trim().length()>0) ||
				(contactRecord.get("townCity")!=null && contactRecord.get("townCity").toString().trim().length()>0) ||
				(contactRecord.get("postcodeZip")!=null && contactRecord.get("postcodeZip").toString().trim().length()>0) ||
				(contactRecord.get("districtRegion")!=null && contactRecord.get("districtRegion").toString().trim().length()>0))
		{
			//populate PartyAddress using employment address details
			workPartyAddress = new XAddressGroup();
			// Populate the Address object
			workPartyAddress.setAddress(populateXAddress(contactRecord,
					contactRecord.get("residency")));
			workPartyAddress.setSequenceNo(contactRecord.get("contactSequenceNo"));
			AddressUsageType addrUsageType = new AddressUsageType();
			addrUsageType.set_value("Work Address");
			workPartyAddress.setUsage(addrUsageType);
			workPartyAddress.setPreferredAddressIndicator(false);
		}

		return workPartyAddress;
	}

	public static boolean kamlsFieldsRequiredFilled(/* errors,*/
			Customer customer, String country, String offshoreInd) throws Exception {
		boolean result = true;
		Contact contact = new Contact();
        logger.info("Retrieving primary contact from customer... " + customer.getCustomerNumber() );

		Iterator<Contact> iter = customer.getContacts().iterator();
		while (iter.hasNext()) {
			contact = (Contact)iter.next();
			if (contact.isPrimary()){
                logger.info("Found primary contact. " + contact);
				break;
			}
		}

        logger.info("Validating Kamls required fields...");

        if (org.apache.commons.lang.StringUtils.isBlank(contact.getAddressFirstLine()) ||
				org.apache.commons.lang.StringUtils.isBlank(contact.getTownCity()) ||
				org.apache.commons.lang.StringUtils.isBlank(customer.getSolicitationChannel()) ||
				org.apache.commons.lang.StringUtils.isBlank(customer.getPepInd()) ||
				org.apache.commons.lang.StringUtils.isBlank(customer.getInitialDeposit()) ||
				org.apache.commons.lang.StringUtils.isBlank(customer.getExpectedCashVolume()) ||
				org.apache.commons.lang.StringUtils.isBlank(customer.getProhibitedAccountStatus())){

		    logger.error("At least one of required Kamls fields on customer not populated: addressFirstLine, townCity," +
                    " solicitationChannel, pepInd, initialDeposit, expectedCashVolume or prohibitedAccountStatus. " + customer );
			result = false;
		}

		if ("P".equalsIgnoreCase(String.valueOf(customer.getPropositionType())) ||
				"S".equalsIgnoreCase(String.valueOf(customer.getPropositionType()))) {
			CustomerEmployment[] employments =
					TokenHelper.listCustomerEmployment(
							customer.getCustomerNumber(),
							country,
							"1".equals(offshoreInd),
							1);

			if (employments.length > 0){
				CustomerEmployment customerEmployment = employments[0];

				if (null == contact.getDateOfBirth() ||
						customer.getExpectedTransToCountries() == null ||
						org.apache.commons.lang.StringUtils.isBlank(customerEmployment.getEmploymentType()) ||
						org.apache.commons.lang.StringUtils.isBlank(customerEmployment.getDesignation()) ||
						org.apache.commons.lang.StringUtils.isBlank(customer.getGeographicalStatus())) {
                    logger.error("At least one of required Kamls fields on employment not populated: dateOfBirth, " +
                            "expectedTransToCountries, employmentType, designation or geographicalStatus " + customer );
					result = false;
				} else if (org.apache.commons.lang.StringUtils.isBlank(customerEmployment.getJobTitle())
						&& ArrayUtils.contains(new String[]{"EMPLYD", "EMPCON"},
						customerEmployment.getEmploymentType())) {
                    logger.error("Invalid jobTitle value '" + customerEmployment.getJobTitle() + "'. "+ customer );
					result = false;
				} else if (org.apache.commons.lang.StringUtils.isBlank(customerEmployment.getNatureOfBusiness())
						&& ArrayUtils.contains(new String[]{"SELF", "EMPLYD", "EMPCON"},
						customerEmployment.getEmploymentType())) {
                    logger.error("Invalid natureOfBusiness value '" + customerEmployment.getNatureOfBusiness() + "'. "+ customer );
					result = false;
				}
			} else {
                logger.error("No employments provided to Kamls which is required for propositionType '" + String.valueOf(customer.getPropositionType()) + "'. "+ customer );
				result = false;
			}
		} else if (org.apache.commons.lang.StringUtils.isBlank(customer.getEntityType()) ||
				org.apache.commons.lang.StringUtils.isBlank(customer.getNatureOfBusiness()) ||
				null == customer.getCountriesTradedWith() ||
				null == customer.getBusinessEstablishedDate() ||
				org.apache.commons.lang.StringUtils.isBlank(customer.getOperatingStatus()) ||
				org.apache.commons.lang.StringUtils.isBlank(customer.getComplexStructure())) {
			// Corporate and kamls required corporate fields missing.
            logger.error("At least one of required Kamls fields not populated: entityType, natureOfBusiness," +
                    " countriesTradedWith, businessEstablishedDate, operatingStatus, complexStructure " + customer );
            result = false;
		}

		if (!result /*&& errors != null*/) {
            logger.error("Error validating Kamls required fields.");
		}

		logger.info ("kamlsFieldsRequiredFilled? " + result);
		return result;
	}

	public static String callKamlsService(Map<String, String> staffwareTransitionMap, String country, String offshoreInd, boolean deleteCustomer) throws Exception {
		String output = null;
		HashMap<String, Object> customerDetails = null ;
		HashMap<String, String> custRiskDetails = null ;
		try{
			if (org.apache.commons.lang.StringUtils.isNotBlank(staffwareTransitionMap.get("isKamlsOnlineCall")) && Boolean.parseBoolean(staffwareTransitionMap.get("isKamlsOnlineCall"))) {
				logger.info("Calling KAMLS service...");
				customerDetails = setValuesForKamls(staffwareTransitionMap, country, offshoreInd);
				custRiskDetails = KamlsHelper.callKamlsRiskScoringService(customerDetails);
				staffwareTransitionMap.put("riskLevel", custRiskDetails.get("riskLevel").toUpperCase());
				staffwareTransitionMap.put("riskScore", custRiskDetails.get("riskScore"));
				staffwareTransitionMap.put("isAddedToKamls", "Y");
				output = custRiskDetails.get("kycCompliance");
				logger.info("Called KAMLS service successfully : " + custRiskDetails);
			}
		} catch (AxisFault af) {
			Element[] error = af.getFaultDetails();
			if (error != null && error.length > 0) {
				logger.error("Fault Error while calling KAMLS service: "
						+ XMLUtils.getInnerXMLString(error[0]));

				// re-raise the first reason text
				Node reason = XPathAPI.selectSingleNode(error[0], "applicationMessage/reason");
				String reasonText = "" ;
				if (reason != null) {
					reasonText = reason.getTextContent();
					if (deleteCustomer) {
						removeCustomer(staffwareTransitionMap, country, offshoreInd);
					}
					throw new KamlsException(reasonText, af);
				}
			}
			logger.error("Fault error while calling KAMLS service :" + af);
			if (deleteCustomer) {
				removeCustomer(staffwareTransitionMap, country, offshoreInd);
			}
			throw new KamlsException(af.getMessage(), af);
		} catch (Exception e) {
			logger.error("Error while calling KAMLS service", e);
			if (deleteCustomer) {
				removeCustomer(staffwareTransitionMap, country, offshoreInd);
			}
			throw new KamlsException(e.getMessage(), e);
		}
		catch (Message e) {
			logger.error("Error while calling KAMLS service", e);
			if (deleteCustomer) {
				removeCustomer(staffwareTransitionMap, country, offshoreInd);
			}
			// wrap messages as exceptions (never seen thrown)
			throw new KamlsException(e.getMessage(), e);
		}

		return output;
	}


	public static HashMap<String, String> callKamlsService(HashMap<String, Object> customerDetails) throws Exception {
		HashMap<String, String> custRiskDetails = null ;
		try {
			logger.info("Calling KAMLS service for : " + customerDetails.get("customerNumber"));
			custRiskDetails = KamlsHelper.callKamlsRiskScoringService(customerDetails);
			logger.info("Called KAMLS service successfully : " + custRiskDetails);
		} catch (AxisFault af) {
            logger.error("Fault error while calling KAMLS service :" + af);
			Element[] error = af.getFaultDetails();
			if (error != null && error.length > 0) {
				logger.error("Fault Error while calling KAMLS service: "  + XMLUtils.getInnerXMLString(error[0]));

				// re-raise the first reason text
				Node reason = XPathAPI.selectSingleNode(error[0], "applicationMessage/reason");
				String reasonText = "" ;
				if (reason != null) {
					reasonText = reason.getTextContent();
					throw new KamlsException(reasonText, af);
				}
			}
			throw new KamlsException(af.getMessage(), af);
		} catch (Exception e) {
			logger.error("Error while calling KAMLS service", e);
			throw new KamlsException(e.getMessage(), e);
		} catch (Message e) {
			logger.error("Error while calling KAMLS service", e);;
			// wrap messages as exceptions (never seen thrown)
			throw new KamlsException (e.getMessage(), e);
		}

		return custRiskDetails;
	}


	private static void removeCustomer(Map<String, String> staffwareTransitionMap, String country, String offshoreInd)
			throws Exception {
		if (org.apache.commons.lang.StringUtils.isNotBlank(staffwareTransitionMap.get("isAdd")) && Boolean.parseBoolean(staffwareTransitionMap.get("isAdd"))) {
			TokenHelper.deleteCustomer(staffwareTransitionMap, country, offshoreInd, Integer.parseInt(staffwareTransitionMap.get("customerNumber")));
			staffwareTransitionMap.put("customerNumber", "");
		}
	}


	public static ArrayList<String> addAccountsForKamls(
			Customer customer, HashMap<String, Object> hMap) {
		SortedSet<Account> accounts = customer.getAccounts();

		// Add account details for the customer.
		ArrayList<String> prods = new ArrayList<>();
		List<HashMap<String, String>> accountsList = new ArrayList<>();
		for (Account customersAccount : accounts) {
			// due to the way we have loaded the customer, these accounts are only the open accounts.
			HashMap<String, String> account = new HashMap<>();
			account.put("KAMLS_PRODUCT_TYPE", (String)customersAccount.getKamlsProductType());
			prods.add((String)customersAccount.getKamlsProductType());
			String branchNumber = com.barclays.staffware.plugin.util.StringUtils.padLeft(
					Integer.toString(customersAccount.getBranchNumber()),
					'0', 3);

			String accountNumber = com.barclays.staffware.plugin.util.StringUtils.padLeft(
					Integer.toString(customersAccount.getAccountNumber()),
					'0', 7);
			account.put("BRANCH_AND_ACCOUNT_NUMBER", branchNumber + accountNumber);

			accountsList.add(account);
		}

		hMap.put("accountsList", accountsList);

		return prods;
	}
	
	 /**
     * Set RBA fields for Individual Customer
     * @param xp The XPerson instance
     * @param customerDetails The Customer details map     
     * @throws DatatypeConfigurationException,Exception If data is not in expected format
     */
	
	public static  void setRBAFieldsForIndividual (XPerson xp,HashMap<String, Object> customerDetails) throws DatatypeConfigurationException,Exception {
		//WIP812 - Amit	
		logger.info("In side setRBAFieldsForIndividual"); 
		xp.setCasaRefNo(getValue(customerDetails.get("cusSourceUniqueId")));
		xp.setCasaRefNo(getValue(customerDetails.get("cusSourceRefId")));
		
		xp.setXPersonProfileAttrs(new CustProfileAttr());
		
		String sourceOfIncomeStr = (String) customerDetails.get("sourceOfIncome");		
		xp.getXPersonProfileAttrs().setSourcesOtherIncome(TokenHelper.getArrayWithoutBlankSpace(sourceOfIncomeStr));		
		xp.getXPersonProfileAttrs().setOtherSourceOfOtherIncome(getValue(customerDetails.get("sourceOfOtherIncome")));
		
		
		String sourceOfFundsStr = (String) customerDetails.get("sourceOfFunds");
		xp.getXPersonProfileAttrs().setSourcesOfOngoingFunds(TokenHelper.getArrayWithoutBlankSpace(sourceOfFundsStr));		
		xp.getXPersonProfileAttrs().setOtherSourcesOfFunds(getValue(customerDetails.get("sourceOfOtherFunds")));
		
		
		String sourceOfWealthStr = (String) customerDetails.get("sourceOfWealth");
		xp.getXPersonProfileAttrs().setSourceOfInitialFunds(TokenHelper.getArrayWithoutBlankSpace(sourceOfWealthStr));	
		xp.getXPersonProfileAttrs().setOtherSourceOfInitialFunds(getValue(customerDetails.get("sourceOfOtherWealth")));
		
		xp.getXPersonProfileAttrs().setMonthlyTransCashDepositCount(getValue(customerDetails.get("mEAACashDepositVolume")));
		xp.getXPersonProfileAttrs().setMonthlyTransCashDepositVolume(getValue(customerDetails.get("mEAACashDepositAmount")));
		xp.getXPersonProfileAttrs().setMonthlyTransCashWithdraCount(getValue(customerDetails.get("mEAACashWithdrawalVolume")));
		xp.getXPersonProfileAttrs().setMonthlyTransCashWithdraVolume(getValue(customerDetails.get("mEAACashWithdrawalAmount")));		
		
		xp.getXPersonProfileAttrs().setMonthlyTransCheqDepositCount(getValue(customerDetails.get("mEAAChequeDepositVolume")));
		xp.getXPersonProfileAttrs().setMonthlyTransCheqDepositVolume(getValue(customerDetails.get("mEAAChequeDepositAmount")));
		xp.getXPersonProfileAttrs().setMonthlyTransChequeWithdraCount(getValue(customerDetails.get("mEAAChequeWithdrawalVolume")));
		xp.getXPersonProfileAttrs().setMonthlyTransnChequeWithdraVolume(getValue(customerDetails.get("mEAAChequeWithdrawalAmount")));
		
		xp.getXPersonProfileAttrs().setMonthlyTransOthersDepositCount(getValue(customerDetails.get("mEAAInternationalTransferDepositVolume")));
		xp.getXPersonProfileAttrs().setMonthlyTransOthersDepositVolume(getValue(customerDetails.get("mEAAInternationalTransferDepositAmount")));
		xp.getXPersonProfileAttrs().setMonthlyTransOthersWithdraCount(getValue(customerDetails.get("mEAAInternationalTransferWithdrawalVolume")));
		xp.getXPersonProfileAttrs().setMonthlyTransnOthersWithdraVolume(getValue(customerDetails.get("mEAAInternationalTransferWithdrawalAmount")));
		
		xp.getXPersonProfileAttrs().setMonthlyTransLocalDepositsCount(getValue(customerDetails.get("mEAALocalFundsTransferDepositVolume")));
		xp.getXPersonProfileAttrs().setMonthlyTransLocalDepositVolume(getValue(customerDetails.get("mEAALocalFundsTransferDepositAmount")));
		xp.getXPersonProfileAttrs().setMonthlyTransLocalTransfersWithdraCount(getValue(customerDetails.get("mEAALocalFundsTransferWithdrawalVolume")));
		xp.getXPersonProfileAttrs().setMonthlyTransLocalWithdrawlVolume(getValue(customerDetails.get("mEAALocalFundsTransferWithdrawalAmount")));		

	}
	 /**
     * Set RBA fields for Corporate Customer
     * @param xo The XOrg instance
     * @param customerDetails The Customer details map     
     * @throws DatatypeConfigurationException,Exception If data is not in expected format
     */
	public static  void setRBAFieldsForEntity (XOrg xo,HashMap<String, Object> customerDetails) throws DatatypeConfigurationException, Exception {
		//WIP812 - Amit	
		logger.info("In side setRBAFieldsForEntity");
		xo.setCasaRefNo(getValue(customerDetails.get("cusSourceUniqueId")));
		xo.setCasaRefNo(getValue(customerDetails.get("cusSourceRefId")));
		xo.setXOrgProfileAttrs(new CustProfileAttr());
		
		String sourceOfIncomeStr = (String) customerDetails.get("sourceOfIncome");		
		xo.getXOrgProfileAttrs().setSourcesOtherIncome(TokenHelper.getArrayWithoutBlankSpace(sourceOfIncomeStr));	
		xo.getXOrgProfileAttrs().setOtherSourceOfOtherIncome(getValue(customerDetails.get("sourceOfOtherIncome")));
		
		
		String sourceOfFundsStr = (String) customerDetails.get("sourceOfFunds");
		xo.getXOrgProfileAttrs().setSourcesOfOngoingFunds(TokenHelper.getArrayWithoutBlankSpace(sourceOfFundsStr));		
		xo.getXOrgProfileAttrs().setOtherSourcesOfFunds(getValue(customerDetails.get("sourceOfOtherFunds")));
		
		
		String sourceOfWealthStr = (String) customerDetails.get("sourceOfWealth");
		xo.getXOrgProfileAttrs().setSourceOfInitialFunds(TokenHelper.getArrayWithoutBlankSpace(sourceOfWealthStr));		
		xo.getXOrgProfileAttrs().setOtherSourceOfInitialFunds(getValue(customerDetails.get("sourceOfOtherWealth")));
		
		
		xo.getXOrgProfileAttrs().setMonthlyTransCashDepositCount(getValue(customerDetails.get("mEAACashDepositVolume")));
		xo.getXOrgProfileAttrs().setMonthlyTransCashDepositVolume(getValue(customerDetails.get("mEAACashDepositAmount")));
		xo.getXOrgProfileAttrs().setMonthlyTransCashWithdraCount(getValue(customerDetails.get("mEAACashWithdrawalVolume")));
		xo.getXOrgProfileAttrs().setMonthlyTransCashWithdraVolume(getValue(customerDetails.get("mEAACashWithdrawalAmount")));		
		
		xo.getXOrgProfileAttrs().setMonthlyTransCheqDepositCount(getValue(customerDetails.get("mEAAChequeDepositVolume")));
		xo.getXOrgProfileAttrs().setMonthlyTransCheqDepositVolume(getValue(customerDetails.get("mEAAChequeDepositAmount")));
		xo.getXOrgProfileAttrs().setMonthlyTransChequeWithdraCount(getValue(customerDetails.get("mEAAChequeWithdrawalVolume")));
		xo.getXOrgProfileAttrs().setMonthlyTransnChequeWithdraVolume(getValue(customerDetails.get("mEAAChequeWithdrawalAmount")));
		
		xo.getXOrgProfileAttrs().setMonthlyTransOthersDepositCount(getValue(customerDetails.get("mEAAInternationalTransferDepositVolume")));
		xo.getXOrgProfileAttrs().setMonthlyTransOthersDepositVolume(getValue(customerDetails.get("mEAAInternationalTransferDepositAmount")));
		xo.getXOrgProfileAttrs().setMonthlyTransOthersWithdraCount(getValue(customerDetails.get("mEAAInternationalTransferWithdrawalVolume")));
		xo.getXOrgProfileAttrs().setMonthlyTransnOthersWithdraVolume(getValue(customerDetails.get("mEAAInternationalTransferWithdrawalAmount")));
		
		xo.getXOrgProfileAttrs().setMonthlyTransLocalDepositsCount(getValue(customerDetails.get("mEAALocalFundsTransferDepositVolume")));
		xo.getXOrgProfileAttrs().setMonthlyTransLocalDepositVolume(getValue(customerDetails.get("mEAALocalFundsTransferDepositAmount")));
		xo.getXOrgProfileAttrs().setMonthlyTransLocalTransfersWithdraCount(getValue(customerDetails.get("mEAALocalFundsTransferWithdrawalVolume")));
		xo.getXOrgProfileAttrs().setMonthlyTransLocalWithdrawlVolume(getValue(customerDetails.get("mEAALocalFundsTransferWithdrawalAmount")));		

				
		//Setting up Special Customer Typer
		CdSplCustomerTp cdSplCustomerTp = new CdSplCustomerTp();
		Map<String, String> specialCustomerTypeMap = TokenHelper.getMWRefValues(
				customerDetails.get("ISOCode").toString(), 
				Boolean.parseBoolean(customerDetails.get("offshore").toString()), 
				"SPLCUS",getValue(customerDetails.get("specialCustomerType")));
		for (Map.Entry<String,String> entry1 : specialCustomerTypeMap.entrySet())  {			
			cdSplCustomerTp.set_value(entry1.getValue());
			
		}
		xo.setSpecialCustomer(cdSplCustomerTp);
		
		// Setting up HighRiskIndustries		
		CdHighRiskIndustryTp cdHighRiskIndustryTp = new CdHighRiskIndustryTp();
		Map<String, String> highRiskIndustriesMap = TokenHelper.getMWRefValues(
				customerDetails.get("ISOCode").toString(), 
				Boolean.parseBoolean(customerDetails.get("offshore").toString()), 
				"SRCHRI",getValue(customerDetails.get("highRiskIndustries")));
		for (Map.Entry<String,String> entry2 : highRiskIndustriesMap.entrySet())  {			
			cdHighRiskIndustryTp.set_value(entry2.getValue());			
		}
		xo.setHighRiskIndustry(cdHighRiskIndustryTp);
		
	}	

}