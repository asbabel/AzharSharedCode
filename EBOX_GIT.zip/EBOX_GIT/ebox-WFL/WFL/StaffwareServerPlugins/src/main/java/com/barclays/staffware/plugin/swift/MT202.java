package com.barclays.staffware.plugin.swift;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;


import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.data.IMWDBAccess;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TagHelper;
import com.barclays.staffware.plugin.util.ValidateSwift;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

/**
 * EAI java plugin for creating SWIFT message MT202
 * @author LEES
 *
 */
/*
 * DATE		REFERENCE	WHO		VERSION		COMMENTS
 * ----		---------	---		-------		--------
 * 02SEP14	WP668		SL		1.00		Created for SM03
 * 16MAR15	WP668		SL		1.01		Defect #75 fix
 * 30SEP15  WP668       AK      1.02        Modified method signature of formatHeaderTags
 *                                          as this is changed for zambia  INC0030143712 
 *03SEP18  WP774		PC		1.09		Updated logic to populate UETR if come blank or empty
 */

public class MT202 extends SwiftMessage implements ImmediateReleasePluginSDK{

	private final LoggerConnection logger = 
		new LoggerConnection(MT202.class);
	
	private final String INITIALIZATION_FAILED = 
		SwiftParams.initializationFailed(MT202.class.getName());
	
	private final String USE_MT202_COV = "USE MT202 COV Format";
	
	private final String SWIFT_GPI_MEMBER = "SWIFT GPI Member";
	
	private String paymentType;
	private String country;
	private String offshoreInd;
	private String instCur;
	
	private boolean produce202;
	private boolean covEnabled = false;
	
	private int datastoreId;
	
	private IMWDBAccess dataAccess;
	
	/**
	 * Getter for PAYMENT_TYPE
	 * @return paymentType
	 */
	public String getPaymentType() throws Exception{
		if (paymentType == null || paymentType.trim().isEmpty()){
			throw new Exception(SwiftParams.MISSING_PAYMENT_TYPE);
		}
		return paymentType;
	}
	
	/**
	 * Getter for COUNTRY
	 * @return country
	 */
	public String getCountry() throws Exception{
		if (country == null || country.trim().isEmpty()){
			throw new Exception(SwiftParams.COUNTRY_ERROR);
		}
		return country;
	}
	
	/**
	 * Getter for OFFSHORE_IND
	 * @return offshoreInd
	 */
	public String getOffshoreInd() throws Exception{
		if (offshoreInd == null || offshoreInd.trim().isEmpty()){
			throw new Exception(SwiftParams.OFFSHORE_IND_ERROR);
		}
		return offshoreInd;
	}
	
	/**
	 * Getter for INST_CUR
	 * @return instCur
	 */
	public String getInstCur() throws Exception{
		if (instCur == null || instCur.trim().isEmpty()){
			throw new Exception(SwiftParams.INST_CUR_ERROR);
		}
		return instCur;
	}
	
	/**
	 * Getter for PRODUCE_202
	 * @return

	 */
	public boolean isProduce202(){
		return produce202;
	}
	
	public boolean isCovEnabled(){
		return covEnabled;
	}
	
	public void setDataAccess(IMWDBAccess dataAccess){
		this.dataAccess = dataAccess;
	}
	
	/**
	 * Method is called by Staffware before each execute (unless a caching
	 * option is selected in Staffware
	 * 
	 * @param properties
	 * 			contents of eaijava properties file in 
	 * 			root:/swserver/sw_africa/eaijava
	 */
	@Override
	public void initalizeCustomStep(){
		setDataAccess(new MWDBAccess());
	}

	/**
	 * Method Staffware calls in eaijava step
	 * 
	 * @param staticData
	 * 			a string hardcoded in Staffware, this is ignored in this 
	 * 			method
	 * @param outputFields
	 * 			a list of Staffware field objects which Staffware expects to
	 * 			be returned
	 * @param inputFields
	 * 			a list of Staffware field objects which Staffware provides 
	 * 			(with values)
	 * @return the name value pairs returned to Staffware
	 */
	@Override
	public Map executeProcess(String staticData, List outputFields, List inputFields)
			throws FatalPluginException,
			NonFatalPluginException {
		Map<String, Object> result = 
			new HashMap<String, Object>(outputFields.size());
		StaffwareHelper.initialiseReturnValues(outputFields, result);
		try {
			setMessageType("202");
			if (logger.isDebugEnabled()){
				logger.debug("Arguements received from Staffware: ");
				for (Iterator<?> i = inputFields.iterator(); i.hasNext();){
					Field field = (Field) i.next();
					logger.debug(field.getName() + " = " + field.getValue());
				}
			}
			
			setSender(getFieldValue(inputFields, "SENDER"));
			setReceiver(getFieldValue(inputFields, "RECEIVER"));
			setClassProperties(inputFields);
			logger.debug("Executing getCountryAttribute with getCountry : "+getCountry()+", getOffshoreInd:"+getOffshoreInd()+", USE_MT202_COV :"+USE_MT202_COV);
			covEnabled = this.dataAccess.getCountryAttribute(
					getCountry(), getOffshoreInd(), USE_MT202_COV);
			logger.debug("covEnabled :"+covEnabled);
			StringBuffer swiftMessage = new StringBuffer();
			
			basicHeaderBlock(swiftMessage, getSender());
			applicationHeaderBlock(
					swiftMessage, getMessageType(), getReceiver());
			
			// defect #75 fix to include tag 119 for cover messages
			// defect #68 fix to include tag 103 for MT202
			String tag103 = getFieldValue(inputFields, "TAG_103");
			String tag121 = getFieldValue(inputFields, "MT103_UETR");
			logger.debug("tag103 value:"+tag103);
			logger.debug("tag121 value:"+tag121);
			String tag111 = null;

			boolean GPIMember = dataAccess.getCountryAttribute(
					getCountry(), getOffshoreInd(), SWIFT_GPI_MEMBER);
			logger.debug("GPIMember value:"+GPIMember);
			logger.debug("datastoreId value:"+datastoreId);
			if(datastoreId != 0){
				logger.debug("datastoreId value is not zero");
				Map<String, String> swiftProperties = dataAccess.getSwiftMessageProperties(datastoreId);
				tag111 = swiftProperties.get("111");
				logger.debug("tag111 value from swiftProperties:"+tag111);
				logger.debug("tag121 value from swiftProperties ---s:"+swiftProperties.get("121"));
				if(StringUtils.isBlank(tag121) || "" == tag121){
					logger.debug("tag121 value is empty");
					tag121 = swiftProperties.get("121");
					logger.debug("tag121 value from swiftProperties:"+tag121);
				}
			} 
			
			if(StringUtils.isBlank(tag121)){
				logger.debug("tag121 value is blank so generating random uuid");
				tag121 = UUID.randomUUID().toString();
			}
			
			if(null == tag111){
				logger.debug("tag111 value is null so setting value 001");
				tag111 = "001";
			}

			logger.debug("isProduce202 value:"+isProduce202());
			if (isProduce202()){
				// generated with an outward MT103
				appendUserHeaderBlock(
						swiftMessage, 
						TagHelper.formatCOVHeader("BIFD", false, isCovEnabled(),tag111,
								tag121, GPIMember));
			} else {
				// bank transfers 
				// {113:BIFD} for block 3 is never used in this scenario 
				// Refer to WP124 (Bifurcated Payments) for reference
				appendUserHeaderBlock(
						swiftMessage, 
						TagHelper.formatHeaderTags(
								tag103, "BIFD", 
								(tag103 != null && !tag103.isEmpty()),country,null,tag111,
								tag121, GPIMember, getMessageType()));
			}
			messageBlock(swiftMessage, formatMessageTags(inputFields));
			result.put("STATUSCODE", "0");
			result.put("SWIFT_" + getMessageType(), swiftMessage);
			if (logger.isDebugEnabled()){
				logger.debug("Returning values to Staffare: ");
				List<String> keys = new ArrayList<String>(result.keySet());
				Collections.sort(keys);
				for (Iterator<?> i = keys.iterator(); i.hasNext();){
					String key = (String) i.next();
					logger.debug(key + " <- " + result.get(key));
				}
			}
		} catch (Exception e){
			String executeFailed = 
				SwiftParams.cannotFormMessage(getMessageType());
			if (logger.isErrorEnabled()){
				logger.error(executeFailed + ". Details: " + e.getMessage(), e);
			}
			StaffwareHelper.setErrorMessage(e, result, "-1", executeFailed);
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see com.barclays.staffware.plugin.swift.SwiftMessage#formatMessageTags(java.util.List)
	 */
	@Override
	protected StringBuffer formatMessageTags(List<?> inputFields)
			throws Exception {
		StringBuffer tags = new StringBuffer();
		
		String tag72 = null;
		if (datastoreId > 0) {
			tag72 = 
				this.dataAccess.getSwiftItemValue(
						datastoreId, "Sender to Receiver Information");
		}
		appendMandatoryTag(tags, 
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_20"), 16), 
				"20", SwiftParams.TAG_20_ERROR);

		appendMandatoryTag(tags, 
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_21"), 16), 
				"21", SwiftParams.TAG_21_ERROR);

		appendMandatoryTag(
				tags,
				ValidateSwift.validateDateCurrencyAmount(
						getFieldValue(inputFields, "TAG_32A")), 
				"32A", SwiftParams.TAG_32A_ERROR);
		
		String tag52a = getFieldValue(inputFields, "TAG_52A_BIC");
		if (tag52a != null && !tag52a.trim().isEmpty()){
			appendOptionalTag(tags, 
					ValidateSwift.validateIdBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_52A_ID"), tag52a)), 
					"52A");
		} else {
			Map<String, Object> tag52d = new HashMap<String, Object>();
			TagHelper.setGroupTags(tag52d, inputFields, "TAG_52D_");
			appendOptionalTag(
					tags,
					ValidateSwift.validateIdNameAddress(
							TagHelper.formatTagAddress(
									tag52d, "TAG_52D_", "ID")),
					"52D");
		}
		
		String tag53b = getFieldValue(inputFields, "TAG_53B");
		appendTag53(
				tags, 
				getFieldValue(inputFields, "TAG_53A"), 
				tag53b, 
				this.dataAccess.getCorrespAccId(
						tag53b, getPaymentType(), getInstCur(), 
						getCountry(), getOffshoreInd()));

		appendOptionalTag(tags, 
				ValidateSwift.validateIdBIC(
						getFieldValue(inputFields, "TAG_54A")),
				"54A");
		
		String tag56a = getFieldValue(inputFields, "TAG_56A"); 
		
		if (tag56a != null && !tag56a.isEmpty() && 
				!getReceiver().equalsIgnoreCase(tag56a)){
			appendOptionalTag(tags, 
					ValidateSwift.validateIdBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_56A_ID"), 
									tag56a)), 
					"56A");
		}
		
		String tag57a = getFieldValue(inputFields, "TAG_57A");
		String tag57b = getFieldValue(inputFields, "TAG_57B_LOC");
		
		if (tag57a != null && !tag57a.trim().isEmpty()){
			if (!getReceiver().equalsIgnoreCase(tag57a)){
				appendOptionalTag(tags, 
						ValidateSwift.validateIdBIC(
								TagHelper.formatPartyIdBIC(
										getFieldValue(inputFields, "TAG_57A_ID"), 
										tag57a)), 
						"57A");
			} else {} // no TAG_57 fields are populated
		} else if (tag57b != null && !tag57b.trim().isEmpty()){
			appendOptionalTag(tags, 
					ValidateSwift.validateIdLocation(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_57B_ID"), 
									tag57b)), 
					"57B");
		} else {
			Map<String, Object> tag57d = new HashMap<String, Object>();
			TagHelper.setGroupTags(tag57d, inputFields, "TAG_57D_");
			appendOptionalTag(
					tags,
					ValidateSwift.validateIdNameAddress(
							TagHelper.formatTagAddress(
									tag57d, "TAG_57D_", "ID")),
					"57D");
		}
		
		String tag58 = getFieldValue(inputFields, "TAG_58A");
		if (tag58 != null && !tag58.trim().isEmpty()) {
			appendOptionalTag(tags,
					ValidateSwift.validateIdBIC(TagHelper.formatPartyIdBIC(
							getFieldValue(inputFields, "TAG_58A_ACC"), tag58)),
					"58A");
		} else {
			Map<String, Object> tag58d = new HashMap<String, Object>();
			TagHelper.setGroupTags(tag58d, inputFields, "TAG_58D_");
			appendMandatoryTag(tags,
					ValidateSwift.validateIdNameAddress(
							TagHelper.formatTagAccNameAdd(tag58d, "TAG_58D_")),
					"58D", SwiftParams.TAG_58AD_ERROR);
		}

		if (tag72 != null && !tag72.isEmpty()){
			appendOptionalTag(
					tags, 
					ValidateSwift.validateMultiLineSwiftX(tag72, 6, 35), "72");
		} else {
			appendGroupTag(tags, inputFields, "72", "TAG_72_", 6, 35);
		}
		
		if (isCovEnabled() && isProduce202()){
			String tag50 = getFieldValue(inputFields, "TAG_50F_ID");
			if (tag50 != null && !tag50.trim().isEmpty()) {
				Map<String, Object> tag50f = new HashMap<String, Object>();
				TagHelper.setGroupTags(tag50f, inputFields, "TAG_50F_");
				appendOptionalTag(tags,
						ValidateSwift.validateTag50F(
								TagHelper.formatTagAddress(
										tag50f, "TAG_50F_", "ID")),
						"50F");
			} else {
				appendGroupTag(tags, inputFields, "50K", "TAG_50K_");
			}
			String tag59Addr1 = getFieldValue(inputFields, "TAG_59F_ADDR_1");
			String tag59 = getFieldValue(inputFields, "TAG_59_NAME");
			if(tag59Addr1 != null && !tag59Addr1.isEmpty()){
				appendOptionalTag(tags,
						TagHelper.format59FTag(inputFields), "59F");
			} else if (tag59 != null && !tag59.trim().isEmpty()) {
				appendPartyIdNameAddressTag(tags, 
						inputFields, "59", "TAG_59_", SwiftParams.TAG_59_ERROR);
			} 
			appendGroupTag(tags, inputFields, "70", "TAG_70_", 4, 35);
		}
		return tags;
	}

	/**
	 * Method for setting some of the class properties
	 * @param inputFields
	 * 			Inputs from Staffware
	 */
	private void setClassProperties(List<?> inputFields) throws Exception {
		for (Object inputField : inputFields){
			Field field = (Field) inputField;
			String name = field.getName().trim();
			String value = field.getValue().trim();
			if ("PAYMENT_TYPE".equalsIgnoreCase(name)){
				paymentType = value;
			} else if ("COUNTRY".equalsIgnoreCase(name)){
				country = value;
				
			} else if ("OFFSHORE_IND".equalsIgnoreCase(name)){
				offshoreInd = value;
			} else if ("INST_CUR".equalsIgnoreCase(name)){
				instCur = value;
			} else if ("PRODUCE_202".equalsIgnoreCase(name)){
				produce202 = "Yes".equalsIgnoreCase(value) ? true : false;
			} else if ("GROUP_ID".equalsIgnoreCase(name)){
				int groupId = Integer.parseInt(value);
				datastoreId = 
					this.dataAccess.getDatastoreIdByGroupId(groupId);
			} 
		}
	}
}