package com.barclays.staffware.plugin;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.staffware.plugin.kamls.KamlsException;
import com.barclays.staffware.plugin.util.AddAmendCusErrorScenario;
import com.barclays.staffware.plugin.util.AddAmendCustomerException;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class AddCustomerPlugin extends BaseCustomerPlugin implements ImmediateReleasePluginSDK {
    private static final LoggerConnection logger = new LoggerConnection(AddCustomerPlugin.class);

    @Override
    public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {
        super.initialize(properties, "addCustLog");
    }

    @Override
    public Map execute(String staticData, List outputFields, List inputFields) throws FatalPluginException, NonFatalPluginException {
        try {
            Map<String, Object> returnValues = new HashMap<>();
            Map<String, String> inputFieldMap = parseInputFields(inputFields);

            String eboxActivityReference = inputFieldMap.get("SW_CASEDESC");
            String country = inputFieldMap.get("COUNTRY");
            String offshoreInd = inputFieldMap.get("OFFSHORE_IND");

            StaffwareHelper.initialiseReturnValues(outputFields, returnValues);
            Map<String, String> staffwareTransitionDetails = null;

            try {
                staffwareTransitionDetails = getStaffwareTransitionMap(eboxActivityReference);
            } catch (SQLException e) {
                logger.error("Error reading StaffwareTransition", e);

                setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.TECHNICAL_BEFORE_CUS_A, null);
            }

            if (staffwareTransitionDetails != null) {
                try {
                    boolean canContinue = authoriseCustomer(staffwareTransitionDetails, eboxActivityReference, country, offshoreInd);
                    if (canContinue) {
                        // success
                        setSuccessReturnValues(returnValues);
                    } else {
                        // most likely KAMLS business error
                        logger.error("Error thrown by KAMLS");

                        setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.BUSINESS_KAMLS, null);
                    }
                } catch (KamlsException ke) {
                    logger.error(AddAmendCusErrorScenario.BUSINESS_KAMLS.getErrorMsg(), ke);

                    setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.BUSINESS_KAMLS, ke.getMessage());
                } catch (AddAmendCustomerException ace) {
                    logger.error(ace.getErrorScenario().getErrorMsg(), ace);

                    setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, ace.getErrorScenario(), ace.getMessage());
                } catch (DataAccessException e) {
                	// This catch block added for WP 775 Typhoon TC 24 to shown error message and enable Retry button on Customer Error Notification Screen.
                    logger.error("The customer cannot be added to BRAINS at this time. Possible connection error.", e);

                    setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.CONN_BRAINS_CUS_A, null);
                } catch (Exception e) {
                    logger.error("Unexpected Technical error while running Add Customer Staffware plugin", e);

                    setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.TECHNICAL_AFTER_CUS_A, null);
                }

                printOutOutputValues(returnValues);
            }
            return returnValues;
        } catch (Throwable e) {
            logger.error("Uncaught exception", e);
            throw e;
        }
    }

    @Override
    protected SupportedOperation getOperation() {
        return SupportedOperation.ADD;
    }
}
