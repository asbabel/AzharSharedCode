package com.barclays.staffware.plugin;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.plugin.kamls.KamlsException;
import com.barclays.staffware.plugin.util.AddAmendCusErrorScenario;
import com.barclays.staffware.plugin.util.AddAmendCustomerException;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class AmendCustomerPlugin extends BaseCustomerPlugin implements ImmediateReleasePluginSDK {
    private static final LoggerConnection logger = new LoggerConnection(AmendCustomerPlugin.class);

    @Override
    public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {
        super.initialize(properties, "amendCustLog");
    }

    @Override
    public Map execute(String staticData, List outputFields, List inputFields) throws FatalPluginException, NonFatalPluginException {
        try {
            Map<String, Object> returnValues = new HashMap<>();
            Map<String, String> inputFieldMap = parseInputFields(inputFields);

            String eboxActivityReference = inputFieldMap.get("SW_CASEDESC");
            String country = inputFieldMap.get("COUNTRY");
            String offshoreInd =  inputFieldMap.get("OFFSHORE_IND");

            StaffwareHelper.initialiseReturnValues(outputFields, returnValues);
            Map<String, String> staffwareTransitionDetails = null;

            try {
                staffwareTransitionDetails = getStaffwareTransitionMap(eboxActivityReference);
            } catch (SQLException e) {
                logger.error("Error reading StaffwareTransition.", e);
                setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.TECHNICAL_ERROR, null);
            }

            if (staffwareTransitionDetails != null) {
                try {
                    boolean canContinue = authoriseCustomer(staffwareTransitionDetails, eboxActivityReference, country, offshoreInd);
                    if (canContinue) {
                        // success
                        setSuccessReturnValues(returnValues);
                    } else {
                        logger.error("KAMLS not compliant");

                        setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.KAMLS_CUS_NOT_COMPLIANT, null);
                    }
                } catch (KamlsException ke) {
                    logger.error(AddAmendCusErrorScenario.BUSINESS_BRAINS_OR_KAMLS.getErrorMsg(), ke);

                    setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.BUSINESS_BRAINS_OR_KAMLS, ke.getMessage());
                } catch (AddAmendCustomerException ace) {
                    logger.error(ace.getErrorScenario().getErrorMsg(), ace);

                    setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, ace.getErrorScenario(), ace.getMessage());
                } catch (Exception e) {
                    logger.error("Unexpected Technical error while running Add Customer Staffware plugin", e);

                    setErrorReturnValues(returnValues, eboxActivityReference, staffwareTransitionDetails, AddAmendCusErrorScenario.TECHNICAL_ERROR, null);
                }

                printOutOutputValues(returnValues);
            }
            return returnValues;
        } catch (Throwable e) {
            logger.error("Uncaught exception", e);
            throw e;
        }
    }

    @Override
    protected SupportedOperation getOperation() {
        return SupportedOperation.AMEND;
    }
}
