package com.barclays.staffware.plugin.kamls;

/**
 * Exception from calling KAMLS web service
 */
/*
 * DATE     REFERENCE  WHO      VERSION  COMMENTS
 * -------  ---------  ---      -------  ------------------------------------------
 * 19Nov10  -          EARLEB   1.0      Created                                      
 */
public class KamlsException extends Exception {

    /**
     * Appease the serialisation gods
     */
    private static final long serialVersionUID = -1213104869672830561L;

    public KamlsException() {
        super();
    }
    
    public KamlsException(String message) {
        super(message);
    }

    public KamlsException(String message, Throwable cause) {
        super(message, cause);
    }

    public KamlsException(Throwable cause) {
        super(cause);
    }
}
