package com.barclays.staffware.plugin.dto;

import java.io.Serializable;

/**
 * @author MICHAEL
 *
 *	Class to represent an individual account role
 * OLEReplacementPhase3 - Account Details
 */
/*
 * DATE      REFERENCE      WHO           VERSION     COMMENTS
 * ---------   ----------------     ------------   ------------    ---------------------------
 * 05Dec11  OLERP3              MICHAEL    1a                  Created
 * 
 */
public class AccountRole implements Serializable {
	
	private static final long serialVersionUID = 7524113088630853139L;
	
	private String roleName;
	private String roleSource;
	private String clearingToBranch;
	private String sameDayInd;
	
	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleame) {
		this.roleName = roleame;
	}

	public String getRoleSource() {
		return roleSource;
	}

	public void setRoleSource(String roleSource) {
		this.roleSource = roleSource;
	}

	public String getClearingToBranch() {
		return clearingToBranch;
	}

	public void setClearingToBranch(String clearingToBranch) {
		this.clearingToBranch = clearingToBranch;
	}

	public String getSameDayInd() {
		if("N".equalsIgnoreCase(sameDayInd)) {
			return "No";
		}else if("Y".equalsIgnoreCase(sameDayInd)) {
			return "Yes";
		}
		return sameDayInd;
	}

	public void setSameDayInd(String sameDayInd) {
		this.sameDayInd = sameDayInd;
	}
}
