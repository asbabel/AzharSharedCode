package com.barclays.staffware.plugin.reversal;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import static com.barclays.staffware.plugin.reversal.Constants.*;

/**
 * This class is base class for PaymentManagement validation.
 * 
 * @author Anup Kulkarni
 * 
 */
/* 
 * DATE      REFERENCE   WHO     	VERSION  	COMMENTS
 * --------  ---------   ---     	-------  	----------------------
 * 05/02/16  WP697      Anup        1.0	  		Created
 */
public class PaymentReversalValidator {

    private static final String PAYMENTTYPE = "PaymentType";
    private static final String SOURCESYSTEM = "SourceSystem";

    /**
     * This method will perform all the required validation by passing required parameters. If any one of the validation
     * fails, return
     * 
     * @param paymentBean
     * @param returnValues
     * @throws Exception
     */
    public void validate(PaymentOperationBean paymentBean, Map<String, String> returnValues) throws Exception {

        Integer noOfTCREntries;
        Integer noOfPACEntries;

        // Validate if groupid and ItemNumber are present
        if (paymentBean.getGroupId() == null || paymentBean.getItemNumber() == null) {

            setValidationErrorMessage(returnValues, STRINGONE,
                    String.format(MANDATORY_FIELD_NOT_PROVIDED, paymentBean.getGroupId() == null ? GROUPID : ITEMNUMBER));
            return;
        }
        // Validate original transaction exists in MWDB
        List<HashMap<String, Object>> resultListTCR = PaymentManagementHelper.getTCRData(paymentBean);

        noOfTCREntries = resultListTCR.size();

        List<HashMap<String, Object>> resultListPAC = PaymentManagementHelper.getPACData(paymentBean);

        noOfPACEntries = resultListPAC.size();

        if (noOfTCREntries == 0 || noOfPACEntries == 0) {
            setValidationErrorMessage(returnValues, STRINGONE, PAYMENT_NOT_FOUND);
            return;
        }

        // Set Required data from TCR

        paymentBean.setCountry((String) resultListTCR.get(0).get(COUNTRY));
        paymentBean.setOffshoreInd(INTEGERONE == ((Short) resultListTCR.get(0).get(OFFSHOREIND)).intValue() ? true : false);
        paymentBean.setSourceAppName((String) resultListTCR.get(0).get(SOURCESYSTEM));
        paymentBean.setMsgId((String) resultListTCR.get(0).get(MSGID));

        // Validate that reversal request for original transaction is already
        // processed
        List<HashMap<String, Object>> resultListRevXReferenceByOrigId =
                PaymentManagementHelper.getReversalCrossReferenceDataByOrigGroupId(paymentBean);
        if (resultListRevXReferenceByOrigId.size() >= INTEGERONE) {

            setValidationErrorMessage(returnValues, STRINGONE, PAYMENT_TRANSACTION_ALREADY_REVERSED);
            return;
        }

        // Validate the original transaction status is processed or Extracted.
        String status = ((String) resultListPAC.get(0).get(STATUS)).trim();
        if (!PROCESSED.equalsIgnoreCase(status) && !EXTRACTED.equalsIgnoreCase(status)) {

            setValidationErrorMessage(returnValues, STRINGONE, PAYMENT_PROCESSING_NOT_COMPLETE);
            return;
        }

        // Validate reversal payment type is configured

        if (!isReversalTypeConfigured(resultListPAC, paymentBean, returnValues)) {
            return;
        }

        // Validate Tran and SubTrans Codes

        if (!isValidTranSubCode(paymentBean, returnValues)) {
            return;
        }

        List<HashMap<String, Object>> resultListPACCharges = PaymentManagementHelper.getPACChargesData(paymentBean);

        // Validate accounts are not closed
        if (isClosedAccount(resultListPAC, resultListPACCharges, paymentBean, returnValues)) {
            return;
        }

        // Set Reversal transaction data
        setReversalTransactionData(paymentBean);

        paymentBean.setResultListTCR(resultListTCR);
        paymentBean.setResultListPAC(resultListPAC);
        paymentBean.setResultListPACCharges(resultListPACCharges);

    }

    /**
     * @param returnValues
     * @param errorCode
     * @param errorDescription
     */
    public static void setValidationErrorMessage(
            Map<String, String> returnValues,
            String errorCode,
            String errorDescription) {
        returnValues.put(ERRORCODE, errorCode);
        returnValues.put(ERRORDESC, errorDescription);
    }

    /**
     * This method will check PAC accounts are closed or not
     * 
     * @param resultListPAC
     * @param resultListPACCharges
     * @param paymentBean
     * @param returnValues
     * @return
     * @throws Exception
     */
    private boolean isClosedAccount(
            List<HashMap<String, Object>> resultListPAC,
            List<HashMap<String, Object>> resultListPACCharges,
            PaymentOperationBean paymentBean,
            Map<String, String> returnValues) throws Exception {
        Boolean accountClosed = false;
        Integer closedAccount = PaymentManagementHelper.getClosedAccount(resultListPAC, resultListPACCharges, paymentBean);
        if (closedAccount != null) {
            accountClosed = true;
            setValidationErrorMessage(returnValues, STRINGONE, String.format(ACCOUNT_CLOSED, closedAccount));
        }
        return accountClosed;

    }

    /**
     * his method will validate tran sub code from TRXGeneration table
     * 
     * @param paymentBean
     * @param paymentType
     * @param returnValues
     * @return
     * @throws SQLException
     */
    private boolean isValidTranSubCode(PaymentOperationBean paymentBean, Map<String, String> returnValues)
            throws SQLException {
        Boolean validCodes = true;
        TransactionGenerationBean originatorEntry = new TransactionGenerationBean();
        TransactionGenerationBean counterPartyEntry = new TransactionGenerationBean();
        TransactionGenerationBean suspenseEntry = new TransactionGenerationBean();

        List<HashMap<String, Object>> resultListTrxGeneration = PaymentManagementHelper.getTransSubTransCodes(paymentBean);

        PaymentManagementHelper.setTransSubTransCode(resultListTrxGeneration, originatorEntry, counterPartyEntry,
                suspenseEntry);

        // Verify there are not more than 2 rows and originator and counter
        // party entry are present
        boolean orignatorEntryEmpty = StringUtils.isEmpty(originatorEntry.getTransCode())
                || StringUtils.isEmpty(originatorEntry.getSubTransCode());
        boolean counterpartyEntryEmpty = StringUtils.isEmpty(counterPartyEntry.getTransCode())
                || StringUtils.isEmpty(counterPartyEntry.getSubTransCode());

        if (orignatorEntryEmpty || counterpartyEntryEmpty) {

            setValidationErrorMessage(returnValues, STRINGONE, TRANS_SUB_TRANS_CODE_NOT_EXIST);
            validCodes = false;
        } else {
            paymentBean.setOriginatorEntry(originatorEntry);
            paymentBean.setCounterPartyEntry(counterPartyEntry);
        }
        return validCodes;
    }

    /**
     * This method will set the reversal transaction data
     * 
     * @param paymentBean
     * @throws SQLException
     */
    private void setReversalTransactionData(PaymentOperationBean paymentBean) throws SQLException {
        // Set transaction id for reversal payment
        List<HashMap<String, Object>> resultListMWTRXCounter =
                PaymentManagementHelper.getMWCounterNextValue(TRXCOUNTER, paymentBean.isOffshoreInd() ? 1 : 0);
        paymentBean.setReversalTransactionId(String.valueOf(resultListMWTRXCounter.get(0).get(NEXTVALUE)));

        // Set message id for reversal payment
        List<HashMap<String, Object>> resultListMWMSGCounter =
                PaymentManagementHelper.getMWCounterNextValue(MSGCOUNTER, paymentBean.isOffshoreInd() ? 1 : 0);
        paymentBean.setReversalMsgId(String.valueOf(resultListMWMSGCounter.get(0).get(NEXTVALUE)));

        // Set bankcode for suspense account entry
        List<HashMap<String, Object>> resultListBarcLaysBankCode = PaymentManagementHelper.getBarclaysBankCode(paymentBean);
        paymentBean.setSuspenseBankCode(String.valueOf(resultListBarcLaysBankCode.get(0).get(BARCLAYSBANKCODE)));

    }

    /**
     * This method will validate reversal Payment Type configuration
     * 
     * @param resultListPAC
     * @param paymentBean
     * @param returnValues
     * @return
     * @throws SQLException
     */
    private boolean isReversalTypeConfigured(
            List<HashMap<String, Object>> resultListPAC,
            PaymentOperationBean paymentBean,
            Map<String, String> returnValues) throws SQLException {

        boolean reversalConfigured = true;

        String paymentType = ((String) resultListPAC.get(0).get(PAYMENTTYPE)).trim();

        List<HashMap<String, Object>> resultListPaymentType = PaymentManagementHelper.getPaymentTypeData(paymentType);

        String payment = ((String) resultListPaymentType.get(0).get(PAYMENT)).trim();

        String reversalType = (String) resultListPaymentType.get(0).get(REVERSALTYPE);
        if (!StringUtils.isEmpty(reversalType)) {
            reversalType = reversalType.trim();
        }
        List<HashMap<String, Object>> resultListReversalType = null;
        if (!StringUtils.isBlank(reversalType)) {
            resultListReversalType = PaymentManagementHelper.getPaymentTypeData(payment + reversalType);
        }

        if (StringUtils.isBlank(reversalType) || resultListReversalType == null || resultListReversalType.isEmpty()) {
            setValidationErrorMessage(returnValues, STRINGONE, REVERSAL_CODE_NOT_CONFIGURED);
            reversalConfigured = false;
        } else {
            paymentBean.setReversalPaymentType(payment + reversalType);
        }

        return reversalConfigured;
    }

}
