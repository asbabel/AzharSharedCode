package com.barclays.staffware.plugin;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.bean.Country;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.dto.Account;
import com.barclays.staffware.plugin.dto.Customer;
import com.barclays.staffware.plugin.dto.CustomerAccountAddResponse;
import com.barclays.staffware.plugin.dto.CustomerAccountAddUpdateRequest;
import com.barclays.staffware.plugin.dto.CustomerContactAddUpdateRequest;
import com.barclays.staffware.plugin.dto.CustomerEmploymentAddResponse;
import com.barclays.staffware.plugin.dto.CustomerEmploymentAddUpdateRequest;
import com.barclays.staffware.plugin.dto.CustomerNoteAddUpdateRequest;
import com.barclays.staffware.plugin.kamls.KamlsException;
import com.barclays.staffware.plugin.kamls.KamlsHelper;
import com.barclays.staffware.plugin.util.AddAmendCusErrorScenario;
import com.barclays.staffware.plugin.util.AddAmendCustomerException;
import com.barclays.staffware.plugin.util.DateUtil;
import com.barclays.staffware.plugin.util.GlobalDetailsEnquiry;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TokenHelper;
import com.ibm.math.BigDecimal;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.*;

import javax.annotation.Resource;
import java.io.File;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.SortedMap;
import java.util.TreeMap;

import static com.barclays.staffware.plugin.util.StaffwareHelper.STATUSCODE;
import static com.barclays.staffware.plugin.util.StaffwareHelper.STATUSDESC;
import static com.barclays.staffware.plugin.util.TokenHelper.addCustomerEmployment;
import static com.barclays.staffware.plugin.util.TokenHelper.fetchAccounts;
import static com.barclays.staffware.plugin.util.TokenHelper.fetchContacts;
import static com.barclays.staffware.plugin.util.TokenHelper.fetchCustomerDetails;

public abstract class BaseCustomerPlugin {
    public static final String  STAFFWAREMAP_USERNAME = "ext_userName", STAFFWAREMAP_BRANCH = "ext_mainBranch",
            STAFFWAREMAP_LOCATION_NAME = "ext_location_name", STAFFWAREMAP_LOCATION_CODE  = "ext_location_code";

    public enum SupportedOperation {
        ADD,
        AMEND
    }

    protected static final String CONTACT_TYPE_RESIDENTIAL = "RESIDE";
    protected static final String CONTACT_TYPE_CORRESPONDENSE = "CORRES";

    private static final String ID_LIST_SEPARATOR = ",";
    private static final LoggerConnection logger = new LoggerConnection(BaseCustomerPlugin.class);
    private static final String INIT_FAILED_MSG = SwiftParams.initializationFailed(BaseCustomerPlugin.class.getName());

    protected boolean authoriseCustomer(Map<String, String> staffwareTransitionDetails, String eboxActivityReference, String country, String offshoreInd) throws Exception {
        // No customerNumber means create it, so the authorisation is guaranteed a customer
        boolean isNewCustomer = StringUtils.isEmpty(staffwareTransitionDetails.get("customerNumber"));

        logger.info("New Customer? "+ isNewCustomer +  (!isNewCustomer? " [" + staffwareTransitionDetails.get("customerNumber") + "]":""));
        if (isNewCustomer) {
            int newCustomerNumber = createCustomer(staffwareTransitionDetails, country, offshoreInd);

            logger.info("New Customer Number "+ newCustomerNumber +" created.");

            saveStaffwareTransition(staffwareTransitionDetails, eboxActivityReference, "customerNumber", Integer.toString(newCustomerNumber));
            saveStaffwareTransition(staffwareTransitionDetails, eboxActivityReference, "customerContactData", "");
        }

        boolean canContinue = callKamlsService(staffwareTransitionDetails, country, offshoreInd, eboxActivityReference, isNewCustomer);

        if (!canContinue) {
            return false;
        }        
        
    	//WP812- RBA Changes
        if(TokenHelper.isRiskBasedKYCEnabled(country,offshoreInd)) {     	        
        	TokenHelper.updateCustomerRBADetails(staffwareTransitionDetails,country,offshoreInd,"1");
        }

        // Now save the amendments required as a note
        staffwareTransitionDetails.put("noteDate", "");
        staffwareTransitionDetails.put("notes", staffwareTransitionDetails.get("amendmentsRequired"));
        staffwareTransitionDetails.put("noteType", "README");
        staffwareTransitionDetails.put("noteActionBy", "");

        saveCustomerNotes(staffwareTransitionDetails, country, offshoreInd);

        logger.info("Customer "+getOperation().name()+" operation successful.");
        //cab.set("fcuPassFields", cab.getSanctionsPassedString(  cab.getBooleanValue("datanomicSwitch") ));

        return true;
    }

    // This is just used for logging purposes / has no functional use.
    protected abstract SupportedOperation getOperation();

    protected boolean callKamlsService(Map<String, String> staffwareTransitionMap, String country, String offshoreInd, String eboxActivityRef, boolean isNewCustomer) throws Exception {
        boolean canContinue = true;


        if (StringUtils.isNotBlank(staffwareTransitionMap.get("isKamlsOnlineCall")) && Boolean.parseBoolean(staffwareTransitionMap.get("isKamlsOnlineCall")))  {
            Customer customer = new Customer();
            customer.setCustomerNumber(Integer.parseInt(staffwareTransitionMap.get("customerNumber")));
            loadCustomer(customer, country, offshoreInd);
            //SelectionUtils.selectCustomer(request, customer, user);
            Map<String, String> params = new HashMap<>();
            boolean isPepChange = customer.getPepInd().equals(staffwareTransitionMap.get("pepInd"));

            if ("Yes".equals(staffwareTransitionMap.get("isReferralForAuth")) &&
                    // ***HACK FIX*** This is here because for some reason if we
                    // are adding a customer then the isReferralForAuth property
                    // isn't always set to yes at this point and it should be.
                    // This seems to be something to do with saving and holding.
                    // TODO: figure out why it isn't set properly and fix it at
                    // the root.
                    !"ADD".equalsIgnoreCase(staffwareTransitionMap.get("operation"))) {
                String result = "";
                try {
                    // If no further authorisation then add try to make the edit.
                    logger.info("In Amend Kamls Call");
                    result = KamlsHelper.callKamlsService(staffwareTransitionMap, country, offshoreInd, false);
                } catch (Exception ke) {
                    logger.warn(ke.getMessage(), ke);

                    throw new AddAmendCustomerException(ke.getMessage(), ke, AddAmendCusErrorScenario.CONN_KAMLS_AMEND);
                    //return false;
                }

                if (!"Y".equals(customer.getIsAddedToKamls())){
                    updateCustomerIsAddedToKamls(staffwareTransitionMap, customer, country, offshoreInd,null, null, null);

                    if ("no".equalsIgnoreCase(result)) {
                        // The edit cannot be made - they have only just been
                        // added to kamls and so are not listed as compliant.
                        logger.info("just been added to kamls so not compliant");
                        //canContinue = false;
                        throw new AddAmendCustomerException("user just been added to kamls so not compliant", AddAmendCusErrorScenario.KAMLS_CUS_JUST_BEEN_ADDED);
                    }
                } else {
                    if (validateRiskScoreAndLevel(staffwareTransitionMap.get("riskScore"), staffwareTransitionMap.get("riskLevel")) == false) {
                        logger.info("invalid risk score or risk level");
                        staffwareTransitionMap.put("postbackReason", "CALL_BACK_ERROR");
                        throw new AddAmendCustomerException("", AddAmendCusErrorScenario.KAMLS_INVALID_RISK_SCORE_LEVEL_AMEND);
                    }

                    updateCustomerIsAddedToKamls(staffwareTransitionMap,
                            customer,
                            country,
                            offshoreInd,
                            staffwareTransitionMap.get("riskScore"),
                            staffwareTransitionMap.get("riskLevel"),
                            null);

                /*    if ("no".equalsIgnoreCase(result)) {
                        // They are not compliant and are already in kamls!
                        logger.info("user not compliant and already in Kamls");
                        throw new AddAmendCustomerException("User not compliant and already in Kamls", AddAmendCusErrorScenario.KAMLS_CUS_NOT_COMPLIANT);
                    }*/
                }

                params.put("riskLevel", staffwareTransitionMap.get("riskLevel"));
                params.put("riskScore", staffwareTransitionMap.get("riskScore"));
            } else {
                // If the customer is not in KAMLS, they have the required fields
                // and either
                //      this is an new customer or
                //		this is an existing customer and the Pre-Auth call is switched on
                // then add them to KAMLS.
                logger.info(!"Y".equals(customer.getIsAddedToKamls()) +"&&"+
                        KamlsHelper.kamlsFieldsRequiredFilled(customer, country, offshoreInd) +"&&"+
                        "("+isNewCustomer +"||"+ getCustomerCountryConfigValue(country, offshoreInd, "KAMLS Migration Pre-Auth Online Call")+")");
                if (!"Y".equals(customer.getIsAddedToKamls()) &&
                        KamlsHelper.kamlsFieldsRequiredFilled(customer, country, offshoreInd) &&
                        (isNewCustomer || getCustomerCountryConfigValue(country, offshoreInd, "KAMLS Migration Pre-Auth Online Call"))) {
                    try {
                        HashMap<String, String> riskInfo = KamlsHelper.callKamlsService( KamlsHelper.setValuesForKamls(staffwareTransitionMap, country, offshoreInd));

                        params.put("riskLevel", riskInfo.get("riskLevel"));
                        params.put("riskScore", riskInfo.get("riskScore"));
                    } catch (Exception ke) {
                        logger.info(ke.getMessage());
                        throw new KamlsException(ke.getMessage(), ke);
                    }
                    updateCustomerIsAddedToKamls(staffwareTransitionMap, customer, country, offshoreInd,null, null, null);
                }
            }
            saveStaffwareTransition(staffwareTransitionMap, eboxActivityRef, params);
        }
        return canContinue;
    }

    private void loadCustomer(Customer customer, String country, String offshoreInd) throws Exception {
        fetchCustomerDetails(customer, country, offshoreInd);
        fetchAccounts(customer, new Country(country, "1".equals(offshoreInd)), false);
        fetchContacts(customer, new Country(country, "1".equals(offshoreInd)));
    }


    protected Map<String, String> parseInputFields(List inputFields) {
        Map<String, String> fieldsWeCareAbout = new HashMap<>();
        logger.info("Arguments received from Staffware100: ");
        for (Object inputField : inputFields) {
            Field field = (Field) inputField;
            logger.info(field.getName() + " = '" + field.getValue() + "' ;");
            if (field.getName().equalsIgnoreCase("COUNTRY")) {
                fieldsWeCareAbout.put("COUNTRY", field.getValue());
            } else if (field.getName().equalsIgnoreCase("OFFSHORE_IND")) {
                fieldsWeCareAbout.put("OFFSHORE_IND", field.getValue());
            } else if (field.getName().equalsIgnoreCase("SW_CASEDESC")) {
                fieldsWeCareAbout.put("SW_CASEDESC", field.getValue());
            }
        }
        return fieldsWeCareAbout;
    }

    protected void printOutOutputValues(Map<String, Object> returnValues) {
        logger.info("Returning values to Staffware: ");
        List<String> keys = new ArrayList<>(returnValues.keySet());
        Collections.sort(keys);
        for (String key : keys) {
            logger.info(key + " <- " + returnValues.get(key));
        }
    }

    protected void setSuccessReturnValues(Map<String, Object> returnValues) {
        returnValues.put(STATUSCODE, "0");
        returnValues.put(STATUSDESC, "SUCCESS");
    }

    protected void setErrorReturnValues(Map<String, Object> returnValues, String eboxActivityReference, Map<String, String> staffwareTransitionDetails, AddAmendCusErrorScenario errorScenario, String message) {
        returnValues.put(STATUSCODE, "-1");
        returnValues.put(STATUSDESC, errorScenario.getFullErrorMsg(message));
        saveStaffwareTransition(staffwareTransitionDetails, eboxActivityReference, "customerError", errorScenario.getFullErrorMsg(message));
        saveStaffwareTransition(staffwareTransitionDetails, eboxActivityReference, "AmndRetry", errorScenario.getRetryAmendStaffwareTransitionValue());
    }

    protected void initialize(Properties properties, String logFile) throws FatalPluginException, NonFatalPluginException {
        try {
            BrainsSocketConnectionFactory.getInstance().useSecure(properties);
            DataSourceDirectory.getInstance().basePluginDS();
            ClassPathResource resource = new ClassPathResource(properties.getProperty(logFile));

            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());

            // load db driver (unsure if necessary)
           // Class.forName(properties.getProperty("db_driver"));
            //LoggerConnection.configureWFL(properties.getProperty(logFile));

        } catch (Exception e) {
            logger.error(INIT_FAILED_MSG + ". Details: " + e.getMessage(), e);
            // raise exception to calling code, all exceptions considered fatal at this time
            throw new FatalPluginException(INIT_FAILED_MSG + e.getMessage());
        }
    }

    /**
     * Get values out of StaffwareTransition
     */
    protected String getStaffwareTransitionValue(String eboxActivityReference, String key) throws SQLException, DataAccessException {
        return (String) getStaffwareTransitionMap(eboxActivityReference).get(key);
    }

    protected Map<String, String> getStaffwareTransitionMap(String eBoxActivityRef) throws SQLException {
        SortedMap<String, Object> args = new TreeMap<>();
        args.put("eboxActivityReference", eBoxActivityRef);
        Map<String, String> resultMap = new HashMap<>();

        try (SQLConnection db = MWDBAccess.getDatabaseConnection();
            CallableStatement stmt = db.prepareCall("dbo.wfe_genericStaffwareTransitionGet", args);
            ResultSet rs = db.executeQuery(stmt, args)) {

            while (rs.next()) {
                String name = rs.getString("FieldName");
                String value = rs.getString("FieldValue");
                int elementIndex = rs.getInt("ElementIndex");

                if (elementIndex < 1) {
                    resultMap.put(name, value);
                } else { // This must be an "idList"
                    String existingValue = resultMap.get(name);
                    String newValue = existingValue.concat(ID_LIST_SEPARATOR).concat(value);
                    resultMap.put(name, newValue);
                }
            }
            if(rs != null) {
            	rs.close();
            }
        }

        // Add User / Location / Branch details to map
        try (SQLConnection db = MWDBAccess.getDatabaseConnection();
             CallableStatement stmt = db.prepareCall("dbo.wfe_LocationDetailsFromActivityRef", args);
             ResultSet rs = db.executeQuery(stmt, args)) {

            if (rs.next()) {
                String locationName = rs.getString("LocationName");
                String mainBranch = Integer.toString(rs.getInt("MainBranch"));
                String userName = rs.getString("User");
                String locationCode = rs.getString("LocationCode");

                resultMap.put (STAFFWAREMAP_LOCATION_NAME, locationName);
                resultMap.put (STAFFWAREMAP_BRANCH, mainBranch);
                resultMap.put (STAFFWAREMAP_USERNAME, userName);
                resultMap.put (STAFFWAREMAP_LOCATION_CODE, locationCode);
            }
            if(rs != null) {
            	rs.close();
            }
        }

        return resultMap;
    }

    /**
     * Save value into StaffwareTransition
     */
    protected void saveStaffwareTransition(Map<String, String> staffwareTransitionMap, String eBoxActivityRef, String fieldName, String fieldValues) {
        SortedMap<String, Object> args = new TreeMap<>();
        args.put("EBoxActivityReference", eBoxActivityRef);
        args.put("FieldName", fieldName);
        args.put("FieldValue", fieldValues);

        try (SQLConnection db = MWDBAccess.getDatabaseConnection()){
            db.execute("dbo.wfe_GenericStaffwareTransitionInsert", args);
            if (staffwareTransitionMap != null) {
                staffwareTransitionMap.put(fieldName, fieldValues);
            }
        } catch (SQLException e) {
            logger.error("Error writing to StaffwareTransition", e);
        }
    }

    protected void saveStaffwareTransition(Map<String, String> staffwareTransitionMap, String eBoxActivityRef, Map<String, String> params) throws SQLException {
        for (String key : params.keySet()) {
            saveStaffwareTransition(staffwareTransitionMap, eBoxActivityRef, key, params.get(key));
        }
    }

    protected List<Integer> getIdList(Map<String, String> staffwareTransitionMap, String listName) {
        String commaSeparatedList = staffwareTransitionMap.get(listName + "IdList");

        List<Integer> idList = new ArrayList<>();

        if (StringUtils.isNotBlank(commaSeparatedList)) {
            for (String id : commaSeparatedList.split(ID_LIST_SEPARATOR)) {
                idList.add(Integer.parseInt(id));
            }
        }

        logger.info("getIdList for "+ listName +" = "+ idList);
        return idList;
    }

    protected static boolean getCustomerCountryConfigValue(String country, String offshoreInd, String attributeString) throws Exception {
        boolean configured =  false ;
        configured = "1".equals(getCountryAttribute(country ,offshoreInd, attributeString));
        return configured;
    }

    protected static String getCountryAttribute(String country, String offshoreInd, String description)throws Exception {
        SortedMap<String, Object> args = new java.util.TreeMap<>();

        try (SQLConnection conn = MWDBAccess.getDatabaseConnection()) {
            args.put("Country", country);
            args.put("OffshoreInd", offshoreInd);
            args.put("Description", description);

            CallableStatement cs = null;
            ResultSet rs = null;
            try {
                cs = conn.prepareCall("dbo.csc_getCountryAttributeValue", args);

                try {
                    rs = conn.executeQuery(cs, args);
                    if (rs.next()) {
                        return rs.getString("Value");
                    }
                } finally {
                    if (cs != null) cs.close();
                }
            } finally {
                if (conn != null) conn.close();
                if(rs != null) {
                	rs.close();
                }
            }
        }
        return "0";
    }

    protected static boolean validateRiskScoreAndLevel(String riskScore, String riskLevel) {

        if ((riskScore != null && riskScore.isEmpty())
                || (riskLevel != null && riskLevel.isEmpty())) {
            return false;
        }
        try {
            if (riskScore != null) {
                Integer.parseInt(riskScore);
            }
        } catch (NumberFormatException e) {
            return false;
        }
        if (riskLevel != null && riskLevel.equalsIgnoreCase("Not calculated")) {
            return false;
        }
        return true;
    }

    protected static void updateCustomerIsAddedToKamls(
            Map<String, String> staffwareTransitionMap,
            Customer customer,
            String country,
            String offshoreInd,
            String riskScore,
            String riskLevel,
            String productType) throws Exception
    {
        customer.setIsAddedToKamls("Y");

        if (StringUtils.isNotBlank(riskScore)){
            customer.setRiskScore(riskScore);
        }

        if (StringUtils.isNotBlank(riskLevel)){
            customer.setRiskLevel(riskLevel);
        }

        if (StringUtils.isNotBlank(productType)){
            // Remove intended kamls product types for the specified type.
            if (productType.equals("CA")){
                customer.setCurrentAccount("0");
            } else if (productType.equals("FNS") || productType.equals("LNS")){
                customer.setSecuredLoanCurrentFinance("0");
                customer.setSecuredLoanOrFinancing("0");
            } else if (productType.equals("FNU") || productType.equals("LNU")){
                customer.setUnsecuredLoanOrFinancing("0");
            } else if (productType.equals("IP") || productType.equals("TF")){
                customer.setTradePlanOrProducts("0");
            } else if (productType.equals("MF")){
                customer.setInvMgmt("0");
            } else if (productType.equals("SA")){
                customer.setSavingAccount("0");
            } else if (productType.equals("TD")){
                customer.setTermDeposit("0");
            }
        }
// commented below to not call cust-u token
        //TokenHelper.updateCustomerDetails(staffwareTransitionMap, customer, country, offshoreInd, "10");
    }

    protected int createCustomer(Map<String, String> staffwareTransitionMap, String country, String offshoreInd) throws Exception {
        logger.info ("Creating new customer...");

        // Create Customer
        int customerNumber = TokenHelper.saveCustomer(staffwareTransitionMap, country, offshoreInd);
        staffwareTransitionMap.put("customerNumber", Integer.toString(customerNumber));

        logger.info ("Updating Customer documents...");
        // Save the documents
        updateDocumentCustomerNumber(staffwareTransitionMap, customerNumber);
        //CustomerDocumentHelper.saveDocuments(user, ccb);

        // Create Customer Contact
        String contactType = staffwareTransitionMap.get("contactType");

        CustomerContactAddUpdateRequest custContactAddUpdateRequest = prepareContactAddUpdate(customerNumber, 1, staffwareTransitionMap, country, offshoreInd);

        // create contact for selected CONTYP as primary contact
        custContactAddUpdateRequest.setType(contactType);
        custContactAddUpdateRequest.setPrimaryContactIndicator("Y");

        logger.info ("Adding customer contacts...");

        TokenHelper.addCustomerContact(custContactAddUpdateRequest, true);

        String propositionType = staffwareTransitionMap.get("propositionType");

        if ("P".equalsIgnoreCase(propositionType) || "S".equalsIgnoreCase(propositionType)) {
            custContactAddUpdateRequest.setPrimaryContactIndicator("N");

            // If CONTYP is not RESIDE, create a contact copy of RESIDE type
            if (!CONTACT_TYPE_RESIDENTIAL.equalsIgnoreCase(contactType)) {
                custContactAddUpdateRequest.setType(CONTACT_TYPE_RESIDENTIAL);
                TokenHelper.addCustomerContact(custContactAddUpdateRequest, true);
            }
            // If CONTYP is not CORRES, create a contact copy of CORRES type
            else {
                custContactAddUpdateRequest.setType(CONTACT_TYPE_CORRESPONDENSE);
                TokenHelper.addCustomerContact(custContactAddUpdateRequest, true);
            }
        }

        logger.info ("Saving customer notes...");

        // This try-catch block added for WP 775 Typhoon TC 15 to return customerNumber even if any token fails
        try
        {
            // Create customer notes
            saveCustomerNotes(staffwareTransitionMap, country, offshoreInd);

            // Create Customer Employment
            if (!TokenHelper.isCorporateType(propositionType)) {
                logger.info ("Adding Customer employment...");

                saveCustomerEmployment(staffwareTransitionMap, country, offshoreInd);
            }

            // Linked account
            saveAccountLink(staffwareTransitionMap, country, offshoreInd);
        }
        finally
        {
            return customerNumber;
        }
    }

    private void saveAccountLink(Map<String,String> staffwareTransitionMap, String country, String offshoreInd) throws Exception {
        String linkAccountNumber =  staffwareTransitionMap.get("linkAccountNumber");
        String linkAccountBranch =  staffwareTransitionMap.get("linkAccountBranch");

        if (StringUtils.isNotBlank(linkAccountBranch) && StringUtils.isNotBlank(linkAccountNumber)) {
            logger.info ("Adding account links: " + "linkAccountNumber="+ linkAccountNumber + "; linkAccountBranch="+ linkAccountBranch);
            Account account = new Account(Integer.parseInt(linkAccountBranch), Integer.parseInt(linkAccountNumber));
            //setLinkAccount(account);
            Customer customer = new Customer(country, Integer.parseInt(staffwareTransitionMap.get("customerNumber")));

            TokenHelper.fetchCustomerDetails(customer, country, offshoreInd);

            if (!account.isPopulated()) {
                TokenHelper.fetchAccountDetails(account, country, offshoreInd);
            }

            CustomerAccountAddUpdateRequest request = new CustomerAccountAddUpdateRequest();
            request.setCustomerNumber(customer.getCustomerNumber());
            request.setCountry(country);
            request.setPrimaryAccountIndicator("Y");
            request.setAccountType(Integer.toString(account.getAccountType()));
            request.setBarclaysContactBranch(Integer.toString(account.getBranchNumber()));
            request.setBarclaysContactHost(staffwareTransitionMap.get(STAFFWAREMAP_LOCATION_NAME));
            request.setBarclaysContactName(staffwareTransitionMap.get(STAFFWAREMAP_USERNAME));
            request.setOffshoreInd(offshoreInd);
            request.setBranchNumber(new DecimalFormat("000").format(account.getBranchNumber()));
            request.setAccountNumber(new DecimalFormat("0000000").format(account.getAccountNumber()));
            request.setContactStatus("OPENED");

            CustomerAccountAddResponse response = new CustomerAccountAddResponse();
            TokenHelper.addCustomerAccount(request, response, 1);
        }
    }


    private void saveCustomerEmployment(Map<String,String> staffwareTransitionMap, String country, String offshoreInd) throws Exception {
        if (staffwareTransitionMap.get("employmentShown") == null || !staffwareTransitionMap.get("employmentShown").equalsIgnoreCase("true")) {
            return;
        }
        CustomerEmploymentAddResponse empResponse = new CustomerEmploymentAddResponse();
        addCustomerEmployment(prepareEmploymentAddUpdate(staffwareTransitionMap, country, offshoreInd), empResponse);
    }

    private CustomerEmploymentAddUpdateRequest prepareEmploymentAddUpdate(Map<String, String> staffwareTransitionMap, String country, String offshoreInd) throws DataAccessException {

        CustomerEmploymentAddUpdateRequest empRequest = new CustomerEmploymentAddUpdateRequest();

        empRequest.setEmployeeNumber(staffwareTransitionMap.get("employeeNumber"));
        empRequest.setEmployerEmail(staffwareTransitionMap.get("employerEmail"));
        empRequest.setCustomerNumber(Integer.parseInt(staffwareTransitionMap.get("customerNumber")));
        empRequest.setSequenceNumber(staffwareTransitionMap.get("employmentSequenceNo") != null? Integer.parseInt(staffwareTransitionMap.get("employmentSequenceNo")): 0);
        empRequest.setEmploymentType(staffwareTransitionMap.get("employmentType"));
        empRequest.setDesignation(staffwareTransitionMap.get("designation"));

        empRequest.setEmploymentStatus(staffwareTransitionMap.get("employmentStatus"));
        empRequest.setNatureOfBusiness(staffwareTransitionMap.get("empNatureOfBusiness"));
        empRequest.setEmployer(staffwareTransitionMap.get("employer"));
        empRequest.setJobTitle(staffwareTransitionMap.get("empJobTitle"));
        empRequest.setAddressFirstLine(staffwareTransitionMap.get("empAddressFirstLine"));
        empRequest.setPoBoxDetails(staffwareTransitionMap.get("empPoBoxDetails"));
        empRequest.setTown(staffwareTransitionMap.get("empTown"));
        empRequest.setDistrict(staffwareTransitionMap.get("empDistrict"));
        empRequest.setPostcode(staffwareTransitionMap.get("empPostcode"));
        empRequest.setSourceOfFunds(staffwareTransitionMap.get("empSourceOfFunds"));

        Integer lengthYears = StringUtils.isNotBlank(staffwareTransitionMap.get("empLengthYears"))? Integer.parseInt(staffwareTransitionMap.get("empLengthYears")) : null;
        Integer lengthMonths = StringUtils.isNotBlank(staffwareTransitionMap.get("empLengthMonths"))? Integer.parseInt(staffwareTransitionMap.get("empLengthMonths")) : null;
        empRequest.setLengthYears((lengthYears == null) ? 0 : lengthYears.intValue());
        empRequest.setLengthMonths((lengthMonths == null) ? 0 : lengthMonths.intValue());

        empRequest.setEmpContactName(staffwareTransitionMap.get("empContactName"));
        empRequest.setEmpContactNumber(staffwareTransitionMap.get("empContactNumber"));

        BigDecimal grossIncome =  StringUtils.isNotBlank(staffwareTransitionMap.get("empGrossIncome")) ? TokenHelper.getSafeBigDecimal(staffwareTransitionMap.get("empGrossIncome")) : null;
        empRequest.setGrossIncome((grossIncome == null) ? new BigDecimal("0") : grossIncome);
        empRequest.setGrossCur(staffwareTransitionMap.get("empGrossCur"));
        BigDecimal otherIncome = StringUtils.isNotBlank(staffwareTransitionMap.get("empOtherIncome"))? TokenHelper.getSafeBigDecimal(staffwareTransitionMap.get("empOtherIncome")) : null;
        empRequest.setOtherIncome((otherIncome == null) ? new BigDecimal("0") : otherIncome);
        empRequest.setOtherCur(staffwareTransitionMap.get("empOtherCur"));

        if (staffwareTransitionMap.get("empVerified") != null && Boolean.parseBoolean(staffwareTransitionMap.get("empVerified"))) {
            empRequest.setEmploymentStatus("CURRNT");
        } else {
            empRequest.setEmploymentStatus("NEW");
        }

        empRequest.setEmploymentStatusDate(new GlobalDetailsEnquiry(new Country(country, "1".equalsIgnoreCase(offshoreInd))).getBusinessDate());
        empRequest.setContractExpiryDate(DateUtil.getDateOrNull(staffwareTransitionMap.get("contractExpiryDate")));
        empRequest.setCountry(country);
        empRequest.setOffshore("1".equalsIgnoreCase(offshoreInd));
        empRequest.setFosuser(staffwareTransitionMap.get(STAFFWAREMAP_USERNAME));
        empRequest.setHostname(staffwareTransitionMap.get(STAFFWAREMAP_LOCATION_CODE));
        //261 start
        empRequest.setVersionNumber("5");
        //261 end

        return empRequest;
    }

    protected void saveCustomerNotes(Map<String,String> staffwareTransitionMap, String country, String offshoreInd) throws Exception {
        // Only do it if notes were provided
        String notes = staffwareTransitionMap.get("notes");
        if ("".equals(notes)) {
            return;
        }

        CustomerNoteAddUpdateRequest request = new CustomerNoteAddUpdateRequest();
        request.setCustomerNumber(Integer.parseInt(staffwareTransitionMap.get("customerNumber")));
        Date noteDate;
        try {
            noteDate = new SimpleDateFormat("dd/MM/yyyy").parse(staffwareTransitionMap.get("noteDate")); // format this dd/MM/yyyy
        } catch (ParseException e) {
            logger.info("noteDate not provided [or wrong format], defaulting to current Date");
            noteDate = new Date();
        }

        request.setNoteAdditionDate(noteDate);
        request.setNoteType(staffwareTransitionMap.get("noteType"));
        request.setContactBranch(staffwareTransitionMap.get(STAFFWAREMAP_BRANCH));
        // If location code is non-numeric, we need to enter 0 here
        if (request.getContactBranch().matches(".*[^\\d].*")) {
            request.setContactBranch("0");
        }
        request.setHostname(staffwareTransitionMap.get(STAFFWAREMAP_LOCATION_CODE));
        request.setUsername(staffwareTransitionMap.get(STAFFWAREMAP_USERNAME));
        request.setNote(staffwareTransitionMap.get("notes"));

        try {
            request.setActionBy( new SimpleDateFormat("dd/MM/yyyy").parse(staffwareTransitionMap.get("noteActionBy")) ); // format this dd/MM/yyyy
        } catch (ParseException e) {
            logger.info("noteActionBy not provided");
        }

        request.setVersionNumber(1);

        request.setCountry(country);
        request.setOffshore("1".equalsIgnoreCase(offshoreInd));

        TokenHelper.addCustomerNote(request);
    }

    private CustomerContactAddUpdateRequest prepareContactAddUpdate(int customerNumber, int contactSeqNo, Map<String, String> staffwareTransitionMap, String country, String offshoreInd) {
        CustomerContactAddUpdateRequest contact = new CustomerContactAddUpdateRequest();
        contact.setCustomerNumber(customerNumber);
        contact.setSequenceNumber(contactSeqNo);
        contact.setPrimaryContactIndicator(Boolean.parseBoolean(staffwareTransitionMap.get("primaryContactIndicator")) ? "Y" : "N");
        contact.setType(staffwareTransitionMap.get("contactType"));
        contact.setAdviceMethod(staffwareTransitionMap.get("adviceMethod"));
        contact.setName(staffwareTransitionMap.get("contactName"));
        //contact.setPosition(cab.getString("position"));
        contact.setDateOfBirth(DateUtil.getPastDate(staffwareTransitionMap.get("contactDateOfBirth")));
        contact.setMemorableName(staffwareTransitionMap.get("memorableName"));
        contact.setAddressFirstLine(staffwareTransitionMap.get("addressFirstLine"));
        contact.setPoBoxDetails(staffwareTransitionMap.get("poBoxDetails"));
        contact.setTownCity(staffwareTransitionMap.get("townCity"));
        contact.setDistrictRegion(staffwareTransitionMap.get("districtRegion"));
        contact.setCountry(staffwareTransitionMap.get("country"));
        contact.setPostcodeZip(staffwareTransitionMap.get("postcodeZip"));
        contact.setPhoneNumber(staffwareTransitionMap.get("phoneNumber"));
        contact.setMobileNumber(staffwareTransitionMap.get("mobileNumber"));
        contact.setEmailAddress(staffwareTransitionMap.get("emailAddress"));
        contact.setAlternateEmailAddress(staffwareTransitionMap.get("alternateEmailAddress"));
        contact.setStatementDeliveryPreference(staffwareTransitionMap.get("statementDeliveryPreference"));
        contact.setComments(staffwareTransitionMap.get("comments"));
        contact.setFosUser(staffwareTransitionMap.get(STAFFWAREMAP_USERNAME));
        contact.setHostName(staffwareTransitionMap.get(STAFFWAREMAP_LOCATION_CODE));
        contact.setVersionNumber("4");

        contact.setFaxNumber(staffwareTransitionMap.get("faxNumber"));
        if (StringUtils.isNotBlank(staffwareTransitionMap.get("timeAtAddressMonths"))) {
            contact.setTimeAtAddressMonths(Integer.parseInt(staffwareTransitionMap.get("timeAtAddressMonths")));
        }

        if (StringUtils.isNotBlank(staffwareTransitionMap.get("timeAtAddressYears"))) {
            contact.setTimeAtAddressYears(Integer.parseInt(staffwareTransitionMap.get("timeAtAddressYears")));
        }
        contact.setResidentialStatus(staffwareTransitionMap.get("residentialStatus"));
        Integer numberOfDependents = null;
        if (StringUtils.isNotBlank(staffwareTransitionMap.get("numberOfDependents"))) {
            numberOfDependents = Integer.parseInt(staffwareTransitionMap.get("numberOfDependents"));
        }
        contact.setNumberOfDependents((numberOfDependents == null) ? 0 : numberOfDependents.intValue());
        contact.setPlaceOfBirth(staffwareTransitionMap.get("placeOfBirth"));
        contact.setWorkPhone(staffwareTransitionMap.get("workPhone"));
        Integer mobileCountryCode = null;
        if (StringUtils.isNotBlank(staffwareTransitionMap.get("mobileCountryCode"))) {
            mobileCountryCode = Integer.parseInt(staffwareTransitionMap.get("mobileCountryCode"));
        }
        contact.setMobileCountryCode((mobileCountryCode == null) ? 0 : mobileCountryCode.intValue());
        contact.setMaritalStatus(staffwareTransitionMap.get("maritalStatus"));

        contact.setBrainsCountry(country);
        contact.setOffshore("1".equalsIgnoreCase(offshoreInd));

        return contact;
    }

    private void updateDocumentCustomerNumber(Map<String, String> staffwareTransitionMap, int customerNumber) throws SQLException {
        // Grab ALL Document IDs that need customer number updated
        List<Integer> proofOfEmploymentIdList = getIdList(staffwareTransitionMap, "proofOfEmployment");
        List<Integer> additionalDocIdList = getIdList(staffwareTransitionMap, "additionalDoc");
        List<Integer> proofOfAddressIdList = getIdList(staffwareTransitionMap, "proofOfAddress");
        List<Integer> idDocIdList = getIdList(staffwareTransitionMap, "idDoc");
        List<Integer> credChkIdList = getIdList(staffwareTransitionMap, "credChk");

        // ... and add new customerNumber to ALL Documents.
        List<Integer> allDocIds = new ArrayList<>();
        allDocIds.addAll(proofOfAddressIdList);
        allDocIds.addAll(proofOfEmploymentIdList);
        allDocIds.addAll(additionalDocIdList);
        allDocIds.addAll(idDocIdList);
        allDocIds.addAll(credChkIdList);

        for (Integer docId: allDocIds) {
            updateCustomerNumberOnDocument(customerNumber, docId);
        }
    }

    private void updateCustomerNumberOnDocument(int customerNumber, Integer docId) throws SQLException {
        logger.info("Updating document ID "+ docId + " with CustomerNumber "+ customerNumber);

        SortedMap<String, Object> args = new TreeMap<>();
        args.put("CustomerNumber", customerNumber);
        args.put("CustomerDocumentId", docId);

        try (SQLConnection db = MWDBAccess.getDatabaseConnection()){
            db.execute("dbo.wfe_accountopeningCustomerDocumentUpdateCustomerNumber", args);
        }
    }

}
