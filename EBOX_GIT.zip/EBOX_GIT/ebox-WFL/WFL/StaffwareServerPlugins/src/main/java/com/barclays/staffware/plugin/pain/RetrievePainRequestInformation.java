package com.barclays.staffware.plugin.pain;

import static com.barclays.ebox.doc.pain.PainUtilDocument.BANKCODE_BBS;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_AMOUNT;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_CURRENCY;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_CUSTOMERID;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_MESGID;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_NARRATION;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_RECEIVERACCOUNT;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_RECEIVERBANK;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_RECEIVERNAME;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_SENDERACCOUNT;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_SENDERBANK;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_SENDERNAME;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_SENDERREFERENCE;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_TRANSACTIONCODE;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_VALUEDATE;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_ALLOW_ADDITIONAL_FIELDS;
import static com.barclays.staffware.plugin.util.PainParams.COUNTRY;
import static com.barclays.staffware.plugin.util.PainParams.GROUPID;
import static com.barclays.staffware.plugin.util.PainParams.EBOX_ACT_REF;
import static com.barclays.staffware.plugin.util.PainParams.VALUEDATEFROM;
import static com.barclays.staffware.plugin.util.PainParams.SP_GETPAINREQUESTDETAILS;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTRY;
import static com.barclays.staffware.plugin.util.PainParams.DBOFFSHOREIND;
import static com.barclays.staffware.plugin.util.PainParams.DBORIGINATORNAME;
import static com.barclays.staffware.plugin.util.PainParams.DBIBANNUMBER;
import static com.barclays.staffware.plugin.util.PainParams.DBORIGINATORBRANCHID;
import static com.barclays.staffware.plugin.util.PainParams.DBORIGINATORACCOUNTNUMBER;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTERPARTYBANKCODE;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTERPARTYNAME;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTERPARTYNUMBER;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTERLOCALAMOUNT;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTERPARTYCURRENCY;
import static com.barclays.staffware.plugin.util.PainParams.DBSENDERSREFERENCE;
import static com.barclays.staffware.plugin.util.PainParams.DBTRXID;
import static com.barclays.staffware.plugin.util.PainParams.DBPAYMENTTYPE;
import static com.barclays.staffware.plugin.util.PainParams.DBORIGINATORNARRATIVE;
import static com.barclays.staffware.plugin.util.PainParams.DBEMPTYNARRATIVE;
import static com.barclays.staffware.plugin.util.PainParams.DBERROR;
import static com.barclays.staffware.plugin.util.PainParams.BRAINSERR;
import static com.barclays.staffware.plugin.util.PainParams.CUSTNOERROR;
import static com.barclays.staffware.plugin.util.PainParams.CLOSERESOURCESERR;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTERPARTYBRANCHID;
import static com.barclays.staffware.plugin.util.PainParams.DBPURPOSE;
import static com.barclays.staffware.plugin.util.PainParams.SP_GETCOUNTRYCONFIGDETAILS;
import static com.barclays.staffware.plugin.util.PainParams.ADDITIONAL_PAIN001_MESSAGE_FLAG;
import static com.barclays.staffware.plugin.util.PainParams.VALUE;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTERPARTYNARRATIVE;
import static com.barclays.staffware.plugin.util.PainParams.DBCOUNTERPARTYREMITTANCEINFORMATION;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_SENDERBRANCH;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_RECEIVERBRANCH;
import static com.barclays.ebox.doc.pain.PainUtilDocument.PAIN001_PURPOSE;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.UUID;
import com.barclays.ebox.doc.pain.PainUtilDocument;
import com.barclays.ebox.util.PainUtilException;
import org.apache.commons.lang.StringUtils;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.generic.math.Decimal;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.CurrencyUtil;
import com.barclays.staffware.plugin.util.PainParams;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.ibm.math.BigDecimal;

/**
 * Class that should contain util methods that would be utilized for enriching
 * PAIN Request Data.
 * 
 * @author Shahir.Hiralal
 * 
 */

/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 05Feb16   SEFTP2    SRH      1a     Created for Retrieving info from MWDB
 * 18Feb16   SEFTP2    SRH      1b     Updated Mappings
 * 18Jul16   WP716     AS       1c     Modified buildStaffwareMap method to add new fields as part of SEFTPhase2 Integration.
 * 08SEP16			   Anup			   Added logic to fetch and store SEFT turn on/off switch configuration
 * 17Jan17   WP715     LeyJ      -     Refactored data access to MWDB.
 * 17DEC17   WP749   Akhilesh    1d    Adding getNarrative Method as part of WP 749 Seft narrative changes
 * 08AUG17   WL379   Akhilesh    1e    Adding trim to fix the WL379 to remove trailing and leading space from narrative and purpose field
 */

public final class RetrievePainRequestInformation {
    private static final LoggerConnection LOG = new LoggerConnection(
            RetrievePainRequestInformation.class);

    /**
     * Private Constructor
     */
    private RetrievePainRequestInformation() {

    }

    /**
     * Method that would enrich the Pain Request Data from MWDB, build a Map for
     * PAIN001.
     * 
     * @param inputFields
     * @return painMap
     */
    @SuppressWarnings("rawtypes")
    public static Map buildStaffwareMap(List inputFields) {
        Map<String, Object> painMap = new HashMap<>();
        RetrieveInformationFromBrains objBrains =
                new RetrieveInformationFromBrains();
        SortedMap<String, String> args = new TreeMap<>();
        args.put(EBOX_ACT_REF,
                StaffwareHelper.getFieldValue(inputFields, EBOX_ACT_REF));
        args.put(GROUPID, StaffwareHelper.getFieldValue(inputFields, GROUPID));
        CallableStatement cs = null;
        ResultSet results = null;
        SQLConnection conn = null;
		
		try {
            conn = MWDBAccess.getDatabaseConnection();
            
            // Make DB call to fetch the flag value. Hard coded value "0" is passed because 
            // offshore indicator is not present in inpuFields. To remove the hard coding we will have to query the 
            // database again using group id. As this change is only for Seychelles country
            // offshore indicator will always be zero.Hence avoiding a database hit. 
            String allowAdditionalFields = getCountryConfig(conn,
                    StaffwareHelper.getFieldValue(inputFields, COUNTRY), "0", ADDITIONAL_PAIN001_MESSAGE_FLAG);
            
            painMap.put(PAIN001_ALLOW_ADDITIONAL_FIELDS, allowAdditionalFields);
            
            cs = conn.prepareCall(SP_GETPAINREQUESTDETAILS, args);
            results = conn.executeQuery(cs, args);
            while (results.next()) {
                DateFormat dateFormat = new SimpleDateFormat(VALUEDATEFROM);
                String guid = UUID.randomUUID().toString().replaceAll("-", "");
                String country = results.getString(DBCOUNTRY);
                String currency = results.getString(DBCOUNTERPARTYCURRENCY);
                Date valueDate = null;
                valueDate =
                        objBrains.getBusinessDate(country,
                                results.getBoolean(DBOFFSHOREIND));
                BigDecimal tempLocalAmt =
                        new BigDecimal(results.getString(DBCOUNTERLOCALAMOUNT));

                String localAmount =
                        Decimal.getFormattedDecimal(
                                tempLocalAmt,
                                CurrencyUtil.getCurrencyMask(country,
                                        results.getInt(DBOFFSHOREIND), currency),
                                0);

                painMap.put(PAIN001_MESGID, guid);
                painMap.put(PAIN001_SENDERBANK, BANKCODE_BBS);
                painMap.put(PAIN001_SENDERNAME,
                        results.getString(DBORIGINATORNAME));
                String iban = results.getString(DBIBANNUMBER);
                String branchId = results.getString(DBORIGINATORBRANCHID);
                String accNum = results.getString(DBORIGINATORACCOUNTNUMBER);
                if (iban != null && iban.length() > 0) {
                    painMap.put(PAIN001_SENDERACCOUNT, iban);
                } else {
                    painMap.put(PAIN001_SENDERACCOUNT, branchId + accNum);
                }
                painMap.put(PAIN001_CUSTOMERID,
                        objBrains.getCustomerNumber(accNum, branchId, country));
                painMap.put(PAIN001_RECEIVERBANK,
                        results.getString(DBCOUNTERPARTYBANKCODE));
                painMap.put(PAIN001_RECEIVERNAME,
                        results.getString(DBCOUNTERPARTYNAME));
                painMap.put(PAIN001_RECEIVERACCOUNT,
                        results.getString(DBCOUNTERPARTYNUMBER));
                painMap.put(PAIN001_AMOUNT, localAmount);
                painMap.put(PAIN001_CURRENCY, currency);
                painMap.put(PAIN001_VALUEDATE, PainUtilDocument.transformDate(
                        dateFormat.format(valueDate), PainParams.VALUEDATEFROM,
                        PainParams.VALUEDATETO));
                String sendersReference = results.getString(DBSENDERSREFERENCE);
                if (sendersReference != null) {
                    painMap.put(PAIN001_SENDERREFERENCE, sendersReference);
                } else {
                    painMap.put(PAIN001_SENDERREFERENCE,
                            results.getString(DBTRXID));
                }
                painMap.put(PAIN001_TRANSACTIONCODE,
                        results.getString(DBPAYMENTTYPE));
                String narr = results.getString(DBORIGINATORNARRATIVE);
                if (narr != null && narr.equals("")) {
                    narr = DBEMPTYNARRATIVE;
                }
                String cpRemittanceInformation = results.getString(DBCOUNTERPARTYREMITTANCEINFORMATION);
                String cpNarrative = results.getString(DBCOUNTERPARTYNARRATIVE);
                
                String narrative = StringUtils.trim(getNarrative(cpRemittanceInformation,cpNarrative,sendersReference)); // WP 749 SEFT Narrative Changes WorkLog379
                
                painMap.put(PAIN001_NARRATION,narrative);
                painMap.put(PAIN001_SENDERBRANCH,
                        results.getString(DBORIGINATORBRANCHID));
                painMap.put(PAIN001_RECEIVERBRANCH,
                        results.getString(DBCOUNTERPARTYBRANCHID));
               //Start  WP 749 SEFT Narrative Changes 
               if (narrative.length()>35 ) {
				  painMap.put(PAIN001_PURPOSE,StringUtils.trim(StringUtils.substring(narrative,0,35)));
               }else{
               	  painMap.put(PAIN001_PURPOSE,StringUtils.trim(narrative));
               }
            }
        } catch (SQLException e) {
            LOG.error(DBERROR, e);
        } catch (DataAccessException e) {
            LOG.error(BRAINSERR, e);
        } catch (PainUtilException e) {
            LOG.error(CUSTNOERROR, e);
        } finally {
            closeDBConnections(results, cs, conn);
        }
        return painMap;
    }
    
    /** This method will return the narrative value
     * 
     * @param cpRemittanceInformation
     * @param cpNarrative
     * @param sendersReference
     * @return narrative
     */ 
    private static String getNarrative(String cpRemittanceInformation,String cpNarrative, String sendersReference){
    	String narrative=null;
    	if (cpRemittanceInformation == null||cpRemittanceInformation.equals(""))
    	{
    		if(cpNarrative==null||cpNarrative.equals("")){
    			narrative = sendersReference;
    		}else{
    			narrative = cpNarrative;
    		}
    	}
    	else
    	{
    		narrative = cpRemittanceInformation;
    	}
    	return narrative;
    }
   
    /** This method will return the country config value for required flag
     * 
     * @param country
     * @param offshoreInd
     * @param flagDescription
     * @return
     */
	private static String getCountryConfig(SQLConnection conn, String country, String offshoreInd,
			String flagDescription) {
		SortedMap<String, String> args = new TreeMap<>();
		CallableStatement cs = null;
		ResultSet results = null;
		String flagValue = "0";
        
    	args.put(DBCOUNTRY,country);
        args.put(DBOFFSHOREIND,offshoreInd );
        args.put(DBPURPOSE,flagDescription);
        
		LOG.info("Message Argument fetching for additional Fields" + country);
    	
		try {
			cs = conn.prepareCall(SP_GETCOUNTRYCONFIGDETAILS, args);

			results = conn.executeQuery(cs, args);

			if (results.next()) {
				flagValue = results.getString(VALUE);
			}
		} 
		catch (SQLException e) {
			LOG.error(DBERROR, e);
		} 
		finally {
		    closeDBConnections(results, cs, null);
		}
    	return flagValue;	
    }
	
	/**
	 * Handles the closure of all database connections
	 * 
	 * @param results
	 * @param cs
	 * @param conn
	 */
	private static void closeDBConnections(ResultSet results, CallableStatement cs, SQLConnection conn) {
	    if (results != null) {
            try {
                results.close();
            } catch (SQLException e) {
                LOG.error("Failed to close ResultSet", e);
            }
        }
        if (cs != null) {
            try {
                cs.close();
            } catch (SQLException e) {
                LOG.error("Failed to close CollableStatement", e);
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                LOG.error("Failed to close database connection", e);
            }
        }
	}
}
