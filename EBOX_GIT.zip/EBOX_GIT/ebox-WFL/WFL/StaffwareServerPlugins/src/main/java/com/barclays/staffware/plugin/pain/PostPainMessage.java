package com.barclays.staffware.plugin.pain;

import static com.barclays.staffware.plugin.util.PainParams.CLASSNOTFOUNDERROR;
import static com.barclays.staffware.plugin.util.PainParams.COUNTRY;
import static com.barclays.staffware.plugin.util.PainParams.DBDRIVER;
import static com.barclays.staffware.plugin.util.PainParams.ERRORCODE;
import static com.barclays.staffware.plugin.util.PainParams.ERRORDESC;
import static com.barclays.staffware.plugin.util.PainParams.GROUPID;
import static com.barclays.staffware.plugin.util.PainParams.ITEMNUMBER;
import static com.barclays.staffware.plugin.util.PainParams.MQPARAMS;
import static com.barclays.staffware.plugin.util.PainParams.PAINREQCREATED;
import static com.barclays.staffware.plugin.util.PainParams.SENTTOMQ;
import static com.barclays.staffware.plugin.util.PainParams.STAFFWAREARGS;
import static com.barclays.staffware.plugin.util.PainParams.STATUSCODE;
import static com.barclays.staffware.plugin.util.PainParams.STATUSDESC;
import static com.barclays.staffware.plugin.util.PainParams.SUCCESS;
import static com.barclays.staffware.plugin.util.PainParams.SUCCESSCODE;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;


import com.barclays.ebox.doc.pain.PainUtilDocument.PainType;
import com.barclays.ebox.util.PainUtil;
import com.barclays.ebox.util.PainUtilException;
import com.barclays.ebox.util.StorePainMessage;
import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.mq.SendMessageToMQ;
import com.barclays.staffware.plugin.util.PainParams;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.ibm.mq.MQException;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * EAI java plugin for Creating/Storing and Sending a PAIN001 Message. Called in
 * the DOMOUT Procedure on Staffware in the POSTPAIN Step.
 * 
 * @author Shahir.Hiralal
 * 
 */

/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 25Jan16   SEFTP2    SRH      1a     Created for Posting PAIN 001 Message
 * 27Jan16   SEFTP2    SRH      1b     Created Constants for Pain Params and Added
 * 19Feb16   SEFTP2    SRH      1c     Cleaner Code   
 * 17Jan17   WP715     LeyJ      -     Refactored data access to MWDB. 
 * 07Jul17   WP715     LeyJ      -     Updated to use the refactored StorePainMessage class 
 *                                     instead of the PainUtil class.
 */
public class PostPainMessage implements ImmediateReleasePluginSDK {
    private SendMessageToMQ objMQ = new SendMessageToMQ();
    private static final LoggerConnection LOG = new LoggerConnection(PostPainMessage.class);
    private final String initializationFailed = PainParams.initializationFailed(PostPainMessage.class.getName());

    /**
     * Method is called by Staffware before each execute (unless a caching
     * option is selected in Staffware) Loads properties file. This file should
     * contain the DB Driver and the MQ Parameters to the relevant environment.
     * 
     * @param properties contents of eaijava properties file in
     * root:/swserver/sw_africa/eaijava
     */
    @Override
    public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {
       // DataSourceDirectory.getInstance().configure(properties);
        try {
        	BrainsSocketConnectionFactory.getInstance().useSecure(properties);

            ClassPathResource resource = new ClassPathResource(properties.getProperty("postPainMessage"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());

            DataSourceDirectory.getInstance().basePluginDS();
            //Class.forName(properties.getProperty(DBDRIVER));
            objMQ.setMqParams(properties.getProperty(MQPARAMS));
            //LoggerConnection.configureWFL(properties.getProperty("postPainMessage"));
            LOG.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	LOG.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
    }

    /**
     * Method Staffware calls in eaijava step, will take in Pain Fields to Form
     * a PAIN001, Store the Created PAIN001 Message and Send the Message to MQ.
     * 
     * @param staticData a string hardcoded in Staffware, this is ignored in
     * this method
     * @param outputFields a list of Staffware field objects which Staffware
     * expects to be returned
     * @param inputFields a list of Staffware field objects which Staffware
     * provides (with values)
     * @return the name value pairs returned to Staffware
     */
    @SuppressWarnings("rawtypes")
    @Override
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {
        Map<String, Object> result = new HashMap<String, Object>(outputFields.size());

        StaffwareHelper.initialiseReturnValues(outputFields, result);

        if (LOG.isDebugEnabled()) {
            LOG.debug(STAFFWAREARGS);
            for (Iterator<?> i = inputFields.iterator(); i.hasNext();) {
                Field field = (Field) i.next();
                LOG.debug(field.getName() + " = " + field.getValue());
            }
        }

        try {
            result = managePainMessage(inputFields, outputFields.size());
        } catch (SQLException e) {
            LOG.error(PainParams.DBERROR + e.getMessage(), e);
        }
        return result;
    }

    /**
     * Method Form a PAIN001 message, Store the Created PAIN001 Message and Send
     * the Message to MQ
     * 
     * @param inputFields a list of Staffware field objects which Staffware
     * provides (with values)
     * @param outputFieldsSize the size of the outputFields list
     * @return
     * @throws SQLException
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    private Map<String, Object> managePainMessage(List inputFields, int outputFieldsSize) throws SQLException {
        Map<String, Object> result = new HashMap<String, Object>(outputFieldsSize);
        SQLConnection conn = null;
        try {
            Map<String, String> painRequestParams = null;
            painRequestParams = RetrievePainRequestInformation.buildStaffwareMap(inputFields);
            String painRequest = PainUtil.createValidatedPainXml(PainType.PAIN001_CREDITTFR, painRequestParams);
            LOG.info(PAINREQCREATED + painRequest);
            conn = MWDBAccess.getDatabaseConnection();
			conn.setAutoCommit(false);

            StorePainMessage painMessage =
                    new StorePainMessage(painRequest, true);

            painMessage.storePain(
                    StaffwareHelper.getFieldValue(inputFields, GROUPID),
                    StaffwareHelper.getFieldValue(inputFields, ITEMNUMBER),
                    StaffwareHelper.getFieldValue(inputFields, COUNTRY), conn);

            if (objMQ.putInMQ(painRequest, conn)) {
                conn.commit();
                LOG.info(SENTTOMQ);
                result.put(STATUSCODE, SUCCESSCODE);
                result.put(STATUSDESC, SUCCESS);
            }
        } catch (SQLException e) {
            result.put(STATUSCODE, ERRORCODE);
            result.put(STATUSDESC, ERRORDESC);
            StaffwareHelper.rollbackSQLTransaction(conn, e, LOG, PainParams.SPERROR);
        } catch (IOException e) {
            result.put(STATUSCODE, ERRORCODE);
            result.put(STATUSDESC, ERRORDESC);
            StaffwareHelper.rollbackSQLTransaction(conn, e, LOG, PainParams.IOERROR);
        } catch (MQException e) {
            result.put(STATUSCODE, ERRORCODE);
            result.put(STATUSDESC, ERRORDESC);
            StaffwareHelper.rollbackSQLTransaction(conn, e, LOG, PainParams.MQERROR);
        } catch (PainUtilException e) {
            result.put(STATUSCODE, ERRORCODE);
            result.put(STATUSDESC, ERRORDESC);
            StaffwareHelper.rollbackSQLTransaction(conn, e, LOG, PainParams.PAINUTILERROR);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return result;
    }
}
