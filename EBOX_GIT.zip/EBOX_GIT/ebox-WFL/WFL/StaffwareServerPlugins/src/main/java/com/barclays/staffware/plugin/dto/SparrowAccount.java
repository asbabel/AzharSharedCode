package com.barclays.staffware.plugin.dto;


/**
 * An account on the cards system (Sparrow).
 */
/*
 * DATE     REFERENCE  WHO    REVISION  COMMENTS
 * -------  ---------  ---    --------  ----------------------------------------
 * 14Nov07  PAT02281   KEMPD  1a        WP137: created.
 */
public interface SparrowAccount
    extends
        CustomerAccount
{
    /**
     * Sparrow account type.
     */
    public int getSparrowAccountType();
    
    /**
     * Is this the primary account for the card?
     */
    public boolean isPrimaryCardAccount();

    /**
     * Set whether or not this is the primary account for the card.
     */
    public void setPrimaryCardAccount(
            boolean value);
}
