/*
 * Card.java
 *
 * Created on 30 November 2004, 16:45
 */

package com.barclays.staffware.plugin.dto;

import com.barclays.staffware.plugin.util.CardFormatter;

import java.util.Collections;
import java.util.Iterator;
import java.util.SortedSet;


/**
 *
 * @author  SHARPEP
 */
public class Card
    implements
        Comparable,
        java.io.Serializable
{    
    private static final long serialVersionUID = 7418821507397256308L;
    private final char maskCharacter = '*';
    private final int  maskLength = 6;
    
    private String cardNumber=new String("");
    private String maskedCardNumber=new String("");
    private SortedSet accounts=new java.util.TreeSet();
    private String expiryDate=new String();
    private String status=new String("");
    private String lastAction = new String("");
    
    /**
     * EMV fields required for SPARROW
     */
    

    
    public boolean equals(Object obj) {
        return this.compareTo(obj)==0;
    }
           
    /**
     * Holds value of property imd.
     */
    private int imd;    
    
    /**
     * Holds value of property track2.
     */
    private String track2;
    
    /**
     * Holds value of property cvv2.
     */
    private int cvv2;
    
    /**
     * Holds value of property pinBlock.
     */
    private String pinBlock;
    
    /**
     * Holds value of property cycleLength.
     */
    private int cycleLength;
    
    /**
     * Holds value of property cycleLimitOnline.
     */
    private int cycleLimitOnline;
    
    /**
     * Holds value of property cycleLimitNetwork.
     */
    private int cycleLimitNetwork;
    
    /**
     * Holds value of property cardHolderName.
     */
    private String cardHolderName;
    
    /**
     * Holds value of property address1.
     */
    private String address1;
    
    /**
     * Holds value of property address2.
     */
    private String address2;
    
    /**
     * Holds value of property address3.
     */
    private String address3;
    
    /**
     * Holds value of property address4.
     */
    private String address4;

    /** Creates a new instance of Card */
    public Card() {
    }
    /**
     * Hold the Flat whether to write any data on Card
     */
    private boolean writeDataToCard;
    
    /**
     * Holds the Value for customerId
     */
    private String customerId;
	
    
    /**
     * Holds the Value for iccData
     */
    private String iccData;

    /**
     * Holds the Value for iccData
     */
    private String cardType;
    
    /**
     * Holds the internationalIssuearLimit 
     */
    private Integer internationalIssuerLimit;
    
    /**
     * Holds international Issuer Limit Cycle.
     */
    private Integer internationalIssuerLimitCycle;

    
    /**
     * Holds the Value for tagData 91 coming from Sparrow
     */
    private String tagData;
    
    
    /**
     * Holds the Value for IssuerScript
     */
    private String issuerScript;
    
    
    /**
	 * @return the cardType
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * @param cardType the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	/**
     * Holds the Value for iccData
     */
    private Integer intIssuerLimit;
    
    /**
     * Holds the Value for iccData
     */
    private Integer intIssuerLimitCycle;
    
    
    /**
	 * @return the writeDataToCard
	 */
	public boolean isWriteDataToCard() {
		return writeDataToCard;
	}

	/**
	 * @param writeDataToCard the writeDataToCard to set
	 */
	public void setWriteDataToCard(boolean writeDataToCard) {
		this.writeDataToCard = writeDataToCard;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the intIssuerLimit
	 */
	public Integer getIntIssuerLimit() {
		return intIssuerLimit;
	}

	/**
	 * @param intIssuerLimit the intIssuerLimit to set
	 */
	public void setIntIssuerLimit(Integer intIssuerLimit) {
		this.intIssuerLimit = intIssuerLimit;
	}

	/**
	 * @return the intIssuerLimitCycle
	 */
	public Integer getIntIssuerLimitCycle() {
		return intIssuerLimitCycle;
	}

	/**
	 * @param intIssuerLimitCycle the intIssuerLimitCycle to set
	 */
	public void setIntIssuerLimitCycle(Integer intIssuerLimitCycle) {
		this.intIssuerLimitCycle = intIssuerLimitCycle;
	}


    
    
    public Card(
        CustomerAccount account)
    {
        accounts.add(account);
    }
    
    public int compareTo(Object o) {
        if(!(o instanceof Card)) throw new ClassCastException();
        int result;
        String thisCardNumber=new String(this.getCardNumber());
        String thatCardNumber=new String(((Card)o).getCardNumber());
        result=thisCardNumber.compareTo(thatCardNumber);
            
        return result;
    }
    
    protected void finalize() throws Throwable {
        super.finalize();
    }
        
    /**
     * Accounts with which the card is associated.
     */
    public SortedSet getAccounts()
    {
        return Collections.unmodifiableSortedSet(accounts);
    }
    
    public String getCardNumber() {
        return this.cardNumber;
    }
    
    public void setCardNumber(String cardNumber) {
        this.cardNumber=cardNumber;
        if(this.cardNumber.length() != 0)
        {
        	this.maskedCardNumber = getMaskedCardNumber();
        }
    }
    
    public String getMaskedCardNumber() {
         
        String pan = CardFormatter.formatDisplayCardNumber(this.cardNumber);
        
        return(pan.length() == 0)?  pan: 
        	pan.substring(0, 6)
        	+ this.getMaskedString()
        	+ pan.substring
        			(pan.length() -4,pan.length());
    }
    
    private String getMaskedString() {
		char[] maskedCharArray = new char[this.maskLength];
		
		for(int i=0;i < this.maskLength;i++)
		{
			maskedCharArray[i] = this.maskCharacter;
		}
		
		return String.copyValueOf(maskedCharArray);
	}

	public void setMaskedCardNumber(String maskedCardNumber) {
        this.maskedCardNumber=maskedCardNumber;
    }
    
    public String getExpiryDate() {
        return this.expiryDate;
    }
    
    public void setExpiryDate(String expiryDate) {
        this.expiryDate=expiryDate;
    }
    public String getStatus() {
        return this.status;
    }
    public void setStatus(String status) {
        this.status=status;
    }
 
    /**
     * Add an account to the card.
     */
    public void addAccount(
        CustomerAccount account)
    {
        accounts.add(account);
    }
    
    /**
     * Remove all accounts from the card.
     */
    public void clearAccounts()
    {
        accounts.clear();
    }
    
    /**
     * Getter for property imd.
     * @return Value of property imd.
     */
    public int getImd() {
        return this.imd;
    }
    
    /**
     * Setter for property imd.
     * @param imd New value of property imd.
     */
    public void setImd(int imd) {
        this.imd = imd;
    }
    
    /**
     * Getter for property track2.
     * @return Value of property track2.
     */
    public String getTrack2() {
        return this.track2;
    }
    
    /**
     * Setter for property track2.
     * @param track2 New value of property track2.
     */
    public void setTrack2(String track2) {
        this.track2 = track2;
    }
    
    /**
     * Getter for property cvv2.
     * @return Value of property cvv2.
     */
    public int getCvv2() {
        return this.cvv2;
    }
    
    /**
     * Setter for property cvv2.
     * @param cvv2 New value of property cvv2.
     */
    public void setCvv2(int cvv2) {
        this.cvv2 = cvv2;
    }
    
    /**
     * Getter for property pinBlock.
     * @return Value of property pinBlock.
     */
    public String getPinBlock() {
        return this.pinBlock;
    }
    
    /**
     * Setter for property pinBlock.
     * @param pinBlock New value of property pinBlock.
     */
    public void setPinBlock(String pinBlock) {
        this.pinBlock = pinBlock;
    }
    
    /**
     * Getter for property cycleLength.
     * @return Value of property cycleLength.
     */
    public int getCycleLength() {
        return this.cycleLength;
    }
    
    /**
     * Setter for property cycleLength.
     * @param cycleLength New value of property cycleLength.
     */
    public void setCycleLength(int cycleLength) {
        this.cycleLength = cycleLength;
    }
    
    /**
     * Getter for property cycleLimitOnline.
     * @return Value of property cycleLimitOnline.
     */
    public int getCycleLimitOnline() {
        return this.cycleLimitOnline;
    }
    
    /**
     * Setter for property cycleLimitOnline.
     * @param cycleLimitOnline New value of property cycleLimitOnline.
     */
    public void setCycleLimitOnline(int cycleLimitOnline) {
        this.cycleLimitOnline = cycleLimitOnline;
    }
    
    /**
     * Getter for property cycleLimitNetwork.
     * @return Value of property cycleLimitNetwork.
     */
    public int getCycleLimitNetwork() {
        return this.cycleLimitNetwork;
    }
    
    /**
     * Setter for property cycleLimitNetwork.
     * @param cycleLimitNetwork New value of property cycleLimitNetwork.
     */
    public void setCycleLimitNetwork(int cycleLimitNetwork) {
        this.cycleLimitNetwork = cycleLimitNetwork;
    }
    
    /**
     * Getter for property cardHolderName.
     * @return Value of property cardHolderName.
     */
    public String getCardHolderName() {
        return this.cardHolderName;
    }
    /*
     * Get Cardholder name for display 
     * this.cardHolderName should be in sparrow format SURNAME/FIRSTNAME.TITLE
     */
    public String getDisplayCardHolderName() {
        String out="";
        if(this.cardHolderName!=null && this.cardHolderName.length()>0){
            int dotPos = this.cardHolderName.indexOf('.');
            int slashPos = this.cardHolderName.indexOf('/');
            if(dotPos>-1){
                if(this.cardHolderName.substring(dotPos+1).length()==0){
                    out = cardHolderName.substring(slashPos+1,dotPos);
                }
                else{
                    out = cardHolderName.substring(dotPos+1).trim() + " " + 
                            cardHolderName.substring(slashPos+1,dotPos);
                }
            }
            else if (slashPos>0)
                out = this.cardHolderName.substring(slashPos+1);
            
            out = out.trim() + " " + cardHolderName.substring(0,slashPos);
        }
        return out;
    }
    
    
    /**
     * Setter for property cardHolderName.
     * @param cardHolderName New value of property cardHolderName.
     */
    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }
    
    /**
     * Getter for property address1.
     * @return Value of property address1.
     */
    public String getAddress1() {
        return this.address1;
    }
    
    /**
     * Setter for property address1.
     * @param address1 New value of property address1.
     */
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    
    /**
     * Getter for property address2.
     * @return Value of property address2.
     */
    public String getAddress2() {
        return this.address2;
    }
    
    /**
     * Setter for property address2.
     * @param address2 New value of property address2.
     */
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    
    /**
     * Getter for property address3.
     * @return Value of property address3.
     */
    public String getAddress3() {
        return this.address3;
    }
    
    /**
     * Setter for property address3.
     * @param address3 New value of property address3.
     */
    public void setAddress3(String address3) {
        this.address3 = address3;
    }
    
    /**
     * Getter for property address4.
     * @return Value of property address4.
     */
    public String getAddress4() {
        return this.address4;
    }
    
    /**
     * Setter for property address4.
     * @param address4 New value of property address4.
     */
    public void setAddress4(String address4) {
        this.address4 = address4;
    }
    
    public SparrowAccount getPrimaryAccount()
    {
        SparrowAccount returnValue = null;
        Iterator accountsIter = this.accounts.iterator();
        while (accountsIter.hasNext()) {
            SparrowAccount cardAccount = (SparrowAccount)accountsIter.next();
            if (cardAccount.isPrimaryCardAccount()) {
                returnValue = cardAccount;
                break;
            }
        }
        return returnValue;
    }

	/**
	 * @param iccData the iccData to set
	 */
	public void setIccData(String iccData) {
		this.iccData = iccData;
	}

	/**
	 * @return the iccData
	 */
	public String getIccData() {
		return iccData;
	}    

	/**
	 * @return the internationalIssuerLimit
	 */
	public Integer getInternationalIssuerLimit() {
		return internationalIssuerLimit;
	}

	/**
	 * @param internationalIssuerLimit the internationalIssuerLimit to set
	 */
	public void setInternationalIssuerLimit(Integer internationalIssuerLimit) {
		this.internationalIssuerLimit = internationalIssuerLimit;
	}

	/**
	 * @return the internationalIssuerLimitCycle
	 */
	public Integer getInternationalIssuerLimitCycle() {
		return internationalIssuerLimitCycle;
	}

	/**
	 * @param internationalIssuerLimitCycle the internationalIssuerLimitCycle to set
	 */
	public void setInternationalIssuerLimitCycle(
			Integer internationalIssuerLimitCycle) {
		this.internationalIssuerLimitCycle = internationalIssuerLimitCycle;
	}

	/**
	 * @param tagData the tagData to set
	 */
	public void setTagData(String tagData) {
		this.tagData = tagData;
	}

	/**
	 * @return the tagData
	 */
	public String getTagData() {
		return tagData;
	}

	/**
	 * @param issuerScript the issuerScript to set
	 */
	public void setIssuerScript(String issuerScript) {
		this.issuerScript = issuerScript;
	}

	/**
	 * @return the issuerScript
	 */
	public String getIssuerScript() {
		return issuerScript;
	}

	/**
	 * @param lastAction the lastAction to set
	 */
	public void setLastAction(String lastAction) {
		this.lastAction = lastAction;
	}

	/**
	 * @return the lastAction
	 */
	public String getLastAction() {
		return lastAction;
	}

}
