package com.barclays.staffware.plugin.dto;

import java.io.Serializable;

/**
 * @author GX
 *
 * OLEReplacementPhase3 - Account Details
 */
/*
 * DATE      REFERENCE      WHO           VERSION     COMMENTS
 * ---------   ----------------     ------------   ------------    ---------------------------
 * 05Dec11  OLERP3              GX    1a                  Created
 * 
 */
public class AccountInterestRate implements Serializable {
	
	private static final long serialVersionUID = -50143677249272117L;
	
	private String interestRate;
	private String rateType;
	private String interestBalanceRange;
	private String APR;
	private String period;
	private String additionalInfomation;
	private String noRatesIndicator;
	
	public String getNoRatesIndicator() {
		return noRatesIndicator;
	}

	public void setNoRatesIndicator(String noRatesIndicator) {
		this.noRatesIndicator = noRatesIndicator;
	}

	public String getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}

	public String getRateType() {
		return rateType;
	}

	public void setRateType(String rateType) {
		this.rateType = rateType;
	}

	public String getInterestBalanceRange() {
		return interestBalanceRange;
	}

	public void setInterestBalanceRange(String interestBalanceRange) {
		this.interestBalanceRange = interestBalanceRange;
	}

	public String getAPR() {
		return APR;
	}

	public void setAPR(String aPR) {
		APR = aPR;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getAdditionalInfomation() {
		return additionalInfomation;
	}

	public void setAdditionalInfomation(String additionalInfomation) {
		this.additionalInfomation = additionalInfomation;
	}
}
