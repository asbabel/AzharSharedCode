package com.barclays.staffware.plugin;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * EAI java plugin for updating PAC with the Settlement Date.
 * 
 * @author Shahir.Hiralal
 * 
 */
public class UpdateSettlementDate implements ImmediateReleasePluginSDK {
    private static final LoggerConnection LOG = new LoggerConnection(
            UpdateSettlementDate.class);
	private final String initializationFailed = SwiftParams.initializationFailed(UpdateSettlementDate.class.getName());

    /**
     * Method is called by Staffware before each execute (unless a caching
     * option is selected in Staffware) Loads properties file. This file should
     * contain the DB Driver and the MQ Parameters to the relevant environment.
     * 
     * @param properties contents of eaijava properties file in
     * root:/swserver/sw_africa/eaijava
     */
    @Override
    public void initialize(Properties properties)
            throws FatalPluginException,
            NonFatalPluginException {
       // DataSourceDirectory.getInstance().configure(properties);
        try {
           // Class.forName(properties.getProperty("db_driver"));
           // LoggerConnection.configureWFL(properties.getProperty("updateSettlementDateLog"));
            ClassPathResource resource = new ClassPathResource(properties.getProperty("updateSettlementDateLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());

            DataSourceDirectory.getInstance().basePluginDS();
            LOG.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	LOG.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
    }

    /**
     * Method Staffware calls in eaijava step, will update the staffware step
     * name.
     * 
     * @param staticData a string hardcoded in Staffware, this is ignored in
     * this method
     * @param outputFields a list of Staffware field objects which Staffware
     * expects to be returned
     * @param inputFields a list of Staffware field objects which Staffware
     * provides (with values)
     * @return the name value pairs returned to Staffware
     */
    @SuppressWarnings({"rawtypes"})
    @Override
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {
   
        return updateSettlementDate(StaffwareHelper.getFieldValue(inputFields,
                "GROUP_ID"), StaffwareHelper.getFieldValue(inputFields,
                "ITEM_NUMBER"), StaffwareHelper.getFieldValue(
                inputFields, "SETTLEMENTDATE"), outputFields);
    }

    @SuppressWarnings("rawtypes")
    private Map updateSettlementDate(
            String groupId,
            String itemNumber,
            String paymentSettlementDate,
            List outputFields) {
        SortedMap<String, Object> args = new TreeMap<>();
        Map<String, Object> results = new HashMap<>(outputFields.size());
        args.put("GroupId", groupId);
        args.put("ItemNumber", itemNumber);
        args.put("PaymentSettlementDate", paymentSettlementDate);
        SQLConnection conn = null;
        CallableStatement cs = null;
        try {
            conn = MWDBAccess.getDatabaseConnection();
            cs = conn.prepareCall("usp_PaymentAndCollectionsSettlementDateUpdate", args);
            conn.executeUpdate(cs, args);
            results.put("STATUSCODE", 0);
            results.put("STATUSDESC", "UPDATED");
        } catch (SQLException e) {
            results.put("STATUSCODE", 1);
            results.put("STATUSDESC", e.getMessage() != null ? e.getMessage() : e.toString());
            LOG.error("Unable to update Settlement Date", e);
        } finally {
            closeConnection(null, cs, conn);
        }
        return results;
    }
    
    private void closeConnection(ResultSet rs, CallableStatement cs, SQLConnection conn) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                LOG.error("Unable to close ResultSet", e);
            }
        }
        if (cs != null) {
            try {
                cs.close();
            } catch (SQLException e) {
                LOG.error("Unable to close CallableStatement", e);
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                LOG.error("Unable to close connection", e);
            }
        }
    }
}
