package com.barclays.staffware.plugin.reversal;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.transactions.DataAccess;
import com.barclays.middleware.brains.ACC_I;
import com.barclays.staffware.data.MWDBAccess;
import static com.barclays.staffware.plugin.reversal.Constants.*;

/**
 * This is the helper class for Payment Management Reversal Utility
 * 
 * @author Anup Kulkarni
 */
/* 
 * DATE      REFERENCE   WHO     	VERSION  	COMMENTS
 * --------  ---------   ---     	-------  	----------------------
 * 05/02/16  WP697       Anup    1.0	  		Created
 * 17Jan17   WP715       LeyJ      -            Refactored data access to MWDB.
 */
public class PaymentManagementHelper {

    private PaymentManagementHelper() {

    }

    /**
     * This method will fetch data from TCR table for given trxid
     * 
     * @param paymentBean
     * @return
     * @throws SQLException
     */
    public static List<HashMap<String, Object>> getTCRData(PaymentOperationBean paymentBean) throws SQLException {

        SortedMap<String, Object> args = new TreeMap<>();
        args.put(UNDERSCORE_GROUPID, paymentBean.getGroupId());
        return executeQuery(SP_GET_TCR_DATA, args);

    }

    /**
     * This method will fetch data from PAC table for given group and itemnumber
     * 
     * @param paymentBean
     * @return
     * @throws SQLException
     */
    public static List<HashMap<String, Object>> getPACData(PaymentOperationBean paymentBean) throws SQLException {

        SortedMap<String, Object> args = new TreeMap<>();
        args.put(GROUPID, paymentBean.getGroupId());
        args.put(ITEMNUMBER, paymentBean.getItemNumber());

        return executeQuery(SP_GETPACDETAILS, args);

    }

    /**
     * This method will fetch the charge data from PACCharges table for given groupid
     * 
     * @param paymentBean
     * @return
     * @throws SQLException
     */
    public static List<HashMap<String, Object>> getPACChargesData(PaymentOperationBean paymentBean) throws SQLException {

        SortedMap<String, Object> args = new TreeMap<>();
        args.put(GROUPID, paymentBean.getGroupId());
        args.put(GROUPITEMNUMBER, paymentBean.getItemNumber());

        return executeQuery(SP_GET_PACCHARGES_DATA, args);
    }

    /**
     * This method will fetch data from ReversalXReference table for given groupid
     * 
     * @param paymentBean
     * @return
     * @throws SQLException
     */
    public static List<HashMap<String, Object>> getReversalCrossReferenceDataByOrigGroupId(PaymentOperationBean paymentBean)
            throws SQLException {

        SortedMap<String, Object> args = new TreeMap<>();

        args.put(ORIGGROUPID, paymentBean.getGroupId());
        args.put(ORIGITEMNUMBER, paymentBean.getItemNumber());

        return executeQuery(SP_GETREVERSAL_CROSSREFERENCE_DATA, args);
    }

    /**
     * This method will fetch payment type table data for given payment type
     * 
     * @param paymentType
     * @return
     * @throws SQLException
     */
    public static List<HashMap<String, Object>> getPaymentTypeData(String paymentType) throws SQLException {

        SortedMap<String, Object> args = new TreeMap<>();

        args.put(PAYMNTTYPE, paymentType);

        return executeQuery(SP_ECHANNEL_PAYMENTTYPE_GET, args);
    }

    /**
     * This method will fetch the tran and subtran code from transactiongeneration table for given payment type
     * 
     * @param paymentBean
     * @return
     * @throws SQLException
     */
    public static List<HashMap<String, Object>> getTransSubTransCodes(PaymentOperationBean paymentBean) throws SQLException {

        SortedMap<String, Object> args = new TreeMap<>();
        args.put(SOURCESYSTEM, BOX);
        args.put(CONTRY, paymentBean.getCountry());
        args.put(OFFSHORE, paymentBean.isOffshoreInd() ? 1 : 0);
        args.put(ENGINE, BRAINS);
        args.put(PAYMNTTYPE, paymentBean.getReversalPaymentType());

        return executeQuery(SP_GET_TCRGENRATION_DATA, args);
    }

    /**
     * This method will store the tran and subtran code for debit and credit leg in payment bean
     * 
     * @param resultListTrxGeneration
     * @param originatorEntry
     * @param counterPartyEntry
     * @param suspenseEntry
     */
    public static void setTransSubTransCode(
            List<HashMap<String, Object>> resultListTrxGeneration,
            TransactionGenerationBean originatorEntry,
            TransactionGenerationBean counterPartyEntry,
            TransactionGenerationBean suspenseEntry) {

        for (HashMap<String, Object> hashMap : resultListTrxGeneration) {

            if (ORIGINATOR.equalsIgnoreCase(((String) hashMap.get(ENTRYTYPE)).trim())) {
                String[] countryOffshore = ((String) hashMap.get(COUNTRY)).split(";");
                originatorEntry.setCountry(countryOffshore[0]);
                originatorEntry.setOffshoreInd(Integer.valueOf(countryOffshore[1]));
                originatorEntry.setEntryType((String) hashMap.get(ENTRYTYPE));
                originatorEntry.setTransCode((String) hashMap.get(TRANCODE));
                originatorEntry.setSubTransCode((String) hashMap.get(SUBCODE));
                originatorEntry.setPaymentType((String) hashMap.get(PAYMENTTYPE));
                originatorEntry.setDrcrInd((String) hashMap.get(DRCRIND));

            } else if (SUSPENSE.equalsIgnoreCase(((String) hashMap.get(ENTRYTYPE)).trim())) {
                String[] countryOffshore = ((String) hashMap.get(COUNTRY)).split(";");
                suspenseEntry.setCountry(countryOffshore[0]);
                suspenseEntry.setOffshoreInd(Integer.valueOf(countryOffshore[1]));
                suspenseEntry.setEntryType((String) hashMap.get(ENTRYTYPE));
                suspenseEntry.setTransCode((String) hashMap.get(TRANCODE));
                suspenseEntry.setSubTransCode((String) hashMap.get(SUBCODE));
                suspenseEntry.setPaymentType((String) hashMap.get(PAYMENTTYPE));
                suspenseEntry.setDrcrInd((String) hashMap.get(DRCRIND));

            }

            else {
                String[] countryOffshore = ((String) hashMap.get(COUNTRY)).split(";");
                counterPartyEntry.setCountry(countryOffshore[0]);
                counterPartyEntry.setOffshoreInd(Integer.valueOf(countryOffshore[1]));
                counterPartyEntry.setEntryType((String) hashMap.get(ENTRYTYPE));
                counterPartyEntry.setTransCode((String) hashMap.get(TRANCODE));
                counterPartyEntry.setSubTransCode((String) hashMap.get(SUBCODE));
                counterPartyEntry.setPaymentType((String) hashMap.get(PAYMENTTYPE));
                counterPartyEntry.setDrcrInd((String) hashMap.get(DRCRIND));
            }

        }
    }

    /**
     * This method will get the next group id for country * and offshoreInd 0
     * 
     * @param data
     * @return Integer Next GroupId value
     * @throws SQLException
     */
    public static Integer getNextGroupId(DataAccess data) throws SQLException {
        return data.nextValue(GROUP_ID);
    }

    /**
     * This method will make entry in table ReversalCrossReference for given original and new groupid
     * 
     * @param origGroupId
     * @param reversalGroupId
     * @param origItemNumber
     * @param revItemNumber
     * @param con
     * @throws SQLException
     */
    public static void makeReversalXReferenceEntry(
            Integer origGroupId,
            Integer reversalGroupId,
            Integer origItemNumber,
            Integer revItemNumber,
            SQLConnection con) throws SQLException {

        SortedMap<String, Object> args = new TreeMap<>();
        args.put(ORIGGROUPID, origGroupId);
        args.put(REVGROUPID, reversalGroupId);
        args.put(ORIGITEMNUMBER, origItemNumber);
        args.put(REVITEMNUMBER, revItemNumber);
        con.executeUpdate(SP_INSERT_REVRSALXREFERENCE, args);
    }

    /**
     * This method will check the status for account numbers involved in original transaction
     * 
     * @param resultListPAC
     * @param resultListPACCharges
     * @param paymentBean
     * @return
     * @throws Exception
     */
    public static Integer getClosedAccount(
            List<HashMap<String, Object>> resultListPAC,
            List<HashMap<String, Object>> resultListPACCharges,
            PaymentOperationBean paymentBean) throws Exception {

        Integer closedAccount = null;
        // validate originator account for payment
        String country = paymentBean.getCountry();
        boolean isOffshoreInd = paymentBean.isOffshoreInd();

        int originatorAccountNumber = Integer.parseInt((String) resultListPAC.get(0).get(ORIGINATORACCOUNTNUMBER));
        int originatorBranchNumber = (Short) resultListPAC.get(0).get(ORIGINATORBRANCHID);

        if (isAccountClosed(country, isOffshoreInd, originatorBranchNumber, originatorAccountNumber)) {
            closedAccount = originatorAccountNumber;
            return closedAccount;
        }

        // Validate Suspense Account for payment
        if (resultListPAC.get(0).get(SUSPENSEACCOUNTNUMBER) != null && resultListPAC.get(0).get(SUSPENSEBRANCHID) != null) {

            int suspenseAccountNumber = (Integer) resultListPAC.get(0).get(SUSPENSEACCOUNTNUMBER);
            int suspenseBranchNumber = (Short) resultListPAC.get(0).get(SUSPENSEBRANCHID);

            if (isAccountClosed(country, isOffshoreInd, suspenseBranchNumber, suspenseAccountNumber)) {
                closedAccount = suspenseAccountNumber;
                return closedAccount;
            }

        }

        if (paymentBean.isReverseChargesInd() && !resultListPACCharges.isEmpty()) {

            // Validate originator account for charges applied

            int originatorChargeAccount =
                    Integer.parseInt((String) resultListPACCharges.get(0).get(ORIGCHARGEACCOUNTNUMBER));
            int originatorChargeBranch = (Short) resultListPACCharges.get(0).get(ORIGCHARGEBRANCHID);
            if (isAccountClosed(country, isOffshoreInd, originatorChargeBranch, originatorChargeAccount)) {
                closedAccount = originatorChargeAccount;
                return closedAccount;
            }

            // Validate Suspense account for charges

            int counterPartyChargeAccount = (Integer) resultListPACCharges.get(0).get(SUSPENSECHARGEACCOUNTNUMBER);
            int counterPartyChargeBranch = (Short) resultListPACCharges.get(0).get(SUSPENSECHARGEBRANCHID);

            if (isAccountClosed(country, isOffshoreInd, counterPartyChargeBranch, counterPartyChargeAccount)) {
                closedAccount = counterPartyChargeAccount;
                return closedAccount;
            }
        }
        return closedAccount;
    }

    /**
     * This method will check for account status 5 i.e. for closed account
     * 
     * @param country
     * @param isOfshoreInd
     * @param branchNumber
     * @param accountNumber
     * @return
     * @throws Exception
     */
    private static boolean isAccountClosed(String country, boolean isOfshoreInd, Integer branchNumber, Integer accountNumber)
            throws Exception {
        boolean accountClosed = false;

        ACC_I accountInquiryToken = new ACC_I();
        accountInquiryToken.setCountry(country);
        accountInquiryToken.setOffshore(isOfshoreInd);
        accountInquiryToken.setVersionNumber(INTEGER_FIVE);
        accountInquiryToken.setBranchNumber(branchNumber);
        accountInquiryToken.setAccountNumber(accountNumber);
        accountInquiryToken.execute();

        if (((Integer) accountInquiryToken.getHeader().get(ACCOUNT_STATUS)).intValue() == INTEGER_FIVE) {

            accountClosed = true;
        }

        return accountClosed;

    }

    /**
     * @param procedureName
     * @param args
     * @return
     */
    private static ArrayList<HashMap<String, Object>> executeQuery(String procedureName, SortedMap<String, Object> args)
            throws SQLException {

        ArrayList<HashMap<String, Object>> resultSet = new ArrayList<>();
        HashMap<String, Object> currentRow = null;
        int columnCount = 0;

        SQLConnection conn = MWDBAccess.getDatabaseConnection();
        CallableStatement query = conn.prepareCall(procedureName, args);
        ResultSet rs = null;

        try {
            rs = conn.executeQuery(query, args);
            columnCount = rs.getMetaData().getColumnCount();

            while (rs.next()) {
                currentRow = new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    currentRow.put(rs.getMetaData().getColumnName(i), rs.getObject(i));
                }
                resultSet.add(currentRow);
            }
        } finally {
            query.close();
            conn.close();
            if (rs != null) {
                rs.close();
            }

        }

        return resultSet;

    }

    /**
     * This method will provide next value of counter name provided with country *
     * 
     * @param counterName
     * @param offShoreInd
     * @return
     * @throws SQLException
     */
    public static List<HashMap<String, Object>> getMWCounterNextValue(String counterName, int offShoreInd)
            throws SQLException {
        SortedMap<String, Object> args = new TreeMap<>();
        args.put(NAME, counterName);
        args.put(CONTRY, null);
        args.put(OFFSHORE, offShoreInd);
        return executeQuery(SP_GET_MW_COUNTER_DATA, args);

    }

    /**
     * his method will return barclays bank code
     * 
     * @param paymentBean
     * @return
     * @throws SQLException
     */
    public static List<HashMap<String, Object>> getBarclaysBankCode(PaymentOperationBean paymentBean) throws SQLException {
        SortedMap<String, Object> args = new TreeMap<>();
        args.put(UNDERSCORE_SOURCESYSTEM, BOX);
        args.put(UNDERSCORE_COUNTRY, paymentBean.getCountry());
        args.put(UNDERSCORE_OFFSHOREIND, paymentBean.isOffshoreInd() ? 1 : 0);
        return executeQuery(SP_GET_BARCLAYS_BANK_CODE, args);
    }

}
