package com.barclays.staffware.plugin.reversal;


import java.util.HashMap;
import java.util.List;

/**
 * This class will hold all request parameter to be passed for validation
 * @author Anup Kulkarni
 *
 */
/* 
 * DATE      REFERENCE   WHO     	VERSION  	COMMENTS
 * --------  ---------   ---     	-------  	----------------------
 * 05/02/16  WP697       Anup        1.0	  		Created
 */
public class PaymentOperationBean {

    
    
    private String country;
    private boolean offshoreInd;
    private String msgId;
    private Integer groupId;
    private Integer itemNumber;
    private String sourceAppName;
    private String reversalTransactionId;
    private String sourceAppUserId;
    private boolean reverseChargesInd;
    private String reversalMsgId;
    private String suspenseBankCode;
    
    private List<HashMap<String, Object>> resultListTCR;
    private List<HashMap<String, Object>> resultListPAC;
    private List<HashMap<String, Object>> resultListPACCharges;
    
    
    private String reversalPaymentType;
    
    private TransactionGenerationBean originatorEntry;
    private TransactionGenerationBean counterPartyEntry;
    
    
    
    public String getCountry() {
        return country;
    }
    public boolean isOffshoreInd() {
        return offshoreInd;
    }
    public void setOffshoreInd(boolean offshoreInd) {
        this.offshoreInd = offshoreInd;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    
    
    public String getSourceAppName() {
        return sourceAppName;
    }
    public void setSourceAppName(String sourceAppName) {
        this.sourceAppName = sourceAppName;
    }
    public String getReversalTransactionId() {
        return reversalTransactionId;
    }
    public void setReversalTransactionId(String reversalTransactionId) {
        this.reversalTransactionId = reversalTransactionId;
    }
    public List<HashMap<String, Object>> getResultListTCR() {
        return resultListTCR;
    }
    public void setResultListTCR(List<HashMap<String, Object>> resultListTCR) {
        this.resultListTCR = resultListTCR;
    }
    public List<HashMap<String, Object>> getResultListPAC() {
        return resultListPAC;
    }
    public void setResultListPAC(List<HashMap<String, Object>> resultListPAC) {
        this.resultListPAC = resultListPAC;
    }
    
    public List<HashMap<String, Object>> getResultListPACCharges() {
        return resultListPACCharges;
    }
    public void setResultListPACCharges(
            List<HashMap<String, Object>> resultListPACCharges) {
        this.resultListPACCharges = resultListPACCharges;
    }
    public String getReversalPaymentType() {
        return reversalPaymentType;
    }
    public void setReversalPaymentType(String reversalPaymentType) {
        this.reversalPaymentType = reversalPaymentType;
    }
    public TransactionGenerationBean getOriginatorEntry() {
        return originatorEntry;
    }
    public void setOriginatorEntry(TransactionGenerationBean originatorEntry) {
        this.originatorEntry = originatorEntry;
    }
    public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public Integer getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(Integer itemNumber) {
		this.itemNumber = itemNumber;
	}
	public TransactionGenerationBean getCounterPartyEntry() {
        return counterPartyEntry;
    }
    
	public void setCounterPartyEntry(TransactionGenerationBean counterPartyEntry) {
        this.counterPartyEntry = counterPartyEntry;
    }
    public String getSourceAppUserId() {
        return sourceAppUserId;
    }
    public void setSourceAppUserId(String sourceAppUserId) {
        this.sourceAppUserId = sourceAppUserId;
    }
    public boolean isReverseChargesInd() {
		return reverseChargesInd;
	}
	public void setReverseChargesInd(boolean reverseChargesInd) {
		this.reverseChargesInd = reverseChargesInd;
	}
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public String getReversalMsgId() {
		return reversalMsgId;
	}
	public void setReversalMsgId(String reversalMsgId) {
		this.reversalMsgId = reversalMsgId;
	}
	public String getSuspenseBankCode() {
		return suspenseBankCode;
	}
	public void setSuspenseBankCode(String suspenseBankCode) {
		this.suspenseBankCode = suspenseBankCode;
	}
}
