package com.barclays.staffware.plugin.pain;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.barclays.ebox.util.PainUtilException;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.middleware.brains.CUS_SA;
import com.barclays.middleware.brains.GLD_I;
import static com.barclays.staffware.plugin.util.PainParams.MISSING_BUSINESS_DATE;
import static com.barclays.staffware.plugin.util.PainParams.INVALID_BUSINESS_DATE;
import static com.barclays.staffware.plugin.util.PainParams.VALUEDATEFROM;
import static com.barclays.staffware.plugin.util.PainParams.GLDERROR;
import static com.barclays.staffware.plugin.util.PainParams.CUSTNOERROR;
import static com.barclays.staffware.plugin.util.PainParams.BUSINESSDATE;
import static com.barclays.staffware.plugin.util.PainParams.CUSTOMERNUMBER;

/**
 * Class that contains util methods that retrives info from Brains, Tokens used
 * CUS-SA and GLD-I
 * 
 * @author Shahir.Hiralal
 * 
 */

/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 05Feb16   SEFTP2    SRH      1a     Created for Retrieving info from Brains 
 */

public class RetrieveInformationFromBrains {

    private static final LoggerConnection LOG = new LoggerConnection(
            RetrieveInformationFromBrains.class);

    /**
     * Retrieves the current business date from Brains using the GLD_I Token in
     * format ddMMyy
     * 
     * @param country
     * @param offshore
     * @return business date
     * @throws DataAccessException
     */
    public Date getBusinessDate(String country, Boolean offshore)
            throws DataAccessException {
        GLD_I token;
        try {
            token = new GLD_I(country, offshore);
            token.execute();
        } catch (Exception e) {
            LOG.error(GLDERROR, e);
            throw new DataAccessException(e.getMessage(), e);
        }

        String businessDate = (String) token.getHeader().get(BUSINESSDATE);
        if (businessDate.equals("") || businessDate == null) {
            throw new DataAccessException(MISSING_BUSINESS_DATE);
        }

        try {
            return new SimpleDateFormat(VALUEDATEFROM).parse(businessDate);
        } catch (ParseException e) {
            throw new DataAccessException(INVALID_BUSINESS_DATE, e);
        }
    }

    /**
     * Method to retrieve the Customer Number based on the Branch No. and
     * Account Number.
     * 
     * @param account
     * @param branchNumber
     * @param country
     * @return custNumber
     * @throws PainUtilException
     */
    public String getCustomerNumber(
            String account,
            String branchNumber,
            String country) throws PainUtilException {
        CUS_SA token = new CUS_SA();
        int accNum = Integer.parseInt(account);
        int branchId = Integer.parseInt(branchNumber);
        token.setAccountNumber(accNum);
        token.setBranchNumber(branchId);
        token.setCountry(country);

        String custNumber = "";
        try {
            token.execute();
            List<HashMap<String, Object>> rows = new ArrayList<HashMap<String,Object>>();
            rows = token.getRows();
            Map<String, Object> customerAccs = rows.get(0);
            custNumber = (String) customerAccs.get(CUSTOMERNUMBER);
        } catch (Exception e) {
            LOG.error(CUSTNOERROR, e);
            throw new PainUtilException(CUSTNOERROR + e);
        }
        return custNumber;
    }
}
