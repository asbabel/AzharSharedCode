package com.barclays.staffware.plugin.dto;

import com.barclays.generic.data.bean.RefValueBean;
import com.barclays.text.Base64;

import java.util.Date;


/**
 * Represents a record from MWDB.CustomerDocument.
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 03Nov06  -          ILH    1.0a     Created
 * 13Feb08  PAT02404   KEMPD  2        Made serializable.
 */
public class CustomerDocument
    implements
        java.io.Serializable
{
    private static final long serialVersionUID = 5124101620598845315L;
    
    private boolean documentChanged = false;
    private int customerDocumentId;
    private String country;
    private boolean offshore;
    private int customerNumber;
    private String documentName;
    private int documentStoreId;
    private int documentSequence;
    private Date documentScanDate;
    private String additionalInformation;
    private RefValueBean refValue;
    private Date lastUpdatedDate;
    private String lastUpdatedBy;
    private byte[] image;
    
    /**
     * @return the additionalInformation
     */
    public String getAdditionalInformation() {
        return additionalInformation;
    }
    /**
     * @param additionalInformation the additionalInformation to set
     */
    public void setAdditionalInformation(String additionalInformation) {
        this.additionalInformation = additionalInformation;
    }
    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }
    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }
    /**
     * @return the customerNumber
     */
    public int getCustomerNumber() {
        return customerNumber;
    }
    /**
     * @param customerNumber the customerNumber to set
     */
    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }
    /**
     * @return the documentName
     */
    public String getDocumentName() {
        return documentName;
    }
    /**
     * @param documentName the documentName to set
     */
    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }
    /**
     * @return the documentScanDate
     */
    public Date getDocumentScanDate() {
        return documentScanDate;
    }
    /**
     * @param documentScanDate the documentScanDate to set
     */
    public void setDocumentScanDate(Date documentScanDate) {
        this.documentScanDate = documentScanDate;
    }
    /**
     * @return the documentSequence
     */
    public int getDocumentSequence() {
        return documentSequence;
    }
    /**
     * @param documentSequence the documentSequence to set
     */
    public void setDocumentSequence(int documentSequence) {
        this.documentSequence = documentSequence;
    }
    /**
     * @return the documentStoreId
     */
    public int getDocumentStoreId() {
        return documentStoreId;
    }
    /**
     * @param documentStoreId the documentStoreId to set
     */
    public void setDocumentStoreId(int documentStoreId) {
        this.documentStoreId = documentStoreId;
    }
    /**
     * @return the image
     */
    public byte[] getImage() {
        return image;
    }
    /**
     * @param image the image to set
     */
    public void setImage(byte[] image) {
        this.image = image;
    }
    
    /**
     * @return the lastUpdatedBy
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    
    /**
     * @param lastUpdatedBy the lastUpdatedBy to set
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
    
    /**
     * @return the lastUpdatedDate
     */
    public Date getLastUpdatedDate() {
        return lastUpdatedDate;
    }
    
    /**
     * @param lastUpdatedDate the lastUpdatedDate to set
     */
    public void setLastUpdatedDate(Date lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }
    
    /**
     * @return the offshore
     */
    public boolean isOffshore() {
        return offshore;
    }
    
    /**
     * @param offshore the offshore to set
     */
    public void setOffshore(boolean offshore) {
        this.offshore = offshore;
    }
    
    /**
     * @return the refValue
     */
    public RefValueBean getRefValue() {
        return refValue;
    }
    
    /**
     * @param refValue the refValue to set
     */
    public void setRefValue(RefValueBean refValue) {
        this.refValue = refValue;
    }
    /**
     * @return the customerDocumentId
     */
    public int getCustomerDocumentId() {
        return customerDocumentId;
    }
    /**
     * @param customerDocumentId the customerDocumentId to set
     */
    public void setCustomerDocumentId(int customerDocumentId) {
        this.customerDocumentId = customerDocumentId;
    }
    /**
     * @return the documentChanged
     */
    public boolean isDocumentChanged() {
        return documentChanged;
    }
    /**
     * @param documentChanged the documentChanged to set
     */
    public void setDocumentChanged(boolean documentChanged) {
        this.documentChanged = documentChanged;
    }
    
    /**
     * Sets the image byte array from a base64 encoded String
     * Also sets the "DocumentChanged" flag as appropriate 
     * @param document The base64 encoded image string
     */
    public void setBase64Image(String document) {
        if (document != null && !document.equals("")) {
            if (getImage() == null) {
                setDocumentChanged(true);
            } else {
                setDocumentChanged(!getBase64Image().equals(document));
            }
            setImage(Base64.decode(document));
        } else {
            setDocumentChanged((getImage() != null));
            setImage(null);
        }
    }
    
    /**
     * Gets the image in the Base64 encoding
     * @return The encoded String
     */
    public String getBase64Image() {
        if (getImage() == null || getImage().length == 0) {
            return "";
        }
        return Base64.encode(getImage());
    }
}
