package com.barclays.text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;


/**
 * The Base64 encoding.<p>
 * 
 * See <a href="http://www.ietf.org/rfc/rfc2045.txt">
 * http://www.ietf.org/rfc/rfc2045.txt</a> section 6.8 for the
 * specification of Base64.
 * 
 * @author KEMPD
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 12Oct06  -          KEMPD  1a       Created
 */
public class Base64
{
    /**
     * The Base64 alphabet.
     */
    private static final String BASE_64_ALPHABET =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            + "abcdefghijklmnopqrstuvwxyz"
            + "0123456789+/";
    
    /**
     * Given sequence of bytes encoded using Base64.
     */
    public static String encode(
        byte[] in)
    {
        StringBuffer out = new StringBuffer();
        int[] inGroup = new int[3];
        int[] outGroup = new int[4];
        int fillChars = 0;
        int lineLength = 0;
        
        for (int i = 0; i < in.length; i += 3) 
        {
            for (int j = 0; j < inGroup.length; j++)
                if (i + j < in.length)
                    inGroup[j] = in[i + j] + (in[i + j] < 0 ? 256 : 0);
                else {
                    inGroup[j] = 0;
                    fillChars++;
                }
            
            outGroup[0] = 0x3f & (inGroup[0] >> 2);
            outGroup[1] = 0x3f & ((inGroup[0] << 4) | (inGroup[1] >> 4));
            outGroup[2] = 0x3f & ((inGroup[1] << 2) | (inGroup[2] >> 6));
            outGroup[3] = 0x3f & (inGroup[2]);
            
            for (int j = 0; j < 4; j++)
                if (j >= 4 - fillChars)
                    out.append('=');
                else
                    out.append(BASE_64_ALPHABET.charAt(outGroup[j]));
            
            lineLength = (lineLength + 4) % 76;
            if (lineLength == 0)
                out.append('\n');
        }        
        
        return out.toString();
    }
    
    /**
     * Sequence of bytes obtained by decoding the given Base64 string.
     */
    public static byte[] decode(
        String in)
    {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        
        int[] inGroup = new int[4];
        int[] outGroup = new int[3];
        int padding = 0;
        
        int inLength = in.indexOf("=");
        if (inLength == -1)
            inLength = in.length();
        
        int inIndex = 0;
        while (inIndex < inLength)
        {
            int groupIndex = 0;            
            while (groupIndex < 4)
                if (inIndex < inLength) {
                    inGroup[groupIndex] = BASE_64_ALPHABET.indexOf(
                            in.charAt(inIndex++));
                    if (inGroup[groupIndex] != -1)
                        groupIndex++;
                }
                else {
                    padding++;
                    groupIndex++;
                }
            
            outGroup[0] = 0xff & (inGroup[0] << 2 | inGroup[1] >> 4);
            outGroup[1] = 0xff & (inGroup[1] << 4 | inGroup[2] >> 2);
            outGroup[2] = 0xff & (inGroup[2] << 6 | inGroup[3] >> 0);

            for (int j = 0; j < 3; j++)
                if (j < 3 - padding)
                    out.write(outGroup[j]);
        }
        
        return out.toByteArray();
    }
    
    /**
     * Test method.
     */
    public static void main(
        String[] args)
    {
        if (args.length != 1) {
            System.err.println("Usage: " + Base64.class.getName() + " <file>");
            System.exit(1);
        }
        try {
            File inputFile = new File(args[0]);         
            
            FileInputStream in = new FileInputStream(inputFile);
            try {
                byte[] data1 = new byte[(int) inputFile.length()];
                in.read(data1);
                
                String encoded = Base64.encode(data1);
                
                byte[] data2 = Base64.decode(encoded);
                if (data1.length != data2.length) {
                    System.err.println(
                            "Test failed: result has wrong length.");
                    System.exit(1);
                }
                else 
                    for (int i = 0; i < data1.length; i++)
                        if (data1[i] != data2[i]) {
                            System.err.println(
                                    "Test failed: result does not match.");
                            System.exit(1);
                        }
                
                System.err.println("Test successful.");
            }
            finally { in.close(); }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
