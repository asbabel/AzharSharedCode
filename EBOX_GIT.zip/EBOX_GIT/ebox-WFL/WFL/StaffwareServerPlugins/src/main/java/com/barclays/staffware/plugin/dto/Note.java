package com.barclays.staffware.plugin.dto;

import java.util.Date;


/**
 * Represents a Customer Note record in the backing store
 * 
 * @author HUNTI
 */
/*
 *
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 17Oct06  -          ILH    1.0      Created 
 * 13Feb08  PAT02404   KEMPD  2        Made serializable.
 */
public class Note
    implements
        java.io.Serializable
{    
    private static final long serialVersionUID = -341724689623174387L;
    
    private int sequenceNumber;
    private Date noteAdditionDate;
    private String noteType;
    private String contactBranch;
    private String hostname;
    private String username;
    private String note;
    private Date actionBy;
    
    /**
     * @return Returns the actionBy.
     */
    public Date getActionBy() {
        return actionBy;
    }
    /**
     * @param actionBy The actionBy to set.
     */
    public void setActionBy(Date actionBy) {
        this.actionBy = actionBy;
    }
    /**
     * @return Returns the contactBranch.
     */
    public String getContactBranch() {
        return contactBranch;
    }
    /**
     * @param contactBranch The contactBranch to set.
     */
    public void setContactBranch(String contactBranch) {
        this.contactBranch = contactBranch;
    }
    /**
     * @return Returns the hostname.
     */
    public String getHostname() {
        return hostname;
    }
    /**
     * @param hostname The hostname to set.
     */
    public void setHostname(String hostname) {
        this.hostname = hostname;
    }
    /**
     * @return Returns the note.
     */
    public String getNote() {
        return note;
    }
    /**
     * @param note The note to set.
     */
    public void setNote(String note) {
        this.note = note;
    }
    /**
     * @return Returns the noteAdditionDate.
     */
    public Date getNoteAdditionDate() {
        return noteAdditionDate;
    }
    /**
     * @param noteAdditionDate The noteAdditionDate to set.
     */
    public void setNoteAdditionDate(Date noteAdditionDate) {
        this.noteAdditionDate = noteAdditionDate;
    }
    /**
     * @return Returns the noteType.
     */
    public String getNoteType() {
        return noteType;
    }
    /**
     * @param noteType The noteType to set.
     */
    public void setNoteType(String noteType) {
        this.noteType = noteType;
    }
    /**
     * @return Returns the sequenceNumber.
     */
    public int getSequenceNumber() {
        return sequenceNumber;
    }
    /**
     * @param sequenceNumber The sequenceNumber to set.
     */
    public void setSequenceNumber(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }
    /**
     * @return Returns the username.
     */
    public String getUsername() {
        return username;
    }
    /**
     * @param username The username to set.
     */
    public void setUsername(String username) {
        this.username = username;
    }
}
