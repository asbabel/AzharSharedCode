package com.barclays.staffware.data;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.staffware.plugin.swift.SendMessage;
import com.barclays.staffware.plugin.util.SwiftParams;

/**
 * Data access class
 * 
 * @author LEES
 */
/*
 * DATE     REFERENCE    WHO     VERSION     COMMENTS 
 * ----     ---------    ---     -------     --------
 * 13MAR14  WP654WTX     SL      1.00        Created
 * 21NOV14  WP668        SL      1.01        SMxx enhancement
 * 30SEP15  WP668        AK      1.03        Modified code as part of Zambia RTGS payment fix for INC0030143712
 * 17Jan17  WP715        LeyJ    2           Refactored data access to MWDB.
 */
public class MWDBAccess implements IMWDBAccess {

    private static final String ITEM_VALUE = "ItemValue";
    private static final String GROUP_ID = "_GroupId";
    private static final String OFFSHORE_IND = "OffshoreInd";
    private static final String SW_STEPNAME = "_SW_STEPNAME";
    private static final String SW_CASENUM = "_SW_CASENUM";
    private static final String SW_PRONAME = "_SW_PRONAME";
    private static final String COUNTRY_CODE = "Country";
	private static final String MWDB = "mwdb";
    private static final LoggerConnection logger = new LoggerConnection(MWDBAccess.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.barclays.staffware.data.ISwiftData#getCorrespAccId(java.lang.String,
     * java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public String getCorrespAccId(String tag53b, String paymentType, String instCur, String country, String offshoreInd)
            throws SQLException {
        String output = null;
        if (tag53b == null || tag53b.isEmpty()) {
            if (paymentType.startsWith(SwiftParams.XBORDER)) {
                SortedMap<String, Object> args = new TreeMap<String, Object>();
                args.put("_" + SwiftParams.INST_CUR, instCur);
                args.put("_" + SwiftParams.COUNTRY, country);
                args.put("_" + SwiftParams.OFFSHORE_IND, offshoreInd);
                SQLConnection conn = getDatabaseConnection();
                try {
                    CallableStatement query = conn.prepareCall("iop_GetCorrespAccId", args);
                    ResultSet rs = null;
                    try {
                         rs = conn.executeQuery(query, args);
                        if (rs.next()) {
                            output = rs.getString("CorrespondentAccountId");
                        } else {
                            output = SwiftParams.NO_DATA;
                        }
                    } finally {
                        query.close();
                        if(rs != null) {
                        	rs.close();
                        }
                    }
                } finally {
                    if (conn != null) {
                        conn.close();
                    }
                }
            }
        }
        return output;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.barclays.staffware.data.ISwiftData#getCountryAttribute(java.lang.
     * String, java.lang.String)
     */
    @Override
    public Boolean getCountryAttribute(String country, String offshoreInd, String description) throws SQLException {
        Boolean enabled = false;
        String isOffShore = offshoreInd;
        if (offshoreInd == null) {
            isOffShore = "0";
        }
        SortedMap<String, Object> args = new TreeMap<String, Object>();
        args.put(COUNTRY_CODE, country);
        args.put(OFFSHORE_IND, isOffShore);
        args.put("Description", description);
        SQLConnection conn = getDatabaseConnection();
        try {
            CallableStatement query = conn.prepareCall("csc_getCountryAttributeValue", args);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, args);
                if (rs.next()) {
                    enabled = rs.getString("Value").equals("1");
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return enabled;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.barclays.staffware.data.IMWDBAccess#getNewMessageId()
     */
    @Override
    public String getNewMessageId() throws SQLException {
        String returnValue = "0";
        SQLConnection conn = getDatabaseConnection();
        try {
            CallableStatement query = conn.prepareCall("MW_NEW_MSGID", null);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, null);
                if (rs.next()) {
                    returnValue = rs.getString("RETURN_VALUE");
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return returnValue;

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.barclays.staffware.data.IMWDBAccess#updateStaffwareStepname(java.
     * lang.String, int, java.lang.String)
     */
    @Override
    public void updateStaffwareStepname(String proname, int casenum, String stepname) throws SQLException {
        HashMap<String, Object> args = new HashMap<String, Object>();
        args.put(SW_PRONAME, proname);
        args.put(SW_CASENUM, casenum);
        args.put(SW_STEPNAME, stepname);
        SQLConnection conn = getDatabaseConnection();
        try {
            conn.executeUpdate("iop_UpdateSW_STEPNAME", args);
        } catch(Exception ex){
            logger.error("--Exception while executing updateStaffwareStepname :"+ex.getMessage());
        }finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.barclays.staffware.data.IMWDBAccess#getTargetCountry(java.lang.String
     * , int)
     */
    @Override
    public String getTargetCountry(String country, int offshoreInd) throws SQLException {
        String encodedCountry = null;
        SortedMap<String, Object> args = new TreeMap<String, Object>();
        args.put("_country", country);
        args.put("_offshoreInd", offshoreInd);
        SQLConnection conn = getDatabaseConnection();
        try {
            CallableStatement query = conn.prepareCall("MW_ENCODE_COUNTRY", args);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, args);
                if (rs.next()) {
                    encodedCountry = rs.getString("ENCODED_COUNTRY");
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return encodedCountry;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.barclays.staffware.data.IMWDBAccess#getPACStatus(int,
     * java.lang.String)
     */
    @Override
    public String getPACStatus(int swMainCase, String swMainProc) throws SQLException {
        SortedMap<String, Object> args = new TreeMap<String, Object>();
        args.put(SW_CASENUM, swMainCase);
        args.put(SW_PRONAME, swMainProc);
        SQLConnection conn = getDatabaseConnection();
        String status = null;
        try {
            CallableStatement query = conn.prepareCall("iop_GetPACInfoFromCase", args);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, args);
                if (rs.next()) {
                    status = rs.getString("Status");
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
        return status;
    }

    /*
     * (non-Javadoc)
     * @see com.barclays.staffware.data.IMWDBAccess#insertSwiftMessageProcessStatus(java.lang.String, java.lang.String, java.lang.String, int, java.lang.String, java.lang.String, java.lang.String, boolean, int)
     */
    @Override
    public void insertSwiftMessageProcessStatus(
            String casenum,
            String proname,
            String status,
            int errorCode,
            String errorMessage,
            String country,
            String offshoreInd,
            String mt199Status,
            int groupId) throws SQLException {

        SortedMap<String, Object> pacArg = new TreeMap<String, Object>();
        pacArg.put(SW_CASENUM, casenum);
        pacArg.put(SW_PRONAME, proname);
        pacArg.put("_Status", status);
        pacArg.put("_ErrorCode", errorCode);
        pacArg.put("_ErrorMessage", errorMessage);
        SortedMap<String, Object> groupIdArg = new TreeMap<String, Object>();
        groupIdArg.put(GROUP_ID, groupId);

        SQLConnection conn = getDatabaseConnection();
        int datastoreId = 0;

        try {
            CallableStatement query = conn.prepareCall("sfw_PACUpdateStatus", pacArg);
            try {
                ResultSet rs = conn.executeQuery(query, pacArg);
                if (rs.next()) {
                    if (rs.getInt("RETURN_VALUE") < 1) {
                        throw new SQLException(SwiftParams.SP_ERROR);
                    }
                }
                if(rs != null) {
                	rs.close();
                }
            } finally {
                query.close();
            }

            query = conn.prepareCall("sfw_MW_DATASTOREGetIdByGroupId", groupIdArg);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, groupIdArg);
                if (rs.next()) {
                    datastoreId = rs.getInt("DATASTORE_ID");
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
            if (datastoreId > 0) {
                Map<String, Object> statusProcessArg = new HashMap<String, Object>();

                statusProcessArg.put("dataStoreId", datastoreId);
                statusProcessArg.put("status", status);
                String errorMsg = null;

                if ("ERROR".equalsIgnoreCase(status)) {
                    errorMsg = "Credit to other Bank failed";
                }
                statusProcessArg.put("errorMessage", errorMsg);

                conn.executeUpdate("iop_SwiftMessageProcessStatusUpdateStatusById", statusProcessArg);

                Map<String, Object> mt199StatusArg = new HashMap<String, Object>();
                mt199StatusArg.put("MT199Status", mt199Status);
                mt199StatusArg.put("dataStoreId", datastoreId);
                conn.executeUpdate("iop_SwiftMessageProcessStatusUpdateMT199StatusById", mt199StatusArg);
            }
        } finally {
            conn.close();
        }

    }

    /*
     * (non-Javadoc)
     * @see com.barclays.staffware.data.IMWDBAccess#getMutliLineSwiftDetail(int, java.lang.String, java.lang.String)
     */
    @Override
    public String getSwiftItemValue(int datastoreId, String itemName) throws SQLException {
        SortedMap<String, Object> swiftDetailArg = new TreeMap<String, Object>();
        swiftDetailArg.put("_DATASTORE_ID", datastoreId);
        swiftDetailArg.put("_ITEMNAME", itemName);
        String itemValue = "";
        SQLConnection conn = getDatabaseConnection();
        try {
            CallableStatement query = conn.prepareCall("iop_GetSwiftDetail", swiftDetailArg);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, swiftDetailArg);
                if (rs.next()) {
                    itemValue = rs.getString(ITEM_VALUE);
                    if (rs.wasNull()) {
                        itemValue = "";
                    }
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            conn.close();
        }
        return itemValue;
    }

    /*
     * (non-Javadoc)
     * @see com.barclays.staffware.data.IMWDBAccess#getDatastoreIdByGroupId(int)
     */
    @Override
    public int getDatastoreIdByGroupId(int groupId) throws SQLException {
        SortedMap<String, Object> groupIdArg = new TreeMap<String, Object>();
        groupIdArg.put(GROUP_ID, groupId);
        int datastoreId = 0;
        SQLConnection conn = getDatabaseConnection();
        try {
            CallableStatement query = conn.prepareCall("sfw_MW_DATASTOREGetIdByGroupId", groupIdArg);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, groupIdArg);
                if (rs.next()) {
                    datastoreId = rs.getInt("DATASTORE_ID");
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            conn.close();
        }
        return datastoreId;
    }

    @Override
    public Map<Integer, String> getSendersCharges(int datastoreId) throws SQLException {
        SortedMap<String, Object> args = new TreeMap<String, Object>();
        args.put("_DATASTORE_ID", datastoreId);
        SQLConnection conn = getDatabaseConnection();
        Map<Integer, String> sendersCharges = new HashMap<Integer, String>();
        try {
            CallableStatement query = conn.prepareCall("sfw_SwiftDetailGetSendersChargesById", args);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, args);
                while (rs.next()) {
                    sendersCharges.put(rs.getInt("Index"), rs.getString("Currency") + rs.getString("Amount"));
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            conn.close();
        }
        return sendersCharges;
    }

    /*
     * (non-Javadoc)
     * @see com.barclays.staffware.data.IMWDBAccess#getOrderingCustomer(int)
     */
    @Override
    public Map<String, String> getOrderingCustomer(int datastoreId, int groupId) throws SQLException {
        SortedMap<String, Object> args = new TreeMap<String, Object>();
        args.put("datastoreId", datastoreId);
        SortedMap<String, Object> pacArgs = new TreeMap<String, Object>();
        pacArgs.put(GROUP_ID, groupId);
        pacArgs.put("_ItemNumber", 1);
        SQLConnection conn = getDatabaseConnection();
        Map<String, String> orderingCustomer = new HashMap<String, String>();
        try {
            CallableStatement query = conn.prepareCall("wfe_getSwiftDetailsData", args);
            CallableStatement queryPaymentType = conn.prepareCall("csc_getPandCPaymentType", pacArgs);
            ResultSet rs = null,pt = null;
            try {
                 rs = conn.executeQuery(query, args);
                 pt = conn.executeQuery(queryPaymentType, pacArgs);
                String paymentType = "";
                if (pt.next()) {
                    paymentType = pt.getString("PaymentType");
                }
                String account = "";
                String bic = "";
                while (rs.next()) {
                    String tag = rs.getString("SwiftTag");
                    if (tag.startsWith("50") &&
                    // Ignore Tag 50C and 50L
                            !tag.endsWith("C") && !tag.endsWith("L")) {
                        // LCTM02 - IO Payments TB2
                        // Tag 50G from MACUG Debit only MT101 is mapped to Tag
                        // 50A in outward MT103
                        if (tag.equalsIgnoreCase("50A") || tag.equalsIgnoreCase("50G")) {
                            if (rs.getString("ItemName").equalsIgnoreCase("Ordering Customer BIC")) {
                                bic = rs.getString(ITEM_VALUE);
                            } else {
                                // adding '/' for the account number
                                account = "/" + rs.getString(ITEM_VALUE) + "\r\n";
                            }
                        } else {
                            if (!paymentType.startsWith("XBORDERSWFTCUG") && !paymentType.startsWith("LOCALSWFTCUG")) {
                                orderingCustomer.put("tag", rs.getString("SwiftTag"));
                                orderingCustomer.put("value", rs.getString(ITEM_VALUE));
                            }
                        }
                    }
                }
                if (bic != null && !bic.isEmpty()) {
                    orderingCustomer.put("tag", "50A");
                    orderingCustomer.put("value", account + bic);
                }
            } finally {
                query.close();
                queryPaymentType.close();
                if(rs != null) {
                	rs.close();
                }
                if(pt != null) {
                	pt.close();
                }
            }
        } finally {
            conn.close();
        }
        return orderingCustomer;
    }

    /* (non-Javadoc)
     * @see com.barclays.staffware.data.IMWDBAccess#getMwRefValueDescription(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public String getMwRefValueDescription(String country, String offshoreInd, String domain, String code)
            throws SQLException {

        SortedMap<String, Object> groupIdArg = new TreeMap<String, Object>();
        groupIdArg.put(COUNTRY_CODE, country);
        groupIdArg.put(OFFSHORE_IND, Integer.valueOf(offshoreInd));
        groupIdArg.put("Domain", domain);
        groupIdArg.put("Code", code);
        String description = "";
        SQLConnection conn = getDatabaseConnection();
        try {
            CallableStatement query = conn.prepareCall("csc_getMWRefValue", groupIdArg);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, groupIdArg);
                if (rs.next()) {
                    description = rs.getString("Description");
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            conn.close();
        }
        return description;

    }

    /* (non-Javadoc)
     * @see com.barclays.staffware.data.IMWDBAccess#getMwRefValueACCRECCode(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public String getMwRefValueACCRECCode(String country, String offshoreInd, String account) throws SQLException {
        SortedMap<String, Object> groupIdArg = new TreeMap<String, Object>();
        groupIdArg.put(COUNTRY_CODE, country);
        groupIdArg.put(OFFSHORE_IND, Integer.valueOf(offshoreInd));
        groupIdArg.put("Account", account);

        String description = "";
        SQLConnection conn = getDatabaseConnection();
        try {
            CallableStatement query = conn.prepareCall("csc_getAccountRecCode", groupIdArg);
            ResultSet rs = null;
            try {
                 rs = conn.executeQuery(query, groupIdArg);
                if (rs.next()) {
                    description = rs.getString("RecCode");
                }
            } finally {
                query.close();
                if(rs != null) {
                	rs.close();
                }
            }
        } finally {
            conn.close();
        }
        return description;
    }

    /**
     * Method returns a Database connection to MWDB.
     *
     * @throws SQLException If SQL connection fails.
     */
    public static SQLConnection getDatabaseConnection() throws SQLException {
        logger.info("--Executing getDatabaseConnection for MWDB: "+MWDB);
        return new SQLConnection(DataSourceDirectory.getInstance().getDataSource(MWDB).getConnection());
	}

    
	@Override
	public Map<String, String> getSwiftMessageProperties(int datastoreId)
			throws SQLException {
        logger.info("executing getSwiftMessageProperties with datastoreId:"+datastoreId);
		Map<String, String> swiftMessageProperties = new HashMap<String, String>();
		SortedMap<String, Object> args = new TreeMap<String, Object>();
        args.put("DatastoreId", datastoreId);
        SQLConnection conn = getDatabaseConnection();
       
        try {
            CallableStatement query = conn.prepareCall("wfe_ioPaymentsSwiftMessageGet", args);
            ResultSet rs = null;
            try {
                logger.info("wfe_ioPaymentsSwiftMessageGet query :"+query.toString());

            	rs = conn.executeQuery(query, args);
                if (rs.next()) {
                    logger.info("ServiceTypeIdentifier value from ResultSet:"+rs.getString("ServiceTypeIdentifier"));
                    logger.info("UETR value from ResultSet:"+rs.getString("UETR"));

                	swiftMessageProperties.put("111", rs.getString("ServiceTypeIdentifier"));
                	swiftMessageProperties.put("121", rs.getString("UETR"));
                }
            } finally {
            	if(rs != null){
            		rs.close();
            	}
                query.close();
            }
        } finally {
            conn.close();
        }
        
		return swiftMessageProperties;
	}

	@Override
	public int getDatastoreIdByCaseDescription(String caseDescription)
			throws SQLException {
		
		int datastoreId = 0;
		SortedMap<String, Object> args = new TreeMap<String, Object>();
        args.put("CaseDescription", caseDescription);
        SQLConnection conn = getDatabaseConnection();
       
        try {
            CallableStatement query = conn.prepareCall("wfe_ioPaymentsGetDatastoreIdByCaseDescription", args);
            ResultSet rs = null;
            try {
            	rs = conn.executeQuery(query, args);
                if (rs.next()) {
                	datastoreId = rs.getInt("datastore_id");
                }
            } finally {
            	if(rs != null){
            		rs.close();
            	}
                query.close();
            }
        } finally {
            conn.close();
        }
		
		return datastoreId;
	}
}
