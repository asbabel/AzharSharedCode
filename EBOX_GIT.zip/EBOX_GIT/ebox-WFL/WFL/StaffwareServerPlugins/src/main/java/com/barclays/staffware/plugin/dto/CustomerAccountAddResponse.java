

package com.barclays.staffware.plugin.dto;


/**
 * holds output params for account addition 
 */
/*
 * DATE     REFERENCE   WHO   VERSION  COMMENTS
 * -------  ---------   ---   -------  ---------------------------------------------------
 * 19JAN06  -           ACN 1.0a     Created
 * 
 */
public class CustomerAccountAddResponse {
    
     private int sequenceNumber;
    
     /**
      * Getter for property sequenceNumber.
      * @return Value of property sequenceNumber.
      */
     public int getSequenceNumber() {
         return sequenceNumber;
     }     
     
    
     /**
      * Setter for property sequenceNumber.
      * @param sequenceNumber New value of property sequenceNumber.
      */
     public void setSequenceNumber(int sequenceNumber) {
         this.sequenceNumber = sequenceNumber;
     }
     
}
