package com.barclays.staffware.plugin;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.beanutils.BeanUtils;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.BOP_A;
import com.barclays.middleware.brains.BrainsConnectionException;
import com.barclays.middleware.brains.ENT_PM;
import com.barclays.middleware.brains.ENT_PM.SuspenseEntry;
import com.barclays.middleware.brains.GLD_I;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.middleware.util.LoggingExclusion;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.ibm.math.BigDecimal;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * This class is called by staffware to update the MWDB with any changes then
 * post a payment to brains
 * 
 * @author Bonner Earle
 */
/*
 * DATE     REFERENCE  WHO      VERSION COMMENTS
 * -------  ---------  ---      ------- ---------------------------------------------------
 * 06Jan06  -          EARLB    1.0a    Created
 * 20Feb07  PAT01950   BONILLO  1.0b    CR4: BOP codes for Zimbabwe. BOP-A call.
 * 04Jun07  PAT01967   KEMPD    2       Removed logging configuration -- we now
 *                                      use Staffware's own eaijava log4j file.
 * 15May08  PAT02518   EARLEB   -       Java 6 upgrade changes
 * 07Apr14  -          HITCHCP  -       WP668: Post SourceReference as MsgId.
 * 16Dec15  -          KUMARA   -       WP668 Defect 2524: Charging fix.
 * 16Dec15  -          HITCHCP  -       WP668: Enabled logging
 * 11Jul17  -          HITCHCP  -       Added database connection retries
 * 17Jan17  WP715      LeyJ     -       Refactored data access to MWDB.
 */
public class PostPayment implements ImmediateReleasePluginSDK {

    private static final String TRANSACTION_AMOUNT = "TransactionAmount";
    private static final String LOCAL_AMOUNT = "LocalAmount";   
	private static final String STAFFWARE = "mwdb";
    private static final String OFFSHORE_IND = "OFFSHORE_IND";
    private static final String COUNTRY = "COUNTRY";
    private static final LoggerConnection logger = new LoggerConnection(PostPayment.class);
    private static final String UPDATE_FLAG = "saveStaffwareChanges";
    private final String initializationFailed = SwiftParams.initializationFailed(PostPayment.class.getName());

    private static final int DB_CONN_MAX_ATTEMPTS = 3;
    private static final int DB_CONN_ATTEMPT_SLEEP = 2500;
    

    /**
     * Method staffware calls in eaijava step
     * 
     * @param staticData, a string hardcoded in staffware
     * @param outputFields, a List of staffware Field objects which staffware
     * expects to be returned
     * @param inputFields, a List of staffware Field objects which staffware
     * provides (with values)
     * @return Map, the name value pairs returned to staffware. Should only
     * contain names of fields supplied in outputFields
     */
    @SuppressWarnings("rawtypes")
    @Override
    public Map<String, Object> execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {
        HashMap<String, Object> returnValues = new HashMap<>();
        try {
            int groupId = Integer.parseInt(getFieldValue(inputFields, "GROUP_ID"));
            int itemNumber = Integer.parseInt(getFieldValue(inputFields, "GROUP_ITEM"));
            logger.info("Posting payment " + groupId + "/" + itemNumber);
            // check if updating database, flag in static data
            if (staticData.matches(UPDATE_FLAG)) {
                // get input data from staffware and update db
                // input fields has country and offshore ind which we don't
                // want to pass to this method
                ArrayList list = new ArrayList();
                for (Iterator i = inputFields.iterator(); i.hasNext();) {
                    Field f = (Field) i.next();
                    if (!(f.getName().equals(COUNTRY) || f.getName().equals(OFFSHORE_IND))) {
                        list.add(f);
                    }
                }
                updateMwdb(list);
                logger.debug("updated db with staffware changes");
            }

            String country = getFieldValue(inputFields, COUNTRY);
            // the substring is because in staffware this field is
            // declared as a numeric of length one. So it turns up as "0" or
            // "1.0"
            boolean isOffshore = Integer.parseInt(getFieldValue(inputFields, OFFSHORE_IND).substring(0, 1)) == 1;

            // get post payment data from db and pass to brains ENT-PM call
            // if connection error set to retry (StatusCode = 1)
            ENT_PM entPm = new ENT_PM();
            BOP_A bopA = new BOP_A();

            // need to set which brains instance we wish to call, via country
            entPm.setCountry(country);
            entPm.setOffshore(isOffshore);
            bopA.setCountry(country);
            bopA.setOffshore(isOffshore);

            boolean bopARequired = initiateBrainsCall(entPm, groupId, itemNumber, bopA, returnValues);
            logger.info("After initiateBrainsCall()"+entPm.getPostDate());
            // make update call before brains call
            // commit it after the brains call
            // this is to keep brains and pac in sync

            SQLConnection conn = updateMiddlewareDatabase(entPm);
            logger.debug("initiated post to brains");
            try {
                logger.info("entPm values :  " + entPm.toString());
                entPm.execute();
                // CR4: BOP Zimbabwe
                if (bopARequired) {
                    bopA.execute();
                }
            } catch (Exception e) {
                // roll back db and close the connection
                closeDBConnection(rollbackDatabase(conn), null, null);
                throw e;
            }
            logger.debug("executed post to brains");
            // commit the changes and close the connection
            closeDBConnection(commitDatabase(conn), null, null);
            logger.debug("updated post date on MWDB");

            returnValues.put("STATUSCODE", "0");
            returnValues.put("STATUSDESC", " ");
        } catch (BrainsConnectionException e) {
            // any connection errors are to go for retry
            setError(e, returnValues, "1");
        } catch (Exception e) {
            // any errors are returned to staffware in name value pair form
            // Staffware will be checking a StatusCode return value to
            // see if there was an error
            setError(e, returnValues, "-1");
        }
        return returnValues;
    }

    /**
     * Attempts to establish a connection with the database
     * 
     * @return SQLConnection connection to database
     * @throws SQLException
     */
    private SQLConnection getDBConnection() throws SQLException {

        SQLConnection conn = null;
        int attempt = 0;

        while (conn == null && ++attempt <= DB_CONN_MAX_ATTEMPTS) {
            try {
                conn = new SQLConnection(DataSourceDirectory.getInstance().getDataSource(STAFFWARE).getConnection());
            } catch (SQLException e) {
                if (attempt >= DB_CONN_MAX_ATTEMPTS) {
                    throw e;
                } else {
                    logger.warn("Failed to connect to database - attempt " + attempt + ": " + e.getMessage());

                    try {
                        Thread.sleep(DB_CONN_ATTEMPT_SLEEP);
                    } catch (InterruptedException ie) { // NOSONAR
                        logger.warn("Failed to sleep for " + DB_CONN_ATTEMPT_SLEEP + "ms");
                    }
                }
            }
        }
        return conn;
    }
    
    /**
     * Commits the database transaction and passes the connection back for closure
     * @param conn
     * @return SQLConnection to be closed
     */
    private SQLConnection commitDatabase(SQLConnection conn) {
        try {
            conn.commit();
        } catch (SQLException ex) {
            logger.error("Failed to rollback database", ex);
        }
        return conn;
    }
    
    /**
     * Rolls back the database transaction and passes the connection back for closure
     * @param conn
     * @return SQLConnection to be closed
     */
    private SQLConnection rollbackDatabase(SQLConnection conn) {
        try {
            conn.rollback();
        } catch (SQLException ex) {
            logger.error("Failed to rollback database", ex);
        }
        return conn;
    }
    
    /**
     * Manages the closure of all connections to the database
     * 
     * @param conn Main connection to the database
     * @param rs A ResultSet used to return data for the last query
     * @param stmt A CallableStatement used to execute the last query
     */
    private void closeDBConnection(SQLConnection conn, ResultSet rs, CallableStatement stmt) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                logger.error("Failed to close DB resultset", e);
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                logger.error("Failed to close DB statement", e);
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                logger.error("Failed to close DB connection", e);
            }
        }
    }

    private Date getBusinessDate(String country, boolean offshoreInd) throws Exception { // NOSONAR
        // need to set which brains instance we wish to call, via country
        GLD_I gldI = new GLD_I(country, offshoreInd);
        gldI.execute();
        return GLD_I.getBrainsDateFormat().parse((String) gldI.getHeader().get("BUSINESS_DATE"));
    }

    /**
     * Allocate a BRAINS transaction number to the given token.
     */
    private void allocateBrainsTransactionNumber(ENT_PM token) throws java.sql.SQLException {
        SQLConnection db = getDBConnection();
        try {
        Map<String, Object> args = new HashMap<>();
        args.put("Country", token.getCountry());
        args.put("OffshoreInd", Boolean.valueOf(token.isOffshore()));
        args.put("BusinessDate", token.getPostDate());
        args.put("NextNumber", db.makeOutputParameter(Types.INTEGER));

        Map output = db.execute("wfe_ioPaymentsBrainsTranNumberGetNext", args);
        token.setBrainsTranNumber(Integer.parseInt((String)(output.get("NextNumber"))));
        } finally {
            closeDBConnection(db, null, null);
		}
    }

    private void setError(Exception e, HashMap<String, Object> map, String errorCode) {
        String errorMessage;
        if (e.getMessage() != null) {
            errorMessage = e.getMessage();

        } else {
            errorMessage = e.toString();
        }

        logger.error("Error Executing PostPayment. Details: " + errorMessage, e);
        map.put("STATUSCODE", errorCode);
        map.put("STATUSDESC", "Error Executing PostPayment. Details: " + errorMessage);
    }

    /**
     * Will be passed the contents of eaijava properties file in the
     * root:/swserver/sw_africa/eaijava/ folder Will be called by staffware
     * before each execute (unless a caching option is selected in staffware)
     * 
     * @param properties
     */
    public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {
        try {
            //LoggerConnection.configureWFL(properties.getProperty("postPaymentLog"));
            // Modified by ashish
            ClassPathResource resource = new ClassPathResource(properties.getProperty("postPaymentLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());
            BrainsSocketConnectionFactory.getInstance().useSecure(properties);
            DataSourceDirectory.getInstance().basePluginDS();
           // Class.forName(properties.getProperty("db_driver"));
            logger.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
            }
        }

    /**
     * Saves any changes in staffware back to MWDB Expects staffware to pass the
     * only parameters going to pass on to sp call, sp parameter names match
     * staffware field names, if number of params or names don't match will get
     * sql error
     * 
     * @param inputFields, input from staffware
     */
    private void updateMwdb(List<Field> inputFields) throws Exception { // NOSONAR
        
        SQLConnection db = MWDBAccess.getDatabaseConnection();
        LoggingExclusion exclude = new LoggingExclusion();
        try {
            HashMap<String, Object> args = new HashMap<>();
            for (int i = 0; i < inputFields.size(); i++) {
                Field f = inputFields.get(i);
                // dates as ever are different
                logger.debug("param " + exclude.logNameValue(f.getName(), f.getValue()));
                if ("VALUE_DATE".equals(f.getName())) {
                    Date valDate = new SimpleDateFormat("ddMMyy").parse(f.getValue());
                    // data access layer will convert dates to strings
                    args.put(f.getName(), valDate);
                } else {
                    args.put(f.getName(), f.getValue());
                }
            }
            db.execute("dbo.sfw_UpdatePaymentBeforePost", args);

        } finally {
            closeDBConnection(db, null, null);
        }
    }

    /**
     * Goes to the db to populate parameters for the brains call
     * 
     * @throws Exception
     */
    private boolean initiateBrainsCall(
            ENT_PM entPm,
            int groupId,
            int itemNumber,
            BOP_A bopA,
            HashMap<String, Object> returnValues) throws Exception { // NOSONAR
        boolean bopARequired = false;
        CallableStatement stmt = null;
        ResultSet rs = null;       
        SQLConnection db = MWDBAccess.getDatabaseConnection();
        try {
            String chargeOption = null;
            boolean orderingInstOrASIInd = true;
            String valueDateInd = null;
            String dealId = null;
            int valueDays = 0;
            String eBoxActivityRef = null;

            TreeMap<String, Object> args = new TreeMap<>();
            args.put("GroupId", new Integer(groupId));
            args.put("ItemNumber", new Integer(itemNumber));
            stmt = db.prepareCall("dbo.sfw_GetPostPaymentDetail", args);
            rs = db.executeQuery(stmt, args);
            // only expect one row
            String originatorName = null;
            ENT_PM.OriginatorEntry entry1 = null;
            while (rs.next()) {
                returnValues.put("PROCESS_ENGINE", rs.getString("ProcessingEngineName").trim());

                entPm.setTerminalNumber(rs.getInt("TerminalNumber"));
                logger.info("After entPm.setTerminalNumber"+entPm.getTerminalNumber());
                logger.info("Before entPm.setPostDate"+entPm.getPostDate());
                entPm.setPostDate(getBusinessDate(entPm.getCountry(), entPm.isOffshore()));
                logger.info("After entPm.setPostDate"+entPm.getPostDate());
                allocateBrainsTransactionNumber(entPm);
                entPm.setSourceLocation(rs.getInt("SourceLocation"));
                entPm.setSourceSystem(rs.getString("SourceSystem"));
                logger.info("After entPm.setSourceSystem"+entPm.getSourceSystem());
                entPm.setGroupId(groupId);
                entPm.setGroupItemNumber(itemNumber);
                String msgId = rs.getString("MsgId");
                entPm.setSourceReference(msgId != null ? msgId : rs.getString("TrxId"));

                entry1 = new ENT_PM.OriginatorEntry();
                entry1.setCredit(rs.getString("OriginatorDrCrInd").equals("C"));
                entry1.setTransactionCode(rs.getInt("OriginatorTranCode"));
                entry1.setBranchNumber(rs.getInt("OriginatorBranchId"));
                entry1.setAccountNumber(rs.getInt("OriginatorAccountNumber"));
                entry1.setCurrency(rs.getString("OriginatorCurrency"));
                if (rs.getBigDecimal("OriginatorLocalAmount") != null) {
                    entry1.setLocalAmount(new BigDecimal(rs.getBigDecimal("OriginatorLocalAmount")));
                }
                if (rs.getBigDecimal("OriginatorTransactionAmount") != null) {
                    entry1.setTransactionAmount(new BigDecimal(rs.getBigDecimal("OriginatorTransactionAmount")));
                }
                valueDateInd = rs.getString("ValueDateInd");
                if (valueDateInd != null && valueDateInd.length() > 0) {
                    entry1.setValueDateInd(valueDateInd.charAt(0));
                }
                valueDays = rs.getInt("valueDays");
                entry1.setValueDays(valueDays);
                entry1.setNarrative(rs.getString("OriginatorNarrative"));
                if (rs.getBigDecimal("OriginatorUnclearedLocalAmount") != null) {
                    entry1.setUnclearedLocalAmount(new BigDecimal(rs.getBigDecimal("OriginatorUnclearedLocalAmount")));
                }
                if (rs.getBigDecimal("OriginatorUnclearedAmount") != null) {
                    entry1.setUnclearedAmount(new BigDecimal(rs.getBigDecimal("OriginatorUnclearedAmount")));
                }
                entry1.setSubTransactionCode(rs.getInt("OriginatorSubCode"));
                entry1.setAccountEntryType(rs.getInt("OriginatorAccountEntryType"));
                entry1.setRemittanceInformation(rs.getString("OriginatorRemittanceInformation"));
                if (entry1.getRemittanceInformation() == null || entry1.getRemittanceInformation().length() == 0) {
                    entry1.setRemittanceInformation(rs.getString("ExchangeDetails"));
                }
                if (rs.getString("DealId") != null) {
                    dealId = rs.getString("DealId");
                    entry1.setRemittanceInformation(entry1.getRemittanceInformation() + " DEAL=" + dealId);
                }
                originatorName = rs.getString("OriginatorName");
                entPm.addEntry(entry1);

                chargeOption = rs.getString("ChargeOption");
                // Fix for defect# 2524
                orderingInstOrASIInd = rs.getBoolean("OrderingInstOrASIInd");

                // CR4: Get the eBOXActivityReference PaymentAndCollections
                eBoxActivityRef = rs.getString("eBOXActivityReference");
                if (rs.getBigDecimal("CounterpartyTransactionAmount") != null) {
                    bopA.setMoa_amount(new BigDecimal(rs.getBigDecimal("CounterpartyTransactionAmount")));
                }
                bopA.setMoa_currency_code(rs.getString("CounterpartyCurrency"));
                if (rs.getBigDecimal("ExchangeRate") != null) {
                    bopA.setMoa_exchange_rate(new BigDecimal(rs.getBigDecimal("ExchangeRate")));
                }
                // Format branch and account number
                String branchAccount = new DecimalFormat("000").format(entry1.getBranchNumber())
                        + new DecimalFormat("0000000").format(entry1.getAccountNumber());
                bopA.setBranchAccountNumber(branchAccount);
            }
            // next result set, suspense or counterparty
            stmt.getMoreResults();
            rs = stmt.getResultSet();
            ENT_PM.NamedEntry entry2 = null;
            // only expect one row
            while (rs.next()) {
                String type = rs.getString("Type");
                if (type.equals("COUNTERPARTY")) {
                    entry2 = new ENT_PM.CounterpartyEntry();
                } else {
                    entry2 = new ENT_PM.SuspenseEntry();
                }

                entry2.setAccountEntryType(rs.getInt("AccountEntryType"));
                entry2.setAccountNumber(rs.getInt("AccountNumber"));
                entry2.setBranchNumber(rs.getInt("BranchId"));
                entry2.setCurrency(rs.getString("Currency"));
                entry2.setCredit(rs.getString("DrCrInd").equals("C"));
                if (rs.getBigDecimal(LOCAL_AMOUNT) != null) {
                    entry2.setLocalAmount(new BigDecimal(rs.getBigDecimal(LOCAL_AMOUNT)));
                }
                entry2.setNarrative(rs.getString("Narrative"));
                entry2.setSubTransactionCode(rs.getInt("SubCode"));
                entry2.setTransactionCode(rs.getInt("TranCode"));
                if (rs.getBigDecimal(TRANSACTION_AMOUNT) != null) {
                    entry2.setTransactionAmount(new BigDecimal(rs.getBigDecimal(TRANSACTION_AMOUNT)));
                }
                if (valueDateInd != null && valueDateInd.length() > 0) {
                    entry2.setValueDateInd(valueDateInd.charAt(0));
                }
                entry2.setValueDays(valueDays);
                if (entry1 != null) {
                    entry1.setOtherPartyName(rs.getString("CounterpartyName"));
                    entry2.setOtherPartyName(originatorName);
                }
                entry2.setRemittanceInformation(rs.getString("CounterpartyRemittanceInformation"));
                if (dealId != null && (entry2 instanceof SuspenseEntry)) {
                    entry2.setRemittanceInformation(entry2.getRemittanceInformation() + " DEAL=" + dealId);
                }
                entPm.addEntry(entry2);
            }

            // CR4: Add all the charges
            BigDecimal sumCharges = BigDecimal.valueOf(0);
            // next results set, charges
            stmt.getMoreResults();
            rs = stmt.getResultSet();
            while (rs.next()) {
                ENT_PM.ChargeEntry charge = new ENT_PM.OriginatorChargeEntry();
                charge.setAccountEntryType(rs.getInt("AccountEntryType"));
                charge.setAccountNumber(rs.getInt("AccountNumber"));
                charge.setBranchNumber(rs.getInt("BranchId"));
                charge.setCurrency(rs.getString("Currency"));
                charge.setCredit(rs.getString("DrCrInd").equals("C"));
                if (rs.getBigDecimal(LOCAL_AMOUNT) != null) {
                    charge.setLocalAmount(new BigDecimal(rs.getBigDecimal(LOCAL_AMOUNT)));
                }
                charge.setNarrative(rs.getString("Narrative"));
                charge.setSubTransactionCode(rs.getInt("SubCode"));
                charge.setTransactionCode(rs.getInt("TranCode"));
                BigDecimal tranAmt = null;
                if (rs.getBigDecimal(TRANSACTION_AMOUNT) != null) {
                    tranAmt = new BigDecimal(rs.getBigDecimal(TRANSACTION_AMOUNT));
                }
                charge.setTransactionAmount(tranAmt);
                // CR4: Add all the charges
                sumCharges = sumCharges.add(tranAmt);

                if (valueDateInd != null && valueDateInd.length() > 0) {
                    charge.setValueDateInd(valueDateInd.charAt(0));
                }
                charge.setValueDays(valueDays);
                charge.setChargeType(rs.getString("ChargeType"));

                // Added condition for SHA as part of fix for defect# 2524
                if (!"BEN".equals(chargeOption) && !("SHA".equals(chargeOption) && !orderingInstOrASIInd)) {
                    entPm.addEntry(charge);
                } else if (entry2 != null) {
                    entry2.setTransactionAmount(entry2.getTransactionAmount().subtract(charge.getTransactionAmount()));
                    entry2.setLocalAmount(entry2.getLocalAmount().subtract(charge.getLocalAmount()));
                }

                charge = new ENT_PM.SuspenseChargeEntry();
                charge.setAccountEntryType(rs.getInt("SuspAccountEntryType"));
                charge.setAccountNumber(rs.getInt("SuspAccountNumber"));
                charge.setBranchNumber(rs.getInt("SuspBranchId"));
                charge.setCurrency(rs.getString("SuspCurrency"));
                charge.setCredit(rs.getString("SuspDrCrInd").equals("C"));
                if (rs.getBigDecimal("SuspLocalAmount") != null) {
                    charge.setLocalAmount(new BigDecimal(rs.getBigDecimal("SuspLocalAmount")));
                }
                charge.setNarrative(rs.getString("SuspNarrative"));
                charge.setSubTransactionCode(rs.getInt("SuspSubCode"));
                charge.setTransactionCode(rs.getInt("SuspTranCode"));
                if (rs.getBigDecimal("SuspTransactionAmount") != null) {
                    charge.setTransactionAmount(new BigDecimal(rs.getBigDecimal("SuspTransactionAmount")));
                }
                if (valueDateInd != null && valueDateInd.length() > 0) {
                    charge.setValueDateInd(valueDateInd.charAt(0));
                }
                charge.setValueDays(valueDays);
                charge.setChargeType(rs.getString("ChargeType"));
                entPm.addEntry(charge);
            }

            // CR4
            bopA.setMoa_commission(sumCharges);
            // Get the eBoxActivityReference from PaymentAndCollections
            // and use it to get all the values from StaffwareTransition
            bopARequired = populateBopA(eBoxActivityRef, bopA);
        } finally {
            closeDBConnection(db, rs, stmt);
        }
        logger.info("Before exiting initiateBrainsCall(), date is"+entPm.getPostDate());
        return bopARequired;
    }

    private boolean populateBopA(String eBoxActivityRef, BOP_A bopA) throws SQLException {
        boolean bopARequired = false;
        TreeMap<String, Object> args = new TreeMap<String, Object>();
        args.put("eboxActivityReference", eBoxActivityRef);
        String name;
        Object value;
        SimpleDateFormat eboxFormat = new SimpleDateFormat("dd/MM/yy");
        CallableStatement stmt = null;
        ResultSet rs = null;
        SQLConnection db = getDBConnection();
        try {
            stmt = db.prepareCall("dbo.wfe_genericStaffwareTransitionGet", args);
            rs = db.executeQuery(stmt, args);
            
            while (rs.next()) {
                name = rs.getString("FieldName");
                value = rs.getString("FieldValue");
                // If destination property in BOP_A is a date, need to convert value
                try {
                    if (name.endsWith("_date")) {
                        value = eboxFormat.parse(value.toString());
                    }
                } catch (ParseException e) {
                    // Wrong date format, leave value as it is
                }
                try {
                    BeanUtils.copyProperty(bopA, name, value);
                } catch (Exception e) {
                    logger.debug("Cannot set property '" + name + "' with value '" + value + "' in BOP-A. Cause: " + e);
                }
            }
        } finally {
            closeDBConnection(db, rs, stmt);
        }
        bopA.setFilename("");
        bopA.setLin_line_number(new Integer(0));
        bopA.setLin_qualifier(new Integer(138)); // NOSONAR
        bopA.setTransaction_type("O");
        bopA.setForex_module_id("I");
        bopA.setStatus("PENDING");
        // Check if the BOP values are set
        if (bopA.getMoa_qualifier() != null) {
            bopARequired = true;
        }
        return bopARequired;
    }

    /**
     * find the value of a input field
     * 
     * @param list
     * @param name
     * @return
     */
    private String getFieldValue(List<Field> list, String name) {
        for (Iterator<Field> i = list.iterator(); i.hasNext();) {
            Field f = i.next();
            if (f.getName().equalsIgnoreCase(name)) {
                return f.getValue();
            }
        }
        return null;
    }

    /**
     * Save the post date and brains transaction number to the middleware
     * database record.
     */
    private SQLConnection updateMiddlewareDatabase(ENT_PM token) throws Exception { // NOSONAR
        
        SQLConnection db = MWDBAccess.getDatabaseConnection();
        try {
            db.setAutoCommit(false);
            TreeMap<String, Object> args = new TreeMap<>();
            args.put("GroupId", new Integer(token.getGroupId()));
            args.put("GroupItem", new Integer(token.getGroupItemNumber()));
            logger.info("Date before dbo.sfw_UpdatePaymentAfterPost"+token.getPostDate());
            args.put("PostDate", token.getPostDate());
            args.put("BrainsTranNumber", new Integer(token.getBrainsTranNumber()));
            logger.info("Arguments for SP dbo.sfw_UpdatePaymentAfterPost"+args);
            db.execute("dbo.sfw_UpdatePaymentAfterPost", args);
        } catch (Exception e) {
            closeDBConnection(db, null, null);
            throw e;
        }

        return db;
    }
}