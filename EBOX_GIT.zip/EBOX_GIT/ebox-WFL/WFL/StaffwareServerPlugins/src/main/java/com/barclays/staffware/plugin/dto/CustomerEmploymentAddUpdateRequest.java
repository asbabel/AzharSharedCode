package com.barclays.staffware.plugin.dto;

/*
 * DATE     REFERENCE   WHO   	VERSION COMMENTS
 * -------  ---------   ---   	------- ---------------------------------------------------
 * 18JAN06  -           ACN   	1.0     Created
 * 24OCT06	PAT01765	ILH		1a		Now extends new CustomerEmployment class 
 * 12Jun07	PAT01952	ILH		1a		Added contractExpiryDate
 * 21APR08  PAT02474	MANGIPV		1a		Added Employee Number
 */
public class CustomerEmploymentAddUpdateRequest extends CustomerEmployment {
	
	private String versionNumber;
    private String fosuser;
    private String hostname;
    
    public CustomerEmploymentAddUpdateRequest() {
    	
    }
    
    public CustomerEmploymentAddUpdateRequest(CustomerEmployment cemp) {
    	this.setAddressFirstLine(cemp.getAddressFirstLine());
    	this.setCountry(cemp.getCountry());
    	this.setCustomerNumber(cemp.getCustomerNumber());
    	this.setDistrict(cemp.getDistrict());
    	this.setEmpContactName(cemp.getEmpContactName());
    	this.setEmpContactNumber(cemp.getEmpContactNumber());
    	this.setEmployer(cemp.getEmployer());
    	this.setEmploymentStatus(cemp.getEmploymentStatus());
    	this.setEmploymentStatusDate(cemp.getEmploymentStatusDate());
    	this.setEmploymentType(cemp.getEmploymentType());
    	this.setDesignation(cemp.getDesignation());
    	this.setGrossCur(cemp.getGrossCur());
    	this.setGrossIncome(cemp.getGrossIncome());
    	this.setJobTitle(cemp.getJobTitle());
    	this.setLengthMonths(cemp.getLengthMonths());
    	this.setLengthYears(cemp.getLengthYears());
    	this.setNatureOfBusiness(cemp.getNatureOfBusiness());
    	this.setOffshore(cemp.isOffshore());
    	this.setOtherCur(cemp.getOtherCur());
    	this.setOtherIncome(cemp.getOtherIncome());
    	this.setPoBoxDetails(cemp.getPoBoxDetails());
    	this.setPostcode(cemp.getPostcode());
    	this.setSequenceNumber(cemp.getSequenceNumber());
    	this.setTown(cemp.getTown());
    	this.setSourceOfFunds(cemp.getSourceOfFunds());
    	this.setContractExpiryDate(cemp.getContractExpiryDate());
    	this.setEmployeeNumber(cemp.getEmployeeNumber());
    	this.setEmployerEmail(cemp.getEmployerEmail());
    }
    
    /**
     * Getter for property fosuser.
     * @return Value of property fosuser.
     */
    public String getFosuser() {
        return fosuser;
    }

    /**
     * Setter for property fosuser.
     * @param fosuser New value of property fosuser.
     */
    public void setFosuser(String fosuser) {
        this.fosuser = fosuser;
    }

    /**
     * Getter for property hostname.
     * @return Value of property hostname.
     */
    public String getHostname() {
        return hostname;
    }

    /**
     * Setter for property hostname.
     * @param hostname New value of property hostname.
     */
    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

	public String getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
}
