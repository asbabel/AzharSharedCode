package com.barclays.staffware.plugin.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtil {
    protected final static String LONG_DATE_PATTERN = "dd/MM/yyyy";

    public static Date getDateOrNull(String date) {
        Date d = null;
        try {
            d = getFormattedDate(date);
        } catch (ParseException pe) {
            //as per method name, if unparsable, swallows exception and returns null
        }
        return d;
    }

    /**
     * Gets a date formatter suitable for parsing and unparsing dates from the front end
     * @return
     */
    private static SimpleDateFormat getDateFormatter() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        sdf.setLenient(false);
        return sdf;
    }

    /**
     * Gets a date formatter suitable for parsing dates based on the format passed as parameter
     * @param format string
     * @return
     */
    private static SimpleDateFormat getDateFormatter(String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setLenient(false);
        return sdf;
    }

    /**
     * used for formatting dates which have four digit year
     * @return
     */
    public static SimpleDateFormat getLongDateFormatter() {
        SimpleDateFormat sdf = new SimpleDateFormat(LONG_DATE_PATTERN);
        sdf.setLenient(false);
        return sdf;
    }

    /**
     * used for display purposes
     * @return
     */
    public static String getLongDateFormat() {
        return "dd/MM/yyyy";
    }

    public static Date parseLongDateString(String in)
            throws ParseException {
        if(in == null) return null;
        SimpleDateFormat sdf = getLongDateFormatter();
        Date output = sdf.parse(in);
        // even when isLenient == false, two digit years are valid
        // so check year length is correct, dependent on date format not changing
        if(in.substring(in.lastIndexOf("/") + 1).length() != 4)
            throw new ParseException("Invalid year length", 0);
        return output;
    }

    /**
     * Gets a date formatted in the standard way
     * @param date The date to turn into a String
     * @return
     */
    public static String getFormattedDate(Date date) {
        if (date == null) {
            return "";
        }
        return getDateFormatter().format(date);
    }

    /**
     * Returns a date formatted as per the format you have provided
     * @param date Date
     * @param format you want to convert
     * @return
     */
    public static String getFormattedDate(Date date, String format) {
        if (date == null || format == null) {
            return "";
        }
        return getDateFormatter(format).format(date);
    }

    /**
     * Parses a date formatted in the standard way
     * @param date The String to parse
     * @return The date object, or null if it is unparseable
     * @throws ParseException
     */
    public static Date getFormattedDate(String date) throws ParseException {
        return getFormattedDate(date, false);
    }

    /**
     * Parses a date formatted in the standard way
     * @param date The String to parse
     * @param longDate true if date should be in long date format (yyyy)
     * @return The date object, or null if it is unparseable
     * @throws ParseException
     */
    public static Date getFormattedDate(String date, boolean longDate)
            throws ParseException {
        if (date == null || "".equals(date)) {
            return null;
        }

        if(longDate){
            return parseLongDateString(date);
        }
        else{
            return getDateFormatter().parse(date);
        }
    }

    /**
     * Gets a date assuming that the year part is in the past
     * @param date
     * @return
     * @throws ParseException
     */
    public static Date getFormattedPastDate(String date)
            throws ParseException {
        return getFormattedPastDate(date, false);
    }
    /**
     * Gets a date assuming that the year part is in the past
     * @param date
     * @param longDate true if date should be in long date format (yyyy)
     * @return
     * @throws ParseException
     */
    public static Date getFormattedPastDate(String date, boolean longDate)
            throws ParseException {
        if (date == null || "".equals(date)) {
            return null;
        }
        Date output = null;
        if(longDate){
            output = parseLongDateString(date);
        }
        else{
            SimpleDateFormat sdf = getDateFormatter();
            output = sdf.parse(date);
        }
        if (output.after(new Date())) {
            GregorianCalendar cal = new GregorianCalendar();
            cal.setTime(output);
            cal.add(GregorianCalendar.YEAR, -100);
            return cal.getTime();
        }
        return output;
    }

    public static Date getPastDate(String fieldName) {
        Date d = null;
        try {
            d = getFormattedPastDate(fieldName);
        } catch (ParseException pe) {
        }
        return d;
    }
}
