package com.barclays.staffware.plugin.util;

import java.util.Arrays;

/**
 * String utilities helper class
 */
/*
 * DATE     REFERENCE  WHO      VERSION  COMMENTS
 * -------  ---------  -------  -------  ---------------------------------------
 * 28JUN07  PAT01952   LEEDSS   1.0a     Created
 * 22Mar12	Release006 FAIRBANM			 Added the capitalize method
 */ 
public class StringUtils {

	private StringUtils() {}
	
    /**
     * Returns a String formed of the specified character repeated for 
     * the specified length
     * @param c The character to repeat
     * @param length The number of times to repeat the character
     * @return
     */
    public static String repeatChar(char c, int length) { 
        if (length < 0) 
        	throw new IllegalArgumentException(
        		"Argument \"length\" cannot be negative."); 
        char[] chars = new char[length]; 
        Arrays.fill(chars, c); 
        return String.valueOf(chars); 
    } 
    
	/**
	 * Tests if the specified String value is null or an empty string
	 * @param value value to test if null or empty
	 * @return true if value is null or an empty string
	 */
	public static boolean isNullOrEmpty(String value) {
		return value == null || value.length() == 0;
	}
    
    /**
     * Left pads the specified String data with the specified pad character 
     * up to the specified length.
     * @param data The String to be left padded
     * @param pad The character to left pad the String with
     * @param length The length the String should be padded to
     */
    public static String padLeft(String data, char pad, int length) {
    	if(data == null) data = "";
    	int padLength = length - data.length();
    	if(padLength > 0) data = repeatChar(pad, padLength) + data;
    	return data;
    }
    
    /**
     * Right pads the specified String data with the specified pad character 
     * up to the specified length.
     * @param data The String to be right padded
     * @param pad The character to right pad the String with
     * @param length The length the String should be padded to
     */
    public static String padRight(String data, char pad, int length) {
    	if(data == null) data = "";
    	int padLength = length - data.length();
    	if(padLength > 0) data = data + repeatChar(pad, padLength);
    	return data;
    }
    
    /**
     * Capitializes the first letter of the input String
     * @param data The string to be capitialized
     * @return The same string with a capitialized first letter
     */
    public static String capitialize(String data){
    	Character c = data.charAt(0);
    	c = c.toString().toUpperCase().charAt(0);
    	return data.replace(data.charAt(0), c);
    }
    
    
	/**
	 * 
	 * @param Hex
	 * @return
	 */
	public static String HexToBinary(String Hex) {
	    int i = Integer.parseInt(Hex, 16);
	    String Bin = Integer.toBinaryString(i);
	    return Bin;
	}

	/**
	 * 
	 * @param hexStr
	 * @return
	 */
	public static byte[] toBinaryArray( String hexStr ){
        byte bArray[] = new byte[hexStr.length()/2];  
        for(int i=0; i<(hexStr.length()/2); i++){
             byte firstNibble  = Byte.parseByte(hexStr.substring(2*i,2*i+1),16); // [x,y)
             byte secondNibble = Byte.parseByte(hexStr.substring(2*i+1,2*i+2),16);
             int finalByte = (secondNibble) | (firstNibble << 4 ); // bit-operations only with numbers, not bytes.
             bArray[i] = (byte) finalByte;
        }
        return bArray;
    }
}
