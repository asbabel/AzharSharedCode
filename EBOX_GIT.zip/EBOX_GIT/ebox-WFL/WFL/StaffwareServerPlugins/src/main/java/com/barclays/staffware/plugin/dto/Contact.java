package com.barclays.staffware.plugin.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * Describes a customer contact
 * @author  BAKERS
 */
/*
 * DATE     REFERENCE WHO    VERSION  COMMENTS
 * -------  --------- ---    -------  ---------------------------------------------------
 * 05Oct06  -         ILH    1.0a     Added residentialStatus, numberOfDependents, faxNumber, timeAtAddressMonths/Years
 * 									  Removed Veto junk
 * 21Jan08  PAT02371  LEEDSS 2        Changed isPrimary to handle NPE.
 * 21MAY10	PAT03189	AD	 1a		  New field Advice Method has been added
 * 05Jul10  PAT03232  SCDL   1a       New fields added for eStatements.
 * 22Feb13  WP616     MANGESH 1b      Added equals method and change compareTo to check Null Customer
 */
public class Contact implements Serializable, Comparable<Object>
{
    /**
	 * appease the serialisation gods
	 */
	private static final long serialVersionUID = -1781300594439515998L;

    /**
     * Customer
     *
     */
    private Customer customer;
    /**
     * Contact sequence number
     *
     */
    private int sequenceNumber;
    
    /**
     *  Primary contact indicator
     *
     */
    private String primaryContactIndicator;
    
    /**
     *  Contact type
     *
     */
    private String type;
    
    /**
     *  Contact Name
     *
     */
    private String name;
    
    /**
     * position
     *
     */
    private String position;
    
    
    /**
     * date of birth
     *
     */
    private Date dateOfBirth;
    
    /**
     *  memorable_name
     *
     */
    private String memorableName;
    
    /**
     * address_first_line
     *
     */
    private String addressFirstLine;
    
    /**
     *  po_box_details
     *
     */
    private String poBoxDetails;
    
    /**
     * town/city
     *
     */
    private String townCity;
    
    /**
     *  district_or_region
     *
     */
    private String districtRegion;
    
    /**
     *  country
     *
     */
    private String country;
    
    /**
     *  postcode_or_zip
     *
     */
    private String postcodeZip;
    
    /**
     * phone_number
     *
     */
    private String phoneNumber;
    
    /**
     * mobile_number
     *
     **/
    private String mobileNumber;
    
    /**
     * email_address
     *
     **/
    private String emailAddress;
    
    /**
     * comments
     *
     */
    private String comments;

    private String faxNumber;
    private Integer timeAtAddressMonths;
    private Integer timeAtAddressYears;
    private String residentialStatus;
    private int numberOfDependents;
    private String placeOfBirth;
    private String workPhone;
    private int mobileCountryCode = 0;
    private String maritalStatus;
    private String adviceMethod;
    private String statementDeliveryPreference;
    private Date deliveryPreferenceDate;
    private String alternateEmailAddress;
    private String welcomePack;
    private String previousDeliveryPreference;
    private Date conversionStatusDate;
    private Date statementStatusDate;
    private String currentStatementStatus;
    private String currentStatementStatusCode;
    private String statementConversionStatus;
    private String statementConversionStatusCode;
    private boolean clearEmailDeliveryFailure;
            
    /** Creates a new instance of ContactBean */
    public Contact()  {
        super();
    }
    /** Creates a new instance of ContactBean */
    public Contact(String country, int sequenceNumber) {
        super();
        this.setSequenceNumber(sequenceNumber);
        this.setCountry(country);
    }
    /** Creates a new instance of ContactBean */
    public Contact(Customer customer) {
        super();
        this.setCustomer(customer);
    }

    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.<p>
     *
     */
    public int compareTo(Object o) {
        if(!(o instanceof Contact)) throw new ClassCastException();
        Contact thatContact=(Contact) o;
        
        if (this.customer == null && thatContact.customer == null){
        	// Both Contacts do not have the Customer Number yet - No point in comparing further.
        	return 0;
        }else if (this.customer != null && thatContact.customer != null){
        	// Do the Normal Comparison
        }else{
        	return 1;
        }
        	
        Integer thisCustomerNumber=new Integer(this.getCustomerNumber());
        Integer thatCustomerNumber=new Integer(thatContact.getCustomerNumber());
        
        if(thisCustomerNumber.compareTo(thatCustomerNumber)==0) {
            // same customer, check name
            return this.getName().compareTo(thatContact.getName());
        }
        return thisCustomerNumber.compareTo(thatCustomerNumber);
    }
        
    public boolean isPrimary() {
        return "Y".equalsIgnoreCase(this.primaryContactIndicator);
    }
    
    public void setCustomer(Customer customer) {
        this.customer=customer;
    }
    /**
     * Getter for property customerNumber.
     * @return Value of property customerNumber.
     */
    public int getCustomerNumber() {
        return this.customer.getCustomerNumber();
    }
    
    public int getSequenceNumber() {
        return this.sequenceNumber;
    }
   
    public void setSequenceNumber(int sequenceNumber) {
        this.sequenceNumber=sequenceNumber;
    }
    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber=Integer.parseInt(sequenceNumber);
    }
    public String getPrimaryContactIndicator() {
        return this.primaryContactIndicator;
    }
    public void setPrimaryContactIndicator(String primaryContactIndicator) {
        this.primaryContactIndicator=primaryContactIndicator;
    }
    public String getType() {
        return this.type;
    }
    public void setType(String type) {
        this.type=type;
    }
    public String getName() {
        return this.name;
    }
    public void setName(String name) {
        this.name=name;
    }
    public String getPosition() {
        return this.position;
    }
    public void setPosition(String position) {
        this.position=position;
    }
    public Date getDateOfBirth() {
        return this.dateOfBirth;
    }
    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth=dateOfBirth;
    }
    public String getMemorableName() {
        return this.memorableName;
    }
    public void setMemorableName(String memorableName) {
        this.memorableName=memorableName;
    }
    //Warning: this method is used by reflection in OpenAccountAddApplicationAction
    public String getAddressFirstLine() {
        return this.addressFirstLine;
    }
    public void setAddressFirstLine(String addressFirstLine) {
            this.addressFirstLine=addressFirstLine;
    }
  //Warning: this method is used by reflection in OpenAccountAddApplicationAction
    public String getPoBoxDetails() {
        return this.poBoxDetails;
    }
    public void setPoBoxDetails(String poBoxDetails) {
            this.poBoxDetails=poBoxDetails;
    }
    //Warning: this method is used by reflection in OpenAccountAddApplicationAction
    public String getTownCity() {
        return this.townCity;
    }
    public void setTownCity(String townCity) {
        this.townCity=townCity;
    }
    //Warning: this method is used by reflection in OpenAccountAddApplicationAction
    public String getDistrictRegion() {
        return this.districtRegion;
    }
    public void setDistrictRegion(String districtRegion) {
        this.districtRegion=districtRegion;
    }
    /**
     * Getter for property country.
     * Warning: this method is used by reflection in 
     *  OpenAccountAddApplicationAction
     * @return Value of property country.
     */
    public String getCountry() {
        return this.country;
    }
/**
     * Setter for property country.
     * @param country New value of property country.
     */
    public void setCountry(String country) {
        this.country = country;
    }
    //Warning: this method is used by reflection in OpenAccountAddApplicationAction
    public String getPostcodeZip(){
        return this.postcodeZip;
    }
    public void setPostcodeZip(String postcodeZip) {
        this.postcodeZip=postcodeZip;
    }
    public String getPhoneNumber() {
        return this.phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber=phoneNumber;
    }
    public String getMobileNumber() {
        return this.mobileNumber;
    }
    public void setMobileNumber(String mobileNumber){
        this.mobileNumber=mobileNumber;
    }
    public String getEmailAddress() {
        return this.emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress=emailAddress;
    }
    public String getComments() {
        return this.comments;
    }
    public void setComments(String comments) {
        this.comments=comments;
    }
    
	/**
	 * @return Returns the residentialStatus.
	 */
	public String getResidentialStatus() {
		return residentialStatus;
	}
	/**
	 * @param residentialStatus The residentialStatus to set.
	 */
	public void setResidentialStatus(String residentialStatus) {
		this.residentialStatus = residentialStatus;
	}
	/**
	 * @return Returns the numberOfDependents.
	 */
	public int getNumberOfDependents() {
		return numberOfDependents;
	}
	/**
	 * @param numberOfDependents The numberOfDependents to set.
	 */
	public void setNumberOfDependents(int numberOfDependents) {
		this.numberOfDependents = numberOfDependents;
	}
	/**
	 * @return Returns the faxNumber.
	 */
	public String getFaxNumber() {
		return faxNumber;
	}
	/**
	 * @param faxNumber The faxNumber to set.
	 */
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	/**
	 * @return Returns the timeAtAddressMonths.
	 */
	public Integer getTimeAtAddressMonths() {
		return timeAtAddressMonths;
	}
	/**
	 * @param timeAtAddressMonths The timeAtAddressMonths to set.
	 */
	public void setTimeAtAddressMonths(Integer timeAtAddressMonths) {
		this.timeAtAddressMonths = timeAtAddressMonths;
	}
	/**
	 * @return Returns the timeAtAddressYears.
	 */
	public Integer getTimeAtAddressYears() {
		return timeAtAddressYears;
	}
	/**
	 * @param timeAtAddressYears The timeAtAddressYears to set.
	 */
	public void setTimeAtAddressYears(Integer timeAtAddressYears) {
		this.timeAtAddressYears = timeAtAddressYears;
	}
	/**
	 * @return the placeOfBirth
	 */
	public String getPlaceOfBirth() {
		return placeOfBirth;
	}
	/**
	 * @param placeOfBirth the placeOfBirth to set
	 */
	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}
	/**
	 * @return the workPhone
	 */
	public String getWorkPhone() {
		return workPhone;
	}
	/**
	 * @param workPhone the workPhone to set
	 */
	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}
	/**
	 * @return the mobileCountryCode
	 */
	public int getMobileCountryCode() {
		return mobileCountryCode;
	}
	/**
	 * @param mobileCountryCode the mobileCountryCode to set
	 */
	public void setMobileCountryCode(int mobileCountryCode) {
		this.mobileCountryCode = mobileCountryCode;
	}
	/**
	 * @return the maritalStatus
	 */
	public String getMaritalStatus() {
		return maritalStatus;
	}
	/**
	 * @param maritalStatus the maritalStatus to set
	 */
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	/**
	 * @return the adviceMethod
	 */
	public String getAdviceMethod() {
		return adviceMethod;
	}
	/**
	 * @param adviceMethod the adviceMethod to set
	 */
	public void setAdviceMethod(String adviceMethod) {
		this.adviceMethod = adviceMethod;
	}
	
	/**
	 * Gets the contact's preferred statement delivery method.
	 */
	public String getStatementDeliveryPreference()
	{
	    return statementDeliveryPreference;
	}
	
	/**
     * Sets the contact's preferred statement delivery method.
     */
    public void setStatementDeliveryPreference(String value)
    {
        statementDeliveryPreference = value;
    }
    
    /**
     * Gets the date when the delivery preference was last updated.
     */
    public Date getDeliveryPreferenceDate()
    {
        return deliveryPreferenceDate;
    }
    
    /**
     * Sets the date when the delivery preference was last updated.
     */
    public void setDeliveryPreferenceDate(Date value)
    {
        deliveryPreferenceDate = value;
    }
	
    /**
     * Gets the contact's alternate email address.
     */
    public String getAlternateEmailAddress()
    {
        return alternateEmailAddress;
    }
    
    /**
     * Sets the contact's alternate email address.
     */
    public void setAlternateEmailAddress(String value)
    {
        alternateEmailAddress = value;
    }
    
    /**
     * Gets a value that indicates whether the contact is due to be sent a
     * welcome email for eStatements.
     */
    public String getWelcomePack()
    {
        return welcomePack;
    }
    
    /**
     * Sets a value that indicates whether the contact is due to be sent a
     * welcome email for eStatements.
     */
    public void setWelcomePack(String value)
    {
        welcomePack = value;
    }
    
    /**
     * Gets the customer's previous choice of statement delivery method.
     */
    public String getPreviousDeliveryPreference()
    {
        return previousDeliveryPreference;
    }
    
    /**
     * Sets the customer's previous choice of statement delivery method.
     */
    public void setPreviousDeliveryPreference(String value)
    {
        previousDeliveryPreference = value;
    }
    
    /**
     * Gets the date when the customer's conversion status was updated.
     */
    public Date getConversionStatusDate()
    {
        return conversionStatusDate;
    }
    
    /**
     * Sets the date when the customer's conversion status was updated.
     */
    public void setConversionStatusDate(Date value)
    {
        conversionStatusDate = value;
    }
    
    /**
     * Gets the date when the customer's eStatement conversion status was last
     * updated.
     */
    public Date getStatementStatusDate()
    {
        return statementStatusDate;
    }
    
    /**
     * Sets the date when the customer's eStatement conversion status was last
     * updated.
     */
    public void setStatementStatusDate(Date value)
    {
        statementStatusDate = value;
    }
    
    /**
     * Gets the user-friendly description of the current statement delivery
     * status.
     */
    public String getCurrentStatementStatus()
    {
        return currentStatementStatus;
    }
    
    /**
     * Sets the user-friendly description of the current statement delivery
     * status.
     */
    public void setCurrentStatementStatus(String value)
    {
        currentStatementStatus = value;
    }
    
    /**
     * Gets the code that represents the current statement delivery status.
     */
    public String getCurrentStatementStatusCode()
    {
        return currentStatementStatusCode;
    }
    
    /**
     * Sets the code that represents the current statement delivery status.
     */
    public void setCurrentStatementStatusCode(String value)
    {
        currentStatementStatusCode = value;
    }
    
    /**
     * Gets the user-friendly description of the current statement conversion
     * status.
     */
    public String getStatementConversionStatus()
    {
        return statementConversionStatus;
    }
    
    /**
     * Sets the user-friendly description of the current statement conversion
     * status.
     */
    public void setStatementConversionStatus(String value)
    {
        statementConversionStatus = value;
    }
    
    /**
     * Gets the code that represents the current statement conversion status.
     */
    public String getStatementConversionStatusCode()
    {
        return statementConversionStatusCode;
    }
    
    /**
     * Sets the code that represents the current statement conversion status.
     */
    public void setStatementConversionStatusCode(String value)
    {
        statementConversionStatusCode = value;
    }
    
    /**
     * Gets a value to indicate whether eStatement delivery status will be reset
     * to OK.
     */
    public boolean getClearEmailDeliveryFailure()
    {
        return clearEmailDeliveryFailure;
    }
    
    /**
     * Sets a value to indicate whether eStatement delivery status will be reset
     * to OK.
     */
    public void setClearEmailDeliveryFailure(boolean value)
    {
        clearEmailDeliveryFailure = value;
    }
    
    @Override
    public boolean equals(Object obj) {
    	if (compareTo(obj) == 0){
    		return true;
    	}else
    		return false;
    }
    
	@Override
	public String toString() {
		return "[" + getName() + "::" + getEmailAddress() + "::"
				+ getDateOfBirth() + "]";
	}
}
