package com.barclays.staffware.plugin.dto;

import com.barclays.eChannel.data.bean.AccountDetailDynamicDisplayFieldBean;
import com.barclays.generic.business.utils.LoggerConnection;
import com.ibm.math.BigDecimal;

import java.beans.PropertyVetoException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;


/**
 * A customer account on BRAINS.
 * 
 * @author SHARPEP
 */
/*
 * DATE     REFERENCE  WHO      VERSION  COMMENTS
 * -------  ---------  -------  -------  ---------------------------------------
 * 23Nov04  PAT01378   SHARPEP  1a       Created
 * 26Oct05  PAT01562   KEMPD    1b       Changes for eTrade.
 * 05Jun06  PAT01616   KEMPD    1c       Override `hashCode()'.
 * 17Oct06  PAT01765   HUNTI    1d       Removed property change support.
 *                                          Added `populated' property.
 * 30Jan07  PAT01920   HUNTI    1e       Use `BigDecimal' instead of `double'.
 * 17Apr07  PAT01952   LEEDSS   1f       Added `originalLoanAmount',
 *                                          `accountGrade',
 *                                          `calculateAccountStats(...)'
 * 06Nov07  PAT02248   KEMPD    1g       Removed leftover PropertyVetoException.
 * 07Nov07  PAT02281   KEMPD    1h       WP137: implements `CustomerAccount'.
 * 13Nov07             CHAURAP  1i       Added primaryAccount property for AFM8502 solution
 * 16Nov07	PAT2296		SM	 1j		  	 Change primaryAccount property for AFM8502 solution
 * 23Apr08	pat02484	AGJ		1k		 Include prodcutDetailId in stat calculation     
 * 11Dec12	OLE P3	   GX		         OLE replacement phase 3        
 * 09Feb12  R5M2		WIG		OLE P4   Fix build issue.   
 * 12Mar12	R6		   FAIRBANM			 Added mandate instruction to the account                      
 */
public class Account
    implements
        CustomerAccount,
        java.io.Serializable,
        Comparable,
        Cloneable
{
	/**
	 * LoggerConnection object
	 */
	private static final LoggerConnection logger = new LoggerConnection(Account.class);
	/**
	 * Enum that represents the mapping of eBOX values for mandate instruction to the
	 * value they need to be in BRAINS. Also has a static method to go the other way.
	 * The eBOX value are retrieved from MW_RefValues so you'll want to update this
	 * if they ever change.
	 * @author fairbanm
	 *
	 */
	public enum MandateInstructionToBrainsMapping {
		/**
		 * Sole
		 */
		SOLE("S"),
		/**
		 * Both to sign
		 */
		BOTH("J"),
		/**
		 * Either to sign
		 */
		EITHER("O"),
		/**
		 * All to sign
		 */
		ALL("M"),
		/**
		 * Any to sign
		 */
		ANY("T");
		private String brainsValue;

		public String getBrainsValue(){
			return brainsValue;
		}

		public static MandateInstructionToBrainsMapping getMappingByBrainsValue(String brainsValue){
			for (MandateInstructionToBrainsMapping mapping : MandateInstructionToBrainsMapping.values()) {
				if(mapping.getBrainsValue().equals(brainsValue)){
					return mapping;
				}
			}

			return null;
		}

		private MandateInstructionToBrainsMapping(String brainsValue){
			this.brainsValue = brainsValue;
		}
	}

    private static final long serialVersionUID = 6388381323902221602L;

    private boolean hasSignatures;

    /**
     * Holds value of property accountNumber.
     */
    private int accountNumber=-1;

    /**
     * Holds value of property branchNumber.
     */
    private int branchNumber=-1;

    /**
     * Holds value of property accountType.
     */
    private int accountType=-1;

    /**
     * Holds value of property status.
     */
    private String status;

    /**
     * Holds value of property name.
     */
    private String name;

    /**
     * Holds value of property currency.
     */
    private String currency;

    /**
     * Holds value of property external.
     */
    private boolean external;

    /**
     * Holds value of property shortName.
     */
    private String shortName;

    /**
     * Holds value of property kycDate.
     */
    private Date kycDate;

    /**
     * Holds value of property openActBal.
     */
    private BigDecimal openActBal;

    /**
     * Holds value of property openLocBal.
     */
    private BigDecimal openLocBal;

    /**
     * Holds value of property openEarBal.
     */
    private BigDecimal openEarBal;

    /**
     * Holds value of property openUncBal.
     */
    private BigDecimal openUncBal;

    /**
     * Holds value of property openAvlBal.
     */
    private BigDecimal openAvlBal;

    /**
     * Holds value of property currActBal.
     */
    private BigDecimal currActBal;

    /**
     * Holds value of property currLocBal.
     */
    private BigDecimal currLocBal;

    /**
     * Holds value of property currEarBal.
     */
    private BigDecimal currEarBal;

    /**
     * Holds value of property currUncBal.
     */
    private BigDecimal currUncBal;

    /**
     * Holds value of property currAvlBal.
     */
    private BigDecimal currAvlBal;

    /**
     * Holds value of property expiryDate.
     */
    private Date expiryDate;

    /**
     * Holds value of property marketSegCode.
     */
    private int marketSegCode;

    /**
     * Holds value of property marketSegDesc.
     */
    private String marketSegDesc;

    /**
     * Holds value of property openDate.
     */
    private Date openDate;

    /**
     * Holds value of property lastCreditPostDate.
     */
    private Date lastCreditPostDate;

    /**
     * Holds value of property lastEntryPostDate.
     */
    private Date lastEntryPostDate;

    /**
     * Holds value of property lastStmtDate.
     */
    private Date lastStmtDate;

    /**
     * Holds value of property kycInd.
     */
    private int kycInd;

    /**
     * Holds value of property designationId.
     */
    private String designationId;

    /**
     * Holds value of property designationDesc.
     */
    private String designationDesc;

    /**
     * Holds value of property debitLimit.
     */
    private BigDecimal debitLimit;

    /**
     * Holds value of property debitLimitExpiryDate.
     */
    private Date debitLimitExpiryDate;

    /**
     * Holds value of property cards.
     */
    private final SortedSet<Card> cards=new TreeSet<Card>();

    /**
     * Holds value of property signatures.
     */
    private final SortedSet<Signature> signatures=new TreeSet<Signature>();

    /**
     * Holds value of property addresses.
     */
    private final SortedSet<Address> addresses=new TreeSet<Address>();

    /**
     * Holds value of property Iban
     */
    private String iban;

    private BigDecimal originalLoanAmount;

    private boolean populated;

    /**
     * Holds value of property PRIMARY_ACCOUNT_INDICATOR
     */
    private boolean isPrimary;

    /**
     * Holds value of related Customer Contact Status for account
     */
    private String customerContactStatus ;

    /**
     * Holds value of kamlsProductType for account.
     */
    private String kamlsProductType;

    /**
     * Holds value of property accruedCreditInterest.
     */
    private BigDecimal accruedCreditInterest;

	/**
     * Holds value of property accruedDebitInterest.
     */
    private BigDecimal accruedDebitInterest;

	/**
     * Holds value of property referIndicator.
     */
    private String referIndicator;

    /**
     * Holds the value of any mandate instructions for joint accounts
     */
    private String mandateInstruction;

    /**
     * Holds is fixedDeposit property.
     */
    private boolean fixedDeposit;

    /**
     * Holds is automaticTransfer property.
     */
    private boolean automaticTransfer;


    public boolean isAutomaticTransfer() {
		return automaticTransfer;
	}

	public void setAutomaticTransfer(boolean automaticTransfer) {
		this.automaticTransfer = automaticTransfer;
	}

	/**
     * Holds value of property account roles, account linked customers and dynamic field group
     */
    private final ArrayList<AccountRole> accountRoles=new ArrayList<AccountRole>();
    private final SortedSet<AccountLinkedCustomer> accLnkedCustomers = new TreeSet<AccountLinkedCustomer>();
    private final ArrayList<AccountInterestRate> accInterestRates=new ArrayList<AccountInterestRate>();
    private HashMap<String, LinkedList<AccountDetailDynamicDisplayFieldBean>> dynamicFieldGroup
    						= new HashMap<String, LinkedList<AccountDetailDynamicDisplayFieldBean>>();


    /**
     * Holds the indicators of link buttons on Account Details screen
     */
    private SortedSet<AccountLinkButtonIndicators> linkButtonIndicators = new TreeSet<AccountLinkButtonIndicators>();

	/**
	 * @return the isFixedDeposit
	 */
	public boolean isFixedDeposit() {
		return fixedDeposit;
	}

	/**
	 * @param isFixedDeposit the isFixedDeposit to set
	 */
	public void setFixedDeposit(boolean isFixedDeposit) {
		this.fixedDeposit = isFixedDeposit;
	}

    public Account() {
    	super();
    }

    public Account(int branchNumber, int accountNumber, int accountType, String shortName,
    		String address) throws Exception {
        this.setBranchNumber(branchNumber);
        this.setAccountNumber(accountNumber);
        this.setAccountType(accountType);
        this.setShortName(shortName);
        this.setAddress(0,address);
    }

    public Account(int branchNumber, int accountNumber) {
        this.branchNumber = branchNumber;
        this.setAccountNumber(accountNumber);
    }

    public Account(
        String fullAccountNumber)
    {
        if (fullAccountNumber == null || fullAccountNumber.length() != 10)
        {
            throw new IllegalArgumentException("Invalid account number");
        }
        this.branchNumber = Integer.parseInt(fullAccountNumber.substring(0, 3));
        this.accountNumber = Integer.parseInt(fullAccountNumber.substring(3));
    }

    /**
     * Getter for property accountNumber.
     * @return Value of property accountNumber.
     */
    public int getAccountNumber() {
        return this.accountNumber;
    }

    /**
     * Setter for property accountNumber.
     * @param accountNumber New value of property accountNumber.
     */
    private void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getFullAccountNumber()
    {
        return MessageFormat.format(
                "{0,number,000}{1,number,0000000}",
                new Object[] {
                        new Integer(getBranchNumber()),
                        new Integer(getAccountNumber())});
    }

    public int compareTo(
        Object o)
    {
        return getFullAccountNumber().compareTo(
                ((Account) o).getFullAccountNumber());
    }

    public boolean equals(Object obj) {
        return (compareTo(obj)==0);
    }

    public int hashCode()
    {
        return getFullAccountNumber().hashCode();
    }

    /**
     * Getter for property branch.
     * @return Value of property branch.
     */
    public int getBranchNumber() {
        return this.branchNumber;
    }

    /**
     * Setter for property branch.
     * @param branchNumber New value of property branch.
     */
    public void setBranchNumber(int branchNumber) throws Exception {
    	if (branchNumber < 1 || branchNumber > 999) {
    		throw new Exception ("Branch number must be a maximum of 3 digits");
    	}
        this.branchNumber = branchNumber;
    }

    /**
     * Getter for property accountType.
     * @return Value of property accountType.
     */
    public int getAccountType() {
        return this.accountType;
    }

    /**
     * Setter for property accountType.
     * @param accountType New value of property accountType.
     */
    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }

    /**
     * Setter for property accountType.
     * @param accountType New value of property accountType.
     */
    public void setAccountType(String accountType) {
        setAccountType(Integer.parseInt(accountType));
    }

    /**
     * Getter for property status.
     * @return Value of property status.
     */
    public String getStatus() {
        return this.status;
    }

    /**
     * Setter for property status.
     * @param status New value of property status.
     */
    public void setStatus(String status) {
        this.status = status;
    }

    public void clear() {
        //TODO: reset everything else...
        this.removeAllCards();
        this.removeAllSignatures();
    }

    /**
     * Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for property currency.
     * @return Value of property currency.
     */
    public String getCurrency() {
        return this.currency;
    }

    /**
     * Setter for property currency.
     * @param currency New value of property currency.
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Getter for property external.
     * @return Value of property external.
     */
    public boolean isExternal() {
        return this.external;
    }

    /**
     * Setter for property external.
     * @param external New value of property external.
     */
    public void setExternal(boolean external) {
        this.external = external;
    }

    /**
     * Getter for property shortName.
     * @return Value of property shortName.
     */
    public String getShortName() {
        return this.shortName;
    }

    /**
     * Setter for property shortName.
     * @param shortName New value of property shortName.
     */
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    /**
     * Getter for property kycDate.
     * @return Value of property kycDate.
     */
    public Date getKycDate() {
        return this.kycDate;
    }

    /**
     * Setter for property kycDate.
     * @param kycDate New value of property kycDate.
     */
    public void setKycDate(Date kycDate) {
        this.kycDate = kycDate;
    }

    /**
     * Getter for property openActBal.
     * @return Value of property openActBal.
     */
    public BigDecimal getOpenActBal() {
        return this.openActBal;
    }

    /**
     * Setter for property openActBal.
     * @param openActBal New value of property openActBal.
     */
    public void setOpenActBal(BigDecimal openActBal) {
        this.openActBal = openActBal;
    }

    /**
     * Getter for property openLocBal.
     * @return Value of property openLocBal.
     */
    public BigDecimal getOpenLocBal() {
        return this.openLocBal;
    }

    /**
     * Setter for property openLocBal.
     * @param openLocBal New value of property openLocBal.
     */
    public void setOpenLocBal(BigDecimal openLocBal) {
        this.openLocBal = openLocBal;
    }

    /**
     * Getter for property openEarBal.
     * @return Value of property openEarBal.
     */
    public BigDecimal getOpenEarBal() {
        return this.openEarBal;
    }

    /**
     * Setter for property openEarBal.
     * @param openEarBal New value of property openEarBal.
     */
    public void setOpenEarBal(BigDecimal openEarBal) {
        this.openEarBal = openEarBal;
    }

    /**
     * Getter for property openUncBal.
     * @return Value of property openUncBal.
     */
    public BigDecimal getOpenUncBal() {
        return this.openUncBal;
    }

    /**
     * Setter for property openUncBal.
     * @param openUncBal New value of property openUncBal.
     */
    public void setOpenUncBal(BigDecimal openUncBal) {
        this.openUncBal = openUncBal;
    }

    /**
     * Getter for property openAvlBal.
     * @return Value of property openAvlBal.
     */
    public BigDecimal getOpenAvlBal() {
        return this.openAvlBal;
    }

    /**
     * Setter for property openAvlBal.
     * @param openAvlBal New value of property openAvlBal.
     */
    public void setOpenAvlBal(BigDecimal openAvlBal) {
        this.openAvlBal = openAvlBal;
    }

    /**
     * Getter for property currActBal.
     * @return Value of property currActBal.
     */
    public BigDecimal getCurrActBal() {
        return this.currActBal;
    }

    /**
     * Setter for property currActBal.
     * @param currActBal New value of property currActBal.
     */
    public void setCurrActBal(BigDecimal currActBal) {
        this.currActBal = currActBal;
    }

    /**
     * Getter for property currLocBal.
     * @return Value of property currLocBal.
     */
    public BigDecimal getCurrLocBal() {
        return this.currLocBal;
    }

    /**
     * Setter for property currLocBal.
     * @param currLocBal New value of property currLocBal.
     */
    public void setCurrLocBal(BigDecimal currLocBal) {
        this.currLocBal = currLocBal;
    }

    /**
     * Getter for property currEarBal.
     * @return Value of property currEarBal.
     */
    public BigDecimal getCurrEarBal() {
        return this.currEarBal;
    }

    /**
     * Setter for property currEarBal.
     * @param currEarBal New value of property currEarBal.
     */
    public void setCurrEarBal(BigDecimal currEarBal) {
        this.currEarBal = currEarBal;
    }

    /**
     * Getter for property currUncBal.
     * @return Value of property currUncBal.
     */
    public BigDecimal getCurrUncBal() {
        return this.currUncBal;
    }

    /**
     * Setter for property currUncBal.
     * @param currUncBal New value of property currUncBal.
     */
    public void setCurrUncBal(BigDecimal currUncBal) {
        this.currUncBal = currUncBal;
    }

    /**
     * Getter for property currAvlBal.
     * @return Value of property currAvlBal.
     */
    public BigDecimal getCurrAvlBal() {
        return this.currAvlBal;
    }

    /**
     * Setter for property currAvlBal.
     * @param currAvlBal New value of property currAvlBal.
     */
    public void setCurrAvlBal(BigDecimal currAvlBal) {
        this.currAvlBal = currAvlBal;
    }

    /**
     * Getter for property expiryDate.
     * @return Value of property expiryDate.
     */
    public Date getExpiryDate() {
        return this.expiryDate;
    }

    /**
     * Setter for property expiryDate.
     * @param expiryDate New value of property expiryDate.
     */
    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    /**
     * Getter for property marketSegCode.
     * @return Value of property marketSegCode.
     */
    public int getMarketSegCode() {
        return this.marketSegCode;
    }

    /**
     * Setter for property marketSegCode.
     * @param marketSegCode New value of property marketSegCode.
     */
    public void setMarketSegCode(int marketSegCode) {
        this.marketSegCode = marketSegCode;
    }

    /**
     * Getter for property marketSegDesc.
     * @return Value of property marketSegDesc.
     */
    public String getMarketSegDesc() {
        return this.marketSegDesc;
    }

    /**
     * Setter for property marketSegDesc.
     * @param marketSegDesc New value of property marketSegDesc.
     */
    public void setMarketSegDesc(String marketSegDesc) {
        this.marketSegDesc = marketSegDesc;
    }

    /**
     * Getter for property openDate.
     * @return Value of property openDate.
     */
    public Date getOpenDate() {
        return this.openDate;
    }

    /**
     * Setter for property openDate.
     * @param openDate New value of property openDate.
     */
    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    /**
     * Getter for property lastCreditPostDate.
     * @return Value of property lastCreditPostDate.
     */
    public Date getLastCreditPostDate() {
        return this.lastCreditPostDate;
    }

    /**
     * Setter for property lastCreditPostDate.
     * @param lastCreditPostDate New value of property lastCreditPostDate.
     */
    public void setLastCreditPostDate(Date lastCreditPostDate) {
        this.lastCreditPostDate = lastCreditPostDate;
    }

    /**
     * Getter for property lastEntryPostDate.
     * @return Value of property lastEntryPostDate.
     */
    public Date getLastEntryPostDate() {
        return this.lastEntryPostDate;
    }

    /**
     * Setter for property lastEntryPostDate.
     * @param lastEntryPostDate New value of property lastEntryPostDate.
     */
    public void setLastEntryPostDate(Date lastEntryPostDate) {
        this.lastEntryPostDate = lastEntryPostDate;
    }

    /**
     * Getter for property lastStmtDate.
     * @return Value of property lastStmtDate.
     */
    public Date getLastStmtDate() {
        return this.lastStmtDate;
    }

    /**
     * Setter for property lastStmtDate.
     * @param lastStmtDate New value of property lastStmtDate.
     */
    public void setLastStmtDate(Date lastStmtDate) {
        this.lastStmtDate = lastStmtDate;
    }

    /**
     * Getter for property kycInd.
     * @return Value of property kycInd.
     */
    public int getKycInd() {
        return this.kycInd;
    }

    /**
     * Setter for property kycInd.
     * @param kycInd New value of property kycInd.
     */
    public void setKycInd(int kycInd) {
        this.kycInd = kycInd;
    }

    /**
     * Getter for property designationId.
     * @return Value of property designationId.
     */
    public String getDesignationId() {
        return this.designationId;
    }

    /**
     * Setter for property designationId.
     * @param designationId New value of property designationId.
     */
    public void setDesignationId(String designationId) {
        this.designationId = designationId;
    }

    /**
     * Getter for property designationDesc.
     * @return Value of property designationDesc.
     */
    public String getDesignationDesc() {
        return this.designationDesc;
    }

    /**
     * Setter for property designationDesc.
     * @param designationDesc New value of property designationDesc.
     */
    public void setDesignationDesc(String designationDesc) {
        this.designationDesc = designationDesc;
    }

    /**
     * Getter for property debitLimit.
     * @return Value of property debitLimit.
     */
    public BigDecimal getDebitLimit() {
        return this.debitLimit;
    }

    /**
     * Setter for property debitLimit.
     * @param debitLimit New value of property debitLimit.
     */
    public void setDebitLimit(BigDecimal debitLimit) {
        this.debitLimit = debitLimit;
    }

    /**
     * Getter for property debitLimitExpiryDate.
     * @return Value of property debitLimitExpiryDate.
     */
    public Date getDebitLimitExpiryDate() {
        return this.debitLimitExpiryDate;
    }

    /**
     * Setter for property debitLimitExpiryDate.
     * @param debitLimitExpiryDate New value of property debitLimitExpiryDate.
     */
    public void setDebitLimitExpiryDate(Date debitLimitExpiryDate) {
        this.debitLimitExpiryDate = debitLimitExpiryDate;
    }

    protected void finalize() throws Throwable {
        super.finalize();

    }

    /**
     * Holds value of property customer.
     */
    private Customer customer;

    /**
     * Holds value of property address.
     */
    private String[] address={null,null,null};

    /**
     * Holds value of property atmClass.
     */
    private int atmClass;

    /**
     * Holds value of property featureType.
     */
    private String featureType;

    /**
     * Holds value of property creditIntDate.
     */
    private Date creditIntDate;

    /**
     * Holds value of property addressSeqNumber.
     */
    private int addressSeqNumber;

    /**
     * Holds value of property addressContactName.
     */
    private String addressContactName;

    /**
     * Holds value of property note.
     */
    private String[] note={null,null,null};

    /**
     * Holds value of property debitIntDate.
     */
    private Date debitIntDate;

    /**
     * Holds value of property longName.
     */
    private String longName;

    /**
     * Holds value of property pendingItems.
     */
    private boolean pendingItems;

    /**
     * Holds value of property referCode.
     */
    private int referCode;

    /**
     * Holds value of property referCredits.
     */
    private int referCredits;

    /**
     * Holds value of property referDebits.
     */
    private int referDebits;

    /**
     * Holds value of property referNonChequeDebits.
     */
    private int referNonChequeDebits;

    /**
     * Holds value of property riskLevel3.
     */
    private boolean riskLevel3;

    /**
     * Holds value of riskLevel3Score.
     */
    private int riskLevel3Score;

    /**
     * Holds value of property riskLevelBBG.
     */
    private BigDecimal riskLevelBBG;

    /**
     * Holds value of property riskLevelEWL.
     */
    private BigDecimal riskLevelEWL;

    /**
     * Holds value of property statusNarrative.
     */
    private String statusNarrative;

    /**
     * Holds value of property statementFreq.
     */
    private String statementFreq;

    /**
     * Holds value of property statementFreqData.
     */
    private String statementFreqData;

    /**
     * Holds value of property stoppedCheques.
     */
    private boolean stoppedCheques;

    /**
     * Holds value of property typeNarrative.
     */
    private String typeNarrative;

    /**
     * Holds value of property sequenceNumber.
     */
    private int sequenceNumber;

    /**
     * Getter for property customer.
     * @return Value of property customer.
     */
    public Customer getCustomer() {
        return this.customer;
    }

    /**
     * Setter for property customer.
     * @param customer New value of property customer.
     */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void addCard(
        Card card)
    {
        cards.add(card);
        card.addAccount(this);
    }

    public Card getCard(
        String number)
    {
        if (number == null) throw new IllegalArgumentException("null");

        Card result = null;
        for (Iterator<Card> i = cards.iterator(); i.hasNext(); )
        {
            Card c = i.next();
            if (number.equals(c.getCardNumber()))
            {
                result = c;
                break;
            }
        }
        return result;
    }

    public Set<Card> getCards()
    {
        return Collections.unmodifiableSet(cards);
    }

    public void removeAllCards()
    {
        cards.clear();
    }

    public boolean removeCard(
        Card card)
    {
        if (cards.remove(card))
        {
            card.clearAccounts();
            return true;
        }
        return false;
    }

    public Iterator<Signature> signatureIterator() {
        return this.signatures.iterator();
    }

    public void addSignature(final Signature signature) {
        if(this.signatures.contains(signature)) return;
        this.signatures.add(signature);
        signature.setAccount(this);
    }

    public boolean removeSignature(final Signature signature) {
        if(this.signatures.remove(signature)) {
            signature.setAccount(null);
            return true;
        }
        return false;
    }

    public void removeAllSignatures() {
        this.signatures.clear();
    }


    public void addAddress(
            Address address)
        {
            addresses.add(address);
        }

    /**
     * Indexed getter for property address.
     * @param index Index of the property.
     * @return Value of the property at <CODE>index</CODE>.
     */
    public String getAddress(int index) {
        if(index<0 || (index-1)>=this.address.length) return null;
        return this.address[index-1];
    }

    /**
     * Indexed getter for property address.
     * @return Value of the property at <CODE>0</CODE>.
     */
    public String getAddress() {
        return this.address[0];
    }

    /**
     * Indexed setter for property address.
     * @param index Index of the property.
     * @param address New value of the property at <CODE>index</CODE>.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setAddress(int index, String address) throws Exception {
        if(index<0 || index>=this.address.length) throw new Exception("index should be between 1 and "+this.address.length+" inclusive",null);
        this.address[index] = address;
    }

    public Set<Address> getAddresses()
    {
        return Collections.unmodifiableSet(addresses);
    }

    /**
     * Getter for property atmClass.
     * @return Value of property atmClass.
     */
    public int getAtmClass() {
        return this.atmClass;
    }

    /**
     * Setter for property atmClass.
     * @param atmClass New value of property atmClass.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setAtmClass(int atmClass) throws PropertyVetoException {
        this.atmClass = atmClass;
    }

    /**
     * Getter for property featureType.
     * @return Value of property featureType.
     */
    public String getFeatureType() {
        return this.featureType;
    }

    /**
     * Setter for property featureType.
     * @param featureType New value of property featureType.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setFeatureType(String featureType) throws PropertyVetoException {
        this.featureType = featureType;
    }

    /**
     * Getter for property creditIntDate.
     * @return Value of property creditIntDate.
     */
    public Date getCreditIntDate() {
        return this.creditIntDate;
    }

    /**
     * Setter for property creditIntDate.
     * @param creditIntDate New value of property creditIntDate.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setCreditIntDate(Date creditIntDate) throws PropertyVetoException {
        this.creditIntDate = creditIntDate;
    }

    /**
     * Getter for property addressSeqNumber.
     * @return Value of property addressSeqNumber.
     */
    public int getAddressSeqNumber() {
        return this.addressSeqNumber;
    }

    /**
     * Setter for property addressSeqNumber.
     * @param addressSeqNumber New value of property addressSeqNumber.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setAddressSeqNumber(int addressSeqNumber) throws PropertyVetoException {
        this.addressSeqNumber = addressSeqNumber;
    }

    /**
     * Getter for property addressContactName.
     * @return Value of property addressContactName.
     */
    public String getAddressContactName() {
        return this.addressContactName;
    }

    /**
     * Setter for property addressContactName.
     * @param addressContactName New value of property addressContactName.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setAddressContactName(String addressContactName) throws PropertyVetoException {
        this.addressContactName = addressContactName;
    }

    /**
     * Indexed getter for property note.
     * @param index Index of the property.
     * @return Value of the property at <CODE>index</CODE>.
     */
    public String getNote(int index) {
        if(index<0 || index>=this.note.length) return null;
        return this.note[index];
    }

    /**
     * Indexed setter for property note.
     * @param index Index of the property.
     * @param note New value of the property at <CODE>index</CODE>.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setNote(int index, String note) throws Exception {
        if(index<0 || index>=this.note.length) throw new Exception("index should be between 0 and "+(this.note.length-1)+" inclusive",null);
        this.note[index] = note;
    }

    /**
     * Getter for property debitIntDate.
     * @return Value of property debitIntDate.
     */
    public Date getDebitIntDate() {
        return this.debitIntDate;
    }

    /**
     * Setter for property debitIntDate.
     * @param debitIntDate New value of property debitIntDate.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setDebitIntDate(Date debitIntDate) throws PropertyVetoException {
        this.debitIntDate = debitIntDate;
    }

    /**
     * Getter for property longName.
     * @return Value of property longName.
     */
    public String getLongName() {
        return this.longName;
    }

    /**
     * Setter for property longName.
     * @param longName New value of property longName.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setLongName(String longName) throws PropertyVetoException {
        this.longName = longName;
    }

    /**
     * Getter for property pendingItems.
     * @return Value of property pendingItems.
     */
    public boolean isPendingItems() {
        return this.pendingItems;
    }

    /**
     * Setter for property pendingItems.
     * @param pendingItems New value of property pendingItems.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setPendingItems(boolean pendingItems) throws PropertyVetoException {
        this.pendingItems = pendingItems;
    }

    /**
     * Getter for property referCode.
     * @return Value of property referCode.
     */
    public int getReferCode() {
        return this.referCode;
    }

    /**
     * Setter for property referCode.
     * @param referCode New value of property referCode.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setReferCode(int referCode) throws PropertyVetoException {
        this.referCode = referCode;
    }

    /**
     * Getter for property referCredits.
     * @return Value of property referCredits.
     */
    public int getReferCredits() {
        return this.referCredits;
    }

    /**
     * Setter for property referCredits.
     * @param referCredits New value of property referCredits.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setReferCredits(int referCredits) throws PropertyVetoException {
        this.referCredits = referCredits;
    }

    /**
     * Getter for property referDebits.
     * @return Value of property referDebits.
     */
    public int getReferDebits() {
        return this.referDebits;
    }

    /**
     * Setter for property referDebits.
     * @param referDebits New value of property referDebits.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setReferDebits(int referDebits) throws PropertyVetoException {
        this.referDebits = referDebits;
    }

    /**
     * Getter for property referNonChequeDebits.
     * @return Value of property referNonChequeDebits.
     */
    public int getReferNonChequeDebits() {
        return this.referNonChequeDebits;
    }

    /**
     * Setter for property referNonChequeDebits.
     * @param referNonChequeDebits New value of property referNonChequeDebits.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setReferNonChequeDebits(int referNonChequeDebits) throws PropertyVetoException {
        this.referNonChequeDebits = referNonChequeDebits;
    }

    /**
     * Getter for property riskLevel3.
     * @return Value of property riskLevel3.
     */
    public boolean isRiskLevel3() {
        return this.riskLevel3;
    }

    /**
     * Setter for property riskLevel3.
     * @param riskLevel3 New value of property riskLevel3.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setRiskLevel3(boolean riskLevel3) throws PropertyVetoException {
        this.riskLevel3 = riskLevel3;
    }

    /**
     * Getter for property risklevel3Score
     * @return Value of property riskLevel3Score
     */
    public int getRiskLevel3Score() {
        return this.riskLevel3Score;
    }

    /**
     * Setter for property riskLevel3Score
     * @param value New value of property riskLevel3Score.
     */
    public void setRiskLevel3Score(int value) {
        this.riskLevel3Score = value;
    }

    /**
     * Getter for property riskLevelBBG.
     * @return Value of property riskLevelBBG.
     */
    public BigDecimal getRiskLevelBBG() {
        return this.riskLevelBBG;
    }

    /**
     * Setter for property riskLevelBBG.
     * @param riskLevelBBG New value of property riskLevelBBG.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setRiskLevelBBG(BigDecimal riskLevelBBG) throws PropertyVetoException {
        this.riskLevelBBG = riskLevelBBG;
    }

    /**
     * Getter for property riskLevelEWL.
     * @return Value of property riskLevelEWL.
     */
    public BigDecimal getRiskLevelEWL() {
        return this.riskLevelEWL;
    }

    /**
     * Setter for property riskLevelEWL.
     * @param riskLevelEWL New value of property riskLevelEWL.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setRiskLevelEWL(BigDecimal riskLevelEWL) throws PropertyVetoException {
        this.riskLevelEWL = riskLevelEWL;
    }

    /**
     * Getter for property statusNarrative.
     * @return Value of property statusNarrative.
     */
    public String getStatusNarrative() {
        return this.statusNarrative;
    }

    /**
     * Setter for property statusNarrative.
     * @param statusNarrative New value of property statusNarrative.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setStatusNarrative(String statusNarrative) throws PropertyVetoException {
        this.statusNarrative = statusNarrative;
    }

    /**
     * Getter for property statementFreq.
     * @return Value of property statementFreq.
     */
    public String getStatementFreq() {
        return this.statementFreq;
    }

    /**
     * Setter for property statementFreq.
     * @param statementFreq New value of property statementFreq.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setStatementFreq(String statementFreq) throws PropertyVetoException {
        this.statementFreq = statementFreq;
    }

    /**
     * Getter for property statementFreqData.
     * @return Value of property statementFreqData.
     */
    public String getStatementFreqData() {
        return this.statementFreqData;
    }

    /**
     * Setter for property statementFreqData.
     * @param statementFreqData New value of property statementFreqData.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setStatementFreqData(String statementFreqData) throws PropertyVetoException {
        this.statementFreqData = statementFreqData;
    }

    /**
     * Getter for property stoppedCheques.
     * @return Value of property stoppedCheques.
     */
    public boolean isStoppedCheques() {
        return this.stoppedCheques;
    }

    /**
     * Setter for property stoppedCheques.
     * @param stoppedCheques New value of property stoppedCheques.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setStoppedCheques(boolean stoppedCheques) throws PropertyVetoException {
        this.stoppedCheques = stoppedCheques;
    }

    /**
     * Getter for property typeNarrative.
     * @return Value of property typeNarrative.
     */
    public String getTypeNarrative() {
        return this.typeNarrative;
    }

    /**
     * Setter for property typeNarrative.
     * @param typeNarrative New value of property typeNarrative.
     */
    public void setTypeNarrative(String typeNarrative)
    {
        this.typeNarrative = typeNarrative;
    }

    /**
     * Getter for property sequenceNumber.
     * @return Value of property sequenceNumber.
     */
    public int getSequenceNumber() {
        return this.sequenceNumber;
    }



    /**
     * Setter for property sequenceNumber.
     * @param sequenceNumber New value of property sequenceNumber.
     *
     * @throws PropertyVetoException if some vetoable listeners reject the new value
     */
    public void setSequenceNumber(int sequenceNumber) throws PropertyVetoException {
        this.sequenceNumber = sequenceNumber;
    }
    
    /**
     * Determine if this account is KYC compliant. Compliant accounts are ones where the KYC ind is not 1, 4 or 5
     * @returnValue boolean Is compliant
     */
    public boolean isKYCCompliant() {
        boolean returnValue;
        if (this.getKycInd() == 1 ||
            this.getKycInd() == 4 ||
            this.getKycInd() == 5) {
                
            returnValue=true;
        } else {
            returnValue=false;
        }
        return returnValue;
    }
    
    /**
     * Implemented
     */
    public boolean isPrimaryCardAccount() {
        return false;    
    }
    
    public boolean getHasSignatures() {
        return hasSignatures;
    }
    
    public void setHasSignatures(boolean hasSignatures) {
        this.hasSignatures = hasSignatures;
    }
    
    /**
     * Gets the IBAN number for the account
     * @return string containing the number.
     */
    public String getIban() {
    	return iban;
    }
    
    /**
     * Sets the IBAN number for this account
     * @param iban The number to use
     */
    public void setIban(String iban) {
    	this.iban = iban;
    }

    /**
     * Gets the original loan amount
     * @return the original loan amount
     */
    public BigDecimal getOriginalLoanAmount() {
    	return this.originalLoanAmount;
    }
    
    /**
     * Sets the original loan amount
     * @param originalLoanAmount BigDecimal containing the original loan amount
     */
    public void setOriginalLoanAmount(BigDecimal originalLoanAmount) {
    	this.originalLoanAmount = originalLoanAmount;
    }
    
	/**
	 * @return the populated
	 */
	public boolean isPopulated() {
		return populated;
	}

	/**
	 * @param populated the populated to set
	 */
	public void setPopulated(boolean populated) {
		this.populated = populated;
	}
	
	/**
	 * The Account Grade (call calculateAccountGrade() to populate, if required)
	 * @return Returns the Account Grade
	 */
	public String getAccountGrade() {
		return accountGrade;
	}
	public void setAccountGrade(String accountGrade) {
		this.accountGrade = accountGrade;
	}
	private String accountGrade;
	
//	/**
//	 * Calculates the account stats for this account and populates the
//	 * AccountGrade property with the Account Performance Grade
//	 * @param user logged-in user
//	 * @param netMonthlySalary the customer's net monthly salary
//	 * @throws Exception
//	 */
//	public void calculateAccountStats(
//			User user,
//			BigDecimal netMonthlySalary,
//			int maxReturnedItems,
//			int returnedItemsPeriod,
//			int maxExcesses,
//			int excessesPeriod,
//			String productDetailId)
//	throws Exception {
//		this.accountGrade = AccountGradeCalculator.getGrade(
//				this,
//				netMonthlySalary,
//				user,
//				maxReturnedItems,
//				returnedItemsPeriod,
//				maxExcesses,
//				excessesPeriod,
//				productDetailId);
//	}

	public boolean isPrimary() {
		return isPrimary;
	}

	public void setIsPrimary(boolean isPrimary) {
		this.isPrimary = isPrimary;
	}

	public String getCustomerContactStatus() {
		return customerContactStatus ;
	}

	public void setCustomerContactStatus(String customerContactStatus) {
		this.customerContactStatus = customerContactStatus;
	}

	public void setKamlsProductType(String kamlsProductType) {
		this.kamlsProductType = kamlsProductType;
	}

	public String getKamlsProductType() {
		return kamlsProductType;
	}
	
	/**
	 * Should care whether account include fixed deposit 
	 * @return {@link BigDecimal}
	 */
	public BigDecimal getAccruedCreditInterest() {
		return accruedCreditInterest;
	}
	
	public void setAccruedCreditInterest(BigDecimal accruedCreditInterest) {
		this.accruedCreditInterest = accruedCreditInterest;
	}

	public BigDecimal getAccruedDebitInterest() {
		return accruedDebitInterest;
	}

	public void setAccruedDebitInterest(BigDecimal accruedDebitInterest) {
		this.accruedDebitInterest = accruedDebitInterest;
	}

	public String getReferIndicator() {
		return referIndicator;
	}

	public void setReferIndicator(String referIndicator) {
		this.referIndicator = referIndicator;
	}
	
	/**
	 * Gets the mandate instructions for a joint account
	 * @return The instructions for a joint account
	 */
	public String getMandateInstruction(){
		return mandateInstruction;
	}
	
	/**
	 * Sets the mandate instructions for a joint account
	 * NOTE: This method is used in reflection in CustomerActionHelper : populateChangedAccountData
	 * Consider yourself warned if you wish to remove it
	 * @param mandateInstruction The mandate instructions to set the account to
	 */
	public void setMandateInstruction(String mandateInstruction){
		this.mandateInstruction = mandateInstruction;
	}

	public ArrayList<AccountRole> getAccountRoles() {
		return accountRoles;
	}

	public SortedSet<AccountLinkedCustomer> getAccLnkedCustomers() {
		return accLnkedCustomers;
	}       
	
	public ArrayList<AccountInterestRate> getAccInterestRates() {
		return accInterestRates;
	}
	
	public HashMap<String, LinkedList<AccountDetailDynamicDisplayFieldBean>> getDynamicFieldGroup() {
		return dynamicFieldGroup;
	}
	
	/**
	 * @param dynamicFieldGroup the dynamicFieldGroup to set
	 */
	public void setDynamicFieldGroup(
			HashMap<String, LinkedList<AccountDetailDynamicDisplayFieldBean>> dynamicFieldGroup) {
		this.dynamicFieldGroup = dynamicFieldGroup;
	}

	public SortedSet<AccountLinkButtonIndicators> getLinkButtonIndicators() {
		return linkButtonIndicators;
	}

	public void setLinkButtonIndicators(
			SortedSet<AccountLinkButtonIndicators> linkButtonIndicators) {
		this.linkButtonIndicators = linkButtonIndicators;
	}
	
	/**
	 * Possibly a lazy way of doing a shallow clone. Gets all the declared 
	 * fields for the account class and copies their values to a new clone. 
	 * Does save on code mind, seeing how many fields there are on this object. 
	 */
	public Account clone() throws CloneNotSupportedException {
		Account clonedAccount = new Account();
		Field[] existingFields = this.getClass().getDeclaredFields(),
			clonedFields = clonedAccount.getClass().getDeclaredFields();
		for(int i = 0; i < existingFields.length; i++){
			try{
				if((clonedFields[i].getModifiers() & Modifier.FINAL) != Modifier.FINAL){
					clonedFields[i].set(clonedAccount, existingFields[i].get(this));
				}
			} catch (IllegalAccessException e){
	        	logger.error(e.getMessage(), e);
				// If we've checked that its accessible and we still get an access exception
				// then frankly I'm confused
				throw new CloneNotSupportedException(
						"Can not clone account due to access violation on a field.");
			}
		}
		
		return clonedAccount;
	}
}

