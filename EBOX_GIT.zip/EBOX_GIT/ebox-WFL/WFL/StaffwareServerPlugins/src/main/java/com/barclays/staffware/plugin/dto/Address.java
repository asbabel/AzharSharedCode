
package com.barclays.staffware.plugin.dto;

import java.io.Serializable;

/**
 * @author TaylorA3
 *
 *	Class to represent an individual address.
 * WP465
 */
/*
 * DATE     REFERENCE  WHO     VERSION  COMMENTS
 * -------  ---------  ---     -------  -----------------------------------------
 * ???????  PAT03232   TAYLORA 1a       Created
 * 22Feb11  Release002 GoodlifW        Fix error when AddressLine1 is null.
 * 29Mar12	OLE Defect PGJ	   2		Added extra fields for Statement data.
 * 28Jan16  EBXWORKLOG-24  Anup 3      Fixed the worklog item.
 * 
 */
public class Address implements Comparable<Address>, Serializable {
	
	private String addressLine1 = "";
	private String addressLine2 = "";
	private String addressLine3 = "";
	private String addressContactName = "";
	private String addressPurpose = "";
	private String addressCustomerNumber = "";
	private String addressCustomerContactNumber = "";
	private String addressCustomerSequenceNumber = "";
	private String addressCustomerContactName = "";
	private String stmtPurpose = "";
	private String minstmPurpose = "";
	private String frmsetPurpose = "";
	private String retainAtBranch = "";
	private String statementCopies = "";
	
	/**
	 * Appease the serialisation gods
	 */
	private static final long serialVersionUID = 1054999455261038479L;
	
	@Override
	public int compareTo(Address o) {
		// We don't really care what order Addresses are in, but as a TreeSet has 
		// been used we need to be able to compare them. Deal with nulls.
		if (this.getAddressLine1() == null) {
			return -1;
		}
		// Added code to identify equal address object on the sequence number + addressline1 basis
		
		String address1 =this.getAddressCustomerSequenceNumber()+ this.getAddressLine1() ;
		String address2 = o.getAddressCustomerSequenceNumber()+o.getAddressLine1();
		
		return address1.compareTo(address2);
	}

	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @param addressLine1 the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @param addressLine2 the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return addressLine3;
	}

	/**
	 * @param addressLine3 the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	/**
	 * @return the addressContactName
	 */
	public String getAddressContactName() {
		return addressContactName;
	}

	/**
	 * @param addressContactName the addressContactName to set
	 */
	public void setAddressContactName(String addressContactName) {
		this.addressContactName = addressContactName;
	}

	/**
	 * @return the addressPurpose
	 */
	public String getAddressPurpose() {
		return addressPurpose;
	}

	/**
	 * @param addressPurpose the addressPurpose to set
	 */
	public void setAddressPurpose(String addressPurpose) {
		this.addressPurpose = addressPurpose;
	}

	/**
	 * @return the addressCustomerNumber
	 */
	public String getAddressCustomerNumber() {
		return addressCustomerNumber;
	}

	/**
	 * @param addressCustomerNumber the addressCustomerNumber to set
	 */
	public void setAddressCustomerNumber(String addressCustomerNumber) {
		this.addressCustomerNumber = addressCustomerNumber;
	}

	/**
	 * @return the addressCustomerContactNumber
	 */
	public String getAddressCustomerContactNumber() {
		return addressCustomerContactNumber;
	}

	/**
	 * @param addressCustomerContactNumber the addressCustomerContactNumber to set
	 */
	public void setAddressCustomerContactNumber(String addressCustomerContactNumber) {
		this.addressCustomerContactNumber = addressCustomerContactNumber;
	}

	/**
	 * @return the addressCustomerSequenceNumber
	 */
	public String getAddressCustomerSequenceNumber() {
		return addressCustomerSequenceNumber;
	}

	/**
	 * @param addressCustomerSequenceNumber the addressCustomerSequenceNumber to set
	 */
	public void setAddressCustomerSequenceNumber(
			String addressCustomerSequenceNumber) {
		this.addressCustomerSequenceNumber = addressCustomerSequenceNumber;
	}

	/**
	 * @return the addressCustomerContactName
	 */
	public String getAddressCustomerContactName() {
		return addressCustomerContactName;
	}

	/**
	 * @param addressCustomerContactName the addressCustomerContactName to set
	 */
	public void setAddressCustomerContactName(String addressCustomerContactName) {
		this.addressCustomerContactName = addressCustomerContactName;
	}

	/**
	 * @return the stmtPurpose
	 */
	public String getStmtPurpose() {
		return stmtPurpose;
	}

	/**
	 * @param stmtPurpose the stmtPurpose to set
	 */
	public void setStmtPurpose(String stmtPurpose) {
		this.stmtPurpose = stmtPurpose;
	}

	/**
	 * @return the minstmPurpose
	 */
	public String getMinstmPurpose() {
		return minstmPurpose;
	}

	/**
	 * @param minstmPurpose the minstmPurpose to set
	 */
	public void setMinstmPurpose(String minstmPurpose) {
		this.minstmPurpose = minstmPurpose;
	}

	/**
	 * @return the frmsetPurpose
	 */
	public String getFrmsetPurpose() {
		return frmsetPurpose;
	}

	/**
	 * @param frmsetPurpose the frmsetPurpose to set
	 */
	public void setFrmsetPurpose(String frmsetPurpose) {
		this.frmsetPurpose = frmsetPurpose;
	}

	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	/**
	 * @return whether to retain at branch.
	 */
	public String getRetainAtBranch() {
		return retainAtBranch;
	}
	
	/**
	 * @param retainAtBranch the retainAtBranch to set.
	 */
	public void setRetainAtBranch(String retainAtBranch) {
		this.retainAtBranch = retainAtBranch;
	}

	/**
	 * @return the number of statement copies.
	 */
	public String getStatementCopies() {
		return statementCopies;
	}
	
	/**
	 * @param statementCopies the number of statement copies to set.
	 */
	public void setStatementCopies(String statementCopies) {
		this.statementCopies = statementCopies;
	} 			 
}