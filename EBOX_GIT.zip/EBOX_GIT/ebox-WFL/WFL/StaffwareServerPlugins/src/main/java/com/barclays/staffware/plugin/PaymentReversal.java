package com.barclays.staffware.plugin;

import static com.barclays.staffware.plugin.reversal.Constants.ACTIVITYCODE;
import static com.barclays.staffware.plugin.reversal.Constants.BOX;
import static com.barclays.staffware.plugin.reversal.Constants.BRAINS;
import static com.barclays.staffware.plugin.reversal.Constants.CHARGEDESCRIPTION;
import static com.barclays.staffware.plugin.reversal.Constants.CHARGEPACKAGE;
import static com.barclays.staffware.plugin.reversal.Constants.CHARGETYPE;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYACCOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYACCOUNTENTRYTYPE;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYBANKCODE;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYBRANCH;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYCURRENCY;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYLOCALAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYNAME;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYNARRATIVE;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYREMINFO;
import static com.barclays.staffware.plugin.reversal.Constants.COUNTERPARTYTRXAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.ERRORCODE;
import static com.barclays.staffware.plugin.reversal.Constants.ERRORDESC;
import static com.barclays.staffware.plugin.reversal.Constants.ERRORMESSAGE;
import static com.barclays.staffware.plugin.reversal.Constants.GROUP_ID;
import static com.barclays.staffware.plugin.reversal.Constants.INTEGERTWO;
import static com.barclays.staffware.plugin.reversal.Constants.ITEM_NUMBER;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORACCOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORACCOUNTENTRYTYPE;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORBRANCH;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGEACCOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGEACCOUNTENTRYTYPE;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGEBRANCH;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGECURRENCY;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGELOCALAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGENARRATIVE;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGESUBTRANCODE;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGETRANCODE;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCHARGETRXAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORCURRENCY;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORLOCALAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORNAME;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORNARRATIVE;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGINATORTRXAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.ORIGREMINFO;
import static com.barclays.staffware.plugin.reversal.Constants.PROCESSED;
import static com.barclays.staffware.plugin.reversal.Constants.REV;
import static com.barclays.staffware.plugin.reversal.Constants.REVERSE_CHARGES_IND;
import static com.barclays.staffware.plugin.reversal.Constants.REVUTIL;
import static com.barclays.staffware.plugin.reversal.Constants.SOURCELOCATION;
import static com.barclays.staffware.plugin.reversal.Constants.STATUSCODE;
import static com.barclays.staffware.plugin.reversal.Constants.STRINGONE;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSEACCOUNTNUMBER;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSEBRANCHID;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGEACCOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGEACCOUNTENTRYTYPE;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGEBRANCH;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGECURRENCY;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGELOCALAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGENARRATIVE;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGESUBTRANCODE;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGETRANCODE;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECHARGETRXAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSECURRENCY;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSELOCALAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSENARATTIVE;
import static com.barclays.staffware.plugin.reversal.Constants.SUSPENSETRANSACTIONAMOUNT;
import static com.barclays.staffware.plugin.reversal.Constants.TERMINALNUMBER;
import static com.barclays.staffware.plugin.reversal.Constants.VALUEDATEIND;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.bean.Country;
import com.barclays.generic.transactions.Charge;
import com.barclays.generic.transactions.CounterpartyEntry;
import com.barclays.generic.transactions.DataAccess;
import com.barclays.generic.transactions.Entry;
import com.barclays.generic.transactions.Group;
import com.barclays.generic.transactions.OriginatorEntry;
import com.barclays.generic.transactions.Posting;
import com.barclays.generic.transactions.Transaction;
import com.barclays.middleware.brains.BrainsException;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.reversal.Constants;
import com.barclays.staffware.plugin.reversal.PaymentManagementHelper;
import com.barclays.staffware.plugin.reversal.PaymentOperationBean;
import com.barclays.staffware.plugin.reversal.PaymentReversalValidator;
import com.ibm.math.BigDecimal;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * This class is used for performing payment transactions for reversal payment
 * 
 * @author Anup Kulkarni
 */
/* 
 * DATE      REFERENCE   WHO         VERSION        COMMENTS
 * --------  ---------   ---         -------        ----------------------
 * 05/02/16  WP697       Anup        1.0            Created
 * 20/04/16  WP697       Anup        1.1            Added property configuration to reversalMessage property
 * 04/05/16  WP697       Anup        1.2            Code changes for INC0036391103.Modified Narrative logic as per design change
 * 17/01/17  WP715       LeyJ        -              Refactored data access to MWDB.
 * 10/02/17  WP711       PHH         1.3            Removed part of a if statement which did nothing and caused a NULL pointer error
 */
public class PaymentReversal implements ImmediateReleasePluginSDK {

    protected static final LoggerConnection logger = new LoggerConnection(PaymentReversal.class);
    private final String initializationFailed = Constants.initializationFailed(PaymentReversal.class.getName());


    @Override
    public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {

        try {
        	BrainsSocketConnectionFactory.getInstance().useSecure(properties);
            //DataSourceDirectory.getInstance().configure(properties);
            //LoggerConnection.configureWFL(properties.getProperty("reversalMessageLog"));
            // load db driver (unsure if necessary)
            //Class.forName(properties.getProperty("db_driver"));
            ClassPathResource resource = new ClassPathResource(properties.getProperty("reversalMessageLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());

            DataSourceDirectory.getInstance().basePluginDS();
            logger.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
    }

    @Override
    @SuppressWarnings("rawtypes")
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {

        PaymentOperationBean paymentBean = new PaymentOperationBean();
        PaymentReversalValidator paymentValidator = new PaymentReversalValidator();
        HashMap<String, String> returnValues = new HashMap<>();
        returnValues.put(STATUSCODE, "0");
        returnValues.put(ERRORDESC, "");
        // Populate PaymenOperationBean from input list
        populateOperationBean(paymentBean, inputFields);

        try {
            paymentValidator.validate(paymentBean, returnValues);

            if (StringUtils.isEmpty(returnValues.get(ERRORCODE))) {
                reversePaymentAndCharges(paymentBean);

            } else {
                returnValues.put(STATUSCODE, STRINGONE);
            }
        } catch (Exception e) {
            returnValues.put(STATUSCODE, STRINGONE);
            returnValues.put(ERRORDESC, e.getMessage());
            logger.error("Exception: ", e);

        }
        return returnValues;
    }

    /**
     * This method will make reversal payment processing
     * 
     * @param paymentBean
     * @throws Exception
     */
    public static void reversePaymentAndCharges(PaymentOperationBean paymentBean) throws Exception { // NOSONAR

        DataAccess data = new DataAccess();
        // Set the database for DataAccess
		SQLConnection con = null;
		try {
			con = MWDBAccess.getDatabaseConnection();
			data.setDatabase(con);

			Integer groupId = PaymentManagementHelper.getNextGroupId(data);

			Country country = new Country(paymentBean.getCountry(), paymentBean.isOffshoreInd());

			Group g = new Group(country, paymentBean.getReversalTransactionId(), paymentBean.getReversalMsgId(), null,
					paymentBean.getSourceAppUserId(), BOX, groupId.intValue());
			g.setLastChangedBy(REVUTIL);
			g.setStatus(INTEGERTWO);
			g.setStatusUpdate(INTEGERTWO);
			g.setSourceReference(paymentBean.getReversalTransactionId());

			Transaction tx = createTransaction(paymentBean, country);
			// Make Originator Entry to transaction
			createOrignatorEntry(tx, paymentBean);

			// Make Counterparty Entry to transaction
			createCounterPartyEntry(tx, paymentBean);

			// Add transaction to the group
			g.addTransaction(tx);

			// Add charges to the transaction if ReverseChargeInd is true
			if (paymentBean.isReverseChargesInd()) {
				addTransactionCharges(tx, paymentBean);
			}
			// Save details to MWDB and make ENT-PM call
			saveReversalDetails(data, con, g, paymentBean);
		} finally {
			if(con != null) {
				con.close();
			}
		}
    }

    /**
     * This method will add the transactions charges to reversal transaction
     * 
     * @param tx
     * @param paymentBean
     * @throws SQLException
     */
    private static void addTransactionCharges(Transaction tx, PaymentOperationBean paymentBean) throws SQLException {

        List<HashMap<String, Object>> resultListPACCharges = paymentBean.getResultListPACCharges();

        for (HashMap<String, Object> chargeMap : resultListPACCharges) {
            String desc = (String) chargeMap.get(CHARGEDESCRIPTION);

            Charge c = new Charge(desc);

            c.setActivityCode((String) chargeMap.get(ACTIVITYCODE));
            c.setType(REV + " " + (String) chargeMap.get(CHARGETYPE));
            c.setPackage((String) chargeMap.get(CHARGEPACKAGE));

            Entry o = c.getOriginatorEntry();
            o.setDebit(false);
            o.setTransactionCode((String) chargeMap.get(ORIGINATORCHARGETRANCODE));
            o.setSubTransactionCode((String) chargeMap.get(ORIGINATORCHARGESUBTRANCODE));

            o.setBranchNumber((Short) chargeMap.get(ORIGINATORCHARGEBRANCH));
            o.setAccountNumber((String) chargeMap.get(ORIGINATORCHARGEACCOUNT));
            o.setCurrency((String) chargeMap.get(ORIGINATORCHARGECURRENCY));

            String trxAmount = ((java.math.BigDecimal) chargeMap.get(ORIGINATORCHARGETRXAMOUNT)).toPlainString();
            o.setTransactionAmount(new BigDecimal(trxAmount));

            String localAmount = ((java.math.BigDecimal) chargeMap.get(ORIGINATORCHARGELOCALAMOUNT)).toPlainString();
            o.setLocalAmount(new BigDecimal(localAmount));

            o.setNarrative((String) chargeMap.get(ORIGINATORCHARGENARRATIVE));
            o.setAccountEntryType((Short) chargeMap.get(ORIGINATORCHARGEACCOUNTENTRYTYPE));

            Entry s = c.getSuspenseEntry();

            s.setDebit(true);
            s.setTransactionCode((String) chargeMap.get(SUSPENSECHARGETRANCODE));
            s.setSubTransactionCode((String) chargeMap.get(SUSPENSECHARGESUBTRANCODE));
            s.setBranchNumber((Short) chargeMap.get(SUSPENSECHARGEBRANCH));
            s.setAccountNumber(String.valueOf((Integer) chargeMap.get(SUSPENSECHARGEACCOUNT)));
            s.setCurrency((String) chargeMap.get(SUSPENSECHARGECURRENCY));

            String susTrxAmount = ((java.math.BigDecimal) chargeMap.get(SUSPENSECHARGETRXAMOUNT)).toPlainString();
            s.setTransactionAmount(new BigDecimal(susTrxAmount));

            String susLocalAmt = ((java.math.BigDecimal) chargeMap.get(SUSPENSECHARGELOCALAMOUNT)).toPlainString();
            s.setLocalAmount(new BigDecimal(susLocalAmt));

            s.setNarrative((String) chargeMap.get(SUSPENSECHARGENARRATIVE));
            s.setAccountEntryType((Short) chargeMap.get(SUSPENSECHARGEACCOUNTENTRYTYPE));

            tx.addCharge(c);
        }

    }

    /**
     * Make originator Entry for reversal transaction
     * 
     * @param tx
     * @param paymentBean
     */
    private static void createOrignatorEntry(Transaction tx, PaymentOperationBean paymentBean) {

        tx.makeOriginatorEntry();
        OriginatorEntry o = tx.getOriginatorEntry();
        List<HashMap<String, Object>> resultListPAC = paymentBean.getResultListPAC();

        // Although this is originator entry set debit to false as in reversal
        // we want this to be treated as credit entry

        o.setDebit(false);
        o.setTransactionCode(paymentBean.getOriginatorEntry().getTransCode());
        o.setSubTransactionCode(paymentBean.getOriginatorEntry().getSubTransCode());
        o.setBranchNumber((Short) resultListPAC.get(0).get(ORIGINATORBRANCH));
        o.setAccountNumber((String) resultListPAC.get(0).get(ORIGINATORACCOUNT));
        o.setCurrency((String) resultListPAC.get(0).get(ORIGINATORCURRENCY));
        String trxAmount = ((java.math.BigDecimal) resultListPAC.get(0).get(ORIGINATORTRXAMOUNT)).toPlainString();
        o.setTransactionAmount(new BigDecimal(trxAmount));
        String localAmount = ((java.math.BigDecimal) resultListPAC.get(0).get(ORIGINATORLOCALAMOUNT)).toPlainString();
        o.setLocalAmount(new BigDecimal(localAmount));
        // Add SUSPENSENARATTIVE as Narrative
        o.setNarrative((String) resultListPAC.get(0).get(SUSPENSENARATTIVE));
        o.setAccountEntryType((Short) resultListPAC.get(0).get(ORIGINATORACCOUNTENTRYTYPE));
        o.setName((String) resultListPAC.get(0).get(ORIGINATORNAME));
        // Add errorMessage as RemInfomation
        o.setRemittanceInformation((String) resultListPAC.get(0).get(ERRORMESSAGE));
    }

    /**
     * Make counterparty entry for reversal transaction
     * 
     * @param tx
     * @param paymentBean
     */
    private static void createCounterPartyEntry(Transaction tx, PaymentOperationBean paymentBean) {
        tx.makeCounterpartyEntry();
        CounterpartyEntry c = tx.getCounterpartyEntry();
        List<HashMap<String, Object>> resultListPAC = paymentBean.getResultListPAC();
        // Although this is counterparty entry set debit to true as in reversal
        // we want this to be treated as originator entry
        c.setDebit(true);
        c.setTransactionCode(paymentBean.getCounterPartyEntry().getTransCode());
        c.setSubTransactionCode(paymentBean.getCounterPartyEntry().getSubTransCode());

        if (resultListPAC.get(0).get(SUSPENSEACCOUNTNUMBER) != null
                && resultListPAC.get(0).get(SUSPENSEBRANCHID) != null) {
            c.setBranchNumber((Short) resultListPAC.get(0).get(SUSPENSEBRANCHID));
            c.setAccountNumber(String.valueOf(resultListPAC.get(0).get(SUSPENSEACCOUNTNUMBER)));
            c.setCurrency((String) resultListPAC.get(0).get(SUSPENSECURRENCY));
            String susTrxAmount =
                    ((java.math.BigDecimal) resultListPAC.get(0).get(SUSPENSETRANSACTIONAMOUNT)).toPlainString();
            c.setTransactionAmount(new BigDecimal(susTrxAmount));
            String susLocalAmount =
                    ((java.math.BigDecimal) resultListPAC.get(0).get(SUSPENSELOCALAMOUNT)).toPlainString();
            c.setLocalAmount(new BigDecimal(susLocalAmount));
            // Add Originator Narrative as Counter Party narrative
            c.setNarrative((String) resultListPAC.get(0).get(ORIGINATORNARRATIVE));
            c.setAccountEntryType(new Short((short) (0)));
            if (!StringUtils.isEmpty(paymentBean.getSuspenseBankCode())) {
                c.setBankCode(Integer.parseInt(paymentBean.getSuspenseBankCode()));
            }
            c.setName(null);
            // Add Originator RemInfo as counter party RemInfo
            c.setRemittanceInformation((String) resultListPAC.get(0).get(ORIGREMINFO));
            c.setRegionCode(null);
            c.setSerialNumber(null);
        } else {
            c.setBranchNumber((Short) resultListPAC.get(0).get(COUNTERPARTYBRANCH));
            c.setAccountNumber((String) resultListPAC.get(0).get(COUNTERPARTYACCOUNT));
            c.setCurrency((String) resultListPAC.get(0).get(COUNTERPARTYCURRENCY));
            String trxAmount = ((java.math.BigDecimal) resultListPAC.get(0).get(COUNTERPARTYTRXAMOUNT)).toPlainString();
            c.setTransactionAmount(new BigDecimal(trxAmount));
            String localAmount =
                    ((java.math.BigDecimal) resultListPAC.get(0).get(COUNTERPARTYLOCALAMOUNT)).toPlainString();
            c.setLocalAmount(new BigDecimal(localAmount));
            c.setNarrative((String) resultListPAC.get(0).get(COUNTERPARTYNARRATIVE));
            c.setAccountEntryType((Short) resultListPAC.get(0).get(COUNTERPARTYACCOUNTENTRYTYPE));
            c.setBankCode((Integer) resultListPAC.get(0).get(COUNTERPARTYBANKCODE));
            c.setName((String) resultListPAC.get(0).get(COUNTERPARTYNAME));
            c.setRemittanceInformation((String) resultListPAC.get(0).get(COUNTERPARTYREMINFO));
        }

    }

    /**
     * Create the transaction for Reversal payment
     * 
     * @param paymentBean
     * @param country
     * @return
     * @throws Exception
     */
    private static Transaction createTransaction(PaymentOperationBean paymentBean, Country country) throws Exception { // NOSONAR
        Transaction tx = new Transaction();

        List<HashMap<String, Object>> resultListPAC = paymentBean.getResultListPAC();
        tx.setStatus(PROCESSED);
        tx.setLastChangedBy(REVUTIL);
        tx.setPaymentType(paymentBean.getReversalPaymentType());

        Date postDate = Posting.getBusinessDate(country);
        tx.setPostDate(postDate);

        String valueDateInd = (String) resultListPAC.get(0).get(VALUEDATEIND);
        if (valueDateInd != null && valueDateInd.length() > 0) {
            tx.setValueDateIndicator(valueDateInd.charAt(0));
        }
        tx.setTerminalNumber(new Integer((Short)resultListPAC.get(0).get(TERMINALNUMBER)));
        tx.setSourceLocation(new Integer((Short) resultListPAC.get(0).get(SOURCELOCATION)));
        tx.setProcessingEngine(BRAINS);

        tx.setBrainsTransactionNumber(0);

        return tx;
    }

    /**
     * This method will save reversal request in MWDB and revert the charges
     * 
     * @param data
     * @param con
     * @param g
     * @param paymentBean
     * @return
     * @throws SQLException
     * @throws Error
     * @throws Exception
     */
    private static boolean saveReversalDetails(
            DataAccess data,
            SQLConnection con,
            Group g,
            PaymentOperationBean paymentBean) throws SQLException, Error, Exception { // NOSONAR
        logger.info("Saving reversal transaction to MW DB ");
        boolean success = true;
        boolean brainsException = false;
        String message = "";
        con.setAutoCommit(false);
        try {
            data.save(g);
            setBrainsData(g, data);
            logger.info("Saving reversal transaction to Brains ");
            brainsException = postTransactionToBrains(paymentBean, g, con);
            data.save(g);
            con.commit();
        } catch (Throwable e) { // NOSONAR
            try {
                con.rollback();
            } catch (Exception ignored) {
                logger.debug("Exception ignored.." + ignored);
            } catch (Error err) { // NOSONAR
                throw (Error) err;
            }
            throw e;
        }
        finally {
        	if(con != null) {
        		con.close();
        	}
        }
        if (brainsException) {
            throw new BrainsException("", message);

        }
        return success;
    }

    /**
     * This method will set brains data
     * 
     * @param payment
     * @param data
     * @throws Exception
     */
    private static void setBrainsData(Group payment, DataAccess data) throws Exception {// NOSONAR
        Transaction tx = payment.getTransactions().get(0);
        Country country = payment.getCountry();
        int brainsTranNumber = data.allocateBrainsTransactionNumber(country, tx.getPostDate());

        tx.setBrainsTransactionNumber(brainsTranNumber);
    }

    /**
     * This method will set the mandatory field to PaymentOperationBean
     * 
     * @param paymentBean
     * @param inputFields
     */
    @SuppressWarnings("rawtypes")
    private void populateOperationBean(PaymentOperationBean paymentBean, List inputFields) {

        if (!StringUtils.isEmpty(getFieldValue(inputFields, GROUP_ID))) {
            paymentBean.setGroupId(Integer.parseInt(getFieldValue(inputFields, GROUP_ID)));

        }
        if (!StringUtils.isEmpty(getFieldValue(inputFields, ITEM_NUMBER))) {
            paymentBean.setItemNumber(Integer.parseInt(getFieldValue(inputFields, ITEM_NUMBER)));
        }

        if (StringUtils.isEmpty(getFieldValue(inputFields, REVERSE_CHARGES_IND))) {
            paymentBean.setReverseChargesInd(true);
        } else {
            paymentBean.setReverseChargesInd(Boolean.valueOf(getFieldValue(inputFields, REVERSE_CHARGES_IND)));
        }
    }

    /**
     * Method gets the value of the named field from the given list
     * 
     * @param fields list of fields
     * @param key name of field of interest
     * @return value of given field
     */
    protected String getFieldValue(List<?> fields, String key) {
        for (Iterator<?> i = fields.iterator(); i.hasNext();) {
            Field field = (Field) i.next();
            if (key.equalsIgnoreCase(field.getName())) {
                String value = field.getValue();
                return value == null ? "" : value.trim();
            }
        }
        return "";
    }

    /**
     * This method will make ENT-PM token call to Post Brains Entries and make
     * entry to ReversalCrossReference table
     * 
     * @param paymentBean
     * @param g
     * @param con
     * @return
     * @throws SQLException
     */
    private static boolean postTransactionToBrains(PaymentOperationBean paymentBean, Group g, SQLConnection con)
            throws Exception { // NOSONAR

        boolean brainsException = false;
        boolean success = true;
        String message = "";
        try {
            Posting.post(g);
        } catch (BrainsException be) {
            success = false;
            logger.error("Failed to post transaction", be);
            message = be.getOriginalMessage() != null ? be.getOriginalMessage() : be.getMessage();
            brainsException = true;

            for (Object item : g.getTransactions()) {
                Transaction tran = (Transaction) item;
                tran.setError(-1, message);
            }
        } catch (Exception e) {
            success = false;
            logger.error("Failed to post transaction", e);
            message = e.getMessage();

            for (Object item : g.getTransactions()) {
                Transaction tran = (Transaction) item;
                tran.setError(-1, message);
            }
        }
        if (success) {
            // Make entry in ReversalXReference table if ENT-PM is successful//
            PaymentManagementHelper.makeReversalXReferenceEntry(paymentBean.getGroupId(), g.getGroupId(),
                    paymentBean.getItemNumber(), 1, con);
        }
        return brainsException;
    }
}
