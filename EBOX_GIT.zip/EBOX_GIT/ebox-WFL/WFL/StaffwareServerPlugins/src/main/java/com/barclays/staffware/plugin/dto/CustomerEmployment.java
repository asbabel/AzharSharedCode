package com.barclays.staffware.plugin.dto;

import com.ibm.math.BigDecimal;

import java.util.Date;

/**
 * Represents a Customer Employment record in BRAINS
 * @author HUNTI
 */
/*
 * DATE     REFERENCE   WHO   	VERSION  COMMENTS
 * -------  ---------   ---   	-------  ---------------------------------------------------
 * 24OCT06  -           ILH   	1.0      Created
 * 12JUN07	PAT01952	ILH		1a		Added contractExpiryDate
 * 21APR08	PAT02474    MANGIPV	1a		Added EmployeeNumber	
 */
public class CustomerEmployment {
    
	private int sequenceNumber;
    private int customerNumber;
    private String employmentStatus; 
    private Date employmentStatusDate;
    private String employmentType;
    private String employer; 
    private String addressFirstLine; 
    private String poBoxDetails; 
    private String town;
    private String district; 
    private String country;
    private boolean offshore;
    private String postcode; 
    private String natureOfBusiness; 
    private String jobTitle; 
    private String empContactName; 
    private String empContactNumber; 
    private int lengthYears; 
    private int lengthMonths; 
    private BigDecimal grossIncome; 
    private BigDecimal otherIncome; 
    private String grossCur;
    private String otherCur;
    private String sourceOfFunds;
    private Date contractExpiryDate;
    private String employeeNumber;
    private String employerEmail;
    private String designation;
    
    /**
     * Getter for property sequenceNumber.
     * @return Value of property sequenceNumber.
     */
    public int getSequenceNumber() {
        return sequenceNumber;
    }
    
    /**
     * Setter for property sequenceNumber.
     * @param sequenceNumber New value of property sequenceNumber.
     */
    public void setSequenceNumber(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }
    
    /**
     * Getter for property customerNumber.
     * @return Value of property customerNumber.
     */
    public int getCustomerNumber() {
        return customerNumber;
    }
    
    /**
     * Setter for property customerNumber.
     * @param customerNumber New value of property customerNumber.
     */
    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }
    
    /**
     * Getter for property employmentStatus.
     * @return Value of property employmentStatus.
     */
    public String getEmploymentStatus() {
        return employmentStatus;
    }

    /**
     * Setter for property employmentStatus.
     * @param employmentStatus New value of property employmentStatus.
     */
    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    /**
     * Getter for property employmentStatusDate.
     * @return Value of property employmentStatusDate.
     */
    public Date getEmploymentStatusDate() {
        return employmentStatusDate;
    }

    /**
     * Setter for property employmentStatusDate.
     * @param employmentStatusDate New value of property employmentStatusDate.
     */
    public void setEmploymentStatusDate(Date employmentStatusDate) {
        this.employmentStatusDate = employmentStatusDate;
    }

    /**
     * Getter for property employmentType.
     * @return Value of property employmentType.
     */
    public String getEmploymentType() {
        return employmentType;
    }

    /**
     * Setter for property employmentType.
     * @param employmentType New value of property employmentType.
     */
    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    /**
     * Getter for property employer.
     * @return Value of property employer.
     */
    public String getEmployer() {
        return employer;
    }

    /**
     * Setter for property employer.
     * @param employer New value of property employer.
     */
    public void setEmployer(String employer) {
        this.employer = employer;
    }

    /**
     * Getter for property addressFirstLine.
     * @return Value of property addressFirstLine.
     */
    public String getAddressFirstLine() {
        return addressFirstLine;
    }

    /**
     * Setter for property addressFirstLine.
     * @param addressFirstLine New value of property addressFirstLine.
     */
    public void setAddressFirstLine(String addressFirstLine) {
        this.addressFirstLine = addressFirstLine;
    }

    /**
     * Getter for property poBoxDetails.
     * @return Value of property poBoxDetails.
     */
    public String getPoBoxDetails() {
        return poBoxDetails;
    }

    /**
     * Setter for property poBoxDetails.
     * @param poBoxDetails New value of property poBoxDetails.
     */
    public void setPoBoxDetails(String poBoxDetails) {
        this.poBoxDetails = poBoxDetails;
    }

    /**
     * Getter for property town.
     * @return Value of property town.
     */
    public String getTown() {
        return town;
    }

    /**
     * Setter for property town.
     * @param town New value of property town.
     */
    public void setTown(String town) {
        this.town = town;
    }

    /**
     * Getter for property district.
     * @return Value of property district.
     */
    public String getDistrict() {
        return district;
    }

    /**
     * Setter for property district.
     * @param district New value of property district.
     */
    public void setDistrict(String district) {
        this.district = district;
    }

    /**
     * Getter for property country.
     * @return Value of property country.
     */
    public String getCountry() {
        return country;
    }

    /**
     * Setter for property country.
     * @param country New value of property country.
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Getter for property postcode.
     * @return Value of property postcode.
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * Setter for property postcode.
     * @param postcode New value of property postcode.
     */
    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    /**
     * Getter for property natureOfBusiness.
     * @return Value of property natureOfBusiness.
     */
    public String getNatureOfBusiness() {
        return natureOfBusiness;
    }

    /**
     * Setter for property natureOfBusiness.
     * @param natureOfBusiness New value of property natureOfBusiness.
     */
    public void setNatureOfBusiness(String natureOfBusiness) {
        this.natureOfBusiness = natureOfBusiness;
    }

    /**
     * Getter for property jobTitle.
     * @return Value of property jobTitle.
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * Setter for property jobTitle.
     * @param jobTitle New value of property jobTitle.
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    /**
     * Getter for property empContactName.
     * @return Value of property empContactName.
     */
    public String getEmpContactName() {
        return empContactName;
    }

    /**
     * Setter for property empContactName.
     * @param empContactName New value of property empContactName.
     */
    public void setEmpContactName(String empContactName) {
        this.empContactName = empContactName;
    }

    /**
     * Getter for property empContactNumber.
     * @return Value of property empContactNumber.
     */
    public String getEmpContactNumber() {
        return empContactNumber;
    }

    /**
     * Setter for property empContactNumber.
     * @param empContactNumber New value of property empContactNumber.
     */
    public void setEmpContactNumber(String empContactNumber) {
        this.empContactNumber = empContactNumber;
    }

    /**
     * Getter for property lengthYears.
     * @return Value of property lengthYears.
     */
    public int getLengthYears() {
        return lengthYears;
    }

    /**
     * Setter for property lengthYears.
     * @param lengthYears New value of property lengthYears.
     */
    public void setLengthYears(int lengthYears) {
        this.lengthYears = lengthYears;
    }

    /**
     * Getter for property lengthMonths.
     * @return Value of property lengthMonths.
     */
    public int getLengthMonths() {
        return lengthMonths;
    }

    /**
     * Setter for property lengthMonths.
     * @param lengthMonths New value of property lengthMonths.
     */
    public void setLengthMonths(int lengthMonths) {
        this.lengthMonths = lengthMonths;
    }

    /**
     * Getter for property grossIncome.
     * @return Value of property grossIncome.
     */
    public BigDecimal getGrossIncome() {
        return grossIncome;
    }

    /**
     * Setter for property grossIncome.
     * @param grossIncome New value of property grossIncome.
     */
    public void setGrossIncome(BigDecimal grossIncome) {
        this.grossIncome = grossIncome;
    }

    /**
     * Getter for property otherIncome.
     * @return Value of property otherIncome.
     */
    public BigDecimal getOtherIncome() {
        return otherIncome;
    }

    /**
     * Setter for property otherIncome.
     * @param otherIncome New value of property otherIncome.
     */
    public void setOtherIncome(BigDecimal otherIncome) {
        this.otherIncome = otherIncome;
    }

    /**
     * Getter for property grossCur.
     * @return Value of property grossCur.
     */
    public String getGrossCur() {
        return grossCur;
    }

    /**
     * Setter for property grossCur.
     * @param grossCur New value of property grossCur.
     */
    public void setGrossCur(String grossCur) {
        this.grossCur = grossCur;
    }

    /**
     * Getter for property otherCur.
     * @return Value of property otherCur.
     */
    public String getOtherCur() {
        return otherCur;
    }

    /**
     * Setter for property otherCur.
     * @param otherCur New value of property otherCur.
     */
    public void setOtherCur(String otherCur) {
        this.otherCur = otherCur;
    }

	/**
	 * @return the offshore
	 */
	public boolean isOffshore() {
		return offshore;
	}

	/**
	 * @param offshore the offshore to set
	 */
	public void setOffshore(boolean offshore) {
		this.offshore = offshore;
	}
	
	public boolean isVerified() {
		return "CURRNT".equals(getEmploymentStatus());
	}

	/**
	 * @return the sourceOfFunds
	 */
	public String getSourceOfFunds() {
		return sourceOfFunds;
	}

	/**
	 * @param sourceOfFunds the sourceOfFunds to set
	 */
	public void setSourceOfFunds(String sourceOfFunds) {
		this.sourceOfFunds = sourceOfFunds;
	}

	/**
	 * @return the contractExpiryDate
	 */
	public Date getContractExpiryDate() {
		return contractExpiryDate;
	}

	/**
	 * @param contractExpiryDate the contractExpiryDate to set
	 */
	public void setContractExpiryDate(Date contractExpiryDate) {
		this.contractExpiryDate = contractExpiryDate;
	}

	
	 /**
     * Getter for property employeeNumber.
     * @return Value of property employeeNumber.
     */
	
	public String getEmployeeNumber() {
		return employeeNumber;
	}
	/**
	 * @param employeeNumber the employeeNumber to set
	 */
	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployerEmail() {
		return employerEmail;
	}

	public void setEmployerEmail(String employerEmail) {
		this.employerEmail = employerEmail;
	}

	 /**
     * Getter for property designation.
     * @return Value of property designation.
     */
	public String getDesignation() {
		return designation;
	}
	
	
	 /**
     * Setter for property designation.
     * @param designation of property designation.
     */
	public void setDesignation(String designation) {
		this.designation = designation;
	}
}
