

package com.barclays.staffware.plugin.dto;


/**
 * holds input params for exchange rate enquiry 
 */
/*
 * DATE     REFERENCE   WHO   VERSION  COMMENTS
 * -------  ---------   ---   -------  ---------------------------------------------------
 * 28Nov05  -           EARLB 1.0a     Created
 * 
 */
public class CustomerEmploymentAddResponse {
    
     private int sequenceNumber;
    
     /**
      * Getter for property sequenceNumber.
      * @return Value of property sequenceNumber.
      */
     public int getSequenceNumber() {
         return sequenceNumber;
     }     
    
     /**
      * Setter for property sequenceNumber.
      * @param sequenceNumber New value of property sequenceNumber.
      */
     public void setSequenceNumber(int sequenceNumber) {
         this.sequenceNumber = sequenceNumber;
     }
     
}
