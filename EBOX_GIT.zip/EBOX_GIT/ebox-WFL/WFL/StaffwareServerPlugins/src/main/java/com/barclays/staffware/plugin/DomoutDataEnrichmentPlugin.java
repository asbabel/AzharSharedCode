package com.barclays.staffware.plugin;

import java.sql.CallableStatement;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.staffware.data.MWDBAccess;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

import static com.barclays.staffware.plugin.util.EnrichmentParams.*;

/**
 * iProcess EAI Java Plugin to enrich data required to run the DOMOUT workflow
 * 
 * @author ABMH709
 * 
 */
/*
 *  DATE   REFERENCE  WHO     VERSION COMMENTS 
 * ------- --------- -----    ------- --------
 * 27Jan16 WPSeft697 ABMH709   1a     Created 
 * 11Feb16 WPSEft697 ABMMCPF   1      Changed - OriginatorRemittanceInformation to 
 *                                         OriginatorNarrative
 * 27May16 SEFT # 44 Amit	   2	  Changed - buildStaffwareMap method for EBXWORKLOG-94
 * 									  which is incident # INC0036776981
 * 17Jan17 WP715     LeyJ      -      Refactored data access to MWDB.
 */
public class DomoutDataEnrichmentPlugin implements ImmediateReleasePluginSDK {

    private static final LoggerConnection log =
            new LoggerConnection(DomoutDataEnrichmentPlugin.class);

    /**
     * Will be passed the contents of eaijava properties file in the
     * root:/swserver/sw_africa/eaijava/ folder Will be called by staffware
     * before each execute (unless a caching option is selected in staffware)
     */
    @Override
    public void initialize(Properties properties)
            throws FatalPluginException,
            NonFatalPluginException {
        try {

           // DataSourceDirectory.getInstance().configure(properties);

            // load db driver (unsure if necessary)
           // Class.forName(properties.getProperty(DB_DRIVER));
         //   LoggerConnection.configureWFL(properties.getProperty("domOutLog"));
            ClassPathResource resource = new ClassPathResource(properties.getProperty("domOutLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());

            DataSourceDirectory.getInstance().basePluginDS();
            log.debug(this.getClass().toString() + "test log write!");

        } catch (Exception e) {

            log.error(ERR_INIT_1 + this.getClass().getName() + ERR_INIT_2
                    + e.getMessage(), e);

            // raise exception to calling code, all exceptions considered fatal at this time
            throw new FatalPluginException(ERR_INIT_1
                    + this.getClass().getName() + ERR_INIT_2 + e.getMessage());
        }

    }

    /**
     * Method staffware calls in eaijava step
     * 
     * @param arg0 , a string hardcoded in staffware
     * @param outputFields , a List of staffware Field objects which staffware
     * expects to be returned
     * @param inputFields , a List of staffware Field objects which staffware
     * provides (with values)
     * @return Map, the name value pairs returned to staffware. Should only
     * contain names of fields supplied in outputFields
     */
    @SuppressWarnings("rawtypes")
    @Override
    public Map execute(String arg0, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {

        return getStaffwareCaseValues(inputFields);
    }

    /**
     * Get payment values from the database and returns them as a map of staffware fields
     * 
     * @param inputFields A list of input fields in order to obtain values from the database
     * @return map of staffware fields
     * @throws Exception
     */
    @SuppressWarnings("rawtypes")
    private Map<String, Object> getStaffwareCaseValues(List inputFields)
            throws FatalPluginException {
        HashMap<String, Object> swParam = null;
        SortedMap<String, String> args = new TreeMap<>();

        CallableStatement cs = null;
        ResultSet results = null;

        try (SQLConnection db = MWDBAccess.getDatabaseConnection();) {
            for (int i = 0; i < inputFields.size(); i++) {
                Field f = (Field) inputFields.get(i);

                args.put(f.getName(), f.getValue());
            }

            cs = db.prepareCall(SP_GET_DOMOUT_DETAILS, args);
            results = db.executeQuery(cs, args);

            swParam = new HashMap<>();

            // Get the first row. If there are multiple charges, there will be multiple rows
            results.next();

            addMainPaymentDetails(results, swParam);

            addChargesAndRates(results, swParam);

            for (Map.Entry<String, Object> entry : swParam.entrySet()) {
                if (null == entry.getValue()) {
                    entry.setValue(StringUtils.EMPTY);
                }
            }
        } catch (SQLException e) {
            log.error(DB_ERR, e);
            throw new FatalPluginException(DB_ERR + e.getMessage());
        } catch (Exception ex) {
            log.error("Exception occurred enriching DOMOUT data", ex);
            throw new FatalPluginException(DB_ERR + ex.getMessage());
        } finally {
            if (results != null) {
                try {
                    results.close();
                } catch (SQLException e) {
                    log.error("Failed to close ResultSet", e);
                }
            }
            if (cs != null) {
                try {
                    cs.close();
                } catch (SQLException e) {
                    log.error("Failed to close CallableStatement", e);
                }
            }
        }

        return swParam;
    }

    /**
     * Adds the main fields for the outward payment
     * 
     * @param results
     * @param swParam
     * @throws SQLException
     */
    private void addMainPaymentDetails(
            ResultSet results,
            Map<String, Object> swParam) throws SQLException {
        swParam.put(SW_SENDERS_REF, results.getString(DB_SENDERS_REF));
        swParam.put(SW_OP_CODE, "CRED");
        swParam.put(SW_LOCATION_CODE, results.getString(DB_LOCATION_CODE));

        Date valueDate = results.getDate(DB_POST_DATE);
        java.util.Date utilDate = new java.util.Date();
        Date todayDate = new Date(utilDate.getTime());

        DateFormat sdf = new SimpleDateFormat("ddMMyy");
        if (null == valueDate || valueDate.before(todayDate)) {
            swParam.put(SW_VALUE_DATE, sdf.format(todayDate));
        } else {
            swParam.put(SW_VALUE_DATE, sdf.format(valueDate));
        }

        swParam.put(SW_SAME_DAY_VALUE, results.getString(DB_SAME_DAY_VALUE));
        swParam.put(SW_SETTLE_AMT, results.getString(DB_ORIG_LOCAL_AMT));
        swParam.put(SW_SETTLE_CUR, results.getString(DB_COUNTER_CUR));
        swParam.put(SW_INST_AMT, results.getString("CounterpartyTransactionAmount"));
        swParam.put(SW_INST_CUR, results.getString(DB_COUNTER_CUR));
        swParam.put(SW_MARKET_SEGMENT, results.getDouble(DB_MARKET_SEGMENT));
        String iban = results.getString(DB_IBAN_NUMBER);
        if (iban != null && iban.length() > 0) {
            swParam.put(SW_ORDERING_ACC, iban);
        } else {
            swParam.put(SW_ORDERING_ACC, results.getString(DB_ORIG_BRANCH_ID)
                    + results.getString(DB_ORIG_ACC_NUM));
        }
        swParam.put(SW_ORDERING_NAME, results.getString(DB_ORIG_NAME));
        swParam.put(SW_ORDERING_ADDR1, results.getString(DB_ORIG_ADDR1));
        swParam.put(SW_ORDERING_ADDR2, results.getString(DB_ORIG_ADDR2));
        swParam.put(SW_ORDERING_ADDR3, results.getString(DB_ORIG_ADDR3));
        swParam.put(SW_ACC_WITH, results.getString("SwiftCode"));
        swParam.put(SW_PREFERRED_INT,
                results.getString("PreferredIntermediary"));
        swParam.put(SW_BENEF_BANK, results.getString("CounterPartyBankCode"));
        swParam.put(SW_BENEF_ACC,
                results.getString("CounterpartyAccountNumber"));
        swParam.put(SW_BENEF_NAME, results.getString("CounterpartyName"));
        swParam.put(SW_BENEF_ADDR1, results.getString("CounterpartyAddress1"));
        swParam.put(SW_BENEF_ADDR2, results.getString("CounterpartyAddress2"));
        swParam.put(SW_BENEF_ADDR3, results.getString("CounterpartyAddress3"));

        String remittanceInfo = results.getString("RemittanceInformation");
        if (remittanceInfo != null) {
            swParam.put(SW_REM_INFO1,
                    StringUtils.substring(remittanceInfo, 0, 35));
            swParam.put(SW_REM_INFO2,
                    StringUtils.substring(remittanceInfo, 35, 70));
            swParam.put(SW_REM_INFO3,
                    StringUtils.substring(remittanceInfo, 70, 105));
            swParam.put(SW_REM_INFO4,
                    StringUtils.substring(remittanceInfo, 105));
        }
        swParam.put(SW_CHARGES, results.getString("ChargeOption"));
        swParam.put(SW_ML_CHECK, "Y");

        swParam.put(SW_ORIG_CUR, results.getString("OriginatorCurrency"));
        swParam.put(SW_ORIG_BRANCH, results.getDouble("OriginatorBranchId"));
        swParam.put(SW_ORIG_ACC, results.getDouble("OriginatorAccountNumber"));
        swParam.put(SW_ORIG_TRANS_AMT,
                results.getString("OriginatorTransactionAmount"));
        swParam.put(SW_ORIG_LOCAL_AMT,
                results.getString("OriginatorLocalAmount"));
        swParam.put(SW_ORIG_REM_INFO, results.getString("OriginatorNarrative"));
        swParam.put(SW_SUSP_CUR, results.getString("SuspenseCurrency"));
        swParam.put(SW_SUSP_TRANS_AMT,
                results.getString("SuspenseTransactionAmount"));
        swParam.put(SW_SUSP_LOCAL_AMT,
                results.getString("SuspenseTransactionAmount"));
        swParam.put(SW_COUN_LOCAL_AMT,
                results.getString("CounterpartyLocalAmount"));
        swParam.put(SW_BANK_NAME, results.getString("BankName"));
        swParam.put(SW_BANK_ADDR_1, results.getString("BankAddress1"));
        swParam.put(SW_BANK_ADDR_2, results.getString("BankAddress2"));
        swParam.put(SW_BANK_ADDR_3, results.getString("BankAddress1"));
        swParam.put(SW_DISPLAY_CODE, results.getString("CounterPartyBankCode"));
        swParam.put(SW_BIC_BENEFICIARY, ((Boolean) results.getBoolean(
                "BICIsBeneficiary")).booleanValue() ? "1" : "0");
        swParam.put(SW_SEND_TO_REC1, results.getString("BankToBank"));
    }

    /**
     * Add the fields for Charges and Rates
     * 
     * @param results
     * @param swParam
     * @throws SQLException
     */
    private void addChargesAndRates(
            ResultSet results,
            Map<String, Object> swParam) throws SQLException {
        String rateStatus = results.getString("RateStatus");

        if (rateStatus != null) {
            if (rateStatus.equals("INDICATIVE")
                    || results.getString("RateStatus").equals("INDICATIVE-DEAL")) {
                swParam.put("RATE_REQUIRED", "Yes");
            } else {
                swParam.put("RATE_REQUIRED", "No");
            }
            if (rateStatus.equals("INDICATIVE")
                    || results.getString("RateStatus").equals("INDICATIVE-DEAL")
                    || (results.getString("ChargeType") != null
                            && results.getString(
                                    "OriginatorChargeTransactionAmount") == null)) {
                swParam.put("CHARGE_REQUIRED", "Yes");
            } else {
                swParam.put("CHARGE_REQUIRED", "No");
            }
        }

        swParam.put("RATE_STATUS", results.getString("RateStatus"));
        swParam.put("ORIG_RATE_PKG",
                results.getString("OriginatorRatePackage"));
        swParam.put("COUN_RATE_PKG",
                results.getString("CounterpartyRatePackage"));
        swParam.put("EXCHANGE_ON", results.getString("ExchangeOn"));
        swParam.put("DEAL_ID", results.getString("DealId"));
        swParam.put("ORIG_RATE", results.getDouble("OriginatorMidRate"));
        swParam.put("COUN_RATE", results.getDouble("CounterpartyMidRate"));
        swParam.put("EXCHANGE_FORMAT", results.getString("ExchangeRateFormat"));
        swParam.put("CHARGE_PACKAGE", results.getString("ChargePackage"));
        swParam.put("ACTIVITY_CODE", results.getString("ActivityCode"));
        swParam.put("PRIORITY", results.getInt("Priority"));

        for (int i = 0; i < 9; i++) {
            swParam.put("CHG_DESC" + Integer.toString(i + 1),
                    results.getString("OriginatorChargeNarrative"));
            swParam.put("CHG_TYPE" + Integer.toString(i + 1),
                    results.getString("ChargeType"));
            swParam.put("CHG_AMT" + Integer.toString(i + 1),
                    results.getString("OriginatorChargeTransactionAmount"));
            swParam.put("CHG_CUR" + Integer.toString(i + 1),
                    results.getString("OriginatorChargeCurrency"));
            swParam.put("CHG_MAN" + Integer.toString(i + 1),
                    results.getString("ManualChargeInd"));
            if (!results.next()) {
                break;
            }
        }
    }

}
