package com.barclays.staffware.plugin.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ValidateSwift {

    /**
     * generic method to validate that a value is alphabetic
     * 
     * @param value
     * @return the original input string
     * @throws Exception if string is not alphabetic
     */

    private ValidateSwift() {
    }

    public static String validateAlphabetic(String value) throws Exception { // NOSONAR
        if (value != null && !value.isEmpty()) {
            if (!value.matches("[A-Z]+")) {
                throw new Exception(value + " - is not alphabetic");// NOSONAR
            }
        }
        return value;
    }

    /**
     * generic method to validate that a value is alpha-numeric with fixed
     * length
     * 
     * @param value
     * @param n the length of string (fixed)
     * @return the original input string
     * @throws Exception if string is not alpha-numeric or the correct length
     */
    public static String validateAlphabetic(String value, int n) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.length() != n) {
                throw new Exception(SwiftParams.incorrectFormat(value, n + "!a"));// NOSONAR
            }
        }
        return value = validateAlphabetic(value);
    }

    /**
     * generic method to validate that a value is alpha-numeric
     * 
     * @param value
     * @return the original input string
     * @throws Exception if string is not alpha-numeric
     */
    public static String validateAlphaNumeric(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (!value.matches("[A-Z0-9]+")) {
                throw new Exception(value + " - is not alpha-numeric");// NOSONAR
            }
        }
        return value;
    }

    /**
     * generic method to validate that a value is alpha-numeric with fixed
     * length
     * 
     * @param value
     * @param n the length of string (fixed)
     * @return the original input string
     * @throws Exception if string is not alpha-numeric or the correct length
     */
    public static String validateAlphaNumberic(String value, int n) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.length() != n) {
                throw new Exception(SwiftParams.incorrectFormat(value, n + "!c"));// NOSONAR
            }
        }
        return value = validateAlphaNumeric(value);
    }

    /**
     * generic method to validate that a value is numeric
     * 
     * @param value
     * @return the original input string
     * @throws Exception if string is not numberic
     */
    public static String validateNumeric(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (!value.matches("[0-9]+")) {
                throw new Exception(value + " - is not numberic");// NOSONAR
            }
        }
        return value;
    }

    /**
     * performs validation on tag value for Swift X characters - all letters
     * (upper and lower case), numbers, space, CrLf and / - ? : ( ) . , ' +
     * 
     * @param value tag value
     * @param n number of characters
     * @return original input string
     * @throws Exception if string is invalid
     */
    public static String validateSwiftXCharacters(String value, int n) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (!value.matches("[-A-Za-z0-9/:().,'+\\s\\?]{1," + n + "}")) {
                throw new Exception(SwiftParams.incorrectFormat(value, n + "x"));// NOSONAR
            }
        }
        return value;
    }

    /**
     * performs validation on D/C Mark, Date, Currency, Amount (1!a6!n3!a15d)
     * 
     * @param value
     * @return original input string
     * @throws Exception if string is invalid
     */
    public static String validateMarkDateCurrencyAmount(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.length() > 10) {
                char dcMark = value.charAt(0);
                if (dcMark == 'C' || dcMark == 'D') {
                    validateDateCurrencyAmount(value.substring(1));
                } else {
                    throw new Exception(value + " - incorrect D / C Mark");// NOSONAR
                }
            } else {
                throw new Exception(SwiftParams.incorrectFormat(value, "1!a6!n3!a15d"));// NOSONAR
            }
        }
        return value;
    }

    /**
     * performs validation on Date, Currency, and Amount fields (6!n3!a15d)
     * 
     * @param value
     * @return original tag value
     * @throws Exception if string is invalid
     */
    public static String validateDateCurrencyAmount(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty() && value.length() > 9) {
            if (value.length() > 9) {
                String date = value.substring(0, 6);
                String currency = value.substring(6, 9);
                String amount = value.substring(9);

                validateDateTime(date, "yyMMdd");
                validateCurrency(currency);
                validateAmount(amount);
            } else {
                throw new Exception(SwiftParams.incorrectFormat(value, "6!n3!a15d"));// NOSONAR
            }
        }
        return value;
    }

    /**
     * performs validation on currency and amount fields (3!a15d)
     * 
     * @param value
     * @return original tag value
     * @throws Exception if string is invalid
     */
    public static String validateCurrencyAmount(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String currency = value.substring(0, 3);
            String amount = value.substring(3);
            validateCurrency(currency);
            validateAmount(amount);
        }
        return value;
    }

    /**
     * performs validation on floor limit indicator (3!a[1!a]15d)
     * 
     * @param value
     * @return the original tag value
     * @throws Exception if string is invalid
     */
    public static String validateFloorLimitInd(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String currency = value.substring(0, 3);
            validateCurrency(currency);
            if (Character.isDigit(value.charAt(3))) {
                String amount = value.substring(3);
                validateAmount(amount);
            } else {
                char dcMark = value.charAt(3);
                validateAlphabetic(String.valueOf(dcMark));
                String amount = value.substring(4);
                validateAmount(amount);
            }
        }
        return value;
    }

    /**
     * performs validation on time indication fields (/8c/4!n1!x4!n)
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validateTimeIndication(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String[] field = value.split("/");
            if (field.length != 3 || !field[1].matches("[A-Z0-9]{1,8}") || field[2].length() != 9
                    || !field[2].matches("[0-1][0-9][0-5][0-9][-,+][0-1][0-9][0-5][0-9]")
                    || Integer.parseInt(field[2].substring(5, 7)) > 13
                    || Integer.parseInt(field[2].substring(2)) > 59) {

                String timeIndication = field[2].substring(0, 4);
                validateDateTime(timeIndication, "HHmm");
            } else {
                throw new Exception(SwiftParams.incorrectFormat(value, "/8c/4!n1!x4!n"));// NOSONAR
            }
        }
        return value;
    }

    public static String validateTag13D(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.length() == 15) {
                String date = value.substring(0, 6);
                String time = value.substring(6, 10);
                char sign = value.charAt(10);
                String offset = value.substring(11);

                validateDateTime(date, "yyMMdd");
                validateDateTime(time, "HHmm");
                if (sign != '+' && sign != '-') {
                    throw new Exception(SwiftParams.incorrectFormat(value, "6!n4!n1!x4!n"));// NOSONAR
                }
                if (!offset.matches("[0-1][0-9][0-5][0-9]") || Integer.parseInt(offset.substring(0, 2)) > 13
                        || Integer.parseInt(offset.substring(2)) > 59) {
                    throw new Exception(offset + " - HH must be in the range of 00 through 13, "
                            + "MM must be in the range of 00 through 59");// NOSONAR
                }
            } else {
                throw new Exception(SwiftParams.incorrectFormat(value, "6!n4!n1!x4!n"));// NOSONAR
            }
        }
        return value;
    }

    public static String validateNumberCurrencyAmount(String value) throws Exception {// NOSONAR
        String number = "";
        if (value != null && !value.isEmpty()) {
            int currencyStart = 5;
            for (int i = 0; i < value.length(); i++) {
                if (Character.isDigit(value.charAt(i))) {
                    number += value.charAt(i);
                } else {
                    currencyStart = i;
                    break;
                }
            }
            int currencyEnd = currencyStart + 3;
            String currency = value.substring(currencyStart, currencyEnd);
            String amount = value.substring(currencyEnd);
            if (number.length() < 6) {
                validateNumeric(number);
            } else {
                throw new Exception(SwiftParams.incorrectFormat(value, "5n3!a15d"));// NOSONAR
            }
            validateCurrency(currency);
            validateAmount(amount);
        }
        return value;
    }

    /**
     * performs validation on id bic fields ([/1!a][/34x]\n4!a2!a2!c[3!c])
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validateIdBIC(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.contains("\r\n")) {
                // both id and bic are present
                String[] field = value.split("\r\n");
                validateID(field[0]);
                validateBIC(field[1]);
            } else {
                // only bic is present
                validateBIC(value);
            }
        }
        return value;
    }

    /**
     * performs validation on account bic fields ([/34x]\n4!a2!a2!c[3!c])
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validateAccountBIC(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.contains("\r\n")) {
                // both account and bic are present
                String[] field = value.split("\r\n");
                validateAccount(field[0]);
                validateBIC(field[1]);
            } else {
                // only bic is present
                validateBIC(value);
            }
        }
        return value;
    }

    /**
     * performs validation on id location fields ([/1!a][/34x]\n[35x])
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validateIdLocation(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.contains("\r\n")) {
                // both id and location are present
                String[] field = value.split("\r\n");
                validateID(field[0]);
                validateSwiftXCharacters(field[1], 35);
            } else {
                try {
                    validateID(value);
                } catch (Exception e) {// NOSONAR
                    validateSwiftXCharacters(value, 35);
                }
            }
        }
        return value;
    }

    /**
     * performs validation on id, name, and address
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validateIdNameAddress(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String[] field = value.split("\r\n");
            if (field.length - 1 > 4) {
                throw new Exception(SwiftParams.incorrectFormat(value, "[/1!a][/34x]\n4*35x"));// NOSONAR
            }
            int index = 0;
            if (field[0].charAt(0) == '/') {
                validateID(field[0]);
                index = 1;
            }
            for (int i = index; i < field.length; i++) {
                validateSwiftXCharacters(field[i], 35);
            }
        }
        return value;
    }

    /**
     * performs validation on account, name, and address
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validateAccountNameAddress(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String[] field = value.split("\r\n");
            if (field.length - 1 > 4) {
                throw new Exception(SwiftParams.incorrectFormat(value, "[/1!a][/34x]\n4*35x"));// NOSONAR
            }
            int index = 0;
            if (field[0].charAt(0) == '/') {
                validateAccount(field[0]);
                index = 1;
            }
            for (int i = index; i < field.length; i++) {
                validateSwiftXCharacters(field[i], 35);
            }
        }
        return value;
    }

    /**
     * This method is very similar to the above validateIdNameAddress method but
     * the format is slightly different
     * 
     * @param value tag value to be validated
     * @return value passed in unchanged
     * @throws Exception if the tag value is invalid
     */
    public static String validatePartyIdNameAddress(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String[] fields = value.split("\r\n");
            for (String field : fields) {
                validateSwiftXCharacters(field, 35);
            }
        }
        return value;
    }

    /**
     * This method is very similar to the above validateAccountNameAddress
     * method but the format is slightly different
     * 
     * @param value tag value to be validated
     * @return value passed in unchanged
     * @throws Exception if the tag value is invalid
     */
    public static String validateAccNameAddress(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String[] fields = value.split("\r\n");
            if (fields[0].startsWith("/")) {
                validateSwiftXCharacters(fields[0].substring(1), 34);
            } else {
                throw new Exception(value + " - is not in the correct format ([/34x])");// NOSONAR
            }
            for (String field : fields) {
                validateSwiftXCharacters(field, 35);
            }
        }
        return value;
    }

    /**
     * perform validation for tag 50f for MT202COV (35x</br>
     * 4*35x)
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validateTag50F(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String[] field = value.split("\r\n");
            if (field.length - 1 > 4) {
                throw new Exception(SwiftParams.incorrectFormat(value, "35x\n4*35x"));// NOSONAR
            }
            if (field[0].charAt(0) == '/') {
                validateSwiftXCharacters(field[0].substring(1), 34);
            } else if (field[0].substring(0, 8).matches("[A-Z]{4}/[A-Z]{2}/")) {
                validateSwiftXCharacters(field[0].substring(8), 27);
            }
            for (int i = 1; i < field.length; i++) {
                if (Character.isDigit(field[i].charAt(0)) && field[i].charAt(1) == '/') {
                    validateSwiftXCharacters(field[1].substring(2), 33);
                }
            }
        }
        return value;
    }

    /**
     * performs validation on amount (/34x)
     * 
     * @param value
     * @return
     * @throws Exception
     */
    public static String validateAccount(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.charAt(0) == '/') {
                try {
                    validateSwiftXCharacters(value.substring(1), 34);
                } catch (Exception e) {// NOSONAR
                    throw new Exception(SwiftParams.incorrectFormat(value, "/34x"));// NOSONAR
                }
            } else {
                throw new Exception(SwiftParams.incorrectFormat(value, "/34x"));// NOSONAR
            }
        }
        return value;
    }

    /**
     * Performs validation on statement sequence number (5n[/5n])
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validateStatementSequence(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (value.contains("/")) {
                // both statement number and sequence number are present
                String[] fields = value.split("/");
                for (String field : fields) {
                    if (!field.matches("[0-9]{1,5}")) {
                        throw new Exception(SwiftParams.incorrectFormat(value, "5n[/5n]"));// NOSONAR
                    }
                }
            } else {
                if (!value.matches("[0-9]{1,5}")) {
                    throw new Exception(SwiftParams.incorrectFormat(value, "5n[/5n]"));// NOSONAR
                }
            }
        }
        return value;
    }

    /**
     * performs validation on statement sequence number for MT941 (5n[/2n])
     * 
     * @param value
     * @return
     * @throws Exception if string is invalid
     */
    public static String validate941StatementSequence(String value) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            if (!value.matches("[0-9]{1,5}/?([0-9]{1,2})?")) {
                throw new Exception(SwiftParams.incorrectFormat(value, "5n[/2n]"));// NOSONAR
            }
        }
        return value;
    }

    /**
     * Performs validation on date (6!n)
     * 
     * @param date date string
     * @param pattern date pattern
     * @throws Exception if string is invalid
     */
    public static String validateDateTime(String date, String pattern) throws Exception {// NOSONAR
        // INC0034849420: Add current year to date if it was not provided
        // This was added so that leap years will validate properly
        // Previously, year 1970 was assumed when it was not provided in the
        // input

        // Making a copy of this variable so we can return it untouched at the
        // end
        final String unmodifiedDate = date;
        final String PATTERN_YEAR = "yy";
        if (!pattern.contains(PATTERN_YEAR)) { // If Pattern does not include
                                               // year
            Date today = new Date();
            String currentYear = new SimpleDateFormat(PATTERN_YEAR).format(today);

            pattern += PATTERN_YEAR;
            date += currentYear;
        }

        SimpleDateFormat format = new SimpleDateFormat(pattern);

        format.setLenient(false);
        try {
            format.parse(date);
        } catch (ParseException e) {
            throw new Exception(SwiftParams.incorrectFormat(date, pattern));
        }
        return unmodifiedDate;
    }

    /**
     * performs validation on currency (3!a)
     * 
     * @param currency
     * @throws Exception if string is invalid
     */
    private static void validateCurrency(String currency) throws Exception {// NOSONAR
        if (currency != null && !currency.isEmpty()) {
            if (!currency.matches("[A-Z]{3}")) {
                throw new Exception(SwiftParams.incorrectFormat(currency, "3!a"));// NOSONAR
            }
        }
    }

    /**
     * performs validation on amount of fixed length n with comma decimal
     * 
     * @param amount
     * @param n fixed length
     * @throws Exception if string is invalid
     */
    public static String validateAmount(String amount, int n) throws Exception {// NOSONAR
        if (amount != null && !amount.isEmpty()) {
            if (!amount.matches("([0-9]+,([0-9]+)?){1," + n + "}")) {
                throw new Exception(SwiftParams.incorrectFormat(amount, n + "d"));// NOSONAR
            }
        }
        return amount;
    }

    /**
     * performs validation on amount (15d)
     * 
     * @param amount
     * @throws Exception if string is invalid
     */
    public static String validateAmount(String amount) throws Exception {// NOSONAR
        if (amount != null && !amount.isEmpty()) {
            if (!amount.matches("([0-9]+,([0-9]+)?){1,15}")) {
                throw new Exception(SwiftParams.incorrectFormat(amount, "15d"));// NOSONAR
            }
        }
        return amount;
    }

    /**
     * performs validation on id ([/1!a][/34x])
     * 
     * @param id
     * @throws Exception if string is invalid
     */
    private static void validateID(String id) throws Exception {// NOSONAR
        if (id != null && !id.isEmpty()) {
            if (!id.matches("^(/[A-Z])?(/[-A-Za-z0-9/:().,'+\\s\\?]{1,34})?$")) {
                throw new Exception(SwiftParams.incorrectFormat(id, "[/1!a][/34x]"));// NOSONAR
            }
        }
    }

    /**
     * performs validation on BIC (4!a2!a2!c[3!c])
     * 
     * @param bic
     * @throws Exception if string is invalid
     */
    private static void validateBIC(String bic) throws Exception {// NOSONAR
        if (bic != null && !bic.isEmpty()) {
            if (!bic.matches("[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?")) {
                throw new Exception(SwiftParams.incorrectFormat(bic, "4!a2!a2!c[3!c]"));// NOSONAR
            }
        }
    }

    /**
     * performs validation on multi line of swift x characters (e.g. 4*35x)
     * 
     * @param value
     * @param characters number of swift x characters
     * @return the input string
     * @throws Exception if string is invalid
     */
    public static String validateMultiLineSwiftX(String value, int rows, int characters) throws Exception {// NOSONAR
        if (value != null && !value.isEmpty()) {
            String[] lines = value.split("\r\n");
            if (lines.length > rows) {
                throw new Exception(SwiftParams.incorrectFormat(value, rows + "*" + characters + "x"));// NOSONAR
            }
            for (String line : lines) {
                validateSwiftXCharacters(line, characters);
            }
        }
        return value;
    }
}
