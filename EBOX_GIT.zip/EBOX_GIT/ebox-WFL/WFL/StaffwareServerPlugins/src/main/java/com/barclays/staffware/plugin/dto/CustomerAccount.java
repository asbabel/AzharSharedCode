package com.barclays.staffware.plugin.dto;

import java.util.Set;


/**
 * A Barclays customer account.
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 07Nov07  PAT02281   KEMPD  1        WP137: created.
 * 13Feb08  PAT02404   KEMPD  2        Extend java.io.Serializable.
 */
public interface CustomerAccount
    extends java.io.Serializable
{
    /**
     * Full account number.
     */
    public String getFullAccountNumber();
    
    /**
     * Add a card to the account.
     */
    public void addCard(
            Card card);

    /**
     * Remove a card from the account.
     */
    public boolean removeCard(
            Card card);

    /**
     * Remove all cards from the account.
     */
    public void removeAllCards();

    /**
     * Cards that have been added to the account.
     */
    public Set getCards();

    /**
     * The specified card.
     *
     * @return  The card with the given number, or <code>null</code> if it is
     *          not associated with this account
     */
    public Card getCard(
            String number);
}
