package com.barclays.staffware.plugin.swift;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TagHelper;
import com.barclays.staffware.plugin.util.ValidateSwift;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

/**
 * EAI java plugin for creating SWIFT message MT910.  
 * 
 * @author LEES
 * 
 */
/*
 * DATE 	REFERENCE 	WHO 	VERSION 	COMMENTS 
 * ---- 	--------- 	--- 	------- 	--------
 * 19MAR14 	WP669 		SL 		1.00 		Created for MTPCA
 * 26MAR15	MTFixes		SL		1.01		Tag 52A is required for the message to be valid
 * 05NOV15	WP695		Amit				Added two new tags 13D and 50 as part of Swift 2015 Stage 3
 * 
 */
public class MT910 extends SwiftMessage implements ImmediateReleasePluginSDK {

	private String tag20;

	private final LoggerConnection logger = new LoggerConnection(MT910.class);

	private final String INITIALIZATION_FAILED =
			SwiftParams.initializationFailed(MT910.class.getName());

	/**
	 * Getter for TAG_20
	 * 
	 * @return tag20
	 */
	public String getTag20() {
		return tag20;
	}

	/**
	 * Setter for TAG_20
	 * 
	 * @param tag20
	 *            Input from Staffware
	 * @throws Exception
	 *             If TAG_20 is missing
	 */
	public void setTag20(String tag20) throws Exception {
		if (tag20 == null || tag20.trim().isEmpty()) {
			throw new Exception(SwiftParams.TAG_20_ERROR);
		}
		this.tag20 = tag20;
	}

	/**
	 * Method Staffware calls in eaijava step
	 * 
	 * @param staticData
	 *            a string hardcoded in Staffware, this is ignored in this
	 *            method
	 * @param outputFields
	 *            a list of Staffware field objects which Staffware expects to
	 *            be returned. Not used in this method.
	 * @param inputFields
	 *            a list of Staffware field objects which Staffware provides
	 *            (with values)
	 * @return the name value pairs returned to Staffware
	 */
	@Override
	public Map executeProcess(String staticData, List outputFields, List inputFields)
			throws FatalPluginException,
			NonFatalPluginException {

		Map<String, Object> result =
				new HashMap<String, Object>(outputFields.size());
		StaffwareHelper.initialiseReturnValues(outputFields, result);
		try {
			setMessageType("910");
			if (logger.isDebugEnabled()) {
				logger.debug("Arguments received from Staffware: ");
				for (Iterator<?> i = inputFields.iterator(); i.hasNext();) {
					Field field = (Field) i.next();
					logger.debug(field.getName() + " = " + field.getValue());
				}
			}
			setSender(getFieldValue(inputFields, "SENDER"));
			// un-comment line below to simulate build failure case
			//setSender(null);
			setReceiver(getFieldValue(inputFields, "RECEIVER"));
			setTag20(getFieldValue(inputFields, "TAG_20"));
			StringBuffer swiftMessage = new StringBuffer();

			basicHeaderBlock(swiftMessage, getSender());
			applicationHeaderBlock(swiftMessage, getMessageType(),
					getReceiver());
			appendUserHeaderBlock(swiftMessage,
					TagHelper.formatHeaderTag(getTag20()));
			messageBlock(swiftMessage, formatMessageTags(inputFields));
			result.put(SwiftParams.STATUSCODE, "0");
			result.put(SwiftParams.SWIFT + getMessageType(), swiftMessage);
		} catch (Exception e) {
			String executeFailed =
					SwiftParams.cannotFormMessage(getMessageType());
			if (logger.isErrorEnabled()) {
				logger.error(executeFailed + ". Details: " + e.getMessage(), e);
			}
			StaffwareHelper.setErrorMessage(e, result, "-1", executeFailed);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Returning values to Staffware: ");
			List<String> keys = new ArrayList<String>(result.keySet());
			Collections.sort(keys);
			for (Iterator<?> i = keys.iterator(); i.hasNext();) {
				String key = (String) i.next();
				logger.debug(key + " <- " + result.get(key));
			}
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see com.barclays.staffware.plugin.swift.SwiftMessage#formatMessageTags(java.util.List)
	 */
	@Override
	protected StringBuffer formatMessageTags(List<?> inputFields)
			throws Exception {
		StringBuffer tags = new StringBuffer();

		appendTag(tags, "20", ValidateSwift.validateSwiftXCharacters(getTag20(), 16));

		appendMandatoryTag(tags,
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_21"), 16), 
				"21", SwiftParams.TAG_21_ERROR);

		appendMandatoryTag(tags,
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_25"), 35), 
				"25", SwiftParams.TAG_25_ERROR);
		
		/* Added tag 13D as part of Swift 2015 Stage 3 */
		appendOptionalTag(tags, 
				ValidateSwift.validateTag13D(
						getFieldValue(inputFields, "TAG_13D")), "13D");

		appendMandatoryTag(tags,
				ValidateSwift.validateDateCurrencyAmount(
						getFieldValue(inputFields, "TAG_32A")),
				"32A", SwiftParams.TAG_32A_ERROR);
		
		/* Added tag 50 as part of Swift 2015 Stage 3 */
		String orderingParty = getFieldValue(inputFields, "TAG_50F_PARTY");
		String orderingBic = getFieldValue(inputFields, "TAG_50A_BIC");
		String orderingAddr1 = getFieldValue(inputFields, "TAG_50F_ADDR_1");
		
		if(StringUtils.isEmpty(orderingAddr1))
		{
			orderingAddr1 = getFieldValue(inputFields, "TAG_50K_ADDR_1");
		}
		
		if(!StringUtils.isEmpty(orderingAddr1))
		{
			if(!StringUtils.isEmpty(orderingParty))
			{
				Map<String, Object> tag50f = new HashMap<String, Object>();
				TagHelper.setGroupTags(tag50f, inputFields, "TAG_50F_");
				appendOptionalTag(tags,
						ValidateSwift.validateTag50F(
								TagHelper.formatTagAddress(tag50f, "TAG_50F_", "PARTY")),
						"50F");

			}
			else
			{
				Map<String, Object> tag50k = new HashMap<String, Object>();
				TagHelper.setGroupTags(tag50k, inputFields, "TAG_50K_");
				appendOptionalTag(tags,
						ValidateSwift.validateTag50F(
								TagHelper.formatTagAddress(tag50k, "TAG_50K_", "ACC")),
						"50K");

			}
		}
		else if(!StringUtils.isEmpty(orderingBic))
		{
			appendOptionalTag(tags, 
					ValidateSwift.validateAccountBIC(
							TagHelper.formatPartyIdBIC(getFieldValue(inputFields, "TAG_50A_ACC"),orderingBic)), 
					"50A");
		}
		
		/* Swift 2015 Stage 3 changes end */
		
		// MT Fixes - Tag 52A is required for the message to be valid
		/* Added condition as part of Swift 2015 Stage 3 */
		
		if(StringUtils.isEmpty(orderingBic) 
				&& StringUtils.isEmpty(orderingParty) 
				&& StringUtils.isEmpty(orderingAddr1))
		{
			appendOptionalTag(tags, 
					ValidateSwift.validateIdBIC(
							getFieldValue(inputFields, "TAG_52A_BIC")), "52A");
		}

		appendGroupTag(tags, inputFields, "72", "TAG_72_", 3, 35);

		return tags;
	}

}
