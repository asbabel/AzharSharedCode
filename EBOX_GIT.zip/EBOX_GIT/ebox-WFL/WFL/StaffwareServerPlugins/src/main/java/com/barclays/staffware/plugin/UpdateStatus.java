package com.barclays.staffware.plugin;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;


import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.data.IMWDBAccess;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * EAI java plugin for updating the status of the PAC and the SMPS tables
 * 
 * @author LEES
 *
 */
/*
 * DATE     REFERENCE   WHO     VERSION   COMMENTS
 * ----     ---------   ---     -------   --------
 * ?        WP669       SL      1.00      Created
 * 19SEP14  WP669       SL      1.01      "XBORDER..." check removed for Stage 5 enhancement
 * 30SEP14  WP669       SL      1.02      "XBORDERSWFTCUG" and "LOCALSWFTCUG" check added for Stage 5 enhancement
 * 01OCT14  WP669       SL      1.03      "XBORDER" and "LOCAL" check removed
 */

public class UpdateStatus implements ImmediateReleasePluginSDK {

    private static final int TEN = 10;
    private String casenum;
    private String proname;
    private String status;
    private String mt199Status = null;
    private int errorCode;
    private String errorMessage;
    private String paymentType;
    private String country;
    private String offshoreInd;
    private int groupId;

    private IMWDBAccess dataAccess;

    private static final LoggerConnection logger = new LoggerConnection(UpdateStatus.class);

    private final String initializationFailed = SwiftParams.initializationFailed(UpdateStatus.class.getName());

    /**
     * Getter for SW_CASENUM
     * 
     * @return casenum
     */
    public String getCasenum() {
        return casenum;
    }

    /**
     * Getter for SW_PRONAME
     * 
     * @return proname
     */
    public String getProname() {
        return proname;
    }

    /**
     * Getter for STATUS
     * 
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Getter for ERROR_CODE
     * 
     * @return errorCode
     */
    public int getErrorCode() {
        return errorCode;
    }

    /**
     * Getter for ERROR_MESSAGE
     * 
     * @return errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Getter for PAYMENT_TYPE
     * 
     * @return paymentType
     */
    public String getPaymentType() {
        return paymentType;
    }

    /**
     * Getter for RELATED_REF
     * 
     * @return relatedRef
     */
    public int getGroupId() {
        return groupId;
    }

    /**
     * Getter for COUNTRY
     * 
     * @return country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Getter for OFFSHORE_IND
     * 
     * @return offshoreInd
     */
    public String getOffshoreInd() {
        return offshoreInd;
    }

    /**
     * Method is called by Staffware before each execute (unless a caching
     * option is selected in Staffware)
     * 
     * @param properties contents of eaijava properties file in
     * root:/swserver/sw_africa/eaijava
     */
    @Override
    public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {

        dataAccess = new MWDBAccess();
        try {
            //DataSourceDirectory.getInstance().configure(properties);
            //Modified by ashish for sql connection
            DataSourceDirectory.getInstance().basePluginDS();
           // dataAccess = new MWDBAccess();
         //   Class.forName(properties.getProperty("db_driver"));
           //LoggerConnection.configureWFL(properties.getProperty("updateStatusLog"));
            // Modified by ashish
            ClassPathResource resource = new ClassPathResource(properties.getProperty("updateStatusLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());
            logger.info(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
            }
        }

    /**
     * Method Staffware calls in eaijava step
     * 
     * @param staticData a string hardcoded in Staffware, this is ignored in
     * this method
     * @param outputFields a list of Staffware field objects which Staffware
     * expects to be returned
     * @param inputFields a list of Staffware field Objects which Staffware
     * provides (with values)
     * @return the name value pairs returned to Staffware
     */
    @Override
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {
        Map<String, Object> result = new HashMap<String, Object>(outputFields.size());
        if (logger.isDebugEnabled()) {
            logger.debug("Arguments received from Staffware: ");
            for (Iterator<?> i = inputFields.iterator(); i.hasNext();) {
                Field field = (Field) i.next();
                logger.debug(field.getName() + " = " + field.getValue());
            }
        }
        StaffwareHelper.initialiseReturnValues(outputFields, result);
        try {
            setClassProperties(inputFields);
            updatePACStatus();
            result.put("STATUSCODE", "0");
            result.put("STATUSDESC", "SUCCESS");
        } catch (SQLException e) {
            if (logger.isErrorEnabled()) {
                logger.error(SwiftParams.DB_ERROR + ". Details: " + e.getMessage(), e);
            }
            StaffwareHelper.setErrorMessage(e, result, "-1", SwiftParams.DB_ERROR);
        } catch (Exception e) {
            if (logger.isErrorEnabled()) {
                logger.error(SwiftParams.UPDATE_FAILED + ". Details: " + e.getMessage(), e);
            }
            StaffwareHelper.setErrorMessage(e, result, "-1", SwiftParams.UPDATE_FAILED);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Returning values to Staffware: ");
            List<String> keys = new ArrayList<String>(result.keySet());
            Collections.sort(keys);
            for (Iterator<?> i = keys.iterator(); i.hasNext();) {
                String key = (String) i.next();
                logger.debug(key + " <- " + result.get(key));
            }
        }
        return result;
    }

    /**
     * Method calls stored procedure to update the Status, Errorcode, and
     * ErrorMessage in PaymentAndCollections using the Staffware case details
     * provided
     * 
     * @throws SQLException if fail to connect to database or if fail to call
     * stored procedure
     */
    private void updatePACStatus() throws SQLException {

        dataAccess.insertSwiftMessageProcessStatus(getCasenum(), getProname(), getStatus(), getErrorCode(),
                getErrorMessage(), getCountry(), getOffshoreInd(), mt199Status, groupId);
    }

    /**
     * Method for setting some of the class properties
     * 
     * @param inputFields Inputs from Staffware
     * @throws Exception If mandatory fields are missing
     */
    private void setClassProperties(List<?> inputFields) throws Exception { // NOSONAR
        String boAuth = null;
        String rateAvailable = null;
        for (Object inputField : inputFields) {
            Field field = (Field) inputField;
            String name = field.getName().trim();
            String value = field.getValue().trim();

            if ("SW_CASENUM".equalsIgnoreCase(name)) {
                if (value == null || value.isEmpty()) {
                    throw new Exception(SwiftParams.MISSING_CASENUM);// NOSONAR
                } else {
                    casenum = value;
                }
            } else if ("SW_PRONAME".equalsIgnoreCase(name)) {
                if (value == null || value.isEmpty()) {
                    throw new Exception(SwiftParams.MISSING_PRONAME);// NOSONAR
                } else {
                    proname = value;
                }
            } else if ("STATUS".equalsIgnoreCase(name)) {
                status = value;
            } else if ("ERROR_MESSAGE".equalsIgnoreCase(name)) {
                errorMessage = value == null || value.isEmpty() ? "" : value;
            } else if ("ERROR_CODE".equalsIgnoreCase(name)) {
                errorCode = value == null || value.isEmpty() ? 0 : Integer.parseInt(value);
            } else if ("PAYMENT_TYPE".equalsIgnoreCase(name)) {
                if (value == null || value.isEmpty()) {
                    throw new Exception(SwiftParams.MISSING_PAYMENT_TYPE);// NOSONAR
                } else {
                    paymentType = value;
                }
            } else if ("GROUP_ID".equalsIgnoreCase(name)) {
                if (value == null || value.isEmpty()) {
                    throw new Exception(SwiftParams.MISSING_GROUP_ID);// NOSONAR
                } else {
                    groupId = Integer.parseInt(value);
                }
            } else if ("COUNTRY".equalsIgnoreCase(name)) {
                country = value;
            } else if ("OFFSHORE_IND".equalsIgnoreCase(name)) {
                offshoreInd = value;
                // SMxx: added field
            } else if ("BO_AUTH".equalsIgnoreCase(name)) {
                boAuth = value;
                // SMxx: added field
            } else if ("RATE_AVAILABLE".equalsIgnoreCase(name)) {
                rateAvailable = value;
            }
        }
        if (getStatus() == null || getStatus().isEmpty()) {
            throw new Exception(SwiftParams.MISSING_STATUS);// NOSONAR
        } else if (getStatus().length() > TEN || getStatus().matches("[0-9]")) {
            throw new Exception(SwiftParams.INCORRECT_STATUS_FORMAT); // NOSONAR
        }
        // SMxx enhancement
        if ("ERROR".equals(getStatus())) {
            if ("Decline".equals(boAuth) || "No".equalsIgnoreCase(rateAvailable)) {
            } else {
                mt199Status = "EXCLUDED";
            }
        }

    }
}
