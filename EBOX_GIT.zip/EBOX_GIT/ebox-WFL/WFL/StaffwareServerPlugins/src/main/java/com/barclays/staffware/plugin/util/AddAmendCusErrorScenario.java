package com.barclays.staffware.plugin.util;

import org.apache.commons.lang.StringUtils;

public enum AddAmendCusErrorScenario {
    // Add customer scenarios
    CONN_BRAINS_CUS_A("The customer cannot be added to BRAINS at this time. Please retry. If this issue continues," +
            " contact your system administrator.", true, false),
    CONN_BRAINS_CUS_DET_ADD("Some of the customer's details have not been saved successfully. Please contact your system" +
            " administrator. You will be unable to retry this submission. Use the 'Amend' button to complete the" +
            " customer capture.", false, true),
    CONN_KAMLS_ADD("An error occurred while connecting to the KAMLS service. Please contact your system administrator. " +
            " You will be unable to retry this submission. Use the 'Amend' button to resubmit the application at " +
            "a later time.", false, true),
    BUSINESS_CUS_A(""/*Use Exception msg received*/, true, false),
    BUSINESS_CUS_DET(/*Use Exception msg received*/  "; You will be unable to retry this submission. Use the 'Amend' " +
            "button if required.", false, true),
    BUSINESS_KAMLS(/*Exception msg received*/ "; You will be unable to retry this submission.", false, true),
    KAMLS_INVALID_RISK_SCORE_LEVEL_ADD("KAMLS has returned an invalid risk score/level. Please investigate the problem" +
            " in KAMLS before continuing", false, true),
    TECHNICAL_BEFORE_CUS_A("An unexpected error has occurred. Please contact your system administrator.", true, false),
    TECHNICAL_AFTER_CUS_A("An unexpected error has occurred. Please contact your system administrator.", false, true),

    // Amend customer scenarios
    CONN_BRAINS_CUS_DET_AMEND ("Unable to access customer details. Please retry. If this issue continues, contact your " +
            "system administrator.", true, true),
    CONN_BRAINS_CUS_U("An error occurred while connecting to BRAINS. Please retry. If this issue continues, contact" +
            " your system administrator.", true, true),
    CONN_KAMLS_AMEND ("An error occurred while connecting to the KAMLS service. Please retry. If this issue continues, " +
            "contact your system administrator.", true, true),

    BUSINESS_BRAINS_OR_KAMLS(""/*Use Exception msg received*/, true, true),

    KAMLS_INVALID_RISK_SCORE_LEVEL_AMEND("KAMLS has returned an invalid risk score/level. Please investigate the problem" +
            " in KAMLS before continuing", true, true),
    KAMLS_CUS_JUST_BEEN_ADDED("The customer has just been added to the KAMLS system and will not be listed as " +
            "compliant until the KAMLS processing is complete, contact the KAMLS team if you wish to know the" +
            " current status of the customer in the KAMLS system. Your change has not been made, please try " +
            "again later", true, true),
    KAMLS_CUS_NOT_COMPLIANT("The customer is not listed as compliant in the KAMLS system; contact the KAMLS team " +
            "for further details. Your change has not been made", true, true),

    TECHNICAL_ERROR("An unexpected error has occurred. Please contact your system administrator.", true, false);

    private boolean retry;
    private boolean amend;
    private String errorMsg;

    AddAmendCusErrorScenario(String errorMsg, boolean retry, boolean amend) {
        this.errorMsg = errorMsg;
        this.retry = retry;
        this.amend = amend;
    }

    public String getErrorMsg() {
        return this.errorMsg;
    }

    public String getFullErrorMsg(String errorPrefix) {
        if (StringUtils.isNotBlank(errorPrefix)) {
            return errorPrefix.concat(this.errorMsg);
        } else {
            return getErrorMsg();
        }
    }

    public String getRetryAmendStaffwareTransitionValue() {
        if (retry && !amend) {
            return "retry";
        } else if (!retry && amend) {
            return "amend";
        } else if (retry && amend) {
            return "both";
        } else {
            return null;
        }
    }

}
