package com.barclays.staffware.plugin.reversal;

/**
 * This is the Constants Class Used for storing all static constant Strings
 * 
 * @author Anup Kulkarni
 */
/* 
 * DATE      REFERENCE   WHO     	VERSION  	COMMENTS
 * --------  ---------   ---     	-------  	----------------------
 * 08/02/16  WP697       Anup    1.0	  		Created
 */
public class Constants {

    public static final String CHARGEDESCRIPTION = "ChargeDescription";
    public static final String ACTIVITYCODE = "ActivityCode";
    public static final String CHARGETYPE = "ChargeType";
    public static final String REV = "Rev";
    public static final String CHARGEPACKAGE = "ChargePackage";
    public static final String TERMINALNUMBER = "TerminalNumber";
    public static final String SOURCELOCATION = "SourceLocation";
    public static final String VALUEDATEIND = "ValueDateInd";
    public static final String PROCESSED = "PROCESSED";
    public static final String SUSPENSECHARGEACCOUNT = "SuspenseChargeAccountNumber";
    public static final String SUSPENSECHARGEBRANCH = "SuspenseChargeBranchId";
    public static final String SUSPENSECHARGECURRENCY = "SuspenseChargeCurrency";
    public static final String SUSPENSECHARGELOCALAMOUNT = "SuspenseChargeLocalAmount";
    public static final String SUSPENSECHARGETRXAMOUNT = "SuspenseChargeTransactionAmount";
    public static final String SUSPENSECHARGEACCOUNTENTRYTYPE = "SuspenseChargeAccountEntryType";
    public static final String SUSPENSECHARGENARRATIVE = "SuspenseChargeNarrative";
    public static final String ORIGINATORCHARGEBRANCH = "OriginatorChargeBranchId";
    public static final String ORIGINATORCHARGEACCOUNT = "OriginatorChargeAccountNumber";
    public static final String ORIGINATORCHARGELOCALAMOUNT = "OriginatorChargeLocalAmount";
    public static final String ORIGINATORCHARGETRXAMOUNT = "OriginatorChargeTransactionAmount";
    public static final String ORIGINATORCHARGECURRENCY = "OriginatorChargeCurrency";
    public static final String ORIGINATORCHARGENARRATIVE = "OriginatorChargeNarrative";
    public static final String ORIGINATORCHARGEACCOUNTENTRYTYPE = "OriginatorChargeAccountEntryType";
    public static final String SUSPENSECHARGETRANCODE = "SuspenseChargeTranCode";
    public static final String SUSPENSECHARGESUBTRANCODE = "SuspenseChargeSubTranCode";
    public static final String ORIGINATORCHARGETRANCODE = "OriginatorChargeTranCode";
    public static final String ORIGINATORCHARGESUBTRANCODE = "OriginatorChargeSubTranCode";
    public static final String ORIGINATORBRANCH = "OriginatorBranchId";
    public static final String ORIGINATORACCOUNT = "OriginatorAccountNumber";
    public static final String ORIGINATORLOCALAMOUNT = "OriginatorLocalAmount";
    public static final String ORIGINATORTRXAMOUNT = "OriginatorTransactionAmount";
    public static final String ORIGINATORNARRATIVE = "OriginatorNarrative";
    public static final String ORIGINATORACCOUNTENTRYTYPE = "OriginatorAccountEntryType";
    public static final String ORIGINATORCURRENCY = "OriginatorCurrency";
    public static final String ORIGINATORNAME = "OriginatorName";
    public static final String ORIGREMINFO = "OriginatorRemittanceInformation";
    public static final String COUNTERPARTYBRANCH = "CounterpartyBranchId";
    public static final String COUNTERPARTYACCOUNT = "CounterpartyAccountNumber";
    public static final String COUNTERPARTYLOCALAMOUNT = "CounterpartyLocalAmount";
    public static final String COUNTERPARTYTRXAMOUNT = "CounterpartyTransactionAmount";
    public static final String COUNTERPARTYNARRATIVE = "CounterpartyNarrative";
    public static final String COUNTERPARTYACCOUNTENTRYTYPE = "CounterpartyAccountEntryType";
    public static final String COUNTERPARTYCURRENCY = "CounterpartyCurrency";
    public static final String COUNTERPARTYBANKCODE = "CounterpartyBankCode";
    public static final String COUNTERPARTYNAME = "CounterpartyName";
    public static final String COUNTERPARTYREMINFO = "CounterpartyRemittanceInformation";
    public static final String SUSPENSEBRANCHID = "SuspenseBranchId";
    public static final String SUSPENSEACCOUNTNUMBER = "SuspenseAccountNumber";
    public static final String SUSPENSETRANSACTIONAMOUNT = "SuspenseTransactionAmount";
    public static final String SUSPENSELOCALAMOUNT = "SuspenseLocalAmount";
    public static final String SUSPENSECURRENCY = "SuspenseCurrency";
    public static final String SUSPENSENARATTIVE = "SuspenseNarrative";
    public static final String BOX = "BOX";
    public static final String BRAINS = "BRAINS";
    public static final String REVUTIL = "revutil";
    public static final String REVERSECHARGESIND = "ReverseChargesInd";
    public static final String REVERSE_CHARGES_IND = "REV_CHARGES_IND";
    public static final String ERRORMESSAGE = "ErrorMessage";

    // Constants for Payment Management Helper

    public static final String COUNTRY = "Country";
    public static final String CONTRY = "country";
    public static final String OFFSHOREIND = "OffshoreInd";
    public static final String OFFSHORE = "offshore";
    public static final String ENGINE = "engine";
    public static final String TRXID = "TrxId";
    public static final String GROUPID = "GroupId";
    public static final String PAYMENTTYPE = "PaymentType";
    public static final String ORIGINATOR = "ORIGINATOR";
    public static final String SUSPENSE = "SUSPENSE";
    public static final String DRCRIND = "DebitCredit";
    public static final String ENTRYTYPE = "EntryType";
    public static final String TRANCODE = "TransactionCode";
    public static final String SUBCODE = "SubCode";
    public static final String GROUP_ID = "GROUP_ID";
    public static final String SOURCE_SYSTEM = "SourceSystem";
    public static final String ITEMNUMBER = "ItemNumber";
    public static final String ITEM_NUMBER = "ITEM_NUMBER";
    public static final String ORIGGROUPID = "OrigGroupId";
    public static final String ORIGITEMNUMBER = "OrigItemNumber";
    public static final String REVITEMNUMBER = "RevItemNumber";
    public static final String REVGROUPID = "RevGroupId";
    public static final String MSGID = "MsgId";
    public static final String SOURCESYSTEM = "sourceSystem";
    public static final String PAYMNTTYPE = "paymentType";
    public static final String ACCOUNT_STATUS = "ACCOUNT_STATUS";
    public static final String ORIGINATORACCOUNTNUMBER = "OriginatorAccountNumber";
    public static final String ORIGINATORBRANCHID = "OriginatorBranchId";
    public static final String COUNTERPARTYACCOUNTNUMBER = "CounterpartyAccountNumber";
    public static final String COUNTERPARTYBRANCHID = "CounterpartyBranchId";
    public static final String ORIGCHARGEACCOUNTNUMBER = "OriginatorChargeAccountNumber";
    public static final String ORIGCHARGEBRANCHID = "OriginatorChargeBranchId";
    public static final String SUSPENSECHARGEACCOUNTNUMBER = "SuspenseChargeAccountNumber";
    public static final String SUSPENSECHARGEBRANCHID = "SuspenseChargeBranchId";
    public static final int CLOSED_ACCOUNT = 5;

    public static final String NAME = "name";
    public static final String UNDERSCORE_SOURCESYSTEM = "_SourceSystem";
    public static final String UNDERSCORE_COUNTRY = "_Country";
    public static final String UNDERSCORE_OFFSHOREIND = "_OffshoreInd";
    public static final String GROUPITEMNUMBER = "GroupItemNumber";
    public static final String UNDERSCORE_GROUPID = "_GroupId";

    // static constants for stored procedure names
    public static final String SP_ECHANNEL_PAYMENTTYPE_GET = "wfe_EChannelPaymentTypeGet";
    public static final String SP_GETREVERSAL_CROSSREFERENCE_DATA = "wfe_EChannelReversalCrossReferenceGet";
    public static final String SP_GETPACDETAILS = "wfe_EChannelPaymentAndCollectionsGet";
    public static final String SP_GET_TCR_DATA = "csc_getTransactionCrossReferenceKey";
    public static final String SP_INSERT_REVRSALXREFERENCE = "wfe_EChannelReversalCrossReferenceInsert";
    public static final String SP_GET_PACCHARGES_DATA = "wfe_EChannelPaymentAndCollectionsChargesGet";
    public static final String SP_GET_TCRGENRATION_DATA = "wfe_EChannelTransactionGenerationGet";
    public static final String SP_GET_MW_COUNTER_DATA = "wfe_EChannelMercatorCounterGet";
    public static final String SP_GET_BARCLAYS_BANK_CODE = "csc_getBarclaysBankCode";

    // Constants for Payment Validator

    public static final String PAYMENT_NOT_FOUND = "Payment to be reversed not found";
    public static final String PAYMENT_TRANSACTION_ALREADY_REVERSED = "Payment has already been reversed";

    public static final String TRANS_SUB_TRANS_CODE_NOT_EXIST =
            "Transaction/Sub-transaction code not configured for payment reversal posting";
    public static final String REVERSAL_CODE_NOT_CONFIGURED = "Reversal Type not found";
    public static final String PAYMENT_PROCESSING_NOT_COMPLETE =
            "Payment has not been fully processed.Cannot process reversal";
    public static final String ACCOUNT_CLOSED = "Failed to post transaction.Account Number %d is closed";
    public static final String MANDATORY_FIELD_NOT_PROVIDED = "Mandatory input field %s was not provided";

    public static final String EXTRACTED = "EXTRACTED";

    public static final String STATUS = "Status";

    public static final String PAYMENT = "Payment";
    public static final String REVERSALTYPE = "ReversalType";
    public static final String NEXTVALUE = "NextValue";
    public static final String TRXCOUNTER = "$TID";
    public static final String MSGCOUNTER = "$MID";
    public static final String BARCLAYSBANKCODE = "BarclaysBankCode";
    public static final String STRINGONE = "1";
    public static final int INTEGERONE = 1;
    public static final String STATUSCODE = "STATUSCODE";
    public static final String ERRORDESC = "ERRORDESC";
    public static final String ERRORCODE = "ERRORCODE";
    public static final int INTEGERTWO = 2;
    public static final int INTEGER_FIVE = 5;
    public static final String ERROR_INITIALISING = "Error initialising ";
    public static final String DETAILS = ". Details: ";
    public static final String REVERSALMESSAGEPROP = "reversalMessageLog";

    private Constants() {
    }
    
    public static String initializationFailed(String className) {
        return "Error initializing " + className;
    }

}
