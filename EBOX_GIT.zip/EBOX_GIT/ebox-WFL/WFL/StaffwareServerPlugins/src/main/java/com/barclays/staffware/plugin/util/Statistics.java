package com.barclays.staffware.plugin.util;

import com.ibm.math.BigDecimal;

/**
 * Contains statistical methods
 */
/* 
 * DATE      REFERENCE   WHO     VERSION  COMMENTS
 * --------  ---------   ---     -------  -----------------------------------------
 * 19/02/07  -           LEEDSS       	  Created
 */
public class Statistics {
	
	/**
	 * Zero, in BigDecimal format
	 */
	public static final BigDecimal ZERO = new BigDecimal("0");
	
	/**
	 * Returns the maximum value from an array of BigDecimals.
	 * @param data data to find the maximum value of
	 */
	public static BigDecimal max(BigDecimal[] data) {
		BigDecimal most = null;
		for(int i = 0; i < data.length; ++i) {
			if((most == null) || 
					(data[i] != null && most != null && data[i].compareTo(most) > 0)) {
				most = data[i];
			}
		}
		return most;
	}
	
	/**
	 * Returns the maximum of value1 and value2.
	 * @param value1 value to compare
	 * @param value2 value to compare
	 */
	public static BigDecimal max(BigDecimal value1, BigDecimal value2) {
		return max(new BigDecimal[] {value1, value2});
	}
	
	/**
	 * Returns the maximum of value1, value2, and value3.
	 * @param value1 value to compare
	 * @param value2 value to compare
	 * @param value3 value to compare
	 */
	public static BigDecimal max(
			BigDecimal value1, 
			BigDecimal value2, 
			BigDecimal value3) {
		return max(new BigDecimal[] {value1, value2, value3});
	}

	/**
	 * Returns the minimum value from an array of BigDecimals.
	 * @param data data to find the minimum value of
	 */
	public static BigDecimal min(BigDecimal[] data) {
		BigDecimal least = null;
		for(int i = 0; i < data.length; ++i) {
			if((least == null) || 
					(data[i] != null && least != null && data[i].compareTo(least) < 0)) {
				least = data[i];
			}
		}
		return least;
	}
	
	/**
	 * Returns the minimum of value1 and value2.
	 * @param value1 value to compare
	 * @param value2 value to compare
	 */
	public static BigDecimal min(BigDecimal value1, BigDecimal value2) {
		return min(new BigDecimal[] {value1, value2});
	}
	
	/**
	 * Returns the minimum of value1, value2, and value3.
	 * @param value1 value to compare
	 * @param value2 value to compare
	 * @param value3 value to compare
	 */
	public static BigDecimal min(
			BigDecimal value1, 
			BigDecimal value2, 
			BigDecimal value3) {
		return min(new BigDecimal[] {value1, value2, value3});
	}

	/**
	 * Returns the mean value of data. Null values are counted as 0.
	 * @param data data to calculate the mean of
	 * @param roundMode rounding mode to use when dividing to produce the mean
	 * @return
	 */
	public static BigDecimal mean(BigDecimal[] data, int roundMode) {
		BigDecimal sum = new BigDecimal("0");
		for(int i = 0; i < data.length; ++i) {
			if(data[i] != null)
				sum = sum.add(data[i]);
		}
		BigDecimal count = new BigDecimal(data.length);
		return sum.divide(count, roundMode);
	}
	
	/**
	 * Returns the mean of value1 and value2.
	 * @param value1
	 * @param value2
	 * @param roundMode rounding mode to use when dividing to produce the mean
	 * @return
	 */
	public static BigDecimal mean(
			BigDecimal value1, 
			BigDecimal value2, 
			int roundMode) {
		return mean(new BigDecimal[] {value1, value2}, roundMode);
	}
	
	/**
	 * Returns the mean of value1, value2, and value3
	 * @param value1
	 * @param value2
	 * @param value3
	 * @param roundMode rounding mode to use when dividing to produce the mean
	 * @return
	 */
	public static BigDecimal mean(
			BigDecimal value1, 
			BigDecimal value2, 
			BigDecimal value3, 
			int roundMode) {
		return mean(new BigDecimal[] {value1, value2, value3}, roundMode);
	}
	
}
