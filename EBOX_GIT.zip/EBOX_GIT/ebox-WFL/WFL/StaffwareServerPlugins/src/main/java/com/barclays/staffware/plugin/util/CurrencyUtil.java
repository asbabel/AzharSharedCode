package com.barclays.staffware.plugin.util;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.SortedMap;
import java.util.TreeMap;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.staffware.data.MWDBAccess;

/**
 * Will house util methods for formatting amounts.
 * 
 * @author ABSH495
 * 
 */

/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 18Apr16   SEFTP2    SRH      1a     Initial Creation
 * 17Jan17   WP715     LeyJ     -      Refactored data access to MWDB.
 */
public class CurrencyUtil {

    private static final LoggerConnection LOG = new LoggerConnection(
            CurrencyUtil.class);

    //Constants
    public static final String COUNTRYPRAM = "country";
    public static final String OFFSHOREPARAM = "offshoreInd";
    public static final int DEFAULT_MASK = 2;
    public static final String SP_GETCURRENCIES = "csc_getCurrencies";
    public static final String CURRENCY = "Currency";
    public static final String CURRENCYMASK = "CurrencyMask";
    public static final String ERRORMESG =
            "Unable to retrieve Currency Mask from MWDB: ";

    /**
     * Private Constructor
     */
    private CurrencyUtil() {

    }

    /**
     * Specified currency object, loaded from the database.
     * 
     * @param countryCode
     * @param offshore
     * @param currencyCode
     * @return currency mask
     * @throws SQLException
     * @throws DataAccessException
     */
    public static int getCurrencyMask(
            String countryCode,
            int offshore,
            String currencyCode) throws SQLException {
        SortedMap<String, Object> args = new TreeMap<>();
        args.put(COUNTRYPRAM, countryCode);
        args.put(OFFSHOREPARAM, offshore);
        CallableStatement cs = null;
        ResultSet rs = null;
        SQLConnection conn = null;
        int currencyMask = DEFAULT_MASK;

        try {
            conn = MWDBAccess.getDatabaseConnection();
            cs = conn.prepareCall(SP_GETCURRENCIES, args);
            rs = conn.executeQuery(cs, args);
            while (rs.next()) {
                if (rs.getString(CURRENCY).equalsIgnoreCase(currencyCode)) {
                    currencyMask = rs.getInt(CURRENCYMASK);
                    break;
                }
            }
        } catch (SQLException e) {
            LOG.error(ERRORMESG, e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    LOG.error("Failed to close ResultSet", e);
                }
            }
            if (cs != null) {
                try {
                    cs.close();
                } catch (SQLException e) {
                    LOG.error("Failed to close CallableStatement", e);
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    LOG.error("Failed to close connection to database", e);
                }
            }
        }
        return currencyMask;
    }
}
