package com.barclays.staffware.plugin;

import static com.barclays.staffware.plugin.util.PainParams.POSTPAINMESSAGEPROP;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * EAI java plugin for updating the StaffwareCase table with a step name
 * 
 * @author Shahir.Hiralal
 * 
 */

public class UpdateStaffwareStepName implements ImmediateReleasePluginSDK {

    private static final LoggerConnection LOG = new LoggerConnection(
            UpdateStaffwareStepName.class);
    private final String initializationFailed = SwiftParams.initializationFailed(UpdateStaffwareStepName.class.getName());

    /**
     * Method is called by Staffware before each execute (unless a caching
     * option is selected in Staffware) Loads properties file. This file should
     * contain the DB Driver and the MQ Parameters to the relevant environment.
     * 
     * @param properties contents of eaijava properties file in
     * root:/swserver/sw_africa/eaijava
     */
    @SuppressWarnings("static-access")
	@Override
    public void initialize(Properties properties)
            throws FatalPluginException,
            NonFatalPluginException {
       // DataSourceDirectory.getInstance().configure(properties);
        try {
           // Class.forName(properties.getProperty("db_driver"));
           // LoggerConnection.configureWFL(properties.getProperty("updateStaffwareStepLog"));

            ClassPathResource resource = new ClassPathResource(properties.getProperty("updateStaffwareStepLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());

            DataSourceDirectory.getInstance().basePluginDS();
            LOG.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	LOG.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
    }

    /**
     * Method Staffware calls in eaijava step, will update the staffware step
     * name.
     * 
     * @param staticData a string hardcoded in Staffware, this is ignored in
     * this method
     * @param outputFields a list of Staffware field objects which Staffware
     * expects to be returned
     * @param inputFields a list of Staffware field objects which Staffware
     * provides (with values)
     * @return the name value pairs returned to Staffware
     */
    @SuppressWarnings("rawtypes")
    @Override
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {
        MWDBAccess objMWDB = new MWDBAccess();
        Map<String, Object> results =
                new HashMap<String, Object>(outputFields.size());
        try {
            objMWDB.updateStaffwareStepname(StaffwareHelper.getFieldValue(
                    inputFields, "SW_PRONAME"),
                    Integer.parseInt(StaffwareHelper.getFieldValue(inputFields,
                            "SW_CASENUM")), staticData);
            results.put("STATUSCODE", 0);
            results.put("STATUSDESC", "UPDATED");
        } catch (NumberFormatException e) {
            results.put("STATUSCODE", 1);
            results.put("STATUSDESC", e.getMessage());
            LOG.error("Unable to format CaseNumber", e);
        } catch (SQLException e) {
            LOG.error("Unable to update Step Name", e);
            results.put("STATUSCODE", 1);
            results.put("STATUSDESC", e.getMessage());
        }
        return results;
    }
}
