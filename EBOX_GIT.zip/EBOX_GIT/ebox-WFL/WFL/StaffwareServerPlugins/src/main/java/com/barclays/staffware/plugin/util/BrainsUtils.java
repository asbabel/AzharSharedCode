package com.barclays.staffware.plugin.util;

import com.barclays.generic.business.utils.LoggerConnection;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Utility functions for interacting with BRAINS tokens and data.
 *
 * @author  LEEDSS
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 04DEC07  -          LEEDSS 1        Created
 * 31Aug09	PAT03013   SAMANTS 1a	  R1M596492 - Long date format [ddMMyyyy] included
 * 18Nov11  OLE        DTZ             Add method parseBrainsDateTimeWithMinYear
 */
public class BrainsUtils {

    private static LoggerConnection logger = 
    	new LoggerConnection(BrainsUtils.class.getName());
    
    
    /**
     * Parse the given string as a date in the BRAINS format "ddMMyy".<p>
     *
     * @return <tt>null</tt> if the string is either <tt>null</tt> or empty.
     * @throws ParseException If the source String cannot be parsed as ddMMyy.
     */
    public static Date parseDate(String source)
    throws ParseException {
        if (source == null || source.length() == 0)
            return null;
        else {
        	try {
        		return (new SimpleDateFormat("ddMMyy")).parse(source);
        	}
    		/*
    		 * Log invalid parse data. This is to record data for known live
    		 * issues where BRAINS tokens do not appear to be returning
    		 * data in the ddMMyy format and throws PEs and NFEs.
    		 */
        	catch (ParseException pe) {
        		logBrainsDateParseException(pe, source);
        		throw pe;
        	} catch (NumberFormatException nfe) {
        		logBrainsDateParseException(nfe, source);
        		throw nfe;
        	}
        }
    }

    /**
     * Format used to transfer dates to and from Brains.
     * Includes a minimum year so that dates come out in the right century
     */
    public static Date parseBrainsDateTimeWithMinYear(String source)
    throws ParseException {
    	if (source == null || source.length() == 0)
            return null;
    	else {
        	try {
		    	SimpleDateFormat format = new SimpleDateFormat("ddMMyy");
		    	Calendar startDateCal = Calendar.getInstance();
		    	startDateCal.set(1950, 1, 1);
		    	format.set2DigitYearStart(startDateCal.getTime());
		    	return format.parse(source);
        	} catch (ParseException pe) {
        		logBrainsDateParseException(pe, source);
        		throw pe;
        	} catch (NumberFormatException nfe) {
        		logBrainsDateParseException(nfe, source);
        		throw nfe;
        	}
    	}
    }

    /**
     * Parse the given string as a date in the BRAINS format "ddMMyyyy".<p>
     *
     * @return <tt>null</tt> if the string is either <tt>null</tt> or empty.
     * @throws ParseException If the source String cannot be parsed as ddMMyyyy.
     */
    public static Date parseLongDate(String source)
    	throws ParseException {
        if (source == null || source.length() == 0)
            return null;
    	try {
    		return (new SimpleDateFormat("ddMMyyyy")).parse(source);
    	} catch (ParseException pe) { // log exception
    		logBrainsDateParseException(pe, source);
    		throw pe;
    	} catch (NumberFormatException nfe) {
    		logBrainsDateParseException(nfe, source);
    		throw nfe;
    	}
    }
    
    /**
     * Logs the specified exception generated when parsing a BRAINS date.
     * @param e
     * @param parseData
     */
    private static void logBrainsDateParseException(
    		Exception e, 
    		String parseData) {
    	if(parseData == null) parseData = "null";
		logger.error(
				e.getClass().getName() + 
				" - could not parse " + 
				parseData + 
				" as a BRAINS date.");
    }
}
