package com.barclays.staffware.plugin.util;

import static com.barclays.staffware.plugin.BaseCustomerPlugin.STAFFWAREMAP_LOCATION_CODE;
import static com.barclays.staffware.plugin.BaseCustomerPlugin.STAFFWAREMAP_USERNAME;
import static com.barclays.staffware.plugin.util.StaffwareHelper.STATUSCODE;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringUtils;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.bean.Country;
import com.barclays.generic.data.bean.RefValueBean;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.ioPayments.data.brains.AccountDetail;
import com.barclays.middleware.brains.BrainsConnectionException;
import com.barclays.middleware.brains.BrainsToken;
import com.barclays.middleware.brains.BrainsTokenException;
import com.barclays.middleware.brains.CAC_A;
import com.barclays.middleware.brains.CAC_L;
import com.barclays.middleware.brains.CCO_A;
import com.barclays.middleware.brains.CCO_L;
import com.barclays.middleware.brains.CEM_A;
import com.barclays.middleware.brains.CEM_L;
import com.barclays.middleware.brains.CNO_A;
import com.barclays.middleware.brains.CUS_A;
import com.barclays.middleware.brains.CUS_D;
import com.barclays.middleware.brains.CUS_I;
import com.barclays.middleware.brains.CUS_U;
import com.barclays.middleware.brains.RBA_U;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.dto.Account;
import com.barclays.staffware.plugin.dto.Contact;
import com.barclays.staffware.plugin.dto.Customer;
import com.barclays.staffware.plugin.dto.CustomerAccountAddResponse;
import com.barclays.staffware.plugin.dto.CustomerAccountAddUpdateRequest;
import com.barclays.staffware.plugin.dto.CustomerContactAddUpdateRequest;
import com.barclays.staffware.plugin.dto.CustomerEmployment;
import com.barclays.staffware.plugin.dto.CustomerEmploymentAddResponse;
import com.barclays.staffware.plugin.dto.CustomerEmploymentAddUpdateRequest;
import com.barclays.staffware.plugin.dto.CustomerNoteAddUpdateRequest;
import com.ibm.math.BigDecimal;

public class TokenHelper {
    private static final LoggerConnection logger = new LoggerConnection(TokenHelper.class);
    private static final String CUS_A_VERSION = "8";
    private static final String CEM_A_VERSION = "5";
    private static final String CNO_A_VERSION = "1";
    private static final String CCO_A_VERSION = "4";

    public static void addCustomerNote(CustomerNoteAddUpdateRequest request) throws Exception {
        CNO_A token = new CNO_A();

        // Enter params.
        token.setCustomerNumber(request.getCustomerNumber());
        token.setNoteAdditionDate(request.getNoteAdditionDate());
        token.setNoteType(request.getNoteType());
        token.setContactBranch(request.getContactBranch());
        token.setHostname(request.getHostname());
        token.setUsername(request.getUsername());
        token.setNote(request.getNote());
        token.setActionBy(request.getActionBy());
        token.setVersionNumber(Integer.toString(request.getVersionNumber()));

        token.setCountry(request.getCountry());
        token.setOffshore(request.isOffshore());


        try {
            executeToken(token);
        } catch (BrainsConnectionException bce) {
            throw new AddAmendCustomerException("", bce, AddAmendCusErrorScenario.CONN_BRAINS_CUS_DET_ADD);
        } catch (BrainsTokenException e) {
            // This catch block added for WP 775 Typhoon TC 15 to show appropriate error when BRAINS goes down in between the process
            throw new AddAmendCustomerException("", e, AddAmendCusErrorScenario.CONN_BRAINS_CUS_DET_ADD);
        } catch (Exception e) {
            throw new AddAmendCustomerException(e.getMessage(), e, AddAmendCusErrorScenario.BUSINESS_CUS_DET);
        }
    }

    public static void addCustomerContact(CustomerContactAddUpdateRequest request, boolean isAdd) throws AddAmendCustomerException, SQLException, DataAccessException {
        CCO_A token = new CCO_A();

        String emailAddress = request.getEmailAddress();
        boolean needWelcomePack = false;

        // Enter params.
        token.setCustomerNumber(request.getCustomerNumber());
        token.setPrimaryContact(request.getPrimaryContactIndicator());
        token.setContactType(request.getType());
        token.setAdviceMethod(request.getAdviceMethod());
        token.setStatementDeliveryPreference(
                request.getStatementDeliveryPreference());
        token.setContactName(request.getName());
        token.setPosition(request.getPosition());
        if (request.getDateOfBirth() != null) {
            token.setDateOfBirth(getBrainsLongDateFormat().format(request.getDateOfBirth()));
        }
        token.setMemorableName(request.getMemorableName());
        token.setAddressFirstLine(request.getAddressFirstLine());
        token.setPoBoxDetails(request.getPoBoxDetails());
        token.setTownCity(request.getTownCity());
        token.setDistrictRegion(request.getDistrictRegion());
        token.setContactCountry(request.getCountry());
        token.setPostcodeZip(request.getPostcodeZip());
        token.setPhoneNumber(request.getPhoneNumber());
        token.setMobileInternationalDialingCode(request.getMobileCountryCode());
        token.setMobileNumber(request.getMobileNumber());
        token.setEmailAddress(emailAddress);
        token.setAlternateEmailAddress(request.getAlternateEmailAddress());
        token.setComments(request.getComments());
        token.setFosUser(request.getFosUser());
        token.setHostName(request.getHostName());
        token.setVersionNumber(request.getVersionNumber());

        token.setFaxNumber(request.getFaxNumber());
        token.setMonthsAtCurrentAddress(request.getTimeAtAddressMonths() == null ?
                0 : request.getTimeAtAddressMonths().intValue());
        token.setYearsAtCurrentAddress(request.getTimeAtAddressYears() == null ?
                0 : request.getTimeAtAddressYears().intValue());
        token.setResidentialStatus(request.getResidentialStatus());
        token.setNumberOfDependents(request.getNumberOfDependents());
        token.setWorkPhone(request.getWorkPhone());
        token.setPlaceOfBirth(request.getPlaceOfBirth());
        token.setMaritalStatus(request.getMaritalStatus());

        token.setCountry(request.getBrainsCountry());
        token.setOffshore(request.isOffshore());

        String deliveryPreference = getActualStatementDeliveryCode(
                request.getStatementDeliveryPreference(),
                emailAddress,
                request.getDateOfBirth(),
                null,
                null);
        token.setStatementDeliveryPreference(deliveryPreference);

        Map<String, String> statementOptions = getMWRefValues(
                request.getBrainsCountry(),
                request.isOffshore(),
                "STMPRF",
                null);
        boolean eStatementsOn = !statementOptions.containsKey("DP");
        needWelcomePack = eStatementsOn && !isAdd &&
                ("DE".equals(deliveryPreference) || "EP".equals(deliveryPreference)
                        || "BP".equals(deliveryPreference));
        token.setWelcomePackRequired(needWelcomePack ? "W" : "N");

        try {
            token.execute();
        } catch (BrainsConnectionException bce) {
            throw new AddAmendCustomerException("", bce, AddAmendCusErrorScenario.CONN_BRAINS_CUS_DET_ADD);
        } catch (Exception e) {
            throw new AddAmendCustomerException(e.getMessage(), e, AddAmendCusErrorScenario.BUSINESS_CUS_DET);
        }
    }


    public static String getActualStatementDeliveryCode(
            String preferenceCode,
            String emailAddress,
            Date dateOfBirth,
            String oldEmail,
            String oldPreference)
    {
        if ("DD".equals(preferenceCode))
        {
            // update
            if (StringUtils.isNotBlank(oldPreference)) {
                // already on default paper and not changed any relevant fields (or don't exist)
                if ("DP".equals(oldPreference) &&
                        (dateOfBirth == null || StringUtils.isBlank(emailAddress)
                                || emailAddress.equals(oldEmail)))
                {
                    preferenceCode = "DP";
                }
                // on default email but removing email/DoB
                else if ("DE".equals(oldPreference) && (dateOfBirth == null ||
                        StringUtils.isBlank(emailAddress)))
                {
                    preferenceCode = "PP";
                }
                // everything else
                else {
                    preferenceCode = "DE";
                }
            }
            else {
                if (dateOfBirth == null || StringUtils.isBlank(emailAddress)) {
                    preferenceCode = "DP";
                }
                else {
                    preferenceCode = "DE";
                }
            }
        }

        return preferenceCode;
    }


    public static Map<String, String> getMWRefValues(String isoCode, boolean isOffshore, String domain, String code)
            throws SQLException, DataAccessException {
        try (SQLConnection conn = MWDBAccess.getDatabaseConnection()) {

            CallableStatement statement = null;
            ResultSet resultSet = null;

            isoCode = "".equals(isoCode) ? null : isoCode;
            domain = "".equals(domain) ? null : domain;
            code = "".equals(code) ? null : code;

            SortedMap<String, Object> params = new TreeMap<>();
            params.put("country", isoCode);
            params.put("offshoreInd", isOffshore?"1":"0");
            params.put("domain", domain);
            params.put("code", code);

            HashMap<String, String> result = new HashMap<>();

            try {
                statement = conn.prepareCall("dbo.wfe_MWRefValuesGet", params);
                resultSet = (ResultSet) conn.executeQuery(statement, params);

                while (resultSet.next()) {
                    result.put(resultSet.getString("Code"),
                            resultSet.getString("Description"));
                }
            } finally {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (statement != null) {
                    statement.close();
                }

                if(conn!=null){
                    conn.close();
                }

            }

            return result;
        }
    }

    public static SimpleDateFormat getBrainsLongDateFormat(){
        return new SimpleDateFormat("ddMMyyyy");
    }

    public static void deleteCustomer(Map<String, String> staffwareTransitionMap, String country, String offshoreInd, int customerNumber)
            throws Exception {
        CUS_D token = new CUS_D();
        token.setCustomerNumber(customerNumber);
        token.setCountry(country);
        token.setOffshore("1".equalsIgnoreCase(offshoreInd));
        token.setFosUser(staffwareTransitionMap.get(STAFFWAREMAP_USERNAME));
        token.setHostname(staffwareTransitionMap.get(STAFFWAREMAP_LOCATION_CODE));
        executeToken(token);
    }

    public static void updateCustomerDetails(Map<String, String> staffwareTransitionMap, Customer customer, String country, String offshoreInd, String versionNumber) throws Exception
    {
        CUS_U detailsUpdate = new CUS_U();

        // Enter params.
        detailsUpdate.setCustomerNumber(customer.getCustomerNumber());
        detailsUpdate.setBusinessType(customer.getBusinessType());
        detailsUpdate.setChargePackage(customer.getChargePackage());
        detailsUpdate.setCompanyName(customer.getCompanyName());
        detailsUpdate.setCompanyRegistrationNumber(customer.getCompanyRegNo());
        detailsUpdate.setCountryOfRegistration(customer.getCountryOfRegistrationCode());
        detailsUpdate.setCreditRating(customer.getCreditCheckResult());
        detailsUpdate.setCreditReference(customer.getCreditCheckReference());
        detailsUpdate.setCustomerRelationshipNote(customer.getRelationshipNote());
        detailsUpdate.setCustomerStatus(customer.getStatus());
        if (customer.getBusinessEstablishedDate()!= null) {
            detailsUpdate.setDateBusinessEstablished(DateUtil.getFormattedDate(customer.getBusinessEstablishedDate(), "ddMMyyyy"));
        }
        if (customer.getStatusDate() != null) {
            detailsUpdate.setDateOfStatus(BrainsToken.getBrainsDateFormat().format(customer.getStatusDate()));
        }
        detailsUpdate.setDdUnpayExcess(customer.getUnadvisedLimit());
        detailsUpdate.setDisplayName(customer.getDisplayName());
        detailsUpdate.setDrivingLicenceNumber(customer.getDrivingLicenceNumber());
        detailsUpdate.setFamilyName(customer.getFamilyName());
        detailsUpdate.setFirstName(customer.getFirstName());
        detailsUpdate.setFosuser(staffwareTransitionMap.get(STAFFWAREMAP_USERNAME));
        detailsUpdate.setGcisClientId(customer.getGcisId() == null ? 0 : Integer.parseInt(customer.getGcisId()));
        detailsUpdate.setGender(customer.getGender());
        detailsUpdate.setHostname(staffwareTransitionMap.get(STAFFWAREMAP_LOCATION_CODE));
        detailsUpdate.setIcaCaseId(customer.getIcaId());
        detailsUpdate.setIdCrdNumber(customer.getIdCardNumber());
        detailsUpdate.setIncomeTaxNumber(customer.getIncomeTaxNumber());
        detailsUpdate.setInternetBankInd(customer.isInternetBankingAccess() ? "Y" : "N");
        detailsUpdate.setKycStatus(customer.getKycStatus());
        if (StringUtils.isNotBlank(customer.getMarketSegment())) {
            detailsUpdate.setMarketSegment(Integer.parseInt(customer.getMarketSegment()));
        }
        detailsUpdate.setMarketingOptOut(customer.isMarketingOptOut() ? "Y" : "N");
        detailsUpdate.setPreferredMethodOfContact(customer.getPreferredMethodOfContact());
        detailsUpdate.setNationality(customer.getNationalityCode());

        detailsUpdate.setNatureOfBusiness(customer.getNobAdditionalInfo());
        detailsUpdate.setNatureOfBusinessCode(customer.getNatureOfBusiness());
        detailsUpdate.setPassportNumber(customer.getPassportNumber());
        detailsUpdate.setPropositionType(String.valueOf(customer.getPropositionType()));
        detailsUpdate.setRatePackage(customer.getRatePackage());
        if (customer.getCreditCheckDate() != null) {
            detailsUpdate.setRatingDate(BrainsToken.getBrainsDateFormat().format(customer.getCreditCheckDate()));
        }
        detailsUpdate.setReferCode(customer.getReferStream());
        if (customer.getRelationshipEstablishedDate() != null) {
            detailsUpdate.setRelationshipEstablished(BrainsToken.getBrainsDateFormat().format(customer.getRelationshipEstablishedDate()));
        }
        detailsUpdate.setResidency(customer.getResidencyCode());
        detailsUpdate.setTitle(customer.getTitle());
        detailsUpdate.setTurnover(customer.getTurnover());
        detailsUpdate.setVatClassification(customer.getVatClassification());
        detailsUpdate.setVatNumber(customer.getVatNumber());
        detailsUpdate.setCustomerRelationshipNote(customer.getRelationshipNote());
        detailsUpdate.setPepIndicator(customer.getPepInd());

        detailsUpdate.setTradingName(customer.getTradingName());
        boolean isCorporate  = "L".equalsIgnoreCase(String.valueOf(customer.getPropositionType())) ||
                "C".equalsIgnoreCase(String.valueOf(customer.getPropositionType())) ;
        String status = isCorporate ? customer.getOperatingStatus() : customer.getGeographicalStatus() ;
        detailsUpdate.setGeoOrOperStatus(status);
        detailsUpdate.setSolicitationChannel(customer.getSolicitationChannel());
        detailsUpdate.setVolumesExceeded(customer.getInitialDeposit());
        detailsUpdate.setEntityType(customer.getEntityType());
        detailsUpdate.setComplexStructure(customer.getComplexStructure());
        detailsUpdate.setCurrentCount(Integer.valueOf(customer.getCurrentAccount()));
        detailsUpdate.setSavingsCount(Integer.valueOf(customer.getSavingAccount()));
        detailsUpdate.setTermDepCount(Integer.valueOf(customer.getTermDeposit()));
        detailsUpdate.setInvestmentCount(Integer.valueOf(customer.getInvMgmt()));
        detailsUpdate.setSecuredCount(Integer.valueOf(customer.getSecuredLoanOrFinancing()));
        detailsUpdate.setSecuredCreditFinanceCount(Integer.valueOf(customer.getSecuredLoanCurrentFinance()));
        detailsUpdate.setUnsecuredCount(Integer.valueOf(customer.getUnsecuredLoanOrFinancing()));
        detailsUpdate.setTradeOrInsuranceCount(Integer.valueOf(customer.getTradePlanOrProducts()));

        int[] custNumbers = customer.getRelatedCustomerNumbers();

        String[] customerNumbers = new String[custNumbers.length];
        for (int i = 0; i < custNumbers.length; i++) {
            customerNumbers[i] = (new Integer(custNumbers[i])).toString();
        }

        detailsUpdate.setRelatedCustomers(customerNumbers);
        detailsUpdate.setRelationship(customer.getRelationships());

        int[] shareHolds = customer.getShareholdings();

        Integer[] shareHoldingss = new Integer[shareHolds.length];
        for (int i = 0; i < custNumbers.length; i++) {
            shareHoldingss[i] = (new Integer(shareHolds[i]));
        }

        detailsUpdate.setShareholding(shareHoldingss);
        detailsUpdate.setInverseRelationship(customer.getInverseRelationships());


        detailsUpdate.setRiskScore(customer.getRiskScore());
        detailsUpdate.setRiskLevel(customer.getRiskLevel());
        detailsUpdate.setCashVolume(customer.getExpectedCashVolume());
        detailsUpdate.setProhibitedAccountStatus(customer.getProhibitedAccountStatus());
        detailsUpdate.setIsAddedToKamls(customer.getIsAddedToKamls());

        //WP812: RBA Changes
        if(isRiskBasedKYCEnabled(country,offshoreInd)) {
            detailsUpdate.setRtsReferenceNumber(staffwareTransitionMap.get("rtsReferenceNumber"));
            String[] detailedProductsStr = staffwareTransitionMap.get("detailedProducts").split(Pattern.quote("/"));
            Country country1= fetchCountryDetails(country,offshoreInd);
            String[] detailedProductsIDsArr = getDetailedProductIDsForUI(detailedProductsStr,country1,customer.getMarketSegment(),Character.toString(customer.getPropositionType()));
            detailsUpdate.setDetailedProducts(detailedProductsIDsArr);
        }


        if (isCorporate) {
            detailsUpdate.setCountriesOfOperations(customer.getCountriesOfOperations());
            detailsUpdate.setCountriesTradedWith(customer.getCountriesTradedWith());
        } else {
            detailsUpdate.setExpectedTransToCountries(customer.getExpectedTransToCountries());
        }

        detailsUpdate.setVersionNumber(versionNumber);
        detailsUpdate.setCountry(country);
        detailsUpdate.setOffshore("1".equalsIgnoreCase(offshoreInd));

        try {
            executeToken(detailsUpdate);
        } catch (BrainsConnectionException bce) {
            throw new AddAmendCustomerException("", bce, AddAmendCusErrorScenario.CONN_BRAINS_CUS_DET_ADD); // TODO need a isAdd flag
        } catch (Exception e) {
            throw new AddAmendCustomerException(e.getMessage(), e, AddAmendCusErrorScenario.BUSINESS_CUS_DET);
        }

    }

    public static void fetchContacts(
            Customer customer,
            Country country)
            throws Exception
    {
        if (customer == null || country == null) {
            throw new IllegalArgumentException("Customer and country must both be specified.saveCustomer");
        }
        if (customer.getCustomerNumber() == -1) {
            throw new IllegalArgumentException("Customer was not properly identified.");
        }

        CCO_L token = new CCO_L();
        token.setCountry(country.getISOCode());
        token.setOffshore(country.isOffshore());
        token.setCustomerNumber(customer.getCustomerNumber());
        //token.setVersionNumber(3); //WP320
        token.setVersionNumber(4); //WP465
        token.execute();

        for (int i = 0; i < token.getRowCount(); i++) {
            Map<?, ?> row = token.getRow(i);
            Contact c = new Contact();
            c.setAddressFirstLine((String) row.get("ADDRESS_FIRST_LINE"));
            c.setComments((String) row.get("COMMENTS"));
            c.setCountry((String) row.get("COUNTRY"));
            c.setDateOfBirth(BrainsUtils.parseDate((String) row.get("DATE_OF_BIRTH")));
            c.setDistrictRegion((String) row.get("DISTRICT_OR_REGION"));
            c.setEmailAddress((String) row.get("EMAIL_ADDRESS"));
            c.setAlternateEmailAddress((String) row.get("ALT_EMAIL_ADDRESS"));
            c.setMemorableName((String) row.get("MEMORABLE_NAME"));
            String mobileInternationalCode = (String) row.get("MOBILE_INTERNATIONAL_DIALING_CODE");
            if (mobileInternationalCode != null && !"".equals(mobileInternationalCode)) {
                c.setMobileCountryCode(Integer.parseInt(mobileInternationalCode));
            }
            c.setMobileNumber((String) row.get("MOBILE_NUMBER"));
            c.setName((String) row.get("CONTACT_NAME"));
            c.setPhoneNumber((String) row.get("PHONE_NUMBER"));
            c.setPlaceOfBirth((String)row.get("PLACE_OF_BIRTH"));
            String numberOfDependants = (String) row.get("NUMBER_OF_DEPENDENTS");
            if (numberOfDependants != null && !"".equals(numberOfDependants)) c.setNumberOfDependents(Integer.parseInt(numberOfDependants));
            c.setPoBoxDetails((String) row.get("PO_BOX_DETAILS"));
            c.setPosition((String) row.get("POSITION"));
            c.setPostcodeZip((String) row.get("POSTCODE_OR_ZIP"));
            c.setPrimaryContactIndicator((String) row.get("PRIMARY_CONTACT_INDICATOR"));
            c.setSequenceNumber(Integer.parseInt((String) row.get("SEQUENCE_NUMBER")));
            c.setTownCity((String) row.get("TOWN_OR_CITY"));
            c.setType(((String) row.get("CONTACT_TYPE")).trim());
            c.setMaritalStatus(((String) row.get("MARITAL_STATUS")).trim());
            c.setResidentialStatus(((String) row.get("RESIDENTIAL_STATUS")).trim());
            c.setWorkPhone((String)row.get("WORK_PHONE"));
            String timeAtAddressYY = (String) row.get("YEARS_AT_CURRENT_ADDRESS");
            if (timeAtAddressYY != null && !"".equals(timeAtAddressYY)) {
                c.setTimeAtAddressYears(Integer.valueOf(timeAtAddressYY));
            }
            String timeAtAddressMM = (String) row.get("MONTHS_AT_CURRENT_ADDRESS");
            if (timeAtAddressMM != null && !"".equals(timeAtAddressMM)) {
                c.setTimeAtAddressMonths(Integer.valueOf(timeAtAddressMM));
            }
            customer.addContact(c);
            if (i == 0 && c.isPrimary()) {
                customer.setAddress(0, c.getAddressFirstLine());
            }
        }
    }


    public static void fetchAccounts(
            Customer customer,
            Country country,
            boolean unavailableAccounts)
            throws Exception
    {
        if (customer == null || country == null) {
            throw new IllegalArgumentException("Customer and country must both be specified.");
        }
        if (customer.getCustomerNumber() == -1) {
            throw new IllegalArgumentException("Customer was not properly identified.");
        }

        CAC_L token = new CAC_L();
        token.setCountry(country.getISOCode());
        token.setOffshore(country.isOffshore());
        token.setCustomerNumber(customer.getCustomerNumber());
        token.setVersion(4);
        token.setShowCustomers(false);
        token.execute();

        for (int i = 0; i < token.getRowCount(); i++) {
            Map<?, ?> row = token.getRow(i);
            if (!"CLOSED".equals(row.get("CONTACT_STATUS")))
            {
                String accountNumber = (String) row.get("BRANCH_NUMBER");
                Account a = new Account(Integer.parseInt(accountNumber.substring(0, 3)),
                        Integer.parseInt(accountNumber.substring(3)));
                a.setAccountType(Integer.parseInt((String) row.get("ACCOUNT_TYPE")));
                a.setShortName((String) row.get("SHORT_NAME"));
                a.setKamlsProductType((String) row.get("KAMLS_PRODUCT_TYPE"));
                a.setMandateInstruction((String)row.get("MANDATE_SUMMARY"));

                if (unavailableAccounts || isAvailable(a)) {
                    customer.addAccount(a);
                }
            }
        }
    }

    private static boolean isAvailable(Account account) {
        return account.getAccountNumber() != 0
                && !"<not available>".equalsIgnoreCase(account.getShortName());
    }

    public static int saveCustomer(Map<String, String> staffwareTransitionMap, String country, String offshoreInd) throws Exception {
        CUS_A detailsAdd = new CUS_A();

        // Enter params.
        detailsAdd.setBusinessType(staffwareTransitionMap.get("businessType"));
        detailsAdd.setChargePackage(staffwareTransitionMap.get("chargePackage"));
        detailsAdd.setCompanyName(staffwareTransitionMap.get("companyName"));
        detailsAdd.setCompanyRegistrationNumber(staffwareTransitionMap.get("companyRegNo"));
        detailsAdd.setCountryOfRegistration(staffwareTransitionMap.get("countryOfRegistration"));
        detailsAdd.setCreditRating(staffwareTransitionMap.get("credChkResult"));
        detailsAdd.setCreditReference(staffwareTransitionMap.get("credChkReference"));
        detailsAdd.setCustomerRelationshipNote(staffwareTransitionMap.get("relatedCustomerNotes"));
        detailsAdd.setCustomerStatus(staffwareTransitionMap.get("status"));
        if (StringUtils.isNotBlank(staffwareTransitionMap.get("businessEstablishedDate"))) {
            detailsAdd.setDateBusinessEstablished(DateUtil.getFormattedDate(new SimpleDateFormat("dd/MM/yyyy").parse(staffwareTransitionMap.get("businessEstablishedDate")), "ddMMyyyy"));
        }

        Date businessDate = new GlobalDetailsEnquiry(new Country(country, "1".equalsIgnoreCase(offshoreInd))).getBusinessDate();
        if (businessDate != null) {
            detailsAdd.setDateOfStatus(BrainsToken.getBrainsDateFormat().format(businessDate));
        }
        detailsAdd.setDdUnpayExcess(getSafeBigDecimal(staffwareTransitionMap.get("unadvisedLimit")));
        detailsAdd.setDisplayName(getDisplayName(staffwareTransitionMap));
        detailsAdd.setDrivingLicenceNumber(staffwareTransitionMap.get("drivingLicenceNumber"));
        detailsAdd.setFamilyName(staffwareTransitionMap.get("familyName"));
        detailsAdd.setFirstName(staffwareTransitionMap.get("firstName"));

        detailsAdd.setFosuser(staffwareTransitionMap.get(STAFFWAREMAP_USERNAME));

        detailsAdd.setGcisClientId(gcisIdOrZero(staffwareTransitionMap));
        detailsAdd.setGender(staffwareTransitionMap.get("gender"));
        detailsAdd.setHostname(staffwareTransitionMap.get(STAFFWAREMAP_LOCATION_CODE));
        detailsAdd.setIcaCaseId(staffwareTransitionMap.get("icaId"));
        detailsAdd.setIdCrdNumber(staffwareTransitionMap.get("idCardNumber"));
        detailsAdd.setIncomeTaxNumber(staffwareTransitionMap.get("incomeTaxNumber"));
        detailsAdd.setInternetBankInd(Boolean.parseBoolean(staffwareTransitionMap.get("internetBankingAccess")) ? "Y" : "N");
        detailsAdd.setKycStatus(staffwareTransitionMap.get("kycStatus"));
        if (StringUtils.isNotBlank(staffwareTransitionMap.get("marketSegment"))) {
            detailsAdd.setMarketSegment(Integer.parseInt(staffwareTransitionMap.get("marketSegment")));
        }
        detailsAdd.setMarketingOptOut(Boolean.parseBoolean(staffwareTransitionMap.get("marketingOptOut")) ? "Y" : "N");
        detailsAdd.setPreferredMethodOfContact(staffwareTransitionMap.get("preferredMethodOfContact"));
        detailsAdd.setNationality(staffwareTransitionMap.get("nationality"));
        // AFM10533 - nature of business code and NOB additional info values were interchanged
        detailsAdd.setNatureOfBusiness(staffwareTransitionMap.get("nobAdditionalInfo"));
        detailsAdd.setNatureOfBusinessCode(staffwareTransitionMap.get("natureOfBusiness"));
        detailsAdd.setPassportNumber(staffwareTransitionMap.get("passportNumber"));
        detailsAdd.setPropositionType(staffwareTransitionMap.get("propositionType"));
        detailsAdd.setRatePackage(staffwareTransitionMap.get("ratePackage"));
        if (StringUtils.isNotBlank(staffwareTransitionMap.get("credChkDate"))) {
            detailsAdd.setRatingDate(BrainsToken.getBrainsDateFormat().format(DateUtil.getFormattedDate(staffwareTransitionMap.get("credChkDate"), true)));
        }
        if (StringUtils.isNotBlank(staffwareTransitionMap.get("referStream"))) {
            detailsAdd.setReferCode(Integer.parseInt(staffwareTransitionMap.get("referStream")));
        }
        if (StringUtils.isNotBlank(staffwareTransitionMap.get("relationshipEstablishedDate"))) {
            detailsAdd.setRelationshipEstablished(BrainsToken.getBrainsDateFormat().format(DateUtil.getFormattedDate(staffwareTransitionMap.get("relationshipEstablishedDate"))));
        }
        detailsAdd.setResidency(staffwareTransitionMap.get("residency"));
        detailsAdd.setTitle(staffwareTransitionMap.get("title"));
        detailsAdd.setVatClassification(staffwareTransitionMap.get("vatClassification"));
        detailsAdd.setVatNumber(staffwareTransitionMap.get("vatNumber"));
        detailsAdd.setVersionNumber("8");
        detailsAdd.setTurnover(getSafeBigDecimal(staffwareTransitionMap.get("turnover")));
        detailsAdd.setCustomerRelationshipNote(staffwareTransitionMap.get("relatedCustomerNotes"));
        detailsAdd.setPepIndicator(staffwareTransitionMap.get("pepInd"));

        detailsAdd.setTradingName(staffwareTransitionMap.get("tradingName"));
        boolean isCorporate  = isCorporateType(staffwareTransitionMap.get("propositionType"));
        String status = isCorporate ? staffwareTransitionMap.get("operatingStatus") :staffwareTransitionMap.get("geographicalStatus") ;
        detailsAdd.setGeoOrOperStatus(status);
        detailsAdd.setSolicitationChannel(staffwareTransitionMap.get("solicitationChannel"));
        detailsAdd.setVolumesExceeded(staffwareTransitionMap.get("initialDeposit"));
        detailsAdd.setEntityType(staffwareTransitionMap.get("entityType"));
        detailsAdd.setComplexStructure(staffwareTransitionMap.get("complexStructure"));
        detailsAdd.setCurrentCount(Integer.valueOf(staffwareTransitionMap.get("currentAccount")));
        detailsAdd.setSavingsCount(Integer.valueOf(staffwareTransitionMap.get("savingAccount")));
        detailsAdd.setTermDepCount(Integer.valueOf(staffwareTransitionMap.get("termDeposit")));
        detailsAdd.setInvestmentCount(Integer.valueOf(staffwareTransitionMap.get("invMgmt")));
        detailsAdd.setSecuredCount(Integer.valueOf(staffwareTransitionMap.get("securedLoanOrFinancing")));
        detailsAdd.setSecuredCreditFinanceCount(Integer.valueOf(staffwareTransitionMap.get("securedLoanCurrentFinance")));
        detailsAdd.setUnsecuredCount(Integer.valueOf(staffwareTransitionMap.get("unsecuredLoanOrFinancing")));
        detailsAdd.setTradeOrInsuranceCount(Integer.valueOf(staffwareTransitionMap.get("tradePlanOrProducts")));
        detailsAdd.setRelatedCustomers(spaceSeparatedToStringArray(staffwareTransitionMap.get("relatedCustomerNumbers")));
        detailsAdd.setRelationship(spaceSeparatedToStringArray(staffwareTransitionMap.get("relationships")));
        detailsAdd.setShareholding(spaceSeparatedToIntArray(staffwareTransitionMap.get("shareholdings")));

        detailsAdd.setInverseRelationship(spaceSeparatedToStringArray(staffwareTransitionMap.get("inverseRelationships")));
        detailsAdd.setRiskScore(staffwareTransitionMap.get("riskScore"));
        detailsAdd.setRiskLevel(staffwareTransitionMap.get("riskLevel"));
        detailsAdd.setCashVolume(staffwareTransitionMap.get("expectedCashVolume"));

        detailsAdd.setProhibitedAccountStatus(staffwareTransitionMap.get("prohibitedAccountStatus"));
        detailsAdd.setIsAddedToKamls(staffwareTransitionMap.get("isAddedToKamls"));
        //WP812
        detailsAdd.setRtsReferenceNumber(staffwareTransitionMap.get("rtsReferenceNumber"));

        if (isCorporate) {
            detailsAdd.setCountriesOfOperations(getCountryCodes(slashSeparatedToStringArray(staffwareTransitionMap.get("countriesOfOperations"))));
            detailsAdd.setCountriesTradedWith(getCountryCodes(slashSeparatedToStringArray(staffwareTransitionMap.get("countriesTradedWith"))));
        } else {
            detailsAdd.setExpectedTransToCountries(getCountryCodes(slashSeparatedToStringArray(staffwareTransitionMap.get("expectedTransToCountries"))));
        }

        detailsAdd.setCountry(country);
        detailsAdd.setOffshore("1".equals(offshoreInd));

        try {
            executeToken(detailsAdd);
        } catch (BrainsConnectionException bce) {
            throw new AddAmendCustomerException("", bce, AddAmendCusErrorScenario.CONN_BRAINS_CUS_A);
        } catch (Exception e) {
            throw new AddAmendCustomerException(e.getMessage(), e, AddAmendCusErrorScenario.BUSINESS_CUS_A);
        }

        return detailsAdd.getCustomerNumber();

    }

    public static BigDecimal getSafeBigDecimal(String number) {
        BigDecimal bd = null;
        try {
            bd = new BigDecimal(number);
        } catch (Exception e) {
            // field empty / not a number, ignore and return null
        }
        return bd;
    }

    private static Integer[] spaceSeparatedToIntArray(String shareholdings) {
        String[] items = shareholdings.split(" ");

        Integer[] ints = new Integer[items.length];

        if (StringUtils.isNotBlank(shareholdings)) {
            int i = 0;
            for (String item : items) {
                ints[i++] = Integer.parseInt(item);
            }
        }
        return ints;
    }

    private static String[] spaceSeparatedToStringArray(String spaceSeparatedStrings) {
        return stringToArray(spaceSeparatedStrings, " ");
    }

    private static String[] slashSeparatedToStringArray(String countryList) {
        return stringToArray(countryList, "/");
    }

    private static String[] stringToArray(String theString, String separator) {
        return theString.split(separator);
    }

    private static String getDisplayName(Map<String, String> staffwareTransitionMap) {

        String displayName = "";
        if (TokenHelper.isCorporateType(staffwareTransitionMap.get("propositionType"))) {
            displayName = staffwareTransitionMap.get("companyName");
        } else {
            String firstName = staffwareTransitionMap.get("firstName").trim();
            String familyName = staffwareTransitionMap.get("familyName").trim();
            if (familyName.length() > 33) {
                displayName = familyName;
            } else {
                if ((firstName.length() + familyName.length() + 1) <= 35)
                    displayName = firstName + " " + familyName;
                else {
                    String firstN = "";
                    int ind = firstName.indexOf(" ");
                    if (ind != -1)
                        firstN = firstName.substring(0, ind);
                    else
                        firstN = firstName;
                    if ((firstN.length() + familyName.length() + 1) <= 35) {
                        displayName = firstN + " " + familyName;
                    } else {
                        displayName = firstName.charAt(0) + " " + familyName;
                    }
                }
            }
        }
        return displayName;
    }


    private static int gcisIdOrZero(Map<String, String> staffwareTransitionMap) {
        String gcisId = staffwareTransitionMap.get("gcisId") ;

        if (StringUtils.isNotBlank(gcisId) && StringUtils.isNumeric(gcisId)) {
            return Integer.parseInt(gcisId);
        } else {
            return 0;
        }
    }

    public static boolean isCorporateType(String propType) {
        return ("L".equals(propType) || "C".equals(propType));
    }

    private static boolean isLocalBusinessType(String propType) {
        return ("L".equals(propType));
    }

    public static void addCustomerEmployment(CustomerEmploymentAddUpdateRequest request, CustomerEmploymentAddResponse response) throws Exception {
        CEM_A empEnquiry = new CEM_A();
        // enter params
        empEnquiry.setVersionNumber(request.getVersionNumber());
        empEnquiry.setAddressFirstLine(request.getAddressFirstLine());
        if(request.getContractExpiryDate() == null) {
            empEnquiry.setContractExpiryDate("");
        }
        else {
            empEnquiry.setContractExpiryDate(BrainsToken.getBrainsDateFormat().format(request.getContractExpiryDate()));
        }
        empEnquiry.setCountry(request.getCountry());
        empEnquiry.setCustomerNumber(request.getCustomerNumber());
        empEnquiry.setDistrict(request.getDistrict());
        empEnquiry.setEmpContactName(request.getEmpContactName());
        empEnquiry.setEmpContactNumber(request.getEmpContactNumber());
        empEnquiry.setEmployer(request.getEmployer());
        empEnquiry.setEmployeeNumber(request.getEmployeeNumber());
        empEnquiry.setEmployerEmail(request.getEmployerEmail());
        empEnquiry.setEmploymentStatus(request.getEmploymentStatus());
        empEnquiry.setEmploymentStatusDate(request.getEmploymentStatusDate());
        empEnquiry.setEmploymentType(request.getEmploymentType());
        empEnquiry.setFosuser(request.getFosuser());
        empEnquiry.setGrossCur(request.getGrossCur());
        empEnquiry.setGrossIncome(request.getGrossIncome());
        empEnquiry.setHostname(request.getHostname());
        empEnquiry.setJobTitle(request.getJobTitle());
        empEnquiry.setLengthMonths(request.getLengthMonths());
        empEnquiry.setLengthYears(request.getLengthYears());
        empEnquiry.setNatureOfBusiness(request.getNatureOfBusiness());
        empEnquiry.setOffshore(request.isOffshore());
        empEnquiry.setOtherCur(request.getOtherCur());
        empEnquiry.setOtherIncome(request.getOtherIncome());
        empEnquiry.setPoBoxDetails(request.getPoBoxDetails());
        empEnquiry.setPostcode(request.getPostcode());
        empEnquiry.setTown(request.getTown());
        empEnquiry.setSourceOfFunds(request.getSourceOfFunds());
        empEnquiry.setDesignation(request.getDesignation());


        try{
            executeToken(empEnquiry);
        } catch (BrainsConnectionException bce) {
            throw new AddAmendCustomerException("", bce, AddAmendCusErrorScenario.CONN_BRAINS_CUS_DET_ADD);
        } catch (Exception e) {
            throw new AddAmendCustomerException(e.getMessage(), e, AddAmendCusErrorScenario.BUSINESS_CUS_DET);
        }


        // retrieve return values
        // only expecting one row so more than one will over write earlier row
        for (int i = 0; i < empEnquiry.getRowCount(); i++) {
            HashMap row = empEnquiry.getRow(i);
            response.setSequenceNumber( Integer.parseInt(((String)row.get("SEQUENCE_NUMBER"))));
        }
    }

    public static void fetchAccountDetails(Account account, String country, String offshoreInd) throws Exception  {
        if (account == null || country == null) {
            throw new IllegalArgumentException("Account and country must both be specified.");
        }
        if (account.getBranchNumber() == -1 || account.getAccountNumber() == -1) {
            throw new IllegalArgumentException("Account was not properly identified.");
        }

        Map<String, Object> result = AccountDetail.getAccountDetail(
                country, "1".equalsIgnoreCase(offshoreInd),
                account.getAccountNumber(), account.getBranchNumber(), 8);

        if ("-1".equals(result.get(STATUSCODE))) {
            throw new Exception(
                    MessageFormat.format(
                            "No account details available for Account: {0,number,000} / {1,number,0000000}",
                            new Object[]{new Integer(account.getBranchNumber()),
                                    new Integer(account.getAccountNumber())}));
        }

        copyAccountDetails(account, result);
        determineAccountReferIndicator(account);
    }

    private static void determineAccountReferIndicator(Account account) {
        int msgKey = account.getReferCredits() * 4
                + account.getReferDebits() * 2
                + account.getReferNonChequeDebits();
        Map<String, String> referIndicators = new HashMap<>();
        referIndicators.put("0", "");
        referIndicators.put("1", "REFER NON-CHEQUE DEBITS");
        referIndicators.put("2", "REFER DEBITS");
        referIndicators.put("3", "REFER DEBITS & NON-CHEQUE DEBITS");
        referIndicators.put("4", "REFER CREDITS");
        referIndicators.put("5", "REFER CREDITS & NON-CHEQUE DEBITS");
        referIndicators.put("6", "REFER CREDITS & DEBITS");
        referIndicators.put("7", "REFER CREDITS & DEBITS");

        account.setReferIndicator(referIndicators.get(msgKey + ""));
    }

    protected static void copyAccountDetails(Account a, Map<String, Object> source) throws Exception {
        a.setCurrency((String) source.get("ACCOUNT_CUR"));
        a.setStatus((String) source.get("ACCOUNT_STATUS"));
        a.setAccountType(Integer.parseInt((String) source.get("ACCOUNT_TYPE")));
        a.setOpenDate(BrainsUtils.parseDate((String) source.get("ACCT_OPEN_DATE")));
        a.setAddressContactName((String) source.get("ADDRESS_CONTACT_NAME"));
        a.setAddressSeqNumber(Integer.parseInt((String) source.get("ADDRESS_SEQ_NUMBER")));
        a.setAddress(0,(String) source.get("ADDRESS1"));
        a.setAddress(1,(String) source.get("ADDRESS2"));
        a.setAddress(2,(String) source.get("ADDRESS3"));
        a.setAtmClass(Integer.parseInt((String) source.get("ATM_CLASS")));
        a.setFeatureType((String) source.get("BANKACCTFEATTYPE"));
        a.setCreditIntDate(BrainsUtils.parseDate((String) source.get("CREDIT_INT_DATE")));
        a.setCurrActBal(getSafeBigDecimal((String) source.get("CURACTBAL")));
        a.setCurrLocBal(getSafeBigDecimal((String) source.get("CURACTLOCBAL")));
        a.setCurrAvlBal(getSafeBigDecimal((String) source.get("CURAVAILBAL")));
        a.setCurrEarBal(getSafeBigDecimal((String) source.get("CUREARBAL")));
        a.setCurrUncBal(getSafeBigDecimal((String) source.get("CURUNCLBAL")));
        a.setDebitIntDate(BrainsUtils.parseDate((String) source.get("DEBIT_INT_DATE")));
        a.setDebitLimit(getSafeBigDecimal((String) source.get("DEBIT_LIMIT")));
        a.setDesignationId((String) source.get("DESIGNATION_ID"));
        a.setDesignationDesc((String) source.get("DESIGNATION_NARRATIVE"));
        a.setDebitLimitExpiryDate(BrainsUtils.parseBrainsDateTimeWithMinYear((String)source.get("EXPIRY_DATE")));
        a.setExternal(((String) source.get("EXTERNAL_IND")).equals("1"));
        a.setKycDate(BrainsUtils.parseDate((String) source.get("KYC_DATE")));
        a.setKycInd(Integer.parseInt((String) source.get("KYC_IND")));
        a.setLastCreditPostDate(BrainsUtils.parseDate((String) source.get("LAST_CREDIT_POST_DATE")));
        a.setLastEntryPostDate(BrainsUtils.parseDate((String)source.get("LAST_ENTRY_POST_DATE")));
        a.setLastStmtDate(BrainsUtils.parseDate((String) source.get("LAST_STMT_DATE")));
        a.setLongName((String) source.get("LONG_NAME"));
        a.setMarketSegCode(Integer.parseInt((String)source.get("MARKET_SEGMENT_CODE")));
        a.setMarketSegDesc((String) source.get("MARKET_SEGMENT_NARRATIVE"));
        a.setNote(0,(String) source.get("NOTES_LINE_1"));
        a.setNote(1,(String) source.get("NOTES_LINE_2"));
        a.setNote(2,(String) source.get("NOTES_LINE_3"));
        a.setOpenActBal(getSafeBigDecimal((String) source.get("OPENACTBAL")));
        a.setOpenLocBal(getSafeBigDecimal((String) source.get("OPENACTLOCBAL")));
        a.setOpenAvlBal(getSafeBigDecimal((String) source.get("OPENAVAILBAL")));
        a.setOpenEarBal(getSafeBigDecimal((String) source.get("OPENEARBAL")));
        a.setOpenUncBal(getSafeBigDecimal((String) source.get("OPENUNCLBAL")));
        a.setPendingItems(Integer.parseInt((String)source.get("PENDING_ITEMS_IND"))==1);
        a.setReferCode(Integer.parseInt((String) source.get("REFER_CODE")));
        a.setReferCredits(Integer.parseInt((String)source.get("REFER_CREDITS")));
        a.setReferDebits(Integer.parseInt((String) source.get("REFER_DEBITS")));
        a.setReferNonChequeDebits(Integer.parseInt((String) source.get("REFER_NON_CHEQUE_DEBITS")));
        a.setRiskLevel3( Integer.parseInt((String) source.get("RISK_LEVEL_3")) == 1);
        a.setRiskLevel3Score(Integer.parseInt((String) source.get("RISK_LEVEL_3")));
        a.setRiskLevelBBG(getSafeBigDecimal((String)source.get("RISK_LEVEL_BBG")));
        a.setRiskLevelEWL(getSafeBigDecimal((String) source.get("RISK_LEVEL_EWL")));
        a.setShortName((String) source.get("SHORT_NAME"));
        a.setStatusNarrative((String) source.get("STATUS_NARRATIVE"));
        a.setStatementFreq((String) source.get("STMT_FREQ"));
        a.setStatementFreqData((String) source.get("STMT_FREQ_DATA"));
        a.setStoppedCheques(Integer.parseInt((String)source.get("STOPPED_CHEQUES_IND")) == 1);
        a.setTypeNarrative((String) source.get("TYPE_NARRATIVE"));
        a.setHasSignatures(Integer.parseInt((String) source.get("SIGNATURES_IND")) > 0);
        a.setIban((String) source.get("IBAN"));
        a.setOriginalLoanAmount(getSafeBigDecimal((String)source.get("ORIGINAL_LOAN_AMOUNT")));
        a.setAccruedCreditInterest(getSafeBigDecimal((String)source.get("ACCRUEDCREDITINTEREST")));
        a.setAccruedDebitInterest(getSafeBigDecimal((String)source.get("ACCRUEDDEBITINTEREST")));

        a.setPopulated(true);
    }

    public static void fetchCustomerDetails(Customer customer, String country, String offshoreInd) throws Exception {
        if (customer == null || country == null) {
            throw new IllegalArgumentException(
                    "Customer and country must both be specified.");
        }
        if (customer.getCustomerNumber() == -1) {
            throw new IllegalArgumentException(
                    "Customer was not properly identified.");
        }

        CUS_I token = new CUS_I();
        token.setCountry(country);
        token.setOffshore("1".equalsIgnoreCase(offshoreInd));
        token.setCustomerNumber(customer.getCustomerNumber());

        try {
            token.execute();
        } catch (BrainsConnectionException bce) {
            throw new AddAmendCustomerException("", bce, AddAmendCusErrorScenario.CONN_BRAINS_CUS_DET_AMEND); // TODO need a isAdd flag?
        } catch (Exception e) {
            throw new AddAmendCustomerException(e.getMessage(), e, AddAmendCusErrorScenario.BUSINESS_BRAINS_OR_KAMLS);
        }


        Map<?, ?> result = token.getHeader();
        if (result.get("CUSTOMER_NUMBER") == null) {
            throw new Exception("No customer details available.");
        }

        customer.setCountry(country);
        copyCustomerDetails(customer, result);
    }

    protected static void copyCustomerDetails( Customer c,Map<?, ?> source) throws Exception {
        c.setBusinessEstablishedDate(BrainsUtils.parseLongDate((String) source.get("DATE_BUSINESS_ESTABLISHED")));
        c.setBusinessType((String) source.get("BUSINESS_TYPE"));
        c.setCompanyName((String) source.get("COMPANY_NAME"));
        c.setCompanyRegNo((String) source.get("COMPANY_REGISTRATION_NUMBER"));
        c.setCustomerNumber(Integer.parseInt((String)source.get("CUSTOMER_NUMBER")));
        c.setDisplayName((String) source.get("DISPLAY_NAME"));
        c.setFamilyName((String) source.get("FAMILY_NAME"));
        c.setFirstName((String) source.get("FIRST_NAME"));
        c.setGcisId((String) source.get("GCIS_CLIENT_ID"));
        c.setIcaId((String) source.get("ICA_CASE_ID"));
        c.setIdCardNumber((String) source.get("ID_CARD_NUMBER"));
        c.setMarketSegment((String) source.get("MARKET_SEGMENT"));
        c.setMarketingOptOut("Y".equals(source.get("MARKETING_OPT_OUT")));
        String prefMethodContact = ((String)source.get("PREFERRED_METHOD_OF_CONTACT")).trim();
        //QC #2289 (Africa_Account_Opening_MIG)
        //BRAINS has CHAR(1) for this field, so no blank strings allowed.
        //The char gets interpreted as ' ' therefore trim the value here.
        c.setPreferredMethodOfContact(prefMethodContact.trim());
        c.setInternetBankingAccess("Y".equals(source.get("INTERNET_BANK_IND")));
        // AFM10533 - nature of business code and NOB additional info values were interchanged
        c.setNatureOfBusiness(((String) source.get("NATURE_OF_BUSINESS_CODE")).trim());

        c.setPassportNumber((String) source.get("PASSPORT_NUMBER"));
        c.setPrimaryAccountNumber(parsePrimaryAccount((String) source.get("PRIMARY_ACCOUNT")));
        String proposition = (String) source.get("PROPOSITION");
        if (proposition != null && proposition.length() > 0) {
            c.setPropositionType(proposition.charAt(0));
        }
        c.setReferDescription((String) source.get("REFER_DESC"));
        String referCode = (String) source.get("REFER_CODE");
        if (referCode != null && referCode.length() > 0) {
            c.setReferStream(Integer.parseInt(referCode));
        }
        c.setRelationshipEstablishedDate(BrainsUtils.parseDate((String) source.get("RELATIONSHIP_ESTABLISHED")));
        c.setRelationshipNote((String) source.get("CUSTOMER_RELATIONSHIP_NOTE"));
        c.setStatus((String) source.get("CUSTOMER_STATUS"));
        c.setStatusDate(BrainsUtils.parseDate((String) source.get("DATE_OF_STATUS")));
        c.setTitle((String) source.get("TITLE"));
        c.setVatClassification(((String) source.get("VAT_CLASSIFICATION")).trim());
        c.setVatNumber((String) source.get("VAT_NUMBER"));

        //NOW BRAINS STORE CODE AND EBOX NEEDS COUNTRY NAME SOME OF THE PLACES
        String residencyCode = (source.get("RESIDENCY")== null) ? "" : source.get("RESIDENCY").toString().trim();
        String nationalityCode = (source.get("NATIONALITY")== null) ? "" : source.get("NATIONALITY").toString().trim();
        String countryOfRegistrationCode = (source.get("COUNTRY_OF_REGISTRATION")== null) ? "" : source.get("COUNTRY_OF_REGISTRATION").toString().trim();
        String countryNames[] = getCountryNames(new String[]{residencyCode,nationalityCode,countryOfRegistrationCode});

        c.setResidencyCode(residencyCode);
        c.setNationalityCode(nationalityCode);
        c.setCountryOfRegistrationCode(countryOfRegistrationCode);
        c.setResidency(countryNames[0]);
        c.setNationality(countryNames[1]);
        c.setCountryOfRegistration(countryNames[2]);

        String unadvisedLimit = (String) source.get("DD_UNPAY_EXCESS");
        if (unadvisedLimit == null || "".equals(unadvisedLimit)) {
            unadvisedLimit = "0.00";
        }
        c.setUnadvisedLimit(getSafeBigDecimal(unadvisedLimit).setScale(2, BigDecimal.ROUND_CEILING));

        c.setCreditCheckResult((String) source.get("CREDIT_RATING"));
        c.setCreditCheckReference((String) source.get("CREDIT_RATING_REFERENCE"));
        c.setCreditCheckDate(BrainsUtils.parseDate((String) source.get("CREDIT_RATING_DATE")));
        c.setPepInd((String) source.get("PEP_INDICATOR"));
        c.setDrivingLicenceNumber((String) source.get("DRIVER_LICENSE_DETAILS"));
        c.setIncomeTaxNumber((String) source.get("INCOME_TAX_NUMBER"));

        c.setGender((String) source.get("GENDER"));
        c.setKycStatus((String) source.get("KYC_STATUS"));
        String turnover = (String) source.get("TURNOVER");
        if (turnover == null || "".equals(turnover)) {
            turnover = "0.00";
        }
        c.setTurnover(getSafeBigDecimal(turnover).setScale(2, BigDecimal.ROUND_CEILING));
        c.setRelatedCustomerNumbers((Object[])source.get("RELATED_CUSTOMERS"));
        c.setChargePackage(((String)source.get("CHARGE_PACKAGE")).trim());
        c.setRatePackage(((String)source.get("RATE_PACKAGE")).trim());

        //261
        c.setTradingName((String)source.get("TRADING_NAME"));
        // AFM10533 - nature of business code and NOB additional info values were interchanged
        c.setNobAdditionalInfo(((String)source.get("NATURE_OF_BUSINESS")).trim());
        c.setGeographicalStatus(((String)source.get("GEO_OR_OPER_CODE")).trim());
        c.setOperatingStatus(((String)source.get("GEO_OR_OPER_CODE")).trim());
        c.setSolicitationChannel(((String)source.get("SOLICITATION_CHANNEL")).trim());
        c.setInitialDeposit(((String)source.get("VOLUMES_EXCEEDED")).trim());
        c.setEntityType(((String)source.get("ENTITY_TYPE")).trim());
        String complexStructure = (String)source.get("COMPLEX_STRUCTURE");
        complexStructure = "".equals(complexStructure.trim())? "N" : complexStructure.trim();
        c.setComplexStructure(complexStructure);
        c.setCurrentAccount((String)source.get("CURRENT_COUNT"));
        c.setSavingAccount((String)source.get("SAVINGS_COUNT"));
        c.setTermDeposit((String)source.get("TERM_DEP_COUNT"));
        c.setInvMgmt((String)source.get("INVESTMENT_COUNT"));
        c.setSecuredLoanOrFinancing((String)source.get("SECURED_COUNT"));
        c.setUnsecuredLoanOrFinancing((String)source.get("UNSECURED_COUNT"));
        c.setTradePlanOrProducts((String)source.get("TRADE_OR_INSURANCE_COUNT"));
        c.setSecuredLoanCurrentFinance((String)source.get("SECURED_CREDIT_FINANCE_COUNT"));
        c.setRelationships((Object[])source.get("RELATIONSHIP"));
        c.setShareholdings((Object[])source.get("SHAREHOLDING"));
        c.setInverseRelationships((Object[])source.get("INVERSE_RELATIONSHIP"));
        c.setRiskScore((String)source.get("RISK_SCORE"));
        c.setRiskLevel(source.get("RISK_LEVEL").toString().trim());
        c.setExpectedTransToCountries((Object[])source.get("EXPECTED_TRAN"));
        c.setCountriesOfOperations((Object[])source.get("COUNTRY_OPERATIONS"));
        c.setCountriesTradedWith((Object[])source.get("COUNTRY_TRADED"));
        c.setExpectedCashVolume((String)source.get("CASH_VOLUME"));

        c.setProhibitedAccountStatus(((String)source.get("PROHIBITED_ACCOUNT_STATUS")).trim());
        c.setIsAddedToKamls((String)source.get("IS_ADDED_TO_KAMLS"));
        //WP812
        c.setRtsReferenceNumber((String)source.get("RTS_REFERENCE_NUMBER"));
    }

    private static String parsePrimaryAccount(String source) {
        if (source == null || source.length() == 0)
            return null;
        else {
            Matcher m = Pattern.compile(", (\\d{3} \\d{7}),").matcher(source);
            if (!m.find())
                return null;
            else
                return source.substring(m.start(1), m.end(1));
        }
    }

    public static String[] getCountryNames(String[] countryCodes)
            throws Exception {
        try (SQLConnection db = MWDBAccess.getDatabaseConnection()) {
            CallableStatement cs = db.prepareCall("dbo.wfe_EChannelCountriesOnshoreGet", null);
            ResultSet rs = null;
            try {
                rs = db.executeQuery(cs, new TreeMap<String, Object>());

                HashMap<String, String> countryNames = new HashMap<String, String>();
                while(rs.next()) {
                    countryNames.put(rs.getString("CountryISOCode").trim(), rs.getString("Name").trim());
                }

                String[] finalCountryNames = new String[countryCodes.length];
                if(countryCodes.length > 0 && countryCodes[0] != null) {
                    if("".equalsIgnoreCase(countryCodes[0].trim())&& countryCodes.length == 1){
                        finalCountryNames[0] = "" ;
                    } else  {
                        for(int i=0; i<countryCodes.length; i++)
                        {
                            String countryName = countryNames.get(countryCodes[i].trim());
                            finalCountryNames[i] = countryName == null ? "" : countryName;
                        }
                    }
                }
                return finalCountryNames;
            }
            finally {
                cs.close();
                if(rs != null) {
                    rs.close();
                }
            }
        }
    }

    public static String[] getCountryCodes(String[] countryNames) throws Exception {
        try (SQLConnection db = MWDBAccess.getDatabaseConnection()){
            try (CallableStatement cs = db.prepareCall("dbo.wfe_EChannelCountriesOnshoreGet", null)) {
                try (ResultSet rs = db.executeQuery(cs, new TreeMap<String, Object>())) {
                    HashMap<String, String> countryCodes = new HashMap<>();
                    while (rs.next()) {
                        countryCodes.put(rs.getString("Name").trim(), rs.getString("CountryISOCode").trim());
                    }

                    String[] finalCountryCodes = new String[countryNames.length];
                    if (countryNames.length > 0 && countryNames[0] != null) {
                        if ("".equalsIgnoreCase(countryNames[0].trim()) && countryNames.length == 1) {
                            finalCountryCodes[0] = "";
                        } else {
                            for (int i = 0; i < countryNames.length; i++) {
                                String countryCode = countryCodes.get(countryNames[i].trim());
                                finalCountryCodes[i] = countryCode == null ? "" : countryCode;
                            }
                        }
                    }
                    return finalCountryCodes;
                }
            }
        }
    }

    public static CustomerEmployment[] listCustomerEmployment(int customerNumber, String country, boolean offshore,
                                                              int versionNumber) throws Exception {
        CEM_L empEnquiry = new CEM_L();

        // enter params and version should be set set in one place, easy to maintain
        empEnquiry.setVersionNumber("5");
        empEnquiry.setCustomerNumber(customerNumber);
        empEnquiry.setCountry(country);
        empEnquiry.setOffshore(offshore);

        executeToken(empEnquiry);

        ArrayList rows = empEnquiry.getRows();
        Vector output = new Vector();
        for (Iterator iter = rows.iterator(); iter.hasNext(); ) {
            HashMap row = (HashMap) iter.next();
            CustomerEmployment cemp = new CustomerEmployment();
            cemp.setAddressFirstLine((String)row.get("ADDRESS_FIRST_LINE"));
            String contractExpiry = (String)row.get("CONTRACT_EXPIRY");
            if(StringUtils.isNotBlank(contractExpiry)) {
                cemp.setContractExpiryDate(
                        empEnquiry.parseBrainsDateString(contractExpiry));
            }
            cemp.setCountry((String)row.get("COUNTRY"));
            cemp.setCustomerNumber(Integer.parseInt(((String)row.get("CUSTOMER_NUMBER"))));
            cemp.setDistrict((String)row.get("DISTRICT"));
            cemp.setEmpContactName((String)row.get("EMP_CONTACT_NAME"));
            cemp.setEmpContactNumber((String) row.get("EMP_CONTACT_NUMBER"));
            cemp.setEmployer((String)row.get("EMPLOYER"));
            cemp.setEmployeeNumber((String)row.get("EMPLOYEE_NUMBER"));
            cemp.setEmployerEmail((String)row.get("EMPLOYER_EMAIL"));
            cemp.setEmploymentStatus((String)row.get("EMPLOYMENT_STATUS"));
            String employmentStatusDate = (String)row.get("EMPLOYMENT_STATUS_DATE");
            if (!employmentStatusDate.equals("")) {
                cemp.setEmploymentStatusDate(BrainsToken.getBrainsDateFormat().parse(employmentStatusDate));
            }
            cemp.setEmploymentType((String)row.get("EMPLOYMENT_TYPE"));
            cemp.setDesignation((String)row.get("DESIGNATION"));
            cemp.setGrossCur((String)row.get("GROSS_CUR"));
            cemp.setGrossIncome(getSafeBigDecimal((String)row.get("GROSS_INCOME")));
            cemp.setJobTitle((String)row.get("JOB_TITLE"));
            cemp.setLengthMonths(Integer.parseInt(((String)row.get("LENGTH_MONTHS"))));
            cemp.setLengthYears(Integer.parseInt(((String)row.get("LENGTH_YEARS"))));
            cemp.setNatureOfBusiness((String)row.get("NATURE_OF_BUSINESS"));
            cemp.setOtherCur((String)row.get("OTHER_CUR"));
            cemp.setOtherIncome(getSafeBigDecimal((String)row.get("OTHER_INCOME")));
            cemp.setPoBoxDetails((String)row.get("PO_BOX_DETAILS"));
            cemp.setPostcode((String)row.get("POSTCODE"));
            cemp.setTown((String)row.get("TOWN"));
            cemp.setSequenceNumber(Integer.parseInt(((String)row.get("SEQUENCE_NUMBER"))));
            cemp.setSourceOfFunds((String) row.get("SOURCE_OF_FUNDS"));
            output.add(cemp);
        }

        return (CustomerEmployment[]) output.toArray(new CustomerEmployment[output.size()]);

    }

    public static void addCustomerAccount(CustomerAccountAddUpdateRequest request, CustomerAccountAddResponse response, int versionNumber) throws Exception {
        CAC_A accountAdd = new CAC_A();
        // enter params
        accountAdd.setCustomerNumber( request.getCustomerNumber());
        accountAdd.setPrimaryAccountIndicator( request.getPrimaryAccountIndicator() );
        accountAdd.setAccountType( request.getAccountType() );
        accountAdd.setBarclaysContactBranch( request.getBarclaysContactBranch());
        accountAdd.setBarclaysContactHost( request.getBarclaysContactHost());
        accountAdd.setBarclaysContactName( request.getBarclaysContactName() );
        accountAdd.setCountry( request.getCountry() );
        accountAdd.setBranchNumber( request.getBranchNumber() );
        accountAdd.setAccountNumber( request.getAccountNumber() );
        accountAdd.setAccountStatus( request.getContactStatus() );

        boolean offshore = request.getOffshoreInd().equals("1");

        accountAdd.setOffshore( offshore );
        // WP 626 When version number for token is greater than 1, save mandate instruction
        // as well
        if(versionNumber != 1){
            accountAdd.setVersionNumber(Integer.toString(versionNumber));
            accountAdd.setMandateInstruction(request.getMandateInstruction());
        }
        // execute token
        try{
            accountAdd.execute();
        } catch (BrainsConnectionException bce) {
            throw new AddAmendCustomerException("", bce, AddAmendCusErrorScenario.CONN_BRAINS_CUS_DET_ADD);
        } catch (Exception e) {
            throw new AddAmendCustomerException(e.getMessage(), e, AddAmendCusErrorScenario.BUSINESS_CUS_DET);
        }


        // retrieve return values

        // only expecting one row so more than one will over write earlier row
        for(int i = 0; i < accountAdd.getRowCount(); i++){
            HashMap row = accountAdd.getRow(i);
            response.setSequenceNumber( Integer.parseInt(((String)row.get("SEQUENCE_NUMBER"))));
        }
    }

    private static void executeToken(BrainsToken token) throws Exception {
        try {
            token.execute();
        } catch (BrainsConnectionException bce) {
            logger.error(bce);
            throw bce;
        } catch (Exception e) {
            String message = "Error calling Brains. Details: " + e.toString();
            // Wrap up the error as a brains one
            logger.error(message, e);
            throw e;
        }
    }


    /**
     * To get account type for detailed products selected by user.
     * Account type will be the input required for detailed products in BRAINS
     * @param detailedProducts
     * @param country
     * @param marketSegment
     * @param propositionType
     * @return
     * @throws SQLException
     * @throws DataAccessException
     */
    public static String[] getDetailedProductIDsForKAMLS(String[] detailedProducts, Country country,
                                                         String marketSegment, String propositionType)
            throws SQLException, DataAccessException {
        String[] detailedProductsIDs = null;
        if (detailedProducts != null && detailedProducts.length > 0) {
            detailedProductsIDs = new String[detailedProducts.length];
            SortedSet<RefValueBean> dbValues = getConfiguredProductDetails(country.getISOCode(),
                    country.isOffshore(), marketSegment, propositionType);
            for (int i = 0; i < detailedProducts.length; i++) {
                for (RefValueBean value : dbValues) {
                    if (!isNullOrEmpty(detailedProducts[i])
                            && detailedProducts[i].equalsIgnoreCase(value.getDecsription())) {
                        detailedProductsIDs[i] = value.getDomain();
                        break;
                    }
                }
            }
            return detailedProductsIDs;
        }else {
            return null;
        }
    }

    /**
     * WP812
     * To get the list of detailed products configured as per country, market segment
     * and proposition type. This is used to validate detailed products.
     * @param isoCode
     * @param offshoreIndicator
     * @param marketSegment
     * @param propositionType
     * @return
     * @throws SQLException
     * @throws DataAccessException
     */
    public static SortedSet<RefValueBean> getConfiguredProductDetails (String isoCode,
                                                                       boolean offshoreIndicator, String marketSegment, String propositionType) throws SQLException, DataAccessException {

        SortedMap<String, Object> params = new TreeMap<>();
        isoCode = "".equals(isoCode) ? null : isoCode;
        marketSegment = "".equals(marketSegment) ? null : marketSegment;
        propositionType = "".equals(propositionType) ? null : propositionType;

        params.put("country", isoCode);
        params.put("offshoreInd", Boolean.valueOf(offshoreIndicator));
        params.put("MarketSegment", marketSegment);
        params.put("PropositionType", propositionType);

        SortedSet<RefValueBean> result = new TreeSet<>();
        try (SQLConnection conn = MWDBAccess.getDatabaseConnection()) {
            CallableStatement cs = conn.prepareCall("dbo.wfe_GetConfiguredDetailedProducts", params);
            ResultSet rs = conn.executeQuery(cs, params);

            while (rs.next()) {
                RefValueBean rvb = new RefValueBean();
                rvb.setCode(rs.getString("Code"));
                rvb.setDecsription(rs.getString("Description"));
                rvb.setDomain(rs.getString("Domain"));

                result.add(rvb);
            }
        }

        return result;

    }

    /**
     * Tests if the specified String value is null or an empty string
     * @param value value to test if null or empty
     * @return true if value is null or an empty string
     */
    public static boolean isNullOrEmpty(String value) {
        return value == null || value.length() == 0;
    }

    public static String removeBracketFromStringList(List<String> list) {
        return list.toString().replaceAll("(^\\[|\\]$)", "");
    }

    /**
     * Update customer details.
     * @param customer in the state you want it saved
     * @param user the user saving changes
     * @param versionNumber the token version.
     * @throws Exception
     */
    public static void updateCustomerRBADetails(
            Map<String, String> staffwareTransitionDetails,String country, String offshoreInd,String versionNumber) throws Exception
    {
        //WP812 call RBA-U token
        RBA_U detailsUpdate = new RBA_U();
        detailsUpdate.setCustomerNumber(Integer.parseInt(staffwareTransitionDetails.get("customerNumber")));
        detailsUpdate.setVersionNumber(Integer.parseInt(versionNumber));
        boolean isOffshore  = offshoreInd.equalsIgnoreCase("1") ? true : false;

        String longDatePattern = "dd/MM/yyyy";
        String shortDatePattern = "ddMMyy";
        SimpleDateFormat formatter1= new SimpleDateFormat(longDatePattern);
        if(StringUtils.isNotBlank(staffwareTransitionDetails.get("idCardExpiry"))) {
            Date date = formatter1.parse((String)staffwareTransitionDetails.get("idCardExpiry"));
            String requiredDate =  getFormattedDate(date,shortDatePattern);
            detailsUpdate.setIdCardExpiry(requiredDate);
        }else {
            detailsUpdate.setIdCardExpiry(staffwareTransitionDetails.get("idCardExpiry"));
        }

        if(StringUtils.isNotBlank(staffwareTransitionDetails.get("lastRefreshDate"))) {
            Date date = formatter1.parse((String)staffwareTransitionDetails.get("lastRefreshDate"));
            String requiredDate =  getFormattedDate(date,shortDatePattern);
            detailsUpdate.setLastRefreshDate(requiredDate);
        }else {
            detailsUpdate.setLastRefreshDate(staffwareTransitionDetails.get("lastRefreshDate"));
        }
        if(StringUtils.isNotBlank(staffwareTransitionDetails.get("nextRefreshDate"))) {
            Date date = formatter1.parse((String)staffwareTransitionDetails.get("nextRefreshDate"));
            String requiredDate =  getFormattedDate(date,shortDatePattern);
            detailsUpdate.setNextRefreshDate(requiredDate);
        }else {
            detailsUpdate.setNextRefreshDate(staffwareTransitionDetails.get("nextRefreshDate"));
        }
        boolean isCorporate  = "L".equalsIgnoreCase(staffwareTransitionDetails.get("propositionType")) ||
                "C".equalsIgnoreCase(staffwareTransitionDetails.get("propositionType")) ;
        if(isCorporate) {
            detailsUpdate.setHighRiskIndustries(getMWRefValuesDescription(country,isOffshore,"SRCHRI",staffwareTransitionDetails.get("highRiskIndustries")));
            detailsUpdate.setSpecialCustomerType(getMWRefValuesDescription(country,isOffshore,"SPLCUS",staffwareTransitionDetails.get("specialCustomerType")));
        }
        detailsUpdate.setfCcountryISOTaxResidency(staffwareTransitionDetails.get("fCcountryISOTaxResidency"));
        detailsUpdate.setfCTin(staffwareTransitionDetails.get("fCTin"));
        detailsUpdate.setfCGiin(staffwareTransitionDetails.get("fCGiin"));
        detailsUpdate.setfCreasonForNoTin(staffwareTransitionDetails.get("fCreasonForNoTin"));
        detailsUpdate.setfCclassificationFatca(getRefValueDescription(country,isOffshore, "CLNFTC", staffwareTransitionDetails.get("fCclassificationFatca"), null));
        detailsUpdate.setfCclassificationCrs(getRefValueDescription(country,isOffshore, "CLNCRS", staffwareTransitionDetails.get("fCclassificationCrs"), null));
        if(staffwareTransitionDetails.get("fatcaReportable")!=null) {
            detailsUpdate.setFatcaReportable(Boolean.parseBoolean(staffwareTransitionDetails.get("fatcaReportable")));
        }
        if(staffwareTransitionDetails.get("crsReportable")!=null) {
            detailsUpdate.setCrsReportable(Boolean.parseBoolean(staffwareTransitionDetails.get("crsReportable")));
        }

        List<String[]> list = combineControllingPersonsData(staffwareTransitionDetails.get("controllingPersonsDataSize"),
                getArrayAfterPipeSeparated(staffwareTransitionDetails.get("controllingPersonLastNameData")),
                getArrayAfterPipeSeparated(staffwareTransitionDetails.get("controllingPersonForeNameData")),
                getArrayAfterPipeSeparated(staffwareTransitionDetails.get("controllingPersonDobData")),
                getArrayAfterPipeSeparated(staffwareTransitionDetails.get("controllingPersonCityData")),
                getArrayAfterPipeSeparated(staffwareTransitionDetails.get("controllingPersonCountryOfAddressData")),
                getArrayAfterPipeSeparated(staffwareTransitionDetails.get("controllingPersonTaxIdNumberData")),
                getArrayAfterPipeSeparated(staffwareTransitionDetails.get("controllingPersonTaxIdCountryData")),
                getArrayAfterPipeSeparated(staffwareTransitionDetails.get("controllingPersonTypeData")),country,isOffshore);
        detailsUpdate.setControllingPersonsData(list);
        detailsUpdate.setSourceOfIncome(getArrayWithoutBlankSpace(staffwareTransitionDetails.get("sourceOfIncome")));
        detailsUpdate.setSourceOfFunds(getArrayWithoutBlankSpace(staffwareTransitionDetails.get("sourceOfFunds")));
        detailsUpdate.setSourceOfWealth(getArrayWithoutBlankSpace(staffwareTransitionDetails.get("sourceOfWealth")));
        detailsUpdate.setOtherIncomeTxt(staffwareTransitionDetails.get("otherIncomeTxt"));
        detailsUpdate.setOtherFundsTxt(staffwareTransitionDetails.get("otherFundsTxt"));
        detailsUpdate.setOtherWealthTxt(staffwareTransitionDetails.get("otherWealthTxt"));
        detailsUpdate.setmEAACashDepositVolume(staffwareTransitionDetails.get("mEAACashDepositVolume"));
        detailsUpdate.setmEAACashDepositAmount(staffwareTransitionDetails.get("mEAACashDepositAmount"));
        detailsUpdate.setmEAACashWithdrawalVolume(staffwareTransitionDetails.get("mEAACashWithdrawalVolume"));
        detailsUpdate.setmEAACashWithdrawalAmount(staffwareTransitionDetails.get("mEAACashWithdrawalAmount"));
        detailsUpdate.setmEAAChequeDepositVolume(staffwareTransitionDetails.get("mEAAChequeDepositVolume"));
        detailsUpdate.setmEAAChequeDepositAmount(staffwareTransitionDetails.get("mEAAChequeDepositAmount"));
        detailsUpdate.setmEAAChequeWithdrawalVolume(staffwareTransitionDetails.get("mEAAChequeWithdrawalVolume"));
        detailsUpdate.setmEAAChequeWithdrawalAmount(staffwareTransitionDetails.get("mEAAChequeWithdrawalAmount"));
        detailsUpdate.setmEAAOtherInstrumentsDepositVolume(staffwareTransitionDetails.get("mEAAOtherInstrumentsDepositVolume"));
        detailsUpdate.setmEAAOtherInstrumentsDepositAmount(staffwareTransitionDetails.get("mEAAOtherInstrumentsDepositAmount"));
        detailsUpdate.setmEAAOtherInstrumentsWithdrawalVolume(staffwareTransitionDetails.get("mEAAOtherInstrumentsWithdrawalVolume"));
        detailsUpdate.setmEAAOtherInstrumentsWithdrawalAmount(staffwareTransitionDetails.get("mEAAOtherInstrumentsWithdrawalAmount"));
        detailsUpdate.setmEAAFundTransfersDepositVolume(staffwareTransitionDetails.get("mEAAFundTransfersDepositVolume"));
        detailsUpdate.setmEAAFundTransfersDepositAmount(staffwareTransitionDetails.get("mEAAFundTransfersDepositAmount"));
        detailsUpdate.setmEAAFundTransfersWithdrawalVolume(staffwareTransitionDetails.get("mEAAFundTransfersWithdrawalVolume"));
        detailsUpdate.setmEAAFundTransfersWithdrawalAmount(staffwareTransitionDetails.get("mEAAFundTransfersWithdrawalAmount"));
        detailsUpdate.setmEAATotalDepositVolume(staffwareTransitionDetails.get("mEAATotalDepositVolume"));
        detailsUpdate.setmEAATotalDepositAmount(staffwareTransitionDetails.get("mEAATotalDepositAmount"));
        detailsUpdate.setmEAATotalWithdrawalVolume(staffwareTransitionDetails.get("mEAATotalWithdrawalVolume"));
        detailsUpdate.setmEAATotalWithdrawalAmount(staffwareTransitionDetails.get("mEAATotalWithdrawalAmount"));
        detailsUpdate.setCountry(country);
        detailsUpdate.setOffshore(isOffshore);

        executeToken(detailsUpdate);
    }

    public static String getMWRefValuesDescription(String isoCode, boolean isOffshore, String domain, String code) throws Exception {
        Map<String, String> highRiskIndustriesMap = TokenHelper.getMWRefValues(isoCode,isOffshore, domain,code);
        for (Map.Entry<String,String> entry : highRiskIndustriesMap.entrySet())  {
            return entry.getValue();
        }
        return null;
    }

    /**
     * To combine controlling persons data into a list of array
     * @param dataSize
     * @param firstName
     * @param lastName
     * @param dob
     * @param city
     * @param countryAddr
     * @param taxId
     * @param taxIdCountry
     * @param personType
     * @param country
     * @param offshoreInd
     * @return
     * @throws Exception
     */
    public static List<String[]> combineControllingPersonsData(String dataSizeStr,String[] lastName,String[] foreName,String[] dob,String[] city,String[] countryAddr,String[] taxId,
                                                               String[] taxIdCountry, String[] personType, String country, boolean offshoreInd) throws Exception {

        int dataSize=0;
        if(StringUtils.isNotBlank(dataSizeStr)) {
            dataSize=Integer.parseInt(dataSizeStr);
        }
        List<String[]> list = new ArrayList<String[]>();
        String longDatePattern = "dd/MM/yyyy";
        String shortDatePattern = "ddMMyy";
        SimpleDateFormat formatter1= new SimpleDateFormat(longDatePattern);
        Map<String, String> dbValues =null;
        if(dataSize>0) {
            dbValues = getMWRefValuesByDomain(country,offshoreInd, "CTRPRN");
        }
        for (int i = 0; i < dataSize; i++) {
            String[] mergedArray = new String[8];
            try {
                mergedArray[0] = lastName[i];
            } catch (ArrayIndexOutOfBoundsException e) {
                mergedArray[0] = "";
            }
            try {
                mergedArray[1] = foreName[i];
            } catch (ArrayIndexOutOfBoundsException e) {
                mergedArray[1] = "";
            }
            try {
                if (StringUtils.isNotBlank(dob[i])) {
                    Date date = formatter1.parse((String) dob[i]);
                    String requiredDate = getFormattedDate(date, shortDatePattern);
                    mergedArray[2] = requiredDate;
                } else {
                    mergedArray[2] = dob[i];
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                mergedArray[2] = "";
            }
            try {
                mergedArray[3] = city[i];
            } catch (ArrayIndexOutOfBoundsException e) {
                mergedArray[3] = "";
            }
            try {
                mergedArray[4] = countryAddr[i];
            } catch (ArrayIndexOutOfBoundsException e) {
                mergedArray[4] = "";
            }
            try {
                mergedArray[5] = taxId[i];
            } catch (ArrayIndexOutOfBoundsException e) {
                mergedArray[5] = "";
            }
            try {
                mergedArray[6] = taxIdCountry[i];
            } catch (ArrayIndexOutOfBoundsException e) {
                mergedArray[6] = "";
            }
            try {
                mergedArray[7] = getRefValueDescription(country, offshoreInd, "CTRPRN", personType[i], dbValues);
            } catch (ArrayIndexOutOfBoundsException e) {
                mergedArray[7] = "";
            }
            list.add(mergedArray);
        }
        return list;
    }

    /**
     * Returns a date formatted as per the format you have provided
     * @param Date date
     * @param format you want to convert
     * @return
     */
    public static String getFormattedDate(Date date, String format) {
        if (date == null || format == null) {
            return "";
        }
        return getDateFormatter(format).format(date);
    }
    /**
     * Gets a date formatter suitable for parsing dates based on the format passed as parameter
     * @param format string
     * @return
     */
    private static SimpleDateFormat getDateFormatter(String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setLenient(false);
        return sdf;
    }

    public static Map<String, String> getMWRefValuesByDomain(String isoCode, boolean isOffshore, String domain)
            throws SQLException, Exception {
        try (SQLConnection conn = MWDBAccess.getDatabaseConnection()) {
            CallableStatement statement = null;
            ResultSet resultSet = null;

            isoCode = "".equals(isoCode) ? null : isoCode;
            domain = "".equals(domain) ? null : domain;

            SortedMap<String, Object> params = new TreeMap<>();
            params.put("country", isoCode);
            params.put("offshoreInd", isOffshore?"1":"0");
            params.put("domain", domain);

            HashMap<String, String> result = new HashMap<>();

            try {
                statement = conn.prepareCall("dbo.wfe_MWRefValuesGet", params);
                resultSet = (ResultSet) conn.executeQuery(statement, params);

                while (resultSet.next()) {
                    result.put(resultSet.getString("Code"),
                            resultSet.getString("Description"));
                }
            } finally {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (statement != null) {
                    statement.close();
                }

            }

            return result;
        }
    }

    /**
     * This method is used for getting ref value description using its code
     * @param country
     * @param offshoreInd
     * @param domain
     * @param refValueCode
     * @param dbValues
     * @return
     * @throws SQLException
     * @throws Exception
     */
    public static String getRefValueDescription(String country, boolean offshoreInd, String domain, String refValueCode, Map<String, String> dbValues)
            throws SQLException, Exception {
        String refValueCodeDesc = "";

        if (StringUtils.isBlank(refValueCode)) {
            return refValueCodeDesc;
        }
        if(dbValues==null) {
            dbValues = getMWRefValuesByDomain(country,offshoreInd, domain);
        }
        for (Map.Entry<String,String> entry : dbValues.entrySet())  {
            if(refValueCode.equalsIgnoreCase(entry.getKey())) {
                refValueCodeDesc=entry.getValue();
                break;
            }

        }
        return refValueCodeDesc;
    }

    public static String[] getArrayAfterPipeSeparated(String inputString) {
        ArrayList<String> list = new ArrayList<String>();
        if(StringUtils.isNotBlank(inputString)) {
            String[] split = inputString.split(Pattern.quote("||"));
            for(int i=0;i<split.length;i++) {
                list.add((split[i].trim()));
            }

        }
        String[] outputArray = new String[list.size()];
        outputArray = list.toArray(outputArray);

        return outputArray;

    }

    /**
     * To get product ID for detailed products selected by user.
     * Account type will be the input required for detailed products in BRAINS
     * @param detailedProducts
     * @param country
     * @param marketSegment
     * @param propositionType
     * @return
     * @throws SQLException
     * @throws DataAccessException
     */
    public static String[] getDetailedProductIDsForUI(String[] detailedProducts, Country country,
                                                      String marketSegment, String propositionType)
            throws SQLException, DataAccessException {
        String[] detailedProductsIDs = null;
        if (detailedProducts != null && detailedProducts.length > 0) {
            detailedProductsIDs = new String[detailedProducts.length];
            SortedSet<RefValueBean> dbValues = getConfiguredProductDetails(country.getISOCode(),
                    country.isOffshore(), marketSegment, propositionType);
            for (int i = 0; i < detailedProducts.length; i++) {
                for (RefValueBean value : dbValues) {
                    if (!isNullOrEmpty(detailedProducts[i])
                            && detailedProducts[i].equalsIgnoreCase(value.getDecsription())) {
                        detailedProductsIDs[i] = value.getCode();
                        break;
                    }
                }
            }
            return detailedProductsIDs;
        }else {
            return null;
        }
    }



    public static String[] getArrayWithoutBlankSpace(String inputString) {
        ArrayList<String> list = new ArrayList<String>();
        if(StringUtils.isNotBlank(inputString)) {
            for(int i=0;i<inputString.split(",").length;i++) {
                list.add(inputString.split(",")[i].trim());
            }
        }
        String[] outputArray = new String[list.size()];
        outputArray = list.toArray(outputArray);

        return outputArray;

    }



    //WP812
    /**
     * To check if risk based KYC is enabled or not
     * @param user
     * @return
     * @throws SQLException
     * @throws DataAccessException
     */
    public static boolean isRiskBasedKYCEnabled(String country, String offshoreInd) throws SQLException, DataAccessException {
        boolean result = getCountryAttributeBoolean(country,offshoreInd, "Enable Risk Based KYC", false);
        return result;
    }

    /**
     * Retrieves the boolean value of the specified attribute. Provides a default
     * value to return if the attribute is not found.
     *
     * @param user
     * @param attributeDescription
     * @param defaultValue
     * @return
     * @throws SQLException
     * @throws DataAccessException
     */
    public static boolean getCountryAttributeBoolean(String country, String offshoreInd, String attributeDescription, boolean defaultValue)
            throws SQLException, DataAccessException {
        boolean result = defaultValue;
        CallableStatement statement = null;
        ResultSet resultSet = null;
        SQLConnection conn = MWDBAccess.getDatabaseConnection();
        SortedMap<String, Object> params = new TreeMap<>();
        params.put("ConfigDesc", attributeDescription);
        try {

            statement = conn.prepareCall("dbo.csc_getCountryConfigValue", params);
            resultSet = (ResultSet) conn.executeQuery(statement, params);
            while (resultSet.next()) {
                if (country.equals(resultSet.getString("country"))
                        && (Boolean.getBoolean(offshoreInd) ? 1 : 0) == resultSet.getInt("offshoreind")) {
                    result = resultSet.getInt("value") == 1;
                }
            }
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }

            if (statement != null) {
                statement.close();
            }

        }
        return result;
    }


    public static Country fetchCountryDetails(String country, String offshoreInd) throws SQLException {
        try (SQLConnection conn = MWDBAccess.getDatabaseConnection()) {
            SortedMap<String, Object> params = new TreeMap<>();
            params.put("CountryCode", country);
            params.put("OffshoreInd", Integer.parseInt(offshoreInd) );

            CallableStatement cs = conn.prepareCall("dbo.wfe_GetCountryByEitherCode", params);
            try (ResultSet rs = conn.executeQuery(cs, params)) {
                if (rs.next()) {
                    return new Country(country, "1".equals(offshoreInd), rs.getString("CountryName"), rs.getString("ISO3166"));
                }
            }
        }
        return new Country();
    }


}
