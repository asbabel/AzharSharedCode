package com.barclays.staffware.plugin.swift;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TagHelper;
import com.barclays.staffware.plugin.util.ValidateSwift;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * Class for creating SWIFT messages for an outward SWIFT payment
 * 
 * @author LEES
 */
/*
 * DATE REFERENCE WHO VERSION COMMENTS ---- --------- --- ------- --------
 * 04Feb14 WP654 LEES 1.00 Created for SvcSwiftFormMsg writeout
 */
public abstract class SwiftMessage implements ImmediateReleasePluginSDK {

	private static final int THREE = 3;
	private static final int FIVE = 5;
	private static final int EIGHT = 8;
	private static final int TEN = 10;
	private static final int ELEVEN = 11;
	private static final String TAG_61 = "TAG_61_";
	private static final String TAG_86 = "TAG_86_";
	private static final String TAG_50G = "TAG_50G_";

	private String messageType;
	private String sender;
	private String receiver;

	protected static final LoggerConnection logger = new LoggerConnection(SwiftMessage.class);
	private final String initializationFailed = SwiftParams.initializationFailed(SwiftMessage.class.getName());
	
	/**
	 * Initialize method is called from Staffware. This sets the properties
	 * file, the database driver and establishes the logger for the given class.
	 * Calls initializeDataAccess to allow child classes to set their datasource
	 * if required.
	 * 
	 * @param properties
	 *            path of properties file
	 * @throws FatalPluginException
	 *             If fails to load properties file
	 */
	@Override
	public void initialize(Properties properties) throws FatalPluginException {
		try {
			//LoggerConnection.configureWFL(properties.getProperty("swiftFormMsgLog"));
			// Modified by ashish
			logger.error(this.getClass().toString() + "----------------------test log write!-------------");
			ClassPathResource resource = new ClassPathResource(properties.getProperty("swiftFormMsgLog"));
			LoggerContext context = (LoggerContext) LogManager.getContext(false);
			context.setConfigLocation(resource.getURI());

			logger.debug(this.getClass().toString() + "test log write!");
			BrainsSocketConnectionFactory.getInstance().useSecure(properties);
			//DataSourceDirectory.getInstance().configure(properties);
			DataSourceDirectory.getInstance().basePluginDS();
			//Class.forName(properties.getProperty("db_driver"));
		} catch (Exception e) {
			logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
		initalizeCustomStep();
	}
	
	/**
	 * Method is blank to allow child classes to set a datasource in the
	 * initalize method if they require.
	 */
	public void initalizeCustomStep() {
	}

	/**
	 * Staffware calls this execute method 
	 */
	@Override
	public Map execute(String staticData, List outputFields, List inputFields)
			throws FatalPluginException, NonFatalPluginException {
		Map<String, Object> result = new HashMap<String, Object>(outputFields.size());
		
		result=executeProcess(staticData, outputFields, inputFields);
		
		return result;
	}

	
	/**
	 * execute method calls this to allow child classes to perform their own custom
	 * processing.
	 * @param staticData
	 * @param outputFields
	 * @param inputFields
	 * @return
	 * @throws FatalPluginException
	 * @throws NonFatalPluginException
	 */
	abstract Map<String, Object> executeProcess(String staticData, List outputFields, List inputFields) 
			throws FatalPluginException, NonFatalPluginException;

	/**
	 * Getter for MESSAGE_TYPE
	 * 
	 * @return messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * Setter for MESSAGE_TYPE
	 * 
	 * @param messageType
	 *            Input from Staffware
	 * @throws Exception
	 *             If MESSAGE_TYPE is missing
	 */
	public void setMessageType(String messageType) throws Exception {// NOSONAR
		if (isNullOrIsEmpty(messageType)) {
			throw new Exception(SwiftParams.MESSAGE_TYPE_ERROR);// NOSONAR
		} else {
			this.messageType = messageType;
		}
	}

	/**
	 * Getter for SENDER
	 * 
	 * @return sender
	 */
	public String getSender() {
		return sender;
	}

	/**
	 * Setter for SENDER
	 * 
	 * @param sender
	 *            Input from Staffware
	 * @throws Exception
	 *             If SENDER is missing or less than 8 characters
	 */
	public void setSender(String sender) throws Exception {// NOSONAR
		if (sender == null || sender.length() < EIGHT) {
			throw new Exception(SwiftParams.SENDER_ERROR);// NOSONAR
		} else {
			this.sender = sender;
		}
	}

	/**
	 * Getter for RECEIVER
	 * 
	 * @return receiver
	 */
	public String getReceiver() {
		return receiver;
	}

	/**
	 * Setter for RECEIVER
	 * 
	 * @param receiver
	 *            Input from Staffware
	 * @throws Exception
	 *             If RECEIVER is missing
	 */
	public void setReceiver(String receiver) throws Exception {// NOSONAR
		if (receiver == null || receiver.length() < EIGHT) {
			throw new Exception(SwiftParams.RECEIVER_ERROR);// NOSONAR
		} else {
			this.receiver = receiver;
		}
	}

	/**
	 * Method to append the Basic Header Block to the SWIFT message
	 * 
	 * @param message
	 *            the SWIFT message to append to
	 * @param sender
	 *            Must be 8 characters long or over
	 */
	protected void basicHeaderBlock(StringBuffer message, String sender) {
		// append block id
		message.append("{1:");
		// append application id
		message.append("F");
		// append service id
		message.append("01");
		// append first 8 characters from sender
		if (sender.length() > EIGHT) {
			message.append(sender.substring(0, EIGHT));
		} else {
			message.append(sender);
		}
		// append logical terminal
		message.append("A");
		// append characters 9 to 11 of sender (if present)
		if (!(sender.length() < ELEVEN)) {
			message.append(sender.substring(EIGHT, ELEVEN));
		} else {
			message.append(SwiftParams.XXX);
		}
		// append session number
		message.append("0000");
		// append sequence number
		message.append("000000");
		message.append("}");
	}

	/**
	 * Method to append the Application Header Block to the SWIFT message
	 * 
	 * @param message
	 *            the SWIFT message to append to
	 * @param messageType
	 *            the message type (3 characters)
	 * @param receiver
	 *            Must be 3 characters long or over
	 */
	protected void applicationHeaderBlock(StringBuffer message, String messageType, String receiver) {
		// append block id
		message.append("{2:");
		// append input / output
		message.append("I");
		// append message type
		message.append(messageType);
		// append first 8 characters of receiver
		if (receiver.length() > EIGHT) {
			message.append(receiver.substring(0, EIGHT));
		} else {
			message.append(receiver);
		}
		// append logical terminal
		message.append("X");
		// append characters 9 to 11 of receiver if present
		if (!(receiver.length() < ELEVEN)) {
			message.append(receiver.substring(EIGHT, ELEVEN));
		} else {
			message.append(SwiftParams.XXX);
		}
		// append message priority
		message.append("N");
		message.append("}");
	}

	/**
	 * Method to append the userHeaderBlock to the SWIFT message
	 * 
	 * @param message
	 *            the SWIFT message to append to
	 * @param tags
	 *            the formatted string of tags
	 */
	protected void userHeaderBlock(StringBuffer message, StringBuffer tags) {
		message.append("{3:");
		message.append(tags);
		message.append("}");
	}

	/**
	 * Method to append the Message Block to the SWIFT message
	 * 
	 * @param message
	 *            the SWIFT message to append to
	 * @param tags
	 *            the formatted string of tags
	 */
	protected void messageBlock(StringBuffer message, StringBuffer tags) {
		message.append("{4:" + SwiftParams.NEW_LINE);
		message.append(tags);
		message.append("-}");
	}

	

	/**
	 * Method gets the value of the named field from the given list
	 * 
	 * @param fields
	 *            list of fields
	 * @param key
	 *            name of field of interest
	 * @return value of given field
	 */
	protected String getFieldValue(List<?> fields, String key) {
		for (Iterator<?> i = fields.iterator(); i.hasNext();) {
			Field field = (Field) i.next();
			if (key.equalsIgnoreCase(field.getName())) {
				String value = field.getValue();
				return value == null ? "" : value.trim();
			}
		}
		return "";
	}

	/**
	 * Method which decides if the User Header Block is present
	 * 
	 * @param swiftMessage
	 *            SWFIT message to append the User Header Block to
	 * @param headerTags
	 *            formatted string of tags for the User Header Block
	 */
	protected void appendUserHeaderBlock(StringBuffer swiftMessage, StringBuffer headerTags) {
		if (headerTags == null || headerTags.length() == 0) {
			return;
		} else {
			userHeaderBlock(swiftMessage, headerTags);
		}
	}

	/**
	 * Method for formatting the content of a tag and adding it to a string
	 * buffer to be appended to the SWIFT MESSAGE
	 * 
	 * @param tagString
	 *            StringBuffer to add the tag to
	 * @param tagId
	 *            Tag ID
	 * @param tag
	 *            Tag content
	 */
	protected void appendTag(StringBuffer tagString, String tagId, String tag) {
		tagString.append(":");
		tagString.append(tagId);
		tagString.append(":");
		tagString.append(tag);
		tagString.append(SwiftParams.NEW_LINE);
	}

	/**
	 * Generic method for appending non-mandatory tags
	 * 
	 * @param tagString
	 *            StringBuffer to append the tag to
	 * @param value
	 *            Input from Staffware (not mandatory)
	 * @param tagId
	 */
	protected void appendOptionalTag(StringBuffer tagString, String value, String tagId) {
		String tagValue;
		if (value != null && !value.isEmpty()) {
			tagValue = TagHelper.squeezeValue(value);
			appendTag(tagString, tagId, tagValue);
		}
	}

	/**
	 * Generic method for appending mandatory tags
	 * 
	 * @param tagString
	 *            StringBuffer to append the tag to
	 * @param value
	 *            Input from staffware
	 * @param tagId
	 *            tag id
	 * @param errorMessage
	 *            error message for when tag does not exist
	 * @throws Exception
	 *             if the mandatory tag is missing
	 */
	protected void appendMandatoryTag(StringBuffer tagString, String value, String tagId, String errorMessage)
			throws Exception {// NOSONAR

		if (value == null || value.trim().isEmpty()) {
			throw new Exception(errorMessage);// NOSONAR
		} else {
			appendTag(tagString, tagId, value);
		}
	}

	/**
	 * Method for appending number currency amount tags
	 * 
	 * @param tagString
	 *            StringBuffer to append the tag to
	 * @param value
	 *            Input from Staffware
	 * @param tagId
	 *            tag id
	 */
	protected void appendNumberCurrencyAmount(StringBuffer tagString, String value, String tagId) {
		String tagValue = TagHelper.squeezeValue(value);
		String tag = "";
		if (tagValue != null && !tagValue.isEmpty()) {
			int currencyStart = FIVE;
			for (int i = 0; i < tagValue.length(); i++) {
				if (Character.isDigit(tagValue.charAt(i))) {
					tag += tagValue.charAt(i);
				} else {
					currencyStart = i;
					break;
				}
			}
			int currencyEnd = currencyStart + THREE;
			tag += value.substring(currencyStart, currencyEnd);
			tag += TagHelper.parseAmount(value.substring(currencyEnd));
			appendTag(tagString, tagId, tag);
		}
	}

	/**
	 * Method for deciding which tag to use given a choice of 2 tags (with DC
	 * Mark, Date, Currency, and Amount fields)
	 * 
	 * @param tags
	 *            string to append tags to
	 * @param tag1
	 *            first tag value
	 * @param tag2
	 *            second tag value
	 * @param tag1Id
	 *            first tag id
	 * @param tag2Id
	 *            second tag id
	 * @param errorMessage
	 *            error message if tags do not exist
	 * @throws Exception
	 *             If tags do not exist
	 */
	protected void appendTagChoice(StringBuffer tags, String tag1, String tag2, String tag1Id, String tag2Id,
			String errorMessage) throws Exception {// NOSONAR
		if (tag1 != null && !(tag1.trim().length() < ELEVEN)) {
			appendTag(tags, tag1Id, ValidateSwift.validateMarkDateCurrencyAmount(tag1.trim()));
		} else {
			if (tag2 != null && !(tag2.trim().length() < ELEVEN)) {
				appendTag(tags, tag2Id, ValidateSwift.validateMarkDateCurrencyAmount(tag2.trim()));
			} else {
				throw new Exception(errorMessage);// NOSONAR
			}
		}
	}

	/**
	 * Method for appending the first populated tag given a choice of 2 tags
	 * 
	 * @param tag1
	 *            tag1 value
	 * @param tag2
	 *            tag2 value
	 * @param tag1Id
	 *            tag 1 id
	 * @param tag2Id
	 *            tag 2 id
	 * @param tags
	 *            string to append tags to
	 */
	protected void appendTagChoice(StringBuffer tags, String tag1, String tag2, String tag1Id, String tag2Id) {
		if (tag1 != null && !tag1.trim().isEmpty()) {
			appendTag(tags, tag1Id, tag1.trim());
		} else {
			if (tag2 != null && !tag2.trim().isEmpty()) {
				appendTag(tags, tag2Id, tag2.trim());
			}
		}
	}

	/**
	 * Method for appending TAG_23E
	 * 
	 * @param tags
	 *            string to append the tag to
	 * @param value
	 *            tag value
	 */
	protected void appendTag23E(StringBuffer tags, String value) {
		if (value != null && !value.trim().isEmpty()) {
			String tagValue = value.trim();
			String[] fields = tagValue.split("#");
			for (String field : fields) {
				if (field != null && !field.trim().isEmpty()) {
					appendTag(tags, "23E", TagHelper.parseInstruction(field.trim()));
				}
			}
		}
	}

	/**
	 * Method for appending Tag 50F, 50G, or 50H
	 * 
	 * @param tags
	 *            String to append the tag value to
	 * @param inputFields
	 *            List of input fields
	 */
	protected void appendTag50FGH(StringBuffer tags, List<?> inputFields) {
		Map<String, Object> tag50 = new HashMap<String, Object>();
		TagHelper.setGroupTags(tag50, inputFields, "TAG_50F_");
		if (tag50.isEmpty()) {
			TagHelper.setGroupTags(tag50, inputFields, TAG_50G);
			if (tag50.isEmpty()) {
				if (tag50.isEmpty()) {
					return;
				} else {
					appendTag(tags, "50H", TagHelper.formatTagAddress(tag50, "TAG_50H_", "ACC"));
				}
			} else {
				appendTag(tags, "50G", TagHelper.formatPartyIdBIC((String) tag50.get(TAG_50G + "ACC"),
						(String) tag50.get(TAG_50G + "BIC")));
			}
		} else {
			appendTag(tags, "50F", TagHelper.formatTagAddress(tag50, "TAG_50F_", "PARTY"));
		}
	}

	/**
	 * Method for appending either TAG_53A or TAG_53B (or none) to the tag
	 * string (for MT103 and 202)
	 * 
	 * @param tagString
	 *            string to append the tag to
	 * @param tag53a
	 *            Input from Staffware (not mandatory)
	 * @param tag53b
	 *            Input from Staffware (not mandatory)
	 * @param correspAccId
	 *            Correspondent Account ID
	 */
	protected void appendTag53(StringBuffer tagString, String tag53a, String tag53b, String correspAccId) {
        if (tag53a != null && !tag53a.isEmpty()) {
            appendTag(tagString, "53A", TagHelper.formatPartyIdBIC(correspAccId, tag53a));
            return;
        }
        if (isNullOrIsEmpty(tag53b)) {
            if (isNullOrIsEmpty(tag53a) && isNotNullAndIsData(correspAccId)) {
                appendTag(tagString, "53B", TagHelper.formatPartyIdBIC(correspAccId, tag53b));
            }
        } else {
            appendTag(tagString, "53B", tag53b);
        }
    }

	private boolean isNotNullAndIsData(String correspAccId) {
		return correspAccId != null && !correspAccId.equals(SwiftParams.NO_DATA);
	}

	private boolean isNullOrIsEmpty(String tagName) {
		return tagName == null || tagName.isEmpty();
	}

	/**
	 * Method for appending Tag A, C, or D for Tag 56 and 57
	 * 
	 * @param tags
	 *            String to append the tag value to
	 * @param inputFields
	 *            List of input fields
	 * @param tagId
	 *            tag id
	 */
	protected void appendTagACD(StringBuffer tags, List<?> inputFields, String tagId) {
		Map<String, Object> tag56 = new HashMap<String, Object>();
		TagHelper.setGroupTags(tag56, inputFields, "TAG_" + tagId + "A_");
		if (tag56.isEmpty()) {
			String tag56c = getFieldValue(inputFields, "TAG_" + tagId + "C");
			if (tag56c == null || tag56c.trim().isEmpty()) {
				TagHelper.setGroupTags(tag56, inputFields, "TAG_" + tagId + "D_");
				if (tag56.isEmpty()) {
					return;
				} else {
					appendTag(tags, tagId + "D", TagHelper.formatTagAddress(tag56, "TAG_" + tagId + "D_", "ID"));
				}
			} else {
				appendTag(tags, tagId + "C", TagHelper.formatPartyIdBIC(tag56c, null));
			}
		} else {
			appendTag(tags, tagId + "A", TagHelper.formatPartyIdBIC((String) tag56.get("TAG_" + tagId + "A_ID"),
					(String) tag56.get("TAG_" + tagId + "A_BIC")));
		}
	}

	/**
	 * Method for appending non mandatory group tags with suffix N, where N is
	 * the array index, to the tag string
	 * 
	 * @param tags
	 *            String buffer to append the tags to
	 * @param inputFields
	 *            Inputs from Staffware
	 * @param tagId
	 *            tag id
	 * @param tag
	 *            tag name
	 * @param n
	 *            size of tag array
	 * @throws Exception
	 */
	protected void appendGroupTag(StringBuffer tags, List<?> inputFields, String tagId, String tag, int n, int maxChar)
			throws Exception {// NOSONAR
		Map<String, Object> tagMap = new HashMap<String, Object>();
		TagHelper.setGroupTags(tagMap, inputFields, tag);
		if (tagMap.size() > 0) {
			appendTag(tags, tagId, TagHelper.formatTagN(tagMap, tag, n, maxChar));
		}
	}

	/**
	 * Method for appending non mandatory group tags with suffix ACC, NAME,
	 * ADDR1, ADDR2, and ADDR3 to the tag string
	 * 
	 * @param tags
	 *            String buffer to append the tags to
	 * @param inputFields
	 *            Inputs from Staffware
	 * @param tagId
	 *            tag id
	 * @param tagPrefix
	 *            tag prefix
	 * @throws Exception
	 */
	protected void appendGroupTag(StringBuffer tags, List<?> inputFields, String tagId, String tagPrefix)
			throws Exception {// NOSONAR
		Map<String, Object> tagMap = new HashMap<String, Object>();
		TagHelper.setGroupTags(tagMap, inputFields, tagPrefix);
		if (tagMap.size() > 0) {
			appendTag(tags, tagId,
					ValidateSwift.validateAccountNameAddress(TagHelper.formatTagAccNameAdd(tagMap, tagPrefix)));
		}
	}

	/**
	 * Method for appending mandatory group tags with suffix N, where N is the
	 * array index, to the tag string
	 * 
	 * @param tags
	 *            String buffer to append the tags to
	 * @param inputFields
	 *            Inputs from Staffware
	 * @param tagId
	 *            tag Id
	 * @param tag
	 *            tag name
	 * @param value
	 *            tag value
	 * @param errorMessage
	 *            error message if tag is missing
	 * @throws Exception
	 *             If the mandatory tag is missing
	 */
	protected void appendGroupTag(StringBuffer tags, List<?> inputFields, String tagId, String tagPrefix, int n,
			int maxChar, String errorMessage) throws Exception {// NOSONAR

		Map<String, Object> tagMap = new HashMap<String, Object>();
		TagHelper.setGroupTags(tagMap, inputFields, tagPrefix);
		if (tagMap.size() > 0) {
			appendTag(tags, tagId, TagHelper.formatTagN(tagMap, tagPrefix, n, maxChar));
		} else {
			throw new Exception(errorMessage);// NOSONAR
		}
	}

	/**
	 * Method for appending statement lines (max 10 lines)
	 * 
	 * @param tags
	 *            string to append the tags to
	 * @param inputFields
	 *            List of fields from Staffware
	 * @param tagId
	 *            tag id
	 * @param tagPrefix
	 *            tag prefix
	 * @throws Exception
	 *             if fields are not in the correct format
	 */
	protected void appendStatementLineAccInfo(StringBuffer tags, List<?> inputFields, String tagId, String tagPrefix)
			throws Exception {// NOSONAR
		Map<String, Object> tagGroup = new HashMap<String, Object>();
		TagHelper.setGroupTags(tagGroup, inputFields, tagPrefix);
		for (int i = 1; i <= TEN; i++) {
			String value = (String) tagGroup.get(tagPrefix + i);
			if (value != null && !value.trim().isEmpty()) {
				String parsedValue = TagHelper.parseStatementLineAccInfo(tagPrefix + i, value);
				appendOptionalTag(tags, parsedValue, tagId);
			}
		}
	}

	/**
	 * Method for appending repeating lines of tag61 and tag86 (max 10 lines)
	 * 
	 * @param tags
	 *            String to append the tags to
	 * @param inputFields
	 *            List of fields from Staffware
	 * @throws Exception
	 *             if fields are not in the correct format
	 */

	//existing
	/*protected void appendRepeatingLines(StringBuffer tags, List<?> inputFields) throws Exception {// NOSONAR
		Map<String, Object> tag61 = new HashMap<String, Object>();
		TagHelper.setGroupTags(tag61, inputFields, TAG_61);
		Map<String, Object> tag86 = new HashMap<String, Object>();
		TagHelper.setGroupTags(tag86, inputFields, TAG_86);
		for (int i = 1; i <= TEN; i++) {
			String value = (String) tag61.get(TAG_61 + i);
			if (value != null && !value.trim().isEmpty()) {
				String value61 = TagHelper.parseStatementLineAccInfo(TAG_61 + i, value);
				appendOptionalTag(tags, value61, "61");
			}
			value = (String) tag86.get(TAG_86 + i);
			if (value != null && !value.trim().isEmpty()) {
				String value86 = TagHelper.parseInformationToAccountOwner(TAG_86 + i, value);
				appendOptionalTag(tags, value86, "86");
			}
		}
	}*/
  //nemish changes for UAT
	protected void appendRepeatingLines(StringBuffer tags, List<?> inputFields) throws Exception {// NOSONAR
		Map<String, Object> tag61 = new HashMap<String, Object>();
		TagHelper.setGroupTags(tag61, inputFields, TAG_61);
		Map<String, Object> tag86 = new HashMap<String, Object>();
		TagHelper.setGroupTags(tag86, inputFields, TAG_86);

		//WL682 Trim REMIT of Tag86 to 29 characters for ZMB
		Boolean trim=true;

		for (int i = 1; i <= TEN; i++) {
			String value = (String) tag61.get(TAG_61 + i);
			if (value != null && !value.trim().isEmpty()) {
				String value61 = TagHelper.parseStatementLineAccInfo(TAG_61 + i, value);
				appendOptionalTag(tags, value61, "61");
			}
			value = (String) tag86.get(TAG_86 + i);
			if (value != null && !value.trim().isEmpty()) {
				//WL682 Trim REMIT of Tag86 to 29 characters for ZMB
				//Added validation for GHA
				String value86 ="" ;
				String country=getFieldValue(inputFields,"COUNTRY");
				if(("ZMB".equalsIgnoreCase(country)||"GHA".equalsIgnoreCase(country)) && getMessageType().equals("940")) {
					logger.info("checking input filed for ZMB or GHA COUNTRY");
					value86 = TagHelper.parseInformationToAccountOwner(TAG_86 + i, value,trim);
					logger.info("TAG_86 value for ZMB or GHA COUNTRY:"+value86);
				}else {
					logger.info("Executing else part for other then ZMB or GHA COUNTRY");
					value86 = TagHelper.parseInformationToAccountOwner(TAG_86 + i, value,!trim);
					logger.info("Executing else part, TAG_86 value for other then ZMB or GHA COUNTRY:"+value86);
				}
				appendOptionalTag(tags, value86, "86");
			}
		}
	}


	/**
	 * Method for appending non mandatory group tags with suffix ACC, NAME,
	 * ADDR1, ADDR2, and ADDR3 to the tag string
	 * 
	 * @param tags
	 *            String buffer to append the tags to
	 * @param inputFields
	 *            Inputs from Staffware
	 * @param tagId
	 *            tag id
	 * @param tagPrefix
	 *            tag prefix
	 * @throws Exception
	 */
	protected void appendPartyIdNameAddressTag(StringBuffer tags, List<?> inputFields, String tagId, String tagPrefix,
			String errorMessage) throws Exception {// NOSONAR
		Map<String, Object> tagMap = new HashMap<String, Object>();
		TagHelper.setGroupTags(tagMap, inputFields, tagPrefix);
		if (tagMap.size() > 0) {
			appendTag(tags, tagId,
					ValidateSwift.validatePartyIdNameAddress(TagHelper.formatTagAccNameAdd(tagMap, tagPrefix)));
		} else {
			if (errorMessage != null && !errorMessage.isEmpty()) {
				throw new Exception(errorMessage);// NOSONAR
			}
		}
	}

	/**
	 * Method for formatting the tag string for the message block.
	 * <p>
	 * 
	 * Swift tags are also validated here. Ideally, the tags should be validated
	 * before they get to this method
	 * 
	 * @param inputFields
	 *            List of input fields from Staffware
	 * @return formatted string
	 * @throws Exception
	 *             if mandatory tags are missing
	 */
	protected abstract StringBuffer formatMessageTags(List<?> inputFields) throws Exception;// NOSONAR
}
