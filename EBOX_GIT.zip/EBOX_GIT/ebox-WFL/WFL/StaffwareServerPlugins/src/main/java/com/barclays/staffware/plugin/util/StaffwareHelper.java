package com.barclays.staffware.plugin.util;

import java.rmi.server.UID;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.staffware.eaijava.Field;

/**
 * Class for generic methods to use in Staffware server plugins
 * 
 * @author LEES
 * 
 */
/*
 * DATE REFERENCE WHO VERSION COMMENTS 
 * ---- --------- --- ------- --------
 * 31MAR14 WP669MT900_910 SL 1.00 Created
 * 17Jan17 WP715          LeyJ -  Refactored data access to MWDB.
 */
public class StaffwareHelper {

    public static final String STATUSCODE = "STATUSCODE";
    public static final String STATUSDESC = "STATUSDESC";
    public static final String ERRORCODE = "ERRORCODE";
    public static final String ERRORDESC = "ERRORDESC";

    private StaffwareHelper() {
    }

    /**
     * Method to initialise all return values
     * 
     * @param outputFields List of output fields
     * @param returnValues Map of return values
     */
    public static void initialiseReturnValues(List<?> outputFields, Map<String, Object> returnValues) {
        Field outputField = null;
        for (int i = 0; i < outputFields.size(); i++) {
            outputField = (Field) outputFields.get(i);
            // initialise all return values to empty, so staffware can always
            // parse the result map
            returnValues.put(outputField.getName(), "SW_NA");
        }
        // initialise the error return info, to error
        if (returnValues.containsKey(STATUSCODE)) {
            returnValues.put(STATUSCODE, "-1");
        }
        if (returnValues.containsKey(STATUSDESC)) {
            returnValues.put(STATUSDESC, " ");
        }
        if (returnValues.containsKey(ERRORCODE)) {
            returnValues.put(ERRORCODE, "-1");
        }
        if (returnValues.containsKey(ERRORDESC)) {
            returnValues.put(ERRORDESC, "Unexpected Error");
        }
    }

    /**
     * Method for generating new message id
     * 
     * @return message id
     */
    public static String newMessageId() {
        return "UID-" + new UID().toString();
    }

    /**
     * Method for getting the system date
     * 
     * @return
     */
    public static String newSentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        return dateFormat.format(new Date());
    }

    /**
     * Method for formatting MsgData
     */
    public static String formatMsgData(String mwmh, String swiftMessage) {
        StringBuilder msgData = new StringBuilder();
        msgData.append("<MWMS>");
        msgData.append(mwmh);
        msgData.append("<MWMB><![CDATA[");
        msgData.append(swiftMessage);
        msgData.append("]]></MWMB>");
        msgData.append("</MWMS>");
        return msgData.toString();
    }


    public static void setErrorMessage(
            Exception e,
            Map<String, Object> returnValues,
            String errorCode,
            String errorDescription) {
        returnValues.put(ERRORCODE, errorCode);
        returnValues.put(ERRORDESC, errorDescription + ". Details: " + e.getMessage());
    }

    /**
     * Method returns an XML tag
     * 
     * @param tagName
     * @param tagValue
     * @return formatted XML tag
     */
    public static String formatXMLTag(String tagName, String tagValue) {
        StringBuilder tag = new StringBuilder();
        tag.append("<").append(tagName).append(">").append(tagValue).append("</").append(tagName).append(">");
        return tag.toString();
    }

    /**
     * Method for rolling back SQL transaction and logging error messages
     * 
     * @param conn SQL connection
     * @param e Exception
     * @throws SQLException if SQL connection fails
     */
    public static void rollbackSQLTransaction(
            SQLConnection conn,
            Exception e,
            LoggerConnection logger,
            String errorMessage) throws SQLException {
        if (conn != null) {
            conn.rollback();
        }
        logger.error(errorMessage + ". Details: " + e.getMessage(), e);
    }

    /**
     * Method gets the value of the named field from the given list
     * 
     * @param fields list of fields
     * @param key name of field of interest
     * @return value of given field
     */
    public static String getFieldValue(List<?> fields, String key) {
        for (Iterator<?> i = fields.iterator(); i.hasNext();) {
            Field field = (Field) i.next();
            if (key.equalsIgnoreCase(field.getName())) {
                String value = field.getValue();
                return value == null ? "" : value.trim();
            }
        }
        return "";
    }
}
