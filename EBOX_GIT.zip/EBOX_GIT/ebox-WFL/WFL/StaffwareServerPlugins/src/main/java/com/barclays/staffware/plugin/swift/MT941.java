package com.barclays.staffware.plugin.swift;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TagHelper;
import com.barclays.staffware.plugin.util.ValidateSwift;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

/**
 * EAIJava plugin for creating SWIFT message MT941
 * @author LEES
 *
 */
public class MT941 extends SwiftMessage implements ImmediateReleasePluginSDK {

	private final LoggerConnection logger = 
		new LoggerConnection(MT941.class);
	
	private final String INITIALIZATION_FAILED = 
		SwiftParams.initializationFailed(MT941.class.getName());
	
	private String tag20;
	
	/**
	 * Gets for TAG_20
	 * @return tag20
	 */
	public String getTag20(){
		return tag20;
	}
	
	/**
	 * Sets tag20
	 * @param tag20
	 * 			Input from Staffware
	 * @throws Exception
	 * 			If TAG_20 is missing
	 */
	public void setTag20(String tag20) throws Exception {
		if (tag20 == null || tag20.trim().isEmpty()){
			throw new Exception(SwiftParams.TAG_20_ERROR);
		}
		this.tag20 = tag20.trim();
	}

	/**
	 * Method Staffware calls in eaijava step
	 * 
	 * @param staticData
	 * 			a string hardcoded in Staffware, this is ignored in this 
	 * 			method
	 * @param outputFields
	 * 			a list of Staffware field objects which Staffware expects to 
	 * 			be returned
	 * @param inputFields
	 * 			a list of Staffware field objects which Staffware provides 
	 * 			(with values)
	 * @return the name value pairs returned to Staffware
	 */
	@Override
	public Map executeProcess(String staticData, List outputFields, List inputFields)
			throws FatalPluginException,
			NonFatalPluginException {
		Map<String, Object> result = 
			new HashMap<String, Object>(outputFields.size());
		StaffwareHelper.initialiseReturnValues(outputFields, result);
		try {
			setMessageType("941");
			if (logger.isDebugEnabled()){
				logger.debug("Arguments received from Staffware: ");
				for (Iterator<?> i = inputFields.iterator(); i.hasNext();){
					Field field = (Field) i.next();
					logger.debug(field.getName() + " = " + field.getValue());
				}
			}
			setSender(getFieldValue(inputFields, "SENDER"));
			setReceiver(getFieldValue(inputFields, "RECEIVER"));
			setTag20(getFieldValue(inputFields, "TAG_20"));
			StringBuffer swiftMessage = new StringBuffer();
			basicHeaderBlock(
					swiftMessage, getSender());
			applicationHeaderBlock(
					swiftMessage, getMessageType(), getReceiver());
			appendUserHeaderBlock(
					swiftMessage, TagHelper.formatHeaderTag(getTag20()));
			messageBlock(swiftMessage, formatMessageTags(inputFields));
			result.put("STATUSCODE", "0");
			result.put("SWIFT_" + getMessageType(), swiftMessage);
		} catch (Exception e){
			String executeFailed = 
				SwiftParams.cannotFormMessage(getMessageType());
			if (logger.isErrorEnabled()){
				logger.error(
						executeFailed  + ". Details: " + e.getMessage(), e);
			}
			StaffwareHelper.setErrorMessage(e, result, "-1", executeFailed);
		}
		if (logger.isDebugEnabled()){
			logger.debug("Returning values to Staffware: ");
			List<String> keys = new ArrayList<String>(result.keySet());
			Collections.sort(keys);
			for (Iterator<?> i = keys.iterator(); i.hasNext(); ){
				String key = (String) i.next();
				logger.debug(key + " <- " + result.get(key));
			}
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * @see com.barclays.staffware.plugin.swift.SwiftMessage#formatMessageTags(java.util.List)
	 */
	@Override
	protected StringBuffer formatMessageTags(List<?> inputFields)
			throws Exception {
		
		StringBuffer tags = new StringBuffer();
		
		appendMandatoryTag(tags, 
				ValidateSwift.validateSwiftXCharacters(getTag20(), 16), 
				"20", SwiftParams.TAG_20_ERROR);
		
		appendOptionalTag(tags, 
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_21"), 16), "21");
		
		appendMandatoryTag(tags, 
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_25"), 35), 
				"25", SwiftParams.TAG_25_ERROR);
		
		appendMandatoryTag(tags, 
				ValidateSwift.validate941StatementSequence(
						getFieldValue(inputFields, "TAG_28")), 
				"28", SwiftParams.TAG_28_ERROR);
		
		appendOptionalTag(tags, 
				ValidateSwift.validateTag13D(
						getFieldValue(inputFields, "TAG_13D")), "13D");
		
		appendOptionalTag(tags, 
				ValidateSwift.validateMarkDateCurrencyAmount(
						getFieldValue(inputFields, "TAG_60F")), "60F");
		
		appendMandatoryTag(tags, 
				ValidateSwift.validateMarkDateCurrencyAmount(
						getFieldValue(inputFields, "TAG_62F")), 
				"62F", SwiftParams.TAG_62FM_ERROR);
		
		appendOptionalTag(tags, 
				ValidateSwift.validateMarkDateCurrencyAmount(
						getFieldValue(inputFields, "TAG_64")), "64");
		
		appendOptionalTag(tags, 
				ValidateSwift.validateMarkDateCurrencyAmount(
						getFieldValue(inputFields, "TAG_65_1")), "65");
		
		appendOptionalTag(tags, 
				ValidateSwift.validateMarkDateCurrencyAmount(
						getFieldValue(inputFields, "TAG_65_2")), "65");
		
		return tags;
	}
	

}
