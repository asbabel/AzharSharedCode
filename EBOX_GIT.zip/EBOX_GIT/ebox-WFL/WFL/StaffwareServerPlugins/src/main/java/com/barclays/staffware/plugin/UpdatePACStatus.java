package com.barclays.staffware.plugin;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;


/**
 * EAI java plugin for updating the status of the PAC table
 * 
 * @author LEES
 * 
 */
/*
 * DATE		REFERENCE	WHO		VERSION		COMMENTS
 * ----		---------	---		-------		--------
 * 9Feb15   WP697		ABMH709	1a			Created
 * 15Feb15  WP697       ABSH495 1b          Updated Parameters
 * 17Jan17  WP715       LeyJ    -           Refactored data access to MWDB.
 */
public class UpdatePACStatus implements ImmediateReleasePluginSDK {

    private static final LoggerConnection log = new LoggerConnection(
            UpdatePACStatus.class);
    private final String initializationFailed = SwiftParams.initializationFailed(UpdatePACStatus.class.getName());

    /**
     * Will be passed the contents of eaijava properties file in the
     * root:/swserver/sw_africa/eaijava/ folder Will be called by staffware
     * before each execute (unless a caching option is selected in staffware)
     */
    public void initialize(Properties properties)
            throws FatalPluginException,
            NonFatalPluginException {
        try {
            //DataSourceDirectory.getInstance().configure(properties);
            ClassPathResource resource = new ClassPathResource(properties.getProperty("updatePacStatusLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());

            DataSourceDirectory.getInstance().basePluginDS();
            // load db driver (unsure if necessary)
            //Class.forName(properties.getProperty("db_driver"));
            //LoggerConnection.configureWFL(properties.getProperty("updatePacStatusLog"));
            log.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	log.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }

    }

    /**
     * Method Staffware calls in eaijava step
     * 
     * @param staticData a string hardcoded in Staffware, this is the value to
     * update the status with
     * @param outputFields a list of Staffware field objects which Staffware
     * expects to be returned
     * @param inputFields a list of Staffware field Objects which Staffware
     * provides (with values)
     * @return the name value pairs returned to Staffware
     */
    @SuppressWarnings("rawtypes")
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {

        // Prepare Output Map
        Map<String, Object> results =
                new HashMap<String, Object>(outputFields.size());
        StaffwareHelper.initialiseReturnValues(outputFields, results);

        try {
            updatePACStatus(inputFields);
            results.put("STATUSCODE", "0");
            results.put("STATUSDESC", "SUCCESS");
        } catch (SQLException e) {
            log.error("Error updating PAC status", e);
            results.put("STATUSDESC", e.getMessage());
        }

        return results;
    }

    @SuppressWarnings("rawtypes")
    public void updatePACStatus(List fields) throws SQLException {

        // Create Stored Proc Arguments
        SortedMap<String, Object> args = createInputArgs(fields);

        // Execute the stored procedure to update the status
        SQLConnection conn = MWDBAccess.getDatabaseConnection();
        ResultSet rs = null;
        try {
            CallableStatement cs =
                    conn.prepareCall("sfw_PACUpdateStatus", args);
             rs = conn.executeQuery(cs, args);
            if (rs.next()) {
                if (rs.getInt("RETURN_VALUE") < 1) {
                    throw new SQLException(SwiftParams.SP_ERROR);
                }
            }
        } finally {
            conn.close();
            if(rs != null) {
            	rs.close();
            }
        }

    }

    /**
     * Created the SortedMap required for the Stored Proc
     * 
     * @param Input Fileds from Staffware
     * @return Sorted Map of the arguments for the Stored Procedure
     */
    @SuppressWarnings("rawtypes")
    public SortedMap<String, Object> createInputArgs(List fields) {

        SortedMap<String, Object> args = new TreeMap<String, Object>();

        for (int i = 0; i < fields.size(); i++) {
            Field field = (Field) fields.get(i);
            String name = field.getName();
            String value = field.getValue();

            if ("SW_CASENUM".equalsIgnoreCase(name)) {
                args.put("_SW_CASENUM", value);
            } else if ("SW_PRONAME".equalsIgnoreCase(name)) {
                args.put("_SW_PRONAME", value);
            } else if ("ERRORCODE".equalsIgnoreCase(name)) {
                args.put("_ErrorCode", value);
            } else if ("ERRORDESC".equalsIgnoreCase(name)) {
                args.put("_ErrorMessage", value);
            } else if ("PACSTATUS".equalsIgnoreCase(name)) {
                args.put("_Status", value);
            }
        }
        return args;
    }
}
