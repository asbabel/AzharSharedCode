package com.barclays.staffware.plugin.util;

/**
 * Utilized for constants used in any class in the
 * com.barclays.staffware.plugin.pain package
 * 
 * @author ABSH495
 * 
 */

/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 25Jan16   SEFTP2    SRH      1a     Created for Constants
 * 18JUL16   SEFTP2    AS       1b     Added constants as part of SEFT Phase 2 Integration Changes
 * 08SEP16			   Anup			   Added new constants related to SEFT turn on/off switch
 * 17DEC17   WP749 	   Akhilesh 1d     Added New Constant as part of WP749 SEFT narrative
 */
public final class PainParams {

    /**
     * PainParams private constructor.
     */
    private PainParams() {

    }

    //Error handling Constants
    public static final String MQERROR = "Unable to Send Message to MQ: ";
    public static final String PARSEERROR = "Failed to parse values: ";
    public static final String SPERROR = "Error executing stored procedure: ";
    public static final String IOERROR = "Error loading properties file: ";
    public static final String PAINUTILERROR =
            "Error creating PAIN001 Request: ";
    public static final String DBERROR =
            "Unable to Retrieve Information from MWDB: ";
    public static final String CLASSNOTFOUNDERROR =
            "Unable to Initialize Class: ";
    public static final String INVALID_BUSINESS_DATE =
            "Unable to parse the business date received from BRAINS.";
    public static final String MISSING_BUSINESS_DATE =
            "No business date received from BRAINS for this country.";
    public static final String GLDERROR = "Unable to execute GLD_I Token: ";
    public static final String CUSTNOERROR =
            "Unable to Retrive Customer Number from Brains: ";
    public static final String BRAINSERR =
            "Unable to retrieve information from Brains";
    public static final String CLOSERESOURCESERR = "Unable to close resources";
    public static final String INITIALIZATIONFAILED = "Error initialising: ";

    //Status and Error Return Values for Staffware
    public static final String STATUSCODE = "STATUSCODE";
    public static final String STATUSDESC = "STATUSDESC";
    public static final String SUCCESS = "SUCCESS";
    public static final String SUCCESSCODE = "0";
    public static final String ERRORCODE = "1";
    public static final String ERRORDESC = "A technical error has occured, please contact your administrator.";
    public static final String UPDATED = "UPDATED";
    public static final String NOTUPDATED = "NOT UPDATED";
    public static final String CURRENTSTATUS = "CURRENTSTATUS";
    public static final String RESPONSESTATUS = "RESPONSESTATUS";

    //Date Format Constants
    public static final String VALUEDATEFROM = "ddMMyy";
    public static final String VALUEDATETO = "yyyy-MM-dd";

    //Properties from a loaded propfile
    public static final String POSTPAINMESSAGEPROP = "postPainMessage";
    public static final String DBDRIVER = "db_driver";
    public static final String MQPARAMS = "seft_mq_params";

    //Informational Messages
    public static final String STAFFWAREARGS =
            "Arguments received from Staffware: ";
    public static final String PAINREQCREATED = "Pain Request Created: ";
    public static final String SENTTOMQ = "Sent PAIN Request to MQ";

    //Params Passed in from Staffware
    public static final String GROUPID = "GROUP_ID";
    public static final String ITEMNUMBER = "ITEM_NUMBER";
    public static final String COUNTRY = "COUNTRY";
    public static final String EBOX_ACT_REF = "EBOX_ACT_REF";

    //Params Returned from Brains
    public static final String BUSINESSDATE = "BUSINESS_DATE";
    public static final String CUSTOMERNUMBER = "CUSTOMER_NUMBER";

    //Stored Procedures
    public static final String SP_GETPAINREQUESTDETAILS =
            "sfw_getPainRequestDetails";

    //Database fields from MWDB
    public static final String DBCOUNTRY = "Country";
    public static final String DBOFFSHOREIND = "OffshoreInd";
    public static final String DBORIGINATORNAME = "OriginatorName";
    public static final String DBIBANNUMBER = "IBANNumber";
    public static final String DBORIGINATORBRANCHID = "OriginatorBranchId";
    public static final String DBORIGINATORACCOUNTNUMBER =
            "OriginatorAccountNumber";
    public static final String DBCOUNTERPARTYBANKCODE = "CounterpartyBankCode";
    public static final String DBCOUNTERPARTYNAME = "CounterpartyName";
    public static final String DBCOUNTERPARTYNUMBER =
            "CounterpartyAccountNumber";
    public static final String DBCOUNTERLOCALAMOUNT = "CounterpartyLocalAmount";
    public static final String DBCOUNTERPARTYCURRENCY = "CounterpartyCurrency";
    public static final String DBSENDERSREFERENCE = "SendersReference";
    public static final String DBTRXID = "TrxId";
    public static final String DBPAYMENTTYPE = "PaymentType";
    public static final String DBORIGINATORNARRATIVE = "OriginatorNarrative";
    public static final String DBEMPTYNARRATIVE = "(None)";
    public static final String DBCOUNTERPARTYBRANCHID = "CounterpartyBranchId";
    public static final String DBPURPOSE = "Description";  
    public static final String DBCOUNTERPARTYNARRATIVE = "CounterpartyNarrative";//WP749 Changes
    public static final String DBCOUNTERPARTYREMITTANCEINFORMATION = "CounterpartyRemittanceInformation";//WP749 Changes
    
    
    //Integer Constants
    public static final int INTEGERFOUR = 4;
    
    //String Constants for SEFT turn on/off switch Fields
	public static final String SP_GETCOUNTRYCONFIGDETAILS = "csc_getCountryAttributeValue";
	public static final String ADDITIONAL_PAIN001_MESSAGE_FLAG = "Allow PAIN001 Message To Send Additional Fields to Meridian";
	public static final String VALUE = "Value";
    
    /**
     * PainStatus Enum mainly utilized for "ranking" pain statuses as they may
     * be Received in random order.
     * 
     * @author ABSH495
     * 
     */
    public enum PainStatus {
        ACTC("ACTC", 1), ACCP("ACCP", 2), ACSP("ACSP", 3), RJCT("RJCT", 4);

        private final String painStatus;
        private final int rank;

        private PainStatus(String painStatus, int rank) {
            this.painStatus = painStatus;
            this.rank = rank;
        }

        public String getPainStatus() {
            return painStatus;
        }

        public int getRank() {
            return rank;
        }
    }
    
    public static String initializationFailed(String className) {
        return "Error initializing " + className;
    }

}
