package com.barclays.staffware.plugin.swift;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.data.IMWDBAccess;
import com.barclays.staffware.data.MWDBAccess;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.staffware.plugin.util.TagHelper;
import com.barclays.staffware.plugin.util.ValidateSwift;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;


/**
 * EAI java plugin for creating SWIFT message MT103 </br>
 * Please note that this class does not currently process all the tags 
 * in the swift standards.  Some optional fields are ignored because we do
 * not currently use them.
 * @author LEES
 *
 */
/*
 * DATE		REFERENCE	WHO		VERSION		COMMENTS
 * ----		---------	---		-------		--------
 * 09SEP14	WP668		SL		1.00		Created for SM04
 * 16MAR15	WP668		SL		1.01		Defect #76 fix
 * 05MAY15	WP668		SL		1.02		Defect #97 fix
 * 14SEP15	WP668		YA		1.03		Live PCA2 issue fix
 * 14SEP15	WP668		PH		1.04		Only use tag 56A if 57A is present
 * 28SEP15  WP668       YA		1.05        Check TAG_50F_ID for populating tag 50F.
 * 28SEP15  WP668       AK      1.06        Modified code as part of Zambia RTGS payment fix for INC0030143712
 * 06OCT15  WP668       YA      1.07        Populate tag 56A only if any of Tag 57 is present.
 * 29OCT15  WP695       YA      1.08        Updated logic to populate 50F tag as per new SWIFT standards
 * 03SEP18  WP774		PC		1.09		Updated logic to populate UETR if come blank or empty
 */
public class MT103 extends SwiftMessage implements ImmediateReleasePluginSDK {


	private final String INITIALIZATION_FAILED = 
		SwiftParams.initializationFailed(MT103.class.getName());
	
	private final String SWIFT_GPI_MEMBER = "SWIFT GPI Member";
	
	private String paymentType;
	private String country;
	private String offshoreInd;
	private String instCur;
	
	private boolean produce202;
	
	private int datastoreId;
	private int groupId;
	
	private IMWDBAccess dataAccess;
	
	/**
	 * Getter for PAYMENT_TYPE
	 * @return paymentType
	 */
	public String getPaymentType() throws Exception{
		if (paymentType == null || paymentType.trim().isEmpty()){
			throw new Exception(SwiftParams.MISSING_PAYMENT_TYPE);
		}
		return paymentType;
	}
	
	/**
	 * Getter for COUNTRY
	 * @return country
	 */
	public String getCountry() throws Exception{
		if (country == null || country.trim().isEmpty()){
			throw new Exception(SwiftParams.COUNTRY_ERROR);
		}
		return country;
	}
	
	/**
	 * Getter for OFFSHORE_IND
	 * @return offshoreInd
	 */
	public String getOffshoreInd() throws Exception {
		if (offshoreInd == null || offshoreInd.trim().isEmpty()){
			throw new Exception(SwiftParams.OFFSHORE_IND_ERROR);
		}
		return offshoreInd;
	}

	/**
	 * Getter for INST_CUR
	 * @return instCur
	 */
	public String getInstCur() throws Exception {
		if (instCur == null || instCur.trim().isEmpty()){
			throw new Exception(SwiftParams.INST_CUR_ERROR);
		}
		return instCur;
	}
	
	public boolean isProduce202(){
		return produce202;
	}
	
	@Override
	public void initalizeCustomStep() {	
		this.dataAccess = new MWDBAccess();
	}

	/**
	 * Method Staffware calls in eaijava step
	 * 
	 * @param staticData
	 * 			a string hardcoded in Staffware, this is ignored in this
	 * 			method
	 * @param outputFields
	 * 			a list of Staffware field objects which Staffare expects to 
	 * 			be returned
	 * @param inputFields
	 * 			a list of Staffware field objects which Staffware provides 
	 * 			(with values)
	 * @return the name value pairs returned to Staffware
	 */
	@Override
	public Map executeProcess(String staticData, List outputFields, List inputFields)
			throws FatalPluginException,
			NonFatalPluginException {
		Map<String, Object> result = 
			new HashMap<String, Object>(outputFields.size());
		StaffwareHelper.initialiseReturnValues(outputFields, result);
		try {
			setMessageType("103");
			if (logger.isDebugEnabled()){
				logger.debug("Arguements receivered from Staffware: ");
				for (Iterator<?> i = inputFields.iterator(); i.hasNext();){
					Field field = (Field) i.next();
					logger.debug(field.getName() + " = " + field.getValue());
				}
			}
			setClassProperties(inputFields);
			setSender(getFieldValue(inputFields, "SENDER"));
			setReceiver(getFieldValue(inputFields, "RECEIVER"));
			StringBuffer swiftMessage = new StringBuffer();
			
			basicHeaderBlock(swiftMessage, getSender());
			applicationHeaderBlock(
					swiftMessage, getMessageType(), getReceiver());
			String tag103 = getFieldValue(inputFields, "TAG_103");
			String tag108= getFieldValue(inputFields, "TAG_20");
			String tag111 = null;
			String tag121 = null;
			boolean GPIMember = dataAccess.getCountryAttribute(
					getCountry(), getOffshoreInd(), SWIFT_GPI_MEMBER);
			if(datastoreId != 0){
				Map<String, String> swiftProperties = dataAccess.getSwiftMessageProperties(datastoreId);
				tag111 = swiftProperties.get("111");
				tag121 = swiftProperties.get("121");
			} 
			
			if(null == tag111){
				tag111 = "001";
			}
			if(StringUtils.isBlank(tag121)){
				tag121 = UUID.randomUUID().toString();
			}
			
			appendUserHeaderBlock(swiftMessage, 
					TagHelper.formatHeaderTags(
							tag103, 
							"BIFD", 
							(tag103 != null && !tag103.isEmpty()) || isProduce202(),country, tag108, tag111,
							tag121, GPIMember,getMessageType()));
			messageBlock(swiftMessage, formatMessageTags(inputFields));
			result.put("MT103_UETR", tag121);
			result.put("STATUSCODE", "0");
			result.put("SWIFT_" + getMessageType(), swiftMessage);
			if (logger.isDebugEnabled()){
				logger.debug("Returning values to Staffware: ");
				List<String> keys = new ArrayList<String>(result.keySet());
				Collections.sort(keys);
				for (Iterator<?> i = keys.iterator(); i.hasNext();){
					String key = (String) i.next();
					logger.debug(key + " <- " + result.get(key));
				}
			}
		} catch (Exception e){
			String executeFailed = 
				SwiftParams.cannotFormMessage(getMessageType());
			if (logger.isErrorEnabled()){
				logger.error(executeFailed + ". Details: " + e.getMessage(), e);
			}
			StaffwareHelper.setErrorMessage(e, result, "-1", executeFailed);
		}
		return result;
	}
	
	/**
	 * Method that formats the optional tag 56A
	 *
	 * @param tags
	 * 			a StringBuffer containing the output tags for the SWIFT message
	 * @param inputFields
	 * 			a list of Staffware field objects which Staffware provides 
	 * 			(with values)
	 */
	private void formatTag56A(StringBuffer tags, List<?> inputFields)
			throws Exception {
		String tag56a = getFieldValue(inputFields, "TAG_56A"); 
		
		if (tag56a != null && !tag56a.isEmpty() && 
				!getReceiver().equalsIgnoreCase(tag56a)){
			appendOptionalTag(tags, 
					ValidateSwift.validateIdBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_56A_ID"), 
									tag56a)), 
					"56A");
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.barclays.staffware.plugin.swift.SwiftMessage#formatMessageTags(java.util.List)
	 */
	@Override
	protected StringBuffer formatMessageTags(List<?> inputFields)
			throws Exception {
		StringBuffer tags = new StringBuffer();
		String tag70 = "";
		Map<Integer, String> tag71F = null;
		String tag72 = "";
		String tag33B = "";

		String currency = "";
		Map<String, String> tag50 = null;
		String tag103 = getFieldValue(inputFields, "TAG_103");
		boolean isRTGS=(tag103 != null && !tag103.isEmpty());
		if (datastoreId > 0){
			tag70 = 
				this.dataAccess.getSwiftItemValue(
						datastoreId, "Remittance Information");
			tag72 = 
				this.dataAccess.getSwiftItemValue(
						datastoreId, "Sender to Receiver Information");
			tag71F = 
				this.dataAccess.getSendersCharges(datastoreId);
			
			currency = this.dataAccess.getSwiftItemValue(datastoreId, "Currency");
			String amount = this.dataAccess.getSwiftItemValue(datastoreId, "Instructed Amount");
			
			if (currency != null && !currency.isEmpty() && 
					amount != null && !amount.isEmpty()){
				tag33B = currency + amount;	
			} else {
				currency = this.dataAccess.getSwiftItemValue(datastoreId, "Original Ordered Currency");
				amount = this.dataAccess.getSwiftItemValue(datastoreId, "Original Ordered Amount");
				if (currency != null && !currency.isEmpty() && 
						amount != null && !amount.isEmpty()){
					tag33B = currency + amount;	
				}
			}
			
		}
		appendMandatoryTag(tags, 
				ValidateSwift.validateSwiftXCharacters(
						getFieldValue(inputFields, "TAG_20"), 16), 
				"20", SwiftParams.TAG_20_ERROR);
		appendMandatoryTag(
				tags, 
				ValidateSwift.validateAlphaNumberic(
						getFieldValue(inputFields, "TAG_23B"), 4), 
				"23B", SwiftParams.TAG_23B_ERROR);
		String tag32A = getFieldValue(inputFields, "TAG_32A");
		appendMandatoryTag(
				tags, 
				ValidateSwift.validateDateCurrencyAmount(tag32A), 
				"32A", SwiftParams.TAG_32A_ERROR);
		
		if (tag33B != null && !tag33B.isEmpty()){
			appendOptionalTag(tags, ValidateSwift.validateCurrencyAmount(
						tag33B), "33B");
			// defect #97 fix - If field 33B is present and the currency code is 
			// different from the currency code in field 32A, field 36 must be present
			if (!currency.equals(tag32A.substring(6, 9))){
				String tag36 = 
					this.dataAccess.getSwiftItemValue(datastoreId, "Exchange Rate");
				if (tag36 != null && !tag36.isEmpty()){
					appendMandatoryTag(tags, 
							ValidateSwift.validateAmount(tag36, 12), 
							"36", SwiftParams.TAG_36_ERROR);
				}
			}
		} else {
			appendOptionalTag(
					tags, 
					ValidateSwift.validateCurrencyAmount(
							getFieldValue(inputFields, "TAG_33B")), 
					"33B");
			appendOptionalTag(
					tags, 
					ValidateSwift.validateAmount(
							getFieldValue(inputFields, "TAG_36"), 12), 
					"36");
		}
		
		
		
		String tag = getFieldValue(inputFields, "TAG_50A_BIC");
		if (tag != null && !tag.trim().isEmpty()){
			appendOptionalTag(
					tags, 
					ValidateSwift.validateAccountBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_50A_ACC"), 
									tag)), 
					"50A");
		} else {
			String tag50FId = getFieldValue(inputFields, "TAG_50F_ID");
			String tag50FAddr1 = getFieldValue(inputFields, "TAG_50F_ADDR_1");
			if (tag50FId != null && !tag50FId.trim().isEmpty()
					&& tag50FAddr1 != null && !tag50FAddr1.trim().isEmpty()){
				appendOptionalTag(tags,
						TagHelper.format50FTag(inputFields, tag50FId, tag50FAddr1), "50F");
			} else {
				appendPartyIdNameAddressTag(
						tags, inputFields, "50K", "TAG_50K_", 
						SwiftParams.TAG_50AFK_ERROR);
			}
		} 
		

		String tag52a = getFieldValue(inputFields, "TAG_52A_BIC");
		if (tag52a != null && !tag52a.isEmpty()){
			appendOptionalTag(
					tags, 
					ValidateSwift.validateIdBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_52A_ID"), 
									getFieldValue(inputFields, "TAG_52A_BIC"))), 
					"52A");
		} else {
			Map<String, Object> tag52d = new HashMap<String, Object>();
			TagHelper.setGroupTags(tag52d, inputFields, "TAG_52D_");
			appendOptionalTag(tags, 
					ValidateSwift.validateIdNameAddress(
							TagHelper.formatPartyAddrTag(
									tag52d, "TAG_52D_", "TAG_52D_ID")), "52D");
		}
		
		String tag53b = getFieldValue(inputFields, "TAG_53B");
		
		appendTag53(
				tags,
				getFieldValue(inputFields, "TAG_53A"), 
				tag53b,
				this.dataAccess.getCorrespAccId(
						tag53b, getPaymentType(), getInstCur(), 
						getCountry(), getOffshoreInd()));
		
		appendOptionalTag(
				tags, 
				ValidateSwift.validateIdBIC(
						getFieldValue(inputFields, "TAG_54A")), "54A");
		
		String tag57 = getFieldValue(inputFields, "TAG_57A");
		if (tag57 != null && !tag57.isEmpty()){  
			if (!getReceiver().equalsIgnoreCase(tag57)){
				// format 56A now that we know a tag 57a option is present
				formatTag56A(tags, inputFields);
				// now format tag 57A
				appendOptionalTag(
						tags, 
						ValidateSwift.validateIdBIC(
								TagHelper.formatPartyIdBIC(
										getFieldValue(
												inputFields, "TAG_57A_2"), tag57)), 
						"57A");
			}
		} else {
			tag57 = getFieldValue(inputFields, "TAG_57B_LOC");
			if (tag57 != null && !tag57.isEmpty()){
				// format 56A now that we know a tag 57a option is present
				formatTag56A(tags, inputFields);
				// now format tag 57B
				appendOptionalTag(
						tags, 
						ValidateSwift.validateIdLocation(
								TagHelper.formatPartyIdBIC(
										getFieldValue(
												inputFields, "TAG_57B_ID"), tag57)), 
						"57B");
			} else {
				Map<String, Object> tag57d = new HashMap<String, Object>();
				TagHelper.setGroupTags(tag57d, inputFields, "TAG_57D_");
				String tag57add = getFieldValue(inputFields, "TAG_57D_ADDR_1");
				if (tag57add != null && !tag57add.isEmpty()){
					// format 56A now that we know a tag 57a option is present
					formatTag56A(tags, inputFields);
					// now format tag 57D
					appendOptionalTag(tags,
							ValidateSwift.validateIdNameAddress(
									TagHelper.formatTagAddress(
											tag57d, "TAG_57D_", "ID")), "57D");
				} else {
					tag57 = getFieldValue(inputFields, "TAG_57C");
					
					if(tag57 != null && !tag57.isEmpty()){
						// format 56A now that we know a tag 57a option is present
						formatTag56A(tags, inputFields);
						// now format tag 57C
						appendOptionalTag(
								tags, 
								ValidateSwift.validateAccount(tag57), "57C");
					}
				}
			}
		} 
		String tag59 = getFieldValue(inputFields, "TAG_59_NAME");
		String tag59Addr1 = getFieldValue(inputFields, "TAG_59F_ADDR_1");
		if(tag59Addr1 != null && !tag59Addr1.isEmpty()){
			appendOptionalTag(tags,
					TagHelper.format59FTag(inputFields), "59F");
		} else if (tag59 != null && !tag59.isEmpty()){
			appendGroupTag(tags, inputFields, "59", "TAG_59_");
		} else {
			appendMandatoryTag(
					tags, 
					ValidateSwift.validateAccountBIC(
							TagHelper.formatPartyIdBIC(
									getFieldValue(inputFields, "TAG_59A_ACC"), 
									getFieldValue(inputFields, "TAG_59A_BIC"))), 
					"59A", SwiftParams.TAG_59A_ERROR);
		}
		
		if (tag70 != null && !tag70.isEmpty()){
			appendOptionalTag(
					tags, 
					ValidateSwift.validateMultiLineSwiftX(tag70, 4, 35), "70");
		} else {
			appendGroupTag(tags, inputFields, "70", "TAG_70_", 4, 35);
		}
		
		appendMandatoryTag(
				tags, 
				ValidateSwift.validateAlphabetic(
						getFieldValue(inputFields, "TAG_71A"), 3), 
				"71A", SwiftParams.TAG_71A_ERROR);
		
		if (tag71F != null && !tag71F.isEmpty()){
			SortedSet<Integer> keys = new TreeSet<Integer>(tag71F.keySet());
			for (Integer key : keys) {
				appendOptionalTag(tags, 
						ValidateSwift.validateCurrencyAmount(
								tag71F.get(key)), "71F");
			}
		}
		appendOptionalTag(tags, 
				ValidateSwift.validateCurrencyAmount(
						getFieldValue(inputFields, "TAG_71F_2")), "71F");
		
		appendOptionalTag(tags, 
				TagHelper.formatCurrencyAmount(
						getFieldValue(inputFields, "TAG_71G")), "71G");
		
		//Added code for zambia RTGS payment
		if(SwiftParams.ZAMBIA.equals(country) && isRTGS){
			tag72=formTag72(tag72, inputFields);
			//avoid swift validation and form tag 72
			appendOptionalTag(tags, tag72, "72");
		}else if (tag72 != null && !tag72.isEmpty()){
			appendOptionalTag(
					tags, ValidateSwift.validateMultiLineSwiftX(tag72, 6, 35), "72");
		} else {
			appendGroupTag(tags, 
					inputFields, "72", "TAG_72_", 6, 35);
		}
		
		return tags;
	}
	
	/**
	 * Method for setting some of the class properties
	 * @param inputFields
	 * 			Inputs from Staffware
	 */
	private void setClassProperties(List<?> inputFields) throws Exception {
		for (Object inputField : inputFields){
			Field field = (Field) inputField;
			String name = field.getName().trim();
			String value = field.getValue().trim();
			if ("PAYMENT_TYPE".equalsIgnoreCase(name)){
				paymentType = value;
			} else if ("COUNTRY".equalsIgnoreCase(name)){
				country = value;
			} else if ("OFFSHORE_IND".equalsIgnoreCase(name)){
				offshoreInd = value;
			} else if ("INST_CUR".equalsIgnoreCase(name)){
				instCur = value;
			} else if ("PRODUCE_202".equalsIgnoreCase(name)){
				produce202 = "Yes".equalsIgnoreCase(value) ? true : false;
			} else if ("GROUP_ID".equalsIgnoreCase(name)){
				groupId = Integer.parseInt(value);
				datastoreId = 
					this.dataAccess.getDatastoreIdByGroupId(groupId);
			}
		}
	}
	
	/**Method to form tag72 used for RTGS ZAMBIA payment
	 * @param tag72
	 * @param inputFields
	 * @throws Exception
	 */
	private String formTag72(String tag72,List<?> inputFields) throws Exception{
		
	        StringBuffer formattedTag72=new StringBuffer();
	        formattedTag72.append("/TTC/"+this.dataAccess.getMwRefValueDescription(country,offshoreInd,SwiftParams.DOMAIN_103TTC,SwiftParams.RTGS));
	        formattedTag72.append(SwiftParams.NEW_LINE);
	        formattedTag72.append("/REC/"+this.dataAccess.getMwRefValueACCRECCode(country,offshoreInd,getFieldValue(inputFields, "TAG_59_ACC").replaceFirst("/","")));
	        formattedTag72.append(SwiftParams.NEW_LINE);
	        formattedTag72.append("/RPF/"+getFieldValue(inputFields, "TAG_50K_ACC").replaceFirst("/",""));
	        formattedTag72.append(SwiftParams.NEW_LINE);
	        formattedTag72.append("/USR/"+"^AUTH^");
			tag72=formattedTag72.toString();
		
		return tag72;
	}

}
