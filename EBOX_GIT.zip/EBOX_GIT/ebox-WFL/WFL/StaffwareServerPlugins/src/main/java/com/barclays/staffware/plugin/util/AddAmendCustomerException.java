package com.barclays.staffware.plugin.util;


public class AddAmendCustomerException extends Exception {
    private AddAmendCusErrorScenario errorScenario;

    private AddAmendCustomerException() {
        super();
    }

    public AddAmendCustomerException(AddAmendCusErrorScenario errorScenarion) {
        super();
        this.errorScenario = errorScenarion;
    }

    public AddAmendCustomerException(String msg, AddAmendCusErrorScenario errorScenario) {
        super(msg);
        this.errorScenario = errorScenario;
    }

    public AddAmendCustomerException(String msg, Throwable cause, AddAmendCusErrorScenario errorScenario) {
        super(msg, cause);
        this.errorScenario = errorScenario;
    }

    public AddAmendCusErrorScenario getErrorScenario() {
        return this.errorScenario;
    }
}