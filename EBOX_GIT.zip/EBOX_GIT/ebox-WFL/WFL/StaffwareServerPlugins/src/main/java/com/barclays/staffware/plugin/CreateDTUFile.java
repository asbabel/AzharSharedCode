package com.barclays.staffware.plugin;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;

/**
 * @author James
 *
 * generate DTU file from WFL to MDW  
 */
/*
 * DATE     REFERENCE  WHO    		VERSION  COMMENTS
 * -------  ---------  ---    		-------  -----------------------------------
 * 30April12   WP559    James         1        created
 * 26MAR14	WP669		SL			1.01		enhanced to handle MT900 + 910
 * 16Oct2014  WP679      PHH            2        Fix to help prevent duplicate BFG 
 *                                               filename generation
 * 02APR2018 WP758     Akhilesh       2.1     Changes for WP758 Statement files to H2H                  
 */
public class CreateDTUFile implements ImmediateReleasePluginSDK{
	private static final LoggerConnection logger=new LoggerConnection(CreateDTUFile.class);
	private String dtuFilePath;
	private String bfgFilePath;
	private String h2hFilePath;
	private final String initializationFailed = SwiftParams.initializationFailed(CreateDTUFile.class.getName());
	
	/**
	 * Will be passed the contents of eaijava properties file in the 
	 * root:/swserver/sw_africa/eaijava/ folder
	 * Will be called by staffware before each execute (unless a 
	 * caching option is selected in staffware) 
	 */
	@Override
	public void initialize(Properties properties) throws FatalPluginException,
			NonFatalPluginException {
		try {
			// Modified by Hiren
            ClassPathResource resource = new ClassPathResource(properties.getProperty("dtuFileLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());
			
           // DataSourceDirectory.getInstance().configure(properties);
            DataSourceDirectory.getInstance().basePluginDS();
            // load db driver (unsure if necessary)
            //Class.forName(properties.getProperty("db_driver"));
            dtuFilePath = properties.getProperty("dtuFile.path");
            bfgFilePath = properties.getProperty("bfgFile.path");
            h2hFilePath = properties.getProperty("h2hFile.path");
            //LoggerConnection.configureWFL(properties.getProperty("dtuFileLog"));
            logger.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
		
	}

	
	/**
	 * Method staffware calls in eaijava step
	 * @param staticData, a string hardcoded in staffware
	 * @param outputFields, a List of staffware Field objects which
	 * 			staffware expects to be returned 
	 * @param inputFields, a List of staffware Field objects which
	 * 			staffware provides (with values)
	 * @return Map, the name value pairs returned to staffware. Should
	 * 			only contain names of fields supplied in outputFields
	 */
	@Override
	public Map execute(String staticData, List outputFields, List inputFields)
			throws FatalPluginException, NonFatalPluginException {
		String messageType = getFieldValue(inputFields, "MESSAGE_TYPE");
		String content = "";
		HashMap<String, String> returnValues = new HashMap<String, String>();
		if ("900".equals(messageType)){
			content = getFieldValue(inputFields, "SWIFT_900");
		} else if ("910".equals(messageType)){
			content = getFieldValue(inputFields, "SWIFT_910");
		} else if ("940".equals(messageType)) {
			content = getFieldValue(inputFields, "SWIFT_940");
		} else if ("941".equals(messageType)){
			content = getFieldValue(inputFields, "SWIFT_941");
		} else if ("942".equals(messageType)) {
			content = getFieldValue(inputFields, "SWIFT_942");
		} else if ("950".equals(messageType)) {
			content = getFieldValue(inputFields, "SWIFT_950");
		}
		
		String fileTransferInd = getFieldValue(inputFields, "DTU_TRANS");
		String fileName = "";
		String gmtDateTime = "";
		
		if(fileTransferInd.equals("1")){
			//Set DTU File Transfer properties.
			fileName = "MT" + messageType + "-"
            + getFieldValue(inputFields, "ACC_IDENTI") + "-"
            + getFieldValue(inputFields, "SENDERS_REF") + "."
            + getFieldValue(inputFields, "DTU_ID");
			
			
			logger.info("Creating DTU file with name - " + fileName);
			writeFileToPath(gmtDateTime,fileName,dtuFilePath,content,returnValues);
		} else if(fileTransferInd.equals("2")){
			//Set BFG File Transfer properties.
			Date date = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'hhmmss");
			dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			gmtDateTime = dateFormat.format(date);
			
			// BFG workaround fix to help prevent duplicate filenames being used
			String senderRef = getFieldValue(inputFields, "SENDERS_REF");
			if (! "".equals(senderRef)) {
				Integer time = new Integer((new Integer(senderRef.substring(senderRef.length()-3)).intValue() % 600));
				String seconds = String.valueOf(time.intValue() % 60);
				String minutes = "0";
				minutes = String.valueOf(time.intValue() / 60);
				gmtDateTime = gmtDateTime.substring(0, 12) + minutes
					+ "00".substring(seconds.length()) + seconds;
			}
			
			fileName = "BRAINS_FG_MT" + messageType + "_" +
			getFieldValue(inputFields, "ACC_IDENTI") + "_" + gmtDateTime + "_A";
			logger.info("Creating BFG file with name - " + fileName );
			writeFileToPath(gmtDateTime, fileName, bfgFilePath ,content, returnValues);
			logger.info("Creating H2H file with name - " + fileName );
			writeFileToPath(gmtDateTime, fileName, h2hFilePath, content, returnValues);
		}
		return returnValues;
	}
	
	/**
	 * Method writeFileToPath calls in execute method to write the file at the path
	 * @param gmtDateTime, a string which contain the date time
	 * @param fileName, a string which contain the file name
	 * @param filePath, a string which contain the file path
	 * @param content, a string which contain the content of message
	 * @param returnValues, the name value pairs returned to staffware. Should
	 * 			only contain names of fields supplied in outputFields
	 * @return HashMap, the name value pairs returned to staffware. Should
	 * 			only contain names of fields supplied in outputFields
	 */
	private HashMap<String, String> writeFileToPath(String gmtDateTime, String fileName,String filePath,String content, HashMap<String, String> returnValues){
		returnValues.put("STATUSCODE", "0");
		returnValues.put("FILE_DATETIME", gmtDateTime);
		try {
			File file = new File(filePath);
			if (!file.exists())
				file.mkdirs();

			FileWriter fw = new FileWriter(new File(file, fileName));
			fw.write(content);
			fw.close();
		} catch (Exception e) {
			logger.error("Error Executing Create DTU file. Details: " 
	    			+ e.getMessage(), e);
			returnValues.put("STATUSCODE", "-1");
		}
		return returnValues;
	}
	
	
	/**
	 * find the value of a input field
	 * @param list
	 * @param name
	 * @return
	 */
	private String getFieldValue(List list, String name){
		for(Iterator i = list.iterator(); i.hasNext(); ){
			Field f = (Field)i.next();
			if(f.getName().equalsIgnoreCase(name))
				return f.getValue();
		}
		return null;
	}
	
}
