

package com.barclays.staffware.plugin.dto;

import java.util.Date;

/**
 * holds input params for exchange rate enquiry 
 */
/*
 * DATE     REFERENCE   WHO   VERSION  COMMENTS
 * -------  ---------   ---   -------  ---------------------------------------------------
 * 19JAN06  -           ACN   1.0a     Created
 * 22MAR12	WP626		MCF			   Now includes the mandate instruction for joint accounts
 * 
 */
public class CustomerAccountAddUpdateRequest {
    
    private int customerNumber;
    private String primaryAccountIndicator;
    private int sequenceNumber;;
    private String accountType;
    private String branchNumber;
    private String barclaysContactBranch;
    private String barclaysContactHost;
    private String barclaysContactName;
    private String country;
    private String offshoreInd;
    private String contactStatus = "SUBMIT";
    private String accountNumber = "0000000";
    private Date contactStatusDate;
    private String mandateInstruction;

    
    public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
     * Getter for property customerNumber.
     * @return Value of property customerNumber.
     */
    public int getCustomerNumber() {
        return customerNumber;
    }    
    
    /**
     * Setter for property customerNumber.
     * @param customerNumber New value of property customerNumber.
     */
    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }
    
    /**
     * Getter for property primaryAccountIndicator.
     * @return Value of property primaryAccountIndicator.
     */
    public String getPrimaryAccountIndicator() {
        return primaryAccountIndicator;
    }

    /**
     * Setter for property primaryAccountIndicator.
     * @param primaryAccountIndicator New value of property primaryAccountIndicator.
     */
    public void setPrimaryAccountIndicator(String primaryAccountIndicator) {
        this.primaryAccountIndicator = primaryAccountIndicator;
    }

    /**
     * Getter for property accountType.
     * @return Value of property accountType.
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * Setter for property accountType.
     * @param accountType New value of property accountType.
     */
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    /**
     * Getter for property branchNumber.
     * @return Value of property branchNumber.
     */
    public String getBranchNumber() {
        return branchNumber;
    }

    /**
     * Setter for property branchNumber.
     * @param branchNumber New value of property branchNumber.
     */
    public void setBranchNumber(String branchNumber) {
        this.branchNumber = branchNumber;
    }



    /**
     * Getter for property barclaysContactBranch.
     * @return Value of property barclaysContactBranch.
     */
    public String getBarclaysContactBranch() {
        return barclaysContactBranch;
    }

    /**
     * Setter for property barclaysContactBranch.
     * @param barclaysContactBranch New value of property barclaysContactBranch.
     */
    public void setBarclaysContactBranch(String barclaysContactBranch) {
        this.barclaysContactBranch = barclaysContactBranch;
    }

    /**
     * Getter for property barclaysContactHost.
     * @return Value of property barclaysContactHost.
     */
    public String getBarclaysContactHost() {
        return barclaysContactHost;
    }

    /**
     * Setter for property barclaysContactHost.
     * @param barclaysContactHost New value of property barclaysContactHost.
     */
    public void setBarclaysContactHost(String barclaysContactHost) {
        this.barclaysContactHost = barclaysContactHost;
    }

    /**
     * Getter for property barclaysContactName.
     * @return Value of property barclaysContactName.
     */
    public String getBarclaysContactName() {
        return barclaysContactName;
    }

    /**
     * Setter for property barclaysContactName.
     * @param barclaysContactName New value of property barclaysContactName.
     */
    public void setBarclaysContactName(String barclaysContactName) {
        this.barclaysContactName = barclaysContactName;
}

    /**
     * Getter for property country.
     * @return Value of property country.
     */
    public String getCountry() {
        return country;
    }

    /**
     * Setter for property country.
     * @param country New value of property country.
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Getter for property offshoreInd.
     * @return Value of property offshoreInd.
     */
    public String getOffshoreInd() {
        return offshoreInd;
    }

    /**
     * Setter for property offshoreInd.
     * @param offshoreInd New value of property offshoreInd.
     */
    public void setOffshoreInd(String offshoreInd) {
        this.offshoreInd = offshoreInd;
    }

    /**
     * Getter for property sequenceNumber.
     * @return Value of property sequenceNumber.
     */
    public int getSequenceNumber() {
        return sequenceNumber;
    }



    /**
     * Setter for property sequenceNumber.
     * @param sequenceNumber New value of property sequenceNumber.
     */
    public void setSequenceNumber(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    /**
     * Getter for property contactStatus.
     * @return Value of property contactStatus.
     */
    public String getContactStatus() {
        return contactStatus;
    }

    /**
     * Setter for property contactStatus.
     * @param contactStatus New value of property contactStatus.
     */
    public void setContactStatus(String contactStatus) {
        this.contactStatus = contactStatus;
    }

    /**
     * Getter for property contactStatusDate.
     * @return Value of property contactStatusDate.
     */
    public Date getContactStatusDate() {
        return contactStatusDate;
    }

    /**
     * Setter for property contactStatusDate.
     * @param contactStatusDate New value of property contactStatusDate.
     */
    public void setContactStatusDate(Date contactStatusDate) {
        this.contactStatusDate = contactStatusDate;
    }
    
    /**
     * Getter for property mandateInstruction
     * @return Value of property mandateInstruction
     */
    public String getMandateInstruction(){
    	return mandateInstruction;
    }
    
    /**
     * Setter for property mandateInstruction
     * @param mandateInstruction New value of property mandateInstruction
     */
    public void setMandateInstruction(String mandateInstruction){
    	this.mandateInstruction = mandateInstruction;
    }
}
