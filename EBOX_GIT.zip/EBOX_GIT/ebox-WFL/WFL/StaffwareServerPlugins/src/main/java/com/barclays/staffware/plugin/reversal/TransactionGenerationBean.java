package com.barclays.staffware.plugin.reversal;

/**
 * This class will hold TransactionGeneration table entries required for populating require fields.
 * @author Anup Kulkarni
 *
 */
/* 
 * DATE      REFERENCE   WHO         VERSION      COMMENTS
 * --------  ---------   ---         -------      ----------------------
 * 05/02/16  WP697       Anup        1.0              Created
 */
public class TransactionGenerationBean {
    
    private String transCode;
    private String subTransCode;
    private String entryType;
    private String paymentType;
    private String country;
    private int offshoreInd;
    private String drcrInd;
    
    public String getTransCode() {
        return transCode;
    }
    public void setTransCode(String transCode) {
        this.transCode = transCode;
    }
    public String getSubTransCode() {
        return subTransCode;
    }
    public void setSubTransCode(String subTransCode) {
        this.subTransCode = subTransCode;
    }
    public String getEntryType() {
        return entryType;
    }
    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }
    public String getPaymentType() {
        return paymentType;
    }
    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public int getOffshoreInd() {
        return offshoreInd;
    }
    public void setOffshoreInd(int offshoreInd) {
        this.offshoreInd = offshoreInd;
    }
    public String getDrcrInd() {
        return drcrInd;
    }
    public void setDrcrInd(String drcrInd) {
        this.drcrInd = drcrInd;
    }
    

}
