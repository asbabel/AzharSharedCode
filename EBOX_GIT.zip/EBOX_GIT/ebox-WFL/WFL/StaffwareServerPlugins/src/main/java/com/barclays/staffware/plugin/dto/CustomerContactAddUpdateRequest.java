/*
 * CustomerContactAddUpdateRequest.java
 *
 */
package com.barclays.staffware.plugin.dto;


/**
 * Contains details required for an add/update of a customer contact (i.e. BRAINS tokens CCO-A, CCO-U)
 * @author HUNTI
 */
/*
 * DATE     REFERENCE   WHO   VERSION  COMMENTS
 * -------  ---------   ---   -------  ---------------------------------------------------
 * 09Oct06	-			HUNTI 1.0a	   Added CCO-A parameters
 * 
 */
public class CustomerContactAddUpdateRequest extends Contact {
    
	private static final long serialVersionUID = 4606807732074023482L;
	private int customerNumber;
    private String fosUser;
    private String hostName;
    private String versionNumber;
    private String brainsCountry;
    private boolean offshore;
    

	/**
     * Getter for property customerNumber.
     * @return Value of property customerNumber.
     */
    public int getCustomerNumber() {
        return customerNumber;
    }
    
    /**
     * Setter for property customerNumber.
     * @param customerNumber New value of property customerNumber.
     */
    public void setCustomerNumber(int customerNumber) {
        this.customerNumber = customerNumber;
    }
       
    /**
     * Getter for property fosuser.
     * @return Value of property fosuser.
     */
    public String getFosUser() {
        return fosUser;
    }

    /**
     * Setter for property fosuser.
     * @param fosUser New value of property fosuser.
     */
    public void setFosUser(String fosUser) {
        this.fosUser = fosUser;
    }

    /**
     * Getter for property hostname.
     * @return Value of property hostname.
     */
    public String getHostName() {
        return hostName;
    }

    /**
     * Setter for property hostname.
     * @param hostName New value of property hostname.
     */
    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

	public String getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}

	/**
	 * @return the country
	 */
	public String getBrainsCountry() {
		return brainsCountry;
	}

	/**
	 * @param brainsCountry the country to set
	 */
	public void setBrainsCountry(String brainsCountry) {
		this.brainsCountry = brainsCountry;
	}

	/**
	 * @return the offshore
	 */
	public boolean isOffshore() {
		return offshore;
	}

	/**
	 * @param offshore the offshore to set
	 */
	public void setOffshore(boolean offshore) {
		this.offshore = offshore;
	}
}
