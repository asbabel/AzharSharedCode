package com.barclays.staffware.plugin;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * @author James
 *
 * check DTU file whether has been sent or not
 */
/*
 * DATE     REFERENCE  WHO    		VERSION  COMMENTS
 * -------  ---------  ---    		-------  -----------------------------------
 * 30April12   WP559    James         1        created
 * 12MAY14	WP669		SL			1.01		file path changed
 * 02APR2018 WP758     Akhilesh       2.1      Changes for WP758 Statement files to H2H       
 */
public class CheckDTUFile implements ImmediateReleasePluginSDK{
	private static final LoggerConnection logger=new LoggerConnection(CheckDTUFile.class);
	private String dtuFilePath;
	private String bfgFilePath;
	private String h2hFilePath;
	private final String initializationFailed = SwiftParams.initializationFailed(CheckDTUFile.class.getName());
	/**
	 * Will be passed the contents of eaijava properties file in the 
	 * root:/swserver/sw_africa/eaijava/ folder
	 * Will be called by staffware before each execute (unless a 
	 * caching option is selected in staffware) 
	 */
	@Override
	public void initialize(Properties properties) throws FatalPluginException,
			NonFatalPluginException {
		try {
            //DataSourceDirectory.getInstance().configure(properties);
			// Modified by Hiren
			ClassPathResource resource = new ClassPathResource(properties.getProperty("dtuFileLog"));
			LoggerContext context = (LoggerContext) LogManager.getContext(false);
			context.setConfigLocation(resource.getURI());
			DataSourceDirectory.getInstance().basePluginDS();
            // load db driver (unsure if necessary)
            //Class.forName(properties.getProperty("db_driver"));
            dtuFilePath = properties.getProperty("dtuFileSent.path");
            bfgFilePath = properties.getProperty("bfgFileSent.path");
            h2hFilePath = properties.getProperty("h2hFileSent.path");
            //LoggerConnection.configureWFL(properties.getProperty("dtuFileLog"));
            logger.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
		
	}

	
	/**
	 * Method staffware calls in eaijava step
	 * @param staticData, a string hardcoded in staffware
	 * @param outputFields, a List of staffware Field objects which
	 * 			staffware expects to be returned 
	 * @param inputFields, a List of staffware Field objects which
	 * 			staffware provides (with values)
	 * @return Map, the name value pairs returned to staffware. Should
	 * 			only contain names of fields supplied in outputFields
	 */
	@Override
	public Map execute(String staticData, List outputFields, List inputFields)
			throws FatalPluginException, NonFatalPluginException {
		HashMap<String, String> returnValues = new HashMap<String, String>();
		String fileName = "";
		String fileDateTime = "";
		String fileTransferInd = getFieldValue(inputFields, "DTU_TRANS");
		String messageType = getFieldValue(inputFields, "MESSAGE_TYPE");
		String accountNumber = getFieldValue(inputFields, "ACC_IDENTI");
		
		if(fileTransferInd.equals("1")){
			//set DTU file transfer properties.
			fileName = "MT"+messageType+"-"
			+accountNumber+"-"
			+getFieldValue(inputFields, "SENDERS_REF")+"."
			+getFieldValue(inputFields, "DTU_ID");
			checkFileToPath(fileName, dtuFilePath, returnValues);
		} else{
			//Set BFG File Transfer properties.
			fileDateTime = getFieldValue(inputFields, "FILE_DATETIME");
			fileName = "BRAINS_FG_MT"+messageType+"_"+
			accountNumber+"_"+fileDateTime+"_A";
			logger.info("Checking BFG file with name - " + fileName );
			checkFileToPath(fileName, bfgFilePath , returnValues);
			logger.info("Checking H2H file with name - " + fileName );
			checkFileToPath(fileName, h2hFilePath, returnValues);
		}
		return returnValues;
	}
	
	
	/**
	 * Method checkFileToPath calls in execute method to check the file at the path
	 * @param fileName, a string which contain the file name
	 * @param filePath, a string which contain the file path
	 * @param returnValues, the name value pairs returned to staffware. Should
	 * 			only contain names of fields supplied in outputFields
	 * @return HashMap, the name value pairs returned to staffware. Should
	 * 			only contain names of fields supplied in outputFields
	 */
	
	private HashMap<String, String> checkFileToPath(String fileName,String filePath,HashMap<String, String> returnValues){
		returnValues.put("STATUSCODE", "0");
		
		File file = new File(filePath+fileName);
		if (!file.exists()) {
			returnValues.put("STATUSCODE", "-1");
			logger.info("DTU/BFG/H2H file (" + fileName + ") was not sent");
		} 
		logger.info(fileName + " file checked successfully");
		return returnValues;
	}
	
	/**
	 * find the value of a input field
	 * @param list
	 * @param name
	 * @return
	 */
	private String getFieldValue(List list, String name){
		for(Iterator i = list.iterator(); i.hasNext(); ){
			Field f = (Field)i.next();
			if(f.getName().equalsIgnoreCase(name))
				return f.getValue();
		}
		return null;
	}

}
