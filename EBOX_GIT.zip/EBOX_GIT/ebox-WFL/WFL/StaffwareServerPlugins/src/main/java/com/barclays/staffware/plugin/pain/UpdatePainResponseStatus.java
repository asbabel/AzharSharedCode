package com.barclays.staffware.plugin.pain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.staffware.plugin.util.PainParams;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.PainParams.PainStatus;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import static com.barclays.staffware.plugin.util.PainParams.STATUSCODE;
import static com.barclays.staffware.plugin.util.PainParams.STATUSDESC;
import static com.barclays.staffware.plugin.util.PainParams.DBDRIVER;
import static com.barclays.staffware.plugin.util.PainParams.CLASSNOTFOUNDERROR;
import static com.barclays.staffware.plugin.util.PainParams.SUCCESSCODE;
import static com.barclays.staffware.plugin.util.PainParams.ERRORCODE;
import static com.barclays.staffware.plugin.util.PainParams.UPDATED;
import static com.barclays.staffware.plugin.util.PainParams.NOTUPDATED;
import static com.barclays.staffware.plugin.util.PainParams.CURRENTSTATUS;
import static com.barclays.staffware.plugin.util.PainParams.RESPONSESTATUS;
import static com.barclays.staffware.plugin.util.PainParams.INTEGERFOUR;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * This class will be used to update PAC status based on statuses received from
 * Meridian.
 * 
 * @author Shahir.Hiralal
 * 
 */
public class UpdatePainResponseStatus implements ImmediateReleasePluginSDK {
    private static final LoggerConnection LOG = new LoggerConnection(
            UpdatePainResponseStatus.class);
    private final String initializationFailed = PainParams.initializationFailed(UpdatePainResponseStatus.class.getName());

    /**
     * Method is called by Staffware before each execute (unless a caching
     * option is selected in Staffware) Loads properties file. This file should
     * contain the DB Driver and the MQ Parameters to the relevant environment.
     * 
     * @param properties contents of eaijava properties file in
     * root:/swserver/sw_africa/eaijava
     */
    @Override
    public void initialize(Properties properties)
            throws FatalPluginException,
            NonFatalPluginException {
        //DataSourceDirectory.getInstance().configure(properties);
        try {
           // Class.forName(properties.getProperty(DBDRIVER));
           // LoggerConnection.configureWFL("updatePacStatusLog");
            ClassPathResource resource = new ClassPathResource(properties.getProperty("updatePacStatusLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());

            DataSourceDirectory.getInstance().basePluginDS();
            LOG.debug(this.getClass().toString() + "test log write!");
        } catch (Exception e) {
        	LOG.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
        }
    }

    /**
     * Method Staffware calls in eaijava step, will update the Pain Status.
     * 
     * @param staticData a string hardcoded in Staffware, this is ignored in
     * this method
     * @param outputFields a list of Staffware field objects which Staffware
     * expects to be returned
     * @param inputFields a list of Staffware field objects which Staffware
     * provides (with values)
     * @return the name value pairs returned to Staffware
     */

    @SuppressWarnings("rawtypes")
    @Override
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {
        Map<String, Object> results =
                new HashMap<String, Object>(outputFields.size());
        int rankCurrentStatus =
                getRankStatus(StaffwareHelper.getFieldValue(inputFields,
                        CURRENTSTATUS));
        int rankParamStatus =
                getRankStatus(StaffwareHelper.getFieldValue(inputFields,
                        RESPONSESTATUS));
        String paramStatus =
                StaffwareHelper.getFieldValue(inputFields, RESPONSESTATUS);
        if (rankCurrentStatus < rankParamStatus || rankCurrentStatus == 0) {
            results.put(STATUSCODE, SUCCESSCODE);
            results.put(STATUSDESC, UPDATED);
            results.put(CURRENTSTATUS, paramStatus);
        } else {
            results.put(STATUSCODE, ERRORCODE);
            results.put(STATUSDESC, NOTUPDATED);
        }

        return results;
    }

    /**
     * Will associate each pain status to a rank value of 1-4
     * 
     * @param paramStatus
     * @return rank
     */
    private int getRankStatus(String paramStatus) {
        int rank = 0;
        String status = "";
        if (paramStatus != null && paramStatus.length() >= INTEGERFOUR) {
            status = paramStatus.substring(0, INTEGERFOUR).trim();
        }
        for (PainStatus painStatus : PainStatus.values()) {
            if (status.equals(painStatus.getPainStatus())) {
                rank = painStatus.getRank();
            }
        }
        return rank;
    }
}
