package com.barclays.staffware.plugin.swift;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.dstx.MapInvoke;
import com.barclays.middleware.dstx.staffware.SWMapInvoke;
import com.barclays.middleware.util.BrainsSocketConnectionFactory;
import com.barclays.staffware.plugin.util.StaffwareHelper;
import com.barclays.staffware.plugin.util.SwiftParams;
import com.barclays.swift.data.IMWDBAccess;
import com.barclays.swift.data.MWDBAccess;
import com.barclays.swift.util.SwiftMessageUtil;
import com.staffware.eaijava.FatalPluginException;
import com.staffware.eaijava.Field;
import com.staffware.eaijava.ImmediateReleasePluginSDK;
import com.staffware.eaijava.NonFatalPluginException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.core.io.ClassPathResource;

/**
 * EAI java plugin for storing swift messages
 * 
 * @author LEES
 */
/*
 * DATE     REFERENCE   WHO     VERSION     COMMENTS
 * ----     ---------   ---     -------     --------
 * 24MAR14  WP669       SL      1.00        Created
 * 17Jan17  WP715       LeyJ    -           Refactored data access to MWDB.
 */
public class StoreMessage implements ImmediateReleasePluginSDK {

    private SwiftMessageUtil helper;
    private MapInvoke wtx;

    private String accountingToken;
    private String casenum;
    private String encodedCountry;
    private String format;
    private String messageId;
    private String msgData;
    private String processId;
    private String projectId;
    private String proname;
    private String sentDate;
    private String swiftMessage;
    private String targetCountry;
    private String terminate;
    private String transactionId;

    private Integer datastoreId;

    private char inwardOutwardInd;
    private char rejectDuplicate;

    private IMWDBAccess dataAccess;

    private static final String PROJECT_ID = "SYSTEM";
    private static final String ACCOUNTING_TOKEN = "STAFFWARE";
    private static final String SOURCE_APPL_NAME = "STAFFWARE";
    private static final String FORMAT = "NVP";

    private static final LoggerConnection logger = new LoggerConnection(StoreMessage.class);
    private final String initializationFailed = SwiftParams.initializationFailed(StoreMessage.class.getName());

    /**
     * Gets data store id
     * 
     * @return datastore id
     */
    public Integer getDatastoreId() {
        return datastoreId;
    }

    /**
     * Gets message data for the MW_DATASTORE table
     * 
     * @return msgData
     */
    public String getMsgData() {
        return msgData;
    }

    /**
     * Sets the encodedCountry
     * 
     * @param encodedCountry
     */
    public void setEncodedCountry(String encodedCountry) {
        this.encodedCountry = encodedCountry;
    }

    /**
     * Gets the encoded country
     * 
     * @return encoded country
     */
    public String getEncodedCountry() {
        return encodedCountry;
    }

    /**
     * Sets the inward outward indicator
     * 
     * @param indicator
     */
    public void setInwardOutwardInd(char indicator) {
        inwardOutwardInd = indicator;
    }

    /**
     * Gets the inwards outwards indicator
     * 
     * @return
     */
    public char getInwardOutwardInd() {
        return inwardOutwardInd;
    }

    /**
     * Gets reject duplicate field
     * 
     * @return reject duplicate
     */
    public char getRejectDuplicate() {
        return rejectDuplicate;
    }

    /**
     * Gets proname
     * 
     * @return proname
     */
    public String getProname() {
        return proname;
    }

    /**
     * Gets casenum
     * 
     * @return casenum
     */
    public String getCasenum() {
        return casenum;
    }

    /**
     * Gets terminate
     * 
     * @return terminate
     */
    public String getTerminate() {
        return terminate;
    }

    /**
     * Gets a swift message
     * 
     * @return swiftMessage
     */
    public String getSwiftMessage() {
        return swiftMessage;
    }

    /**
     * Gets project id
     * 
     * @return projectId
     */
    public String getProjectId() {
        return projectId;
    }

    /**
     * Gets process id
     * 
     * @return processId
     */
    public String getProcessId() {
        return processId;
    }

    /**
     * Gets accounting token
     * 
     * @return accountingToken
     */
    public String getAccountingToken() {
        return accountingToken;
    }

    /**
     * Gets input format
     * 
     * @return format
     */
    public String getFormat() {
        return format;
    }

    /**
     * Gets transaction id
     * 
     * @return transactionId
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * Gets message id
     * 
     * @return messageId
     */
    public String getMessageId() {
        return messageId;
    }

    /**
     * Gets sent date
     * 
     * @return sentDate
     */
    public String getSentDate() {
        return sentDate;
    }

    /**
     * Gets target country
     * 
     * @return targetCountry
     */
    public String getTargetCountry() {
        return targetCountry;
    }

    /**
     * Gets data access interface
     * 
     * @return data access interface
     */
    public IMWDBAccess getDataAccess() {
        return dataAccess;
    }

    /**
     * Constructor that takes no parameters for when STORE is called by
     * Staffware
     */
    public StoreMessage() {
        /*
         * Constructor that takes no parameters for when STORE is called by Staffware
         */
    }

    /**
     * Method is called by Staffware before each execute (unless a caching
     * option is selected in Staffware) Loads properties file
     * 
     * @param properties contents of eaijava properties file in
     * root:/swserver/sw_africa/eaijava
     */
    @Override
    public void initialize(Properties properties) throws FatalPluginException, NonFatalPluginException {
        wtx = new SWMapInvoke();
        wtx.setHostname(properties.getProperty("ib_hostname"));
        wtx.setPort(Integer.parseInt(properties.getProperty("ib_port")));
        wtx.setTimeout(Integer.parseInt(properties.getProperty("ib_timeout")));
        this.dataAccess = new MWDBAccess();
        try {
            // modified by gogula
            ClassPathResource resource = new ClassPathResource(properties.getProperty("swiftStoreMsgLog"));
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            context.setConfigLocation(resource.getURI());
        	//LoggerConnection.configureWFL(properties.getProperty("swiftStoreMsgLog"));
        	logger.debug(this.getClass().toString() + "test log write!");
        	BrainsSocketConnectionFactory.getInstance().useSecure(properties);
            // modified by gogula
            DataSourceDirectory.getInstance().basePluginDS();
            //Class.forName(properties.getProperty("db_driver"));
        } catch (Exception e) {
        	logger.error(initializationFailed + ". Details: " + e.getMessage(), e);
        	// raise exception to calling code, all exceptions considered fatal at this time
        	throw new FatalPluginException(initializationFailed + e.getMessage());
            }
        }

    /**
     * Method Staffware calls in eaijava step
     * 
     * @param staticData a string hardcoded in Staffware, this is ignored in
     * this method
     * @param outputFields a list of Staffware field objects which Staffware
     * expects to be returned
     * @param inputFields a list of Staffware field objects which Staffware
     * provides (with values)
     * @return the name value pairs returned to Staffware
     */
    @Override
    public Map execute(String staticData, List outputFields, List inputFields)
            throws FatalPluginException,
            NonFatalPluginException {
        Map<String, Object> result = new HashMap<String, Object>(outputFields.size());
        StaffwareHelper.initialiseReturnValues(outputFields, result);
        setClassProperties(inputFields);
        if (logger.isDebugEnabled()) {
            logger.debug("Arguements received from Staffware: ");
            for (Iterator<?> i = inputFields.iterator(); i.hasNext();) {
                Field field = (Field) i.next();
                logger.debug(field.getName() + " = " + field.getValue());
            }
        }

        try {
            com.barclays.swift.StoreMessage storeMessage = new com.barclays.swift.StoreMessage(this.msgData,
                    getProname(), getCasenum(), getInwardOutwardInd(), getRejectDuplicate());

            if (storeMessage != null) {
                if ("900".equals(storeMessage.getHelper().getMessageType())
                        || "910".equals(storeMessage.getHelper().getMessageType())
                        || "940".equals(storeMessage.getHelper().getMessageType())
                        || "941".equals(storeMessage.getHelper().getMessageType())
                        || "942".equals(storeMessage.getHelper().getMessageType())
                        || "950".equals(storeMessage.getHelper().getMessageType())) {
                    SQLConnection conn = null;

                    try {
                        conn = com.barclays.staffware.data.MWDBAccess.getDatabaseConnection();
                        boolean rowExist = false;
                        try {
                            rowExist = this.dataAccess.isDuplicateMessage(conn, getTransactionId(), getMessageId());
                        } catch (SQLException e) {
                            logger.error(SwiftParams.SP_ERROR + ". Details: " + e.toString(), e);
                        }
                        if (getRejectDuplicate() == 'Y' && rowExist) {
                            // don't do anymore processing
                        } else {
                            conn.setAutoCommit(false);
                            try {
                                storeMessage.store(conn);
                            } catch (SQLException e) {
                                StaffwareHelper.rollbackSQLTransaction(conn, e, logger, SwiftParams.SP_ERROR);
                            } catch (ParseException e) {
                                StaffwareHelper.rollbackSQLTransaction(conn, e, logger, SwiftParams.PARSE_ERROR);
                            }
                            conn.commit();
                        }
                    } catch (SQLException e) {
                        logger.error(SwiftParams.DB_ERROR + ". Details: " + e.getMessage(), e);
                    } catch (Exception e) {
                        // to catch any expected exceptions
                        logger.error("Unexpected Error. Details: " + e.getMessage(), e);
                    } finally {
						if (conn != null) {
							conn.close();
                        }
					}
                } else {
                    return wtx.execute(staticData, outputFields, inputFields);
                }
            }
        } catch (Exception e) {
            logger.error("Unexpected Error. Details: " + e.getMessage(), e);
        }
        // NOTE: result is not updated before return
        return result;
    }

    /**
     * Method for setting class properties
     * 
     * @param inputFields
     */
    private void setClassProperties(List<?> inputFields) {
        for (Object inputField : inputFields) {
            Field field = (Field) inputField;
            String name = field.getName();
            String value = field.getValue();

            if ("SW_PRONAME".equalsIgnoreCase(name)) {
                proname = value;
            } else if ("SW_CASENUM".equalsIgnoreCase(name)) {
                casenum = value;
            } else if ("INWARDOUTWARD".equalsIgnoreCase(name)) {
                inwardOutwardInd = value.charAt(0);
            } else if ("REJECTDUPLICATE".equalsIgnoreCase(name)) {
                rejectDuplicate = value.charAt(0);
            } else if ("SWIFT_MESSAGE".equalsIgnoreCase(name)) {
                swiftMessage = value;
            } else if ("TERMINATE".equalsIgnoreCase(name)) {
                terminate = value;
            } else if ("COUNTRY".equalsIgnoreCase(name)) {
                targetCountry = value;
            }
        }
        transactionId = "SW-" + getCasenum();
        messageId = StaffwareHelper.newMessageId();
        sentDate = StaffwareHelper.newSentDate();
        format = FORMAT;
        accountingToken = ACCOUNTING_TOKEN;

        projectId = PROJECT_ID;
        msgData = StaffwareHelper.formatMsgData(formatMWMH(), getSwiftMessage());
        helper = new SwiftMessageUtil(getMsgData());
    }

    /**
     * Method for formatting MWMH
     * 
     * @return formatted string
     */
    private String formatMWMH() {
        return StaffwareHelper.formatXMLTag("MWMH", StaffwareHelper.formatXMLTag("MWMH1",
                StaffwareHelper.formatXMLTag("MsgType", "REQUEST") + StaffwareHelper.formatXMLTag("Format", getFormat())
                        + StaffwareHelper.formatXMLTag("TransactionId", getTransactionId())
                        + StaffwareHelper.formatXMLTag("MsgId", getMessageId())
                        + StaffwareHelper.formatXMLTag("AccountingToken", ACCOUNTING_TOKEN)
                        + StaffwareHelper.formatXMLTag("SourceApplName", SOURCE_APPL_NAME)
                        + StaffwareHelper.formatXMLTag("SentDate", getSentDate())
                        + StaffwareHelper.formatXMLTag("TargetCountry", getTargetCountry())
                        + StaffwareHelper.formatXMLTag("ProjectId", PROJECT_ID)));
    }
}
