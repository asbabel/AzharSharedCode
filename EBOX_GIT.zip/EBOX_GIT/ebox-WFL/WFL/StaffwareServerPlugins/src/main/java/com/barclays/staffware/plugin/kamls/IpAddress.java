package com.barclays.staffware.plugin.kamls;

/**
 * Represents a row of data from the MWDB table IPAddress
 * @author LEEDSS
 */
/*
 * DATE     REFERENCE  WHO     VERSION  COMMENTS
 * -------  ---------  ---     -------  -----------------------------------------
 * 20Jun07  -          LEEDSS  1        Created.
 */
public class IpAddress {

	private String host;
	private Integer port;
	private String engine;
	private Integer timeout;
	private Integer nextSequenceNumber;
	private Boolean trace;
	private String connectionString;
	//iTouch Changes
	private String clientId;
	private String clientPassword;
	
	public String getConnectionString() {
		return connectionString;
	}
	
	public String getEngine() {
		return engine;
	}
	
	public Integer getNextSequenceNumber() {
		return nextSequenceNumber;
	}
	
	public Integer getTimeout() {
		return timeout;
	}
	
	public Boolean getTrace() {
		return trace;
	}
	
	public String getHost() {
		return host;
	}
	
	public Integer getPort() {
		return port;
	}

	public IpAddress(
			String host, 
			Integer port, 
			String engine, 
			Integer timeout, 
			Integer nextSequenceNumber, 
			Boolean trace, 
			String connectionString) {
		super();
		this.host = host;
		this.port = port;
		this.engine = engine;
		this.timeout = timeout;
		this.nextSequenceNumber = nextSequenceNumber;
		this.trace = trace;
		this.connectionString = connectionString;
	}
//ITouch Specific Changes
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientPassword() {
		return clientPassword;
	}

	public void setClientPassword(String clientPassword) {
		this.clientPassword = clientPassword;
	}
	
//ITouch Specific Changes End	
	
}
