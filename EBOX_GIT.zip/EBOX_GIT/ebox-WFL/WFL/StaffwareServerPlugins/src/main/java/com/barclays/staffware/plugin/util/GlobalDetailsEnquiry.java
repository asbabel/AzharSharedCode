/*
 * GlobalDataEnquiry.java
 *
 * Created on 26 May 2005, 09:51
 */

package com.barclays.staffware.plugin.util;

import com.barclays.generic.data.bean.Country;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.middleware.brains.GLD_I;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * BRAINS Global Details Enquiry.
 * @author  KEMPD
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 15Apr08  PAT02485   PHH    1b       Replaced static SimpleDateFormat 
 *                                     BUSINESS_DATE_FORMAT variable with a direct 
 *                                     call to make it thread safe (R1M447261).
 */
public class GlobalDetailsEnquiry 
{
    private static final String INVALID_BUSINESS_DATE =
            "Unable to parse the business date received from BRAINS.";
    private static final String MISSING_BUSINESS_DATE =
            "No business date received from BRAINS for this country.";
    
    protected GLD_I token;
    
    /**
     * Initialises a new instance of <code>GlobalDataEnquiry</code>.
     */
    public GlobalDetailsEnquiry(
        Country c)
    {
        token = new GLD_I(c.getISOCode(), c.isOffshore());
    }
    
    /**
     * Current business date on BRAINS.
     */
    public Date getBusinessDate()
        throws DataAccessException
    {
        try{
            token.execute();
        }
        catch(Exception e){
            // wrap up the error as a data access one
            throw new DataAccessException(e.getMessage(), e);
        }
        
        String businessDate = (String)token.getHeader().get("BUSINESS_DATE");
        if(businessDate == null || businessDate.equals(""))
            throw new DataAccessException(MISSING_BUSINESS_DATE);
              
        try{
            return new SimpleDateFormat("ddMMyy").parse(businessDate);
        }
        catch (ParseException e) {
            throw new DataAccessException(INVALID_BUSINESS_DATE, e);
        }
    }
}
