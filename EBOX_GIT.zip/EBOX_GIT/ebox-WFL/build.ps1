#
# Script Name:� build.ps1
# Date Written: 23/05/2018
# Author:������ Luke Thomas
# Description:� Script used to build each tier for each provided profile.
#               Only one WEB zip is build without a profile.
#�

[cmdletbinding()]
Param(
    [Parameter(Mandatory = $true)][String[]]$Profiles,
    [Parameter(Mandatory = $false)][String[]]$Tiers = @("Libraries", "WEB", "PAY", "SQL", "UTL", "WFL"),
    [switch]$IsDebug
)

$logFolderLocation = "$PSScriptRoot\buildLogs"
$orderedUnprofiledTiers = @("Libraries", "WEB")
$orderedProfiledTiers = @("PAY", "SQL", "UTL", "WFL")

<#
.SYNOPSIS
Invoke-BuildTier does a maven clean and install for the specified tier.
��
.PARAMETER BuildProfile
The build profile used when doing a maven install.

.PARAMETER Tier
The tier to build.
�
.EXAMPLE
Invoke-BuildTier DEV01 PAY
��
#>
function Invoke-BuildTier {
    Param(
        [Parameter(Mandatory = $false)][String]$BuildProfile,
        [Parameter(Mandatory = $true)][String]$Tier
    )
    Push-Location $Tier

    Write-Host "Building $Tier for [$BuildProfile]" -ForegroundColor Green
    [String]$logFile = "$logFolderLocation\build_$BuildProfile$Tier.log"
    if (![String]::IsNullOrWhiteSpace($BuildProfile)) {
        $BuildProfile = "-P$BuildProfile"
    }
    
    mvn -e clean install "$BuildProfile" "$DebugOptions" | Tee-Object -FilePath "$logFile"
    $exitCode = $LASTEXITCODE
        
    if($exitCode -gt 0) {
        throw "The Maven build for $Tier failed with exit code $exitCode. See log file $logFile"
    }

    Pop-Location
}

$Tiers | ForEach-Object {
    if(-not (Test-Path $_)) {
        throw "Tier $_ does not exist."
    }
}

if (-not (Test-Path $logFolderLocation -PathType Container)) {
    New-Item $logFolderLocation -ItemType Directory
}

[String]$DebugOptions = ""
if ($IsDebug.IsPresent) {
    Write-Host "Adding debug option" -ForegroundColor Yellow
    $DebugOptions = "-X"
}

$orderedUnprofiledTiers | Where-Object { $Tiers -contains $_ } | ForEach-Object {
    Invoke-BuildTier -Tier $_
}

$Profiles | ForEach-Object {
    [String]$profile = $_
    $orderedProfiledTiers | Where-Object { $Tiers -contains $_ } | ForEach-Object {
        Invoke-BuildTier -BuildProfile $profile -Tier $_
    }
}