package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.STC_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * SubTransaction Code Table Handler. This class invokes STC_L token and saves
 * the results from Brains to MWDB.SubTransactionCode table
 * 
 * @see AbstractTableHandler
 * 
 */

/*
 * DATE        REFERENCE   		WHO  		VERSION  	COMMENTS 
 * ---------   ---------   		---  		-------  	------- 
 * 26Nov2014   WP680BNET    	Prachi		1a			Created
 */

public class SubTransactionCodeTableHandler extends AbstractTableHandler {

    private static final String TABLE_NAME = "SubTransactionCode";

    @Override
    public int populateStagingTable() throws ProcessFailedException {
        STC_L token = new STC_L();
        token.setVersionNumber(1);
        int rowCount = 0;
        SQLConnection conn = SQLConnectionHelper.getConnection();
        List<? extends Map<String, Object>> accountTypeCurrencyConf = executeToken(token);
        HashMap<String, Object> argsMap = new HashMap<String, Object>();
        for (Map<String, Object> accountTypeCurrency : accountTypeCurrencyConf) {
            argsMap.clear();
            argsMap.put("country", getParameter(Constants.PARAMETER_COUNTRY));
            argsMap.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
            argsMap.put("transactionCode", accountTypeCurrency.get("TRANSACTION_CODE"));
            argsMap.put("subTransactionCode", accountTypeCurrency.get("SUB_TRANSACTION_CODE"));
            argsMap.put("subCodeNarrative", accountTypeCurrency.get("SUB_CODE_NARRATIVE"));
            argsMap.put("crSubCode", accountTypeCurrency.get("CR_SUB_CODE"));
            argsMap.put("drSubCode", accountTypeCurrency.get("DR_SUB_CODE"));

            try {
                conn.executeUpdate("ext_populateStaging" + getTableName(), argsMap);
            } catch (SQLException e) {
                SQLConnectionHelper.handleSQLException(e);
                throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), e);
            }
            rowCount++;
        }
        SQLConnectionHelper.closeConnection(conn);
        return rowCount;
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

}
