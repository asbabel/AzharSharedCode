package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.ACT_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * SubTransaction Code Table Handler. 
 * This class invokes STC_L token and saves the results from Brains to MWDB.SubTransactionCode table
 * 
 * @see AbstractTableHandler
 * 
 */

/*
 * DATE        REFERENCE   		WHO  		VERSION  	COMMENTS 
 * ---------   ---------   		---  		-------  	------- 
 * 28Nov2014   WP680BNET    	Prachi		1a			Created
 */

public class AccountTypeTableHandler extends AbstractTableHandler {

	private static final String TABLE_NAME = "AccountType";
	
	@Override
	public int populateStagingTable() throws ProcessFailedException {
		ACT_L token = new ACT_L();
		token.setVersionNumber(1);
		int rowCount = 0;
		SQLConnection conn = SQLConnectionHelper.getConnection();
		List<? extends Map<String, Object>> accountTypeCurrencyConf = executeToken(token);
		HashMap<String, Object> argsMap = new HashMap<String, Object>();
		for (Map<String, Object> accountTypeCurrency : accountTypeCurrencyConf) {
			argsMap.clear();
			argsMap.put("country",			getParameter(Constants.PARAMETER_COUNTRY));
			argsMap.put("offshoreInd", 	getParameter(Constants.PARAMETER_OFFSHORE));
			argsMap.put("type", 		accountTypeCurrency.get("ACCOUNT_TYPE"));
			argsMap.put("allowedBackvalueDays", 		accountTypeCurrency.get("ALLOWED_BACKVALUE_DAYS"));
			argsMap.put("intCalculationType", 		accountTypeCurrency.get("INT_CALCULATION_TYPE"));
			argsMap.put("crIntAccrualPeriod", 		accountTypeCurrency.get("CR_INT_ACCRUAL_PERIOD"));
			argsMap.put("drIntAccrualPeriod", 		accountTypeCurrency.get("DR_INT_ACCRUAL_PERIOD"));
			argsMap.put("interestBalanceType", 		accountTypeCurrency.get("INTEREST_BALANCE_TYPE"));
			argsMap.put("linesPerStatement", 		accountTypeCurrency.get("LINES_PER_STATEMENT"));
			argsMap.put("stmentStationeryType", 		accountTypeCurrency.get("STMENT_STATIONERY_TYPE"));
			argsMap.put("maximumChargeableItems", 		accountTypeCurrency.get("MAXIMUM_CHARGEABLE_ITEMS"));
			argsMap.put("unworkedPeriod", 		accountTypeCurrency.get("UNWORKED_PERIOD"));
			argsMap.put("linesPerFullLedger", 		accountTypeCurrency.get("LINES_PER_FULL_LEDGER"));
			argsMap.put("narrative", 		accountTypeCurrency.get("NARRATIVE"));
			argsMap.put("crPortionWholeInd", 		accountTypeCurrency.get("CR_PORTION_WHOLE_IND"));
			argsMap.put("drPortionWholeInd", 		accountTypeCurrency.get("DR_PORTION_WHOLE_IND"));
			argsMap.put("bicCode", 		accountTypeCurrency.get("BIC_CODE"));
			argsMap.put("retentionPeriod", 		accountTypeCurrency.get("RETENTION_PERIOD"));
						
			try {
				conn.executeUpdate("ext_populateStaging" + getTableName(), argsMap);
			} catch (SQLException e) {
				SQLConnectionHelper.handleSQLException(e);
				throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), e);
			}
			rowCount++;
		}
		SQLConnectionHelper.closeConnection(conn);
		return rowCount;
	}

	@Override
	protected String getTableName() {
		return TABLE_NAME;
	}

}
