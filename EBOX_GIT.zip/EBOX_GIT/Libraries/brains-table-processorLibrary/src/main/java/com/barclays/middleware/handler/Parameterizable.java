package com.barclays.middleware.handler;

import java.util.Map;

/**
 * Parameterizable Interface This interface declares it is parameterizable. Any
 * interfaces/classes implemented this interface are able to accept parameters.
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public interface Parameterizable {

    /**
     * Set parameters so that sub-classes or interfaces can make use of these
     * parameters
     * 
     * @param params parameters in {@link Map} to be set
     */
    public void setParameters(Map<String, Object> params);
}
