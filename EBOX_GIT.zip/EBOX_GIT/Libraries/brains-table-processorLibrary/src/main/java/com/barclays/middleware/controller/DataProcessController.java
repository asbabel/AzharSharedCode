package com.barclays.middleware.controller;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.handler.TableHandler;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.Utility;

/**
 * Data Process Controller. This class collects the handlers which are
 * registered in property file, initializes the handler, passes parameters to
 * them and call the same to process brains data.
 */
/*
 * DATE      REFERENCE   WHO  VERSION  COMMENTS 
 * --------- ---------   ---  -------  ------- 
 * 30Aug2011 BAU00003    HZH    1a      Created
 */
public class DataProcessController {

    private static Properties properties;

    private static final LoggerConnection logger = new LoggerConnection(DataProcessController.class);

    /**
     * Constructor, we don't want this class to get initialized
     */
    private DataProcessController() {
    }

    /**
     * Initializes properties
     * 
     * @param props properties {@link Properties} to be configured
     */
    public static synchronized void configure(Properties props) {
        properties = props;
    }

    /**
     * Invokes each handler to process brains data
     * 
     * @param country country specified
     * @param offshoreInd off-shore indicator
     * @return ArrayList<Exception>
     */
    public static List<Exception> process(String country, String offshoreInd) {

        ArrayList<Exception> errorResult = new ArrayList<Exception>();

        // parameters used by each individual handler
        Map<String, Object> params = new HashMap<String, Object>();
        params.put(Constants.PARAMETER_COUNTRY, country);
        params.put(Constants.PARAMETER_OFFSHORE, offshoreInd);

        String handlersProp = properties.getProperty("handlers");
        logger.debug("Handlers configured in property file " + handlersProp);

        String[] handlerNames = handlersProp.trim().split(",");
        if (Utility.isBlank(handlersProp) || Utility.isEmpty(handlerNames)) {
            logger.warn("No table handlers are configured in property file.");
            errorResult.add(new IllegalArgumentException("No table handlers are configured in property file."));
            return errorResult;
        }

        List<String> failedHandlers = new ArrayList<String>();

        for (String handlerName : handlerNames) {
            handlerName = handlerName.trim();
            // catch any exception at any point of table processing, log the
            // error to file
            // and continue with the next handler(table).
            try {
                TableHandler tableHandler = getTableHandler(handlerName);
                tableHandler.setParameters(params);
                tableHandler.handle();
                logger.info(MessageFormat.format("Table handler {0} has been processed successfully.", handlerName));

            } catch (ProcessFailedException pfe) {
                logger.fatal(MessageFormat.format("Process failed on handler {0} for {1}/{2}", handlerName, country,
                        offshoreInd), pfe);
                failedHandlers.add(handlerName);
                errorResult.add(pfe);
            } catch (Exception e) {
                logger.fatal(MessageFormat.format("Unexpected exception on handler {0} for {1}/{2}", handlerName,
                        country, offshoreInd), e);
                failedHandlers.add(handlerName);
                errorResult.add(e);
            }
        }
        
        // None handlers failed
        if (failedHandlers.isEmpty()) { 
            logger.info(MessageFormat.format("All handlers for {0}/{1} have been processed successfully.", country,
                    offshoreInd));
         // Not all handlers succeeded
        } else { 
            logger.error(MessageFormat.format(
                    "Brains data processing for {0}/{1} is complete, the following handlers failed :- {2}", country,
                    offshoreInd, failedHandlers));
        }
        return errorResult;
    }

    /**
     * Returns table handler {@link TableHandler} as per handler name
     * 
     * @param handlerName name of handler to be created
     * @return table handler {@link TableHandler} as per handler name
     * @throws ProcessFailedException if handler name is null/blank, or handler
     * initialization failed.
     */
    private static TableHandler getTableHandler(String handlerName) throws ProcessFailedException {
        TableHandler tableHandler = null;
        if (Utility.isBlank(handlerName)) {
            throw new ProcessFailedException("Handler name is null or blank");
        }

        String className = properties.getProperty("handler.class." + handlerName);
        // if the class of handler is explicitly defined in property file with
        // tag: handler.class.<handlerName>,
        // then try loading this class first
        if (className != null) {
            if (logger.isDebugEnabled()) {
                logger.debug(MessageFormat.format("Class name {0} detected for table handler {1}", className,
                        handlerName));
            }
            tableHandler = initTableHandler(className);
        }

        // if the class of handler is not explicitly defined or it has been
        // loaded failed with given class name,
        // then try loading <package>.<handlerName>TableHandler as default
        // handler class
        if (tableHandler == null) {
            logger.debug("Table Handler not initialized with class name " + className);
            tableHandler =
                    initTableHandler(TableHandler.class.getPackage().getName() + "." + handlerName + "TableHandler");
        }

        if (tableHandler == null) {
            throw new ProcessFailedException("Cannot initialize table handler " + handlerName);
        }

        logger.info(MessageFormat.format("Table handler {0} is initialized successfully", handlerName));
        return tableHandler;
    }

    /**
     * Initializes table handler {@link TableHandler} as per class name
     * 
     * @param className class name of table handler
     * @return table handler {@link TableHandler} object
     * @throws ProcessFailedException if table handler initialization failed
     */
    private static TableHandler initTableHandler(String className) throws ProcessFailedException {
        TableHandler tableHandler = null;
        try {
            @SuppressWarnings("unchecked")
            Class<TableHandler> clazz = (Class<TableHandler>) Class.forName(className);
            tableHandler = clazz.newInstance();
        } catch (ClassNotFoundException cnfe) {
            throw new ProcessFailedException("Class not found for class name " + className, cnfe);
        } catch (Exception e) {
            throw new ProcessFailedException("Failed to initialize table handler with class name " + className, e);
        }
        return tableHandler;
    }
}
