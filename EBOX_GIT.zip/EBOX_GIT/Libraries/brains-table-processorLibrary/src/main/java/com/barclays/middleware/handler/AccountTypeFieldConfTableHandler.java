/**
 * 
 *
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 08 DEC    OLE3      Eric	  1
 */
package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.ATF_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 *
 * @author #Liang.Ma Dec 7, 2011
 * @since 1.5
 */
public class AccountTypeFieldConfTableHandler extends AbstractTableHandler {

    /* (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
     */
    @Override
    public int populateStagingTable() throws ProcessFailedException {
        ATF_L token = new ATF_L();
        int rowCount = 0;
        SQLConnection conn = SQLConnectionHelper.getConnection();
        List<? extends Map<String, Object>> accountFieldConf = executeToken(token);
        HashMap<String, Object> argsMap = new HashMap<String, Object>();
        for (Map<String, Object> map : accountFieldConf) {
            argsMap.clear();
            for (int i = 0; i < ATF_L.RESPONSE_FIELDS.length; i++) {
                argsMap.put(ATF_L.RESPONSE_FIELDS[i], map.get(ATF_L.RESPONSE_FIELDS[i]));
            }
            argsMap.put("country", getParameter(Constants.PARAMETER_COUNTRY));
            argsMap.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
            try {
                conn.executeUpdate("ext_populateStaging" + getTableName(), argsMap);
            } catch (SQLException e) {
                SQLConnectionHelper.handleSQLException(e);
                throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), e);
            }
            rowCount++;
        }
        SQLConnectionHelper.closeConnection(conn);
        return rowCount;
    }

    /* (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
     */
    @Override
    protected String getTableName() {
        return "AccountTypeFieldConf";
    }

}
