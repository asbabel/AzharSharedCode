package com.barclays.middleware.util;

/**
 * Constants class Holding constants used in brains data processor.
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public class Constants {

    /**
     * Parameter labels for passing parameters to handlers
     */
    public static final String PARAMETER_COUNTRY = "country";
    public static final String PARAMETER_OFFSHORE = "offshoreInd";

    /**
     * Flags indicating onshore/offshore.
     */
    public static final String ONSHORE = "0";
    public static final String OFFSHORE = "1";

    /**
     * Reserved Constants Constants used when dealing with the fields from
     * property file
     */
    public static final String HANDLERS = "handlers";
    public static final String HANDLERS_DELIMETER = ",";
    public static final String HANDLER_CLASS_PREFIX = "handler.class.";
    public static final String HANDLER_CLASS_SUFFIX = "TableHandler";
    public static final String HANDLER_PACKAGE_DELIMETER = ".";
    public static final String DATASOURCE_MWDB_USER = "datasource.mwdb.user";
    public static final String LOG4J_CONFIG_NAME = "log4j_config";

    private Constants() {
    }
}
