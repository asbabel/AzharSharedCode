package com.barclays.middleware.handler;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.REF_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * RefValue Table Handler This class invokes REF_L BRAINS token and saves the
 * results to RefValue table
 * 
 * @see AbstractTableHandler
 * @author LEES
 *
 */

/*
 * DATE         REFERENCE   WHO     VERSION  COMMENTS 
 * ---------    ---------   ---     -------  ------- 
 * 18DEC13      WP654       LEES    1        Created
 * 03May16      WP711       CLAREP  1a       Copied to WP711 branch
 * 
 */

public class RefValueTableHandler extends AbstractTableHandler {

    private static final String TABLE_NAME = "RefValue";

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
     */
    @Override
    public int populateStagingTable() throws ProcessFailedException {
        int processedRecords = 0;
        REF_L token = new REF_L();

        Object country = getParameter(Constants.PARAMETER_COUNTRY);
        Object offshoreInd = getParameter(Constants.PARAMETER_OFFSHORE);

        SQLConnection conn = SQLConnectionHelper.getConnection();
        SortedMap<String, Object> args = new TreeMap<String, Object>();
        args.put("Country", country);
        args.put("OffshoreInd", offshoreInd);

        try {
            CallableStatement query = conn.prepareCall("ext_getDomain", args);
            ResultSet results = conn.executeQuery(query, args);
            List<String> domains = new ArrayList<String>();
            while (results.next()) {
                domains.add(results.getString("Domain"));
            }

            token.setDomain(domains);
        } catch (SQLException e) {
            SQLConnectionHelper.handleSQLException(e);
            throw new ProcessFailedException("SQL Exception thrown when processing table Domain", e);
        }
        try {
            List<? extends Map<String, Object>> refVales = executeToken(token);

            HashMap<String, Object> argsMap = new HashMap<String, Object>();

            for (Map<String, Object> refValue : refVales) {
                argsMap.put("Country", country);
                argsMap.put("Domain", refValue.get("DOMAIN"));
                argsMap.put("Code", checkForNull(refValue.get("CODE")));
                argsMap.put("Description", checkForNull(refValue.get("DESCRIPTION")));
                argsMap.put("OffshoreInd", offshoreInd);

                conn.executeUpdate("ext_populateStaging" + getTableName(), argsMap);
                processedRecords++;
            }
            return processedRecords;
        } catch (SQLException e) {
            SQLConnectionHelper.handleSQLException(e);
            throw new ProcessFailedException("SQL Exception throw when processing table " + getTableName(), e);
        } finally {
            SQLConnectionHelper.closeConnection(conn);
        }
    }

    private Object checkForNull(Object object) {
        return object == null ? "" : object;

    }

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
     */
    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }
}
