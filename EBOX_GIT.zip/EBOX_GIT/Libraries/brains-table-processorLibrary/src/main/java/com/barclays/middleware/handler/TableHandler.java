package com.barclays.middleware.handler;

import com.barclays.middleware.exception.ProcessFailedException;

/**
 * Table Handler Interface. This is the interface to all table handlers.
 * 
 * @see Parameterizable
 * @see AbstractTableHandler
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public interface TableHandler extends Parameterizable {

    /**
     * Process the data related to current table
     * 
     * @return number of rows processed
     * @throws ProcessFailedException
     */
    public int handle() throws ProcessFailedException;
}
