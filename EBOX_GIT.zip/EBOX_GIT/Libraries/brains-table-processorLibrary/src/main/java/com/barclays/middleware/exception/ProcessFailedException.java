package com.barclays.middleware.exception;


/**
 * Process Failed Exception
 * User defined exception for handling all exceptions during brains data
 * processing.
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public class ProcessFailedException extends Exception {

	/**
	 * Serial version UID for serialization
	 */
	private static final long serialVersionUID = -5816628163097660954L;

	/**
	 * Constructs a new exception with <code>null</code> as its detail message.
     * 
	 */
	public ProcessFailedException() {
		super();
	}

	/**
     * Constructs a new exception with the specified detail message and
     * cause.
     * 
	 * @param message error message
	 * @param cause exception to handle
	 */
	public ProcessFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
     * Constructs a new exception with the specified detail message.
     * 
	 * @param message error message
	 */
	public ProcessFailedException(String message) {
		super(message);
	}

	/**
     * Constructs a new exception with the specified cause and a detail
     * message of cause.
     * 
	 * @param cause exception to handle
	 */
	public ProcessFailedException(Throwable cause) {
		super(cause);
	}
}
