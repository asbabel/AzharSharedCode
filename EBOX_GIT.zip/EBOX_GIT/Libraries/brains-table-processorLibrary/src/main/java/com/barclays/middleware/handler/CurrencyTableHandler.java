package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.CRF_I;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;
import com.ibm.math.BigDecimal;

/**
 * Currency Table Handler. 
 * This class invokes CRF_I token and saves the results from Brains.currencies table to MWDB.Currency table
 * 
 * @see AbstractTableHandler
 * 
 */
/*
 * DATE        REFERENCE   		WHO  		VERSION  	COMMENTS 
 * ---------   ---------   		---  		-------  	------- 
 * 29SEP2014   RAOPh1BExtra    	Vaibhav		1a			Created
 */
public class CurrencyTableHandler extends AbstractTableHandler {
	
	private static final String TABLE_NAME = "Currency";
	
	/*
	 * (non-Javadoc)
	 * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
	 */
	@Override
	public int populateStagingTable() throws ProcessFailedException {
		BigDecimal minimumUnitOfAccount;
		BigDecimal scalingFactor;

		CRF_I token = new CRF_I();
		List<? extends Map<String, Object>> currencies = executeToken(token);
		
		SQLConnection conn = SQLConnectionHelper.getConnection();
		
		try {
			Map<String, Object> args = new HashMap<String, Object>();
			for (Map<String, Object> currency : currencies) {
				args.clear();
				args.put("country",			getParameter(Constants.PARAMETER_COUNTRY));
				args.put("offshoreInd", 	getParameter(Constants.PARAMETER_OFFSHORE));
				args.put("currency", 		currency.get("SWIFT_CODE"));
				args.put("currencyName", 	currency.get("DISPLAY_CODE"));
				args.put("currencyNumber", 	currency.get("CURRENCY_NUMBER"));
				args.put("currencyMask", 	currency.get("CURRENCY_MASK"));
				
				minimumUnitOfAccount = (BigDecimal) currency.get("MINIMUM_UNIT_OF_ACCOUNT");
				scalingFactor = new BigDecimal((Integer) currency.get("SCALING_FACTOR"));
				if(minimumUnitOfAccount != null && scalingFactor != null)
				{
					args.put("currencyUnit", minimumUnitOfAccount.multiply(scalingFactor));
				}
				else
				{
					args.put("currencyUnit", null);
				}

				conn.executeUpdate("ext_populateStaging" + getTableName(), args);
			}
			return currencies.size();
		} catch (SQLException sqle) {
			SQLConnectionHelper.handleSQLException(sqle);
			throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), sqle);
		} finally {
			SQLConnectionHelper.closeConnection(conn);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
	 */
	@Override
	protected String getTableName() {
		return TABLE_NAME;
	}
}
