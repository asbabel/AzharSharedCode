package com.barclays.middleware.util;

import java.util.Collection;
import java.util.Map;

/**
 * Brains table processor utilities This class provides a list of utility
 * functions for checking {@link String}, {@link Collection} and {@link Map}
 * etc.
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public class Utility {

    /**
     * Constructor, we don't want this class to be initialized.
     */
    private Utility() {
    }

    /**
     * Checks whether string is null or blank
     * 
     * @param s string to be verified
     * @return true if s is null or blank
     */
    public static boolean isBlank(String s) {
        return s == null || s.trim().length() == 0;
    }

    /**
     * Checks whether string is null or blank
     * 
     * @param s string to be verified
     * @return true if s is neither null nor blank
     */
    public static boolean isNotBlank(String s) {
        return !isBlank(s);
    }

    /**
     * Checks whether collection is null or empty
     * 
     * @param coll collection {@link Collection} to be verified
     * @return true if coll is null or empty
     */
    public static boolean isEmpty(Collection<? extends Object> coll) {
        return coll == null || coll.isEmpty();
    }

    /**
     * Checks whether collection is null or empty
     * 
     * @param coll collection {@link Collection} to be verified
     * @return true if coll is neither null nor empty
     */
    public static boolean isNotEmpty(Collection<? extends Object> coll) {
        return !isEmpty(coll);
    }

    /**
     * Checks whether map is null or empty
     * 
     * @param map map {@link Map} to be verified
     * @return true if map is null or empty
     */
    public static boolean isEmpty(Map<? extends Object, ? extends Object> map) {
        return map == null || map.isEmpty();
    }

    /**
     * Checks whether map is null or empty
     * 
     * @param map map {@link Map} to be verified
     * @return true if map is neither null nor empty
     */
    public static boolean isNotEmpty(Map<? extends Object, ? extends Object> map) {
        return !isEmpty(map);
    }

    /**
     * Checks whether array is null or empty
     * 
     * @param array array of {@link Object} to be verified
     * @return true if map is null or empty
     */
    public static boolean isEmpty(Object[] array) {
        return array == null || array.length == 0;
    }

    /**
     * Checks whether array is null or empty
     * 
     * @param array array of {@link Object} to be verified
     * @return true if array is neither null or empty
     */
    public static boolean isNotEmpty(Object[] array) {
        return !isEmpty(array);
    }
}
