/**
 * 
 *
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 08 DEC    OLE3      Eric	  1
 */
package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.AFC_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 *
 * @author #Liang.Ma Dec 7, 2011
 * @since 1.5
 */
public class AccountFieldConfTableHandler extends AbstractTableHandler {

    /* (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
     */
    @Override
    public int populateStagingTable() throws ProcessFailedException {
        AFC_L token = new AFC_L();
        int rowCount = 0;
        SQLConnection conn = SQLConnectionHelper.getConnection();
        List<? extends Map<String, Object>> accountFieldConf = executeToken(token);
        HashMap<String, Object> argsMap = new HashMap<String, Object>();
        String value;
        for (Map<String, Object> map : accountFieldConf) {
            argsMap.clear();
            for (int i = 0; i < AFC_L.RESPONSE_FIELDS.length; i++) {
                value = (String) map.get(AFC_L.RESPONSE_FIELDS[i]);
                if (i == 1 && value != null) {
                    value = capFirstChar(value.trim());
                }
                argsMap.put(AFC_L.RESPONSE_FIELDS[i], value);
            }
            argsMap.put("country", getParameter(Constants.PARAMETER_COUNTRY));
            argsMap.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
            try {
                conn.executeUpdate("ext_populateStaging" + getTableName(), argsMap);
            } catch (SQLException e) {
                SQLConnectionHelper.handleSQLException(e);
                throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), e);
            }
            rowCount++;
        }
        SQLConnectionHelper.closeConnection(conn);
        return rowCount;
    }

    /**
     * @param value
     */
    private String capFirstChar(String value) {
        String[] vs = value.trim().toLowerCase().split(" ");
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < vs.length; j++) {
            String word = vs[j].toLowerCase();
            sb.append(word.substring(0, 1).toUpperCase());
            sb.append(word.substring(1));
            sb.append(" ");
        }

        return sb.toString().trim();
    }

    /* (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
     */
    @Override
    protected String getTableName() {
        return "AccountFieldConf";
    }

}
