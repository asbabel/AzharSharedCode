package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.RQT_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;
import com.barclays.middleware.util.Utility;

/**
 * Requirements Table Handler. This class invokes RQT_L token and saves the
 * results to Requirements table
 * 
 * @see AbstractTableHandler
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public class RequirementsTableHandler extends AbstractTableHandler {

    private static final String NEXTDUEDATE = "NEXT_DUE_DATE";
    private static final String TABLE_NAME = "Requirements";

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
     */
    @Override
    public int populateStagingTable() throws ProcessFailedException {
        int requirementsCount = 0;

        RQT_L token = new RQT_L();
        List<? extends Map<String, Object>> requirements = executeToken(token);

        SQLConnection conn = SQLConnectionHelper.getConnection();
        Date date = null;
        String nextDueDate = null;

        try {
            Map<String, Object> args = new HashMap<String, Object>();
            for (Map<String, Object> record : requirements) {
                args.put("country", getParameter(Constants.PARAMETER_COUNTRY));
                args.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
                args.put("facilityType", record.get("FACILITY_TYPE"));
                args.put("facilityCode", record.get("FACILITY_CODE"));
                args.put("branchNumber", record.get("BRANCH_NUMBER"));
                args.put("accountType", record.get("ACCOUNT_TYPE"));
                args.put("frequencyInd", record.get("FREQUENCY_IND"));
                args.put("frequencyData", record.get("FREQUENCY_DATA"));
                args.put("dcsXmitPriority", record.get("DCS_XMIT_PRIORITY"));
                args.put("dcsExcludeInd", record.get("DCS_EXCLUDE_IND"));
                if (record.get(NEXTDUEDATE) != null && Utility.isNotBlank(record.get(NEXTDUEDATE).toString())) {
                    date = (Date) (record.get(NEXTDUEDATE));
                    nextDueDate = yyyyMMdd.format(date);
                    args.put("nextDueDate", nextDueDate);
                } else {
                    args.put("nextDueDate", null);
                }
                args.put("reportFormatSet", record.get("REPORT_FORMAT_SET"));

                conn.executeUpdate("ext_populateStaging" + getTableName(), args);
                requirementsCount++;
            }
            return requirementsCount;
        } catch (SQLException sqle) {
            SQLConnectionHelper.handleSQLException(sqle);
            throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), sqle);
        } finally {
            SQLConnectionHelper.closeConnection(conn);
        }
    }

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
     */
    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }
}
