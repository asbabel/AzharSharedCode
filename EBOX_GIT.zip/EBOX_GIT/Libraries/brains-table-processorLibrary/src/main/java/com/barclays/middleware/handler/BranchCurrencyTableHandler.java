package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.BCF_I;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * 
 * Branch Currency Handler This class invokes BCF_I BRAINS token and save the
 * results to Branch table
 * 
 * @see AbstractTableHandler
 * @author LEES
 *
 */

/*
 * DATE        REFERENCE        WHO     VERSION     COMMENTS 
 * ---------   ---------        ---     -------     ------- 
 * 03MAR14     WP654            SL      1.00        Created for FOSPARAM writeout
 * 13JUN16     WP711            CLAREP  1a          Copied to WP711 branch
 */

public class BranchCurrencyTableHandler extends AbstractTableHandler {

    private static final String TABLE_NAME = "BranchCurrency";

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
     */
    @Override
    public int populateStagingTable() throws ProcessFailedException {
        int processedRecords = 0;

        BCF_I token = new BCF_I();
        List<? extends Map<String, Object>> branchCurrencies = executeToken(token);

        SQLConnection conn = SQLConnectionHelper.getConnection();
        Map<String, Object> args = new HashMap<String, Object>();

        try {
            for (Map<String, Object> record : branchCurrencies) {
                args.put("Country", getParameter(Constants.PARAMETER_COUNTRY));
                args.put("BranchNumber", record.get("BRANCH_NUMBER"));
                args.put("CurrencyNumber", record.get("CURRENCY_NUMBER"));
                args.put("OffshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));

                conn.executeUpdate("ext_populateStaging" + getTableName(), args);

                processedRecords++;
            }
            return processedRecords;
        } catch (SQLException e) {
            SQLConnectionHelper.handleSQLException(e);
            throw new ProcessFailedException("SQL Exception thrown when processing table " + getTableName(), e);
        } finally {
            SQLConnectionHelper.closeConnection(conn);
        }
    }

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
     */
    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

}
