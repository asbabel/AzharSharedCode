package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.BrainsToken;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;
import com.barclays.middleware.util.Utility;

/**
 * Abstract Table Handler This class manages the processing procedure of all
 * table handlers with a list of common functions and utilities.
 * 
 * @see TableHandler
 * @see Parameterizable
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public abstract class AbstractTableHandler implements TableHandler {

    private static final String ROWCOUNT = "rowcount";

    protected static final DateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");

    protected Map<String, Object> params;

    private static final LoggerConnection logger = new LoggerConnection(AbstractTableHandler.class);

    /**
     * Sole constructor.
     */
    protected AbstractTableHandler() {
    }

    /* 
     * Processing steps:
     * 1. Delete all the records from the staging table where the country & offshore is as specified
     * 2. The relevant BRAINS token is called to retrieve the relevant records, and then a stored 
     *    procedure is called to insert them into the relevant staging MWDB table
     * 3. Delete all records from the live table where the country is the specified country and then
     *    copy all records from the staging table where the country & offshore are as specified
     * 4. The staging table should be emptied for the country & offshore after the live table is updated
     * 
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.Handler#handle()
     */
    @Override
    public int handle() throws ProcessFailedException {
        int purgedCount;
        int populatedCount;

        purgedCount = purgeStagingTable();
        logger.info(MessageFormat.format(
                "Staging table Staging{0} has been purged with {1, number, integer} rows successfully (before processing).",
                getTableName(), purgedCount));

        populatedCount = populateStagingTable();
        logger.info(MessageFormat.format(
                "Staging table Staging{0} has been populated with {1, number, integer} rows successfully.",
                getTableName(), populatedCount));

        populatedCount = populateMasterTable();
        logger.info(MessageFormat.format(
                "Master table {0} has been populated with {1, number, integer} rows successfully.", getTableName(),
                populatedCount));

        // Clear the staging table for the country & offshore, as it doesn't
        // make sense to hold old data after
        // successfully population of masters.
        purgedCount = purgeStagingTable();
        logger.info(MessageFormat.format(
                "Staging table Staging{0} has been purged with {1, number, integer} rows successfully (after processing).",
                getTableName(), purgedCount));

        return populatedCount;
    }

    /**
     * Purges the records from staging tables for specified country.
     * 
     * @return number of rows purged
     * @throws ProcessFailedException if stored procedure execution failed
     */
    public int purgeStagingTable() throws ProcessFailedException {
        SQLConnection conn = null;
        try {
            conn = SQLConnectionHelper.getConnection();
            Map<String, Object> args = new HashMap<String, Object>();
            args.put("country", getParameter(Constants.PARAMETER_COUNTRY));
            args.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
            args.put(ROWCOUNT, conn.makeOutputParameter(Types.INTEGER));

            @SuppressWarnings("rawtypes")
            Map outParams = conn.executeUpdate("ext_purgeStaging" + getTableName(), args);

            return Integer.parseInt(outParams.get(ROWCOUNT).toString());
        } catch (SQLException sqle) {
            SQLConnectionHelper.handleSQLException(sqle);
            throw new ProcessFailedException("SQLException thrown out when populating staging table " + getTableName(),
                    sqle);
        } catch (Exception e) {
            throw new ProcessFailedException("Unexpected exception thrown out when populating staging table "
                    + getTableName(), e);
        } finally {
            SQLConnectionHelper.closeConnection(conn);
        }
    }

    /**
     * Populates staging tables from BRAINS for specified country. This should
     * be implemented in each individual table handler.
     * 
     * @return number of rows populated
     * @throws ProcessFailedException if brains token or stored procedure
     * execution failed
     */
    public abstract int populateStagingTable() throws ProcessFailedException;

    /**
     * Populate master tables from staging tables for specified country.
     * 
     * @return number of rows to be populated
     * @throws ProcessFailedException if stored procedure execution failed.
     */
    public int populateMasterTable() throws ProcessFailedException {
        SQLConnection conn = null;
        try {
            conn = SQLConnectionHelper.getConnection();
            Map<String, Object> args = new HashMap<String, Object>();
            args.put("country", getParameter(Constants.PARAMETER_COUNTRY));
            args.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
            args.put(ROWCOUNT, conn.makeOutputParameter(Types.INTEGER));

            @SuppressWarnings("rawtypes")
            Map outParams = conn.executeUpdate("ext_populate" + getTableName(), args);

            return Integer.parseInt(outParams.get(ROWCOUNT).toString());
        } catch (SQLException sqle) {
            SQLConnectionHelper.handleSQLException(sqle);
            throw new ProcessFailedException("SQLException thrown out when populating master table " + getTableName(),
                    sqle);
        } catch (Exception e) {
            throw new ProcessFailedException("Unexpected exception thrown out when populating master table "
                    + getTableName(), e);
        } finally {
            SQLConnectionHelper.closeConnection(conn);
        }
    }

    /**
     * Set parameters so that handlers are able to use these parameters from
     * controller.
     * 
     * @see com.barclays.middleware.handler.TableHandler#setParameters(java.util.Map)
     */
    @Override
    public void setParameters(Map<String, Object> params) {
        this.params = params;
    }

    /**
     * Executes BRAINS token for specified token name
     * 
     * @param tokenName name of the token to be executed
     * @return results in {@link List} returned from BRAINS token
     * @throws ProcessFailedException if token name is not specified or token
     * execution failed.
     */
    protected List<? extends Map<String, Object>> executeToken(String tokenName) throws ProcessFailedException { // NOSONAR
        if (Utility.isBlank(tokenName)) {
            throw new ProcessFailedException("Brains token name is not specified");
        }

        try {
            @SuppressWarnings("unchecked")
            Class<BrainsToken> clazz =
                    (Class<BrainsToken>) Class.forName(BrainsToken.class.getPackage().getName() + "."
                            + tokenName.replaceAll("-", "_"));
            return executeToken(clazz);
        } catch (ClassNotFoundException cnfe) {
            throw new ProcessFailedException("Brains token class not found for " + tokenName, cnfe);
        } catch (Exception e) {
            throw new ProcessFailedException("Unexpected exception on loading brains token class for " + tokenName, e);
        }
    }

    /**
     * Executes BRAINS token for specified token class
     * 
     * @param clazz class of token to be executed
     * @return results in {@link List} returned from BRAINS token
     * @throws ProcessFailedException if token initialization failed.
     */
    protected List<? extends Map<String, Object>> executeToken(Class<BrainsToken> clazz) throws ProcessFailedException { // NOSONAR
        if (clazz == null) {
            throw new ProcessFailedException("Brains token class is not specified");
        }

        try {
            BrainsToken token = clazz.newInstance();
            return executeToken(token);
        } catch (Exception e) {
            throw new ProcessFailedException("Brains token initialization failed for " + clazz.getName(), e);
        }
    }

    /**
     * Executes BRAINS token for specified token object
     * 
     * @param token token to be executed
     * @return results in {@link List} returned from BRAINS token
     * @throws ProcessFailedException if token initialization failed.
     */
    protected List<? extends Map<String, Object>> executeToken(BrainsToken token) throws ProcessFailedException { // NOSONAR
        if (token == null) {
            throw new ProcessFailedException("Brains token is not initiliazed");
        }

        try {
            token.setCountry(getParameter(Constants.PARAMETER_COUNTRY).toString());
            token.setOffshore(Constants.OFFSHORE.equals(getParameter(Constants.PARAMETER_OFFSHORE).toString()));
            token.execute();

            if (logger.isDebugEnabled()) {
                logger.debug(MessageFormat.format("Brains token {0} is executed successfully", token.getToken()));
            }
            return token.getRows();
        } catch (Exception e) {
            throw new ProcessFailedException("Brains token execution failed for " + token.getToken(), e);
        }
    }

    /**
     * Returns parameter value with specified parameter name
     * 
     * @param paramName name of parameter
     * @return value of parameter
     * @throws ProcessFailedException if parameters are not initialized or
     * parameter name not found.
     */
    protected Object getParameter(String paramName) throws ProcessFailedException {
        if (Utility.isEmpty(params)) {
            throw new ProcessFailedException("No parameters set");
        }
        Object paramValue = params.get(paramName);
        if (paramValue == null) {
            throw new ProcessFailedException("No parameter found for parameter name " + paramName);
        }

        return paramValue;
    }

    /**
     * Returns table name for individual table handler for procedure naming
     * conversion etc.
     * 
     * @return table name of individual table handler
     */
    protected abstract String getTableName();
}
