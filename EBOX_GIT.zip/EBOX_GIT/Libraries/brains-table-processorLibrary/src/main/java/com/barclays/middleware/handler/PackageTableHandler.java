package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.CPK_L;
import com.barclays.middleware.brains.RPK_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * Package Table Handler. This class invokes CPK_L and RPK_L brains tokens and
 * saves the results to Package table
 * 
 * @see AbstractTableHandler
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public class PackageTableHandler extends AbstractTableHandler {

    private static final String TABLE_NAME = "Package";

    private static final LoggerConnection logger = new LoggerConnection(PackageTableHandler.class);

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
     */
    @Override
    public int populateStagingTable() throws ProcessFailedException {

        CPK_L chargeToken = new CPK_L();
        List<? extends Map<String, Object>> chargePackages = executeToken(chargeToken);

        RPK_L rateToken = new RPK_L();
        List<? extends Map<String, Object>> ratePackages = executeToken(rateToken);

        int chargeCount = 0;
        int rateCount = 0;
        int processedRecords = 0;
        SQLConnection conn = SQLConnectionHelper.getConnection();

        try {
            Map<String, Object> chargeArgs = new HashMap<String, Object>();
            for (Map<String, Object> record : chargePackages) {

                chargeArgs.put("packageName", record.get("PACKAGE_NAME"));
                chargeArgs.put("packageType", "CHARGE");
                chargeArgs.put("description", record.get("DESCRIPTION"));
                chargeArgs.put("marketSegmentDefault", record.get("MS_DEFAULT"));
                chargeArgs.put("marketSegment", record.get("MARKET_SEG"));
                chargeArgs.put("accountTypeDefault", record.get("AT_DEFAULT"));
                chargeArgs.put("accountType", record.get("ACCOUNT_TYPE"));
                chargeArgs.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
                chargeArgs.put("country", getParameter(Constants.PARAMETER_COUNTRY));

                conn.executeUpdate("ext_populateStaging" + getTableName(), chargeArgs);

                chargeCount++;
            }
            if (logger.isDebugEnabled()) {
                logger.debug(MessageFormat.format(
                        "Staging table Staging{0} has been populated with {1, number, integer} rows of charge packages",
                        getTableName(), chargeCount));
            }

            Map<String, Object> rateArgs = new HashMap<String, Object>();
            for (Map<String, Object> record : ratePackages) {

                rateArgs.put("packageName", record.get("PACKAGE_NAME"));
                rateArgs.put("packageType", "RATE");
                rateArgs.put("description", record.get("DESCRIPTION"));
                rateArgs.put("marketSegmentDefault", record.get("MS_DEFAULT"));
                rateArgs.put("marketSegment", record.get("MARKET_SEG"));
                rateArgs.put("accountTypeDefault", record.get("AT_DEFAULT"));
                rateArgs.put("accountType", record.get("ACCOUNT_TYPE"));
                rateArgs.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
                rateArgs.put("country", getParameter(Constants.PARAMETER_COUNTRY));

                conn.executeUpdate("ext_populateStaging" + getTableName(), rateArgs);

                rateCount++;
            }
            if (logger.isDebugEnabled()) {
                logger.debug(MessageFormat.format(
                        "Staging table Staging{0} has been populated with {1, number, integer} rows of rate packages",
                        getTableName(), rateCount));
            }

            processedRecords = chargeCount + rateCount;
            return processedRecords;
        } catch (SQLException sqle) {
            SQLConnectionHelper.handleSQLException(sqle);
            throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), sqle);
        } finally {
            SQLConnectionHelper.closeConnection(conn);
        }
    }

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
     */
    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }
}
