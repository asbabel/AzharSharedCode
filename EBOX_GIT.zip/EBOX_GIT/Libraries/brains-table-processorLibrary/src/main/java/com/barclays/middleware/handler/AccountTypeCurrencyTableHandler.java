package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.ATC_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * Account Type Currency Table Handler. This class invokes ATC_L token and saves
 * the results from Brains to MWDB.AccountTypeCurrency table
 * 
 * @see AbstractTableHandler
 * 
 */

/*
 * DATE        REFERENCE        WHO         VERSION     COMMENTS 
 * ---------   ---------   		---  		-------  	------- 
 * 26Nov2014   WP680BNET    	Prachi		1a			Created
 */
public class AccountTypeCurrencyTableHandler extends AbstractTableHandler {

    private static final String TABLE_NAME = "AccountTypeCurrency";

    @Override
    public int populateStagingTable() throws ProcessFailedException {
        ATC_L token = new ATC_L();
        token.setVersionNumber(1);
        int rowCount = 0;
        SQLConnection conn = SQLConnectionHelper.getConnection();
        List<? extends Map<String, Object>> accountTypeCurrencyConf = executeToken(token);
        HashMap<String, Object> argsMap = new HashMap<String, Object>();
        for (Map<String, Object> accountTypeCurrency : accountTypeCurrencyConf) {
            argsMap.clear();
            argsMap.put("country", getParameter(Constants.PARAMETER_COUNTRY));
            argsMap.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
            argsMap.put("accountType", accountTypeCurrency.get("ACCOUNT_TYPE"));
            argsMap.put("currencyNumber", accountTypeCurrency.get("CURRENCY_NUMBER"));
            argsMap.put("drDefaultTranLimit", accountTypeCurrency.get("DR_DEFAULT_TRAN_LIMIT"));
            argsMap.put("crDefaultTranLimit", accountTypeCurrency.get("CR_DEFAULT_TRAN_LIMIT"));
            argsMap.put("drInterestWaiver", accountTypeCurrency.get("DR_INTEREST_WAIVER"));
            argsMap.put("crInterestWaiver", accountTypeCurrency.get("CR_INTEREST_WAIVER"));
            argsMap.put("minimumAccountBalance", accountTypeCurrency.get("MINIMUM_ACCOUNT_BALANCE"));
            argsMap.put("interestBearingBalance", accountTypeCurrency.get("INTEREST_BEARING_BALANCE"));
            argsMap.put("minDRInterestCharge", accountTypeCurrency.get("MIN_DR_INTEREST_CHARGE"));
            argsMap.put("unclaimedBalanceSplit", accountTypeCurrency.get("UNCLAIMED_BALANCE_SPLIT"));
            argsMap.put("unclaimedBalancePeriod", accountTypeCurrency.get("UNCLAIMED_BALANCE_PERIOD"));
            argsMap.put("lffeSetIdentifier", accountTypeCurrency.get("LFEE_SET_IDENTIFIER"));
            argsMap.put("crLffeSetIdentifier", accountTypeCurrency.get("CR_LFEE_CHARGE_BASIS"));
            argsMap.put("fixedLedgerCharge", accountTypeCurrency.get("FIXED_LEDGER_CHARGE"));
            argsMap.put("inoperativeAccountCrg", accountTypeCurrency.get("INOPERATIVE_ACCOUNT_CHG"));
            argsMap.put("extraStatementCharge", accountTypeCurrency.get("EXTRA_STATEMENT_CHG"));
            argsMap.put("ledgerFeeMethod", accountTypeCurrency.get("LEDGER_FEE_METHOD"));
            argsMap.put("crInterestDivisor", accountTypeCurrency.get("CR_INTEREST_DIVISOR"));
            argsMap.put("drInterestDivisor", accountTypeCurrency.get("DR_INTEREST_DIVISOR"));
            argsMap.put("bonusRateId", accountTypeCurrency.get("BONUS_RATE_ID"));

            try {
                conn.executeUpdate("ext_populateStaging" + getTableName(), argsMap);
            } catch (SQLException e) {
                SQLConnectionHelper.handleSQLException(e);
                throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), e);
            }
            rowCount++;
        }
        SQLConnectionHelper.closeConnection(conn);
        return rowCount;
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

}
