package com.barclays.middleware.util;

import java.sql.SQLException;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.exception.ProcessFailedException;

/**
 * SQL Connection Helper This helper class helps manage database connections,
 * transactions and exceptions etc.
 * 
 */
/*
 * DATE        REFERENCE   WHO  VERSION  COMMENTS 
 * ---------   ---------   ---  -------  ------- 
 * 30Aug2011   BAU00003    HZH    1a      Created
 */
public class SQLConnectionHelper {

    private static final LoggerConnection logger = new LoggerConnection(SQLConnectionHelper.class);

    /**
     * Constructor, we don't want this utility class to get initialized
     */
    private SQLConnectionHelper() {
    }

    /**
     * A fresh database connection.
     * 
     * @return connection {@link SQLConnection} retrieved from datasource
     * @throws SQLException
     */
    public static SQLConnection getConnection() throws ProcessFailedException {
        SQLConnection conn;
        try {
            conn = new SQLConnection(DataSourceDirectory.getInstance().getDataSource("mwdb").getConnection());
            return conn;
        } catch (SQLException sqle) {
            throw new ProcessFailedException("Failed to get connection from mwdb", sqle);
        } catch (Exception e) {
            throw new ProcessFailedException("Unexpected exception when fetching connection from mwdb", e);
        }
    }

    /**
     * Switches on/off auto commit.
     * 
     * @param conn database connection {@link SQLConnection}
     * @param autoCommit auto commit flag
     * @throws ProcessFailedException
     */
    public static void setAutoCommit(SQLConnection conn, boolean autoCommit) throws ProcessFailedException {
        if (conn == null) {
            throw new ProcessFailedException("Cannot set auto commit because connection is null");
        }

        try {
            conn.setAutoCommit(autoCommit);
        } catch (SQLException sqle) {
            throw new ProcessFailedException("Set auto commit failed", sqle);
        }
    }

    /**
     * Closes SQL connection, throwing {@link ProcessFailedException} in case
     * closing failed
     * 
     * @param conn database connection {@link SQLConnection} to be closed
     * @throws ProcessFailedException
     */
    public static void closeConnection(SQLConnection conn) throws ProcessFailedException {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException sqle) {
                throw new ProcessFailedException("Failed to close connection", sqle);
            }
        }
    }

    /**
     * Rolls database transaction back, throwing {@link ProcessFailedException}
     * in case rolling back failed This method should be used only when
     * auto-commit mode has been disabled.
     * 
     * @param conn database connection {@link SQLConnection}
     * @throws ProcessFailedException
     */
    public static void rollback(SQLConnection conn) throws ProcessFailedException {
        if (conn == null) {
            throw new ProcessFailedException("Cannot roll back transaction because connection is null");
        }

        try {
            conn.rollback();
        } catch (SQLException sqle) {
            throw new ProcessFailedException("Failed to roll back transaction", sqle);
        }
    }

    /**
     * Commits database transaction, throwing {@link ProcessFailedException} in
     * case committing failed This method should be used only when auto-commit
     * mode has been disabled.
     * 
     * @param conn database connection {@link SQLConnection}
     * @throws ProcessFailedException
     */
    public static void commit(SQLConnection conn) throws ProcessFailedException {
        if (conn == null) {
            throw new ProcessFailedException("Cannot commit transaction because connection is null");
        }

        try {
            conn.commit();
        } catch (SQLException sqle) {
            throw new ProcessFailedException("Failed to commit transaction", sqle);
        }
    }

    /**
     * logs SQLException {@link SQLException} with any exception chain to file.
     * 
     * @param sqle SQL exception {@link SQLException}
     */
    public static void handleSQLException(SQLException sqle) {
        while (sqle != null) {
            logger.fatal(sqle.getMessage(), sqle);
            sqle = sqle.getNextException();
        }
    }
}
