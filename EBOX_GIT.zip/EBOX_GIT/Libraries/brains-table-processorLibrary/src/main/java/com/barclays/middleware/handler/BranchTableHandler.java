package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.BRF_I;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * Branch Table Handler This class invokes BRF_I BRAINS token and save the
 * results to Branch table
 * 
 * @see AbstractTableHandler
 * @author LEES
 *
 */

/*
 * DATE     REFERENCE   WHO     VERSION     COMMENTS
 * -----    ----------  ---     -------     --------
 * 03MAR14  WP654       SL      1.00        created for FOSPARAM writeout
 * 13JUN16  WP711       CLAREP  1a          Copied to WP711 branch
 */

public class BranchTableHandler extends AbstractTableHandler {

    private static final String TABLE_NAME = "Branch";

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
     */
    @Override
    public int populateStagingTable() throws ProcessFailedException {
        int processedRecords = 0;

        BRF_I token = new BRF_I();
        List<? extends Map<String, Object>> branches = executeToken(token);

        SQLConnection conn = SQLConnectionHelper.getConnection();
        Map<String, Object> args = new HashMap<String, Object>();
        try {
            for (Map<String, Object> record : branches) {
                args.put("Country", getParameter(Constants.PARAMETER_COUNTRY));
                args.put("BranchNumber", record.get("BRANCH_NUMBER"));
                args.put("BranchName", record.get("BRANCH_NAME"));
                args.put("BranchType", record.get("COMPUTERISED_BRANCH_IND"));
                args.put("OffshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));

                conn.executeUpdate("ext_populateStaging" + getTableName(), args);

                processedRecords++;
            }
            return processedRecords;
        } catch (SQLException e) {
            SQLConnectionHelper.handleSQLException(e);
            throw new ProcessFailedException("SQL Exception thrown when processing table " + getTableName(), e);
        } finally {
            SQLConnectionHelper.closeConnection(conn);
        }
    }

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
     */
    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

}
