package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.RRF_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * RiskReferral Table Handler This class invokes RRF_L BRAINS token and saves
 * the results to the RiskReferral table
 * 
 * @see AbstractTableHandler
 * @author LEES
 *
 */

/*
 * DATE        	REFERENCE   WHO  	VERSION  COMMENTS 
 * ---------   	---------   ---  	-------  ------- 
 * 18DEC13     	WP654		LEES 	1      	 Created
 * 03May16		WP711		CLAREP	1a		 Copied to WP711 branch
 * 14Jun17      -           PLC              Change so only records with ReferCode > 0 are processed
 */

public class RiskReferralTableHandler extends AbstractTableHandler {

    private static final String TABLE_NAME = "RiskReferral";

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#populateStagingTable()
     */
    @Override
    public int populateStagingTable() throws ProcessFailedException {
        int processedRecords = 0;

        RRF_L token = new RRF_L();
        List<? extends Map<String, Object>> riskReferrals = executeToken(token);

        SQLConnection conn = SQLConnectionHelper.getConnection();

        try {
            Map<String, Object> args = new HashMap<String, Object>();
            for (Map<String, Object> record : riskReferrals) {
                if (referCodeGreaterThanZero(record)){
                    args.put("country", getParameter(Constants.PARAMETER_COUNTRY));
                    args.put("referCode", record.get("REFER_CODE"));
                    args.put("referContact", record.get("REFER_CONTACT"));
                    args.put("referLocation", record.get("REFER_LOCATION"));
                    args.put("telephoneNumber", record.get("TELEPHONE_NUMBER"));
                    args.put("hostname", record.get("HOSTNAME"));
                    args.put("backupReferCode1", record.get("BACKUP_REFER_CODE_1"));
                    args.put("backupReferCode2", record.get("BACKUP_REFER_CODE_2"));
                    args.put("backupReferCode3", record.get("BACKUP_REFER_CODE_3"));
                    args.put("managerReferCode", record.get("MANAGER_REFER_CODE"));
                    args.put("systemType", record.get("SYSTEM_TYPE"));
                    args.put("userId", record.get("USER_ID"));
                    args.put("telephoneNumber", record.get("TELEPHONE_NUMBER"));
                    args.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));

                    conn.executeUpdate("ext_populateStaging" + getTableName(), args);
                    processedRecords++;
                }
            }
            return processedRecords;
        } catch (SQLException e) {
            SQLConnectionHelper.handleSQLException(e);
            throw new ProcessFailedException("SQL Exception thrown when processing table " + getTableName(), e);
        } finally {
            SQLConnectionHelper.closeConnection(conn);
        }
    }

    private boolean referCodeGreaterThanZero(Map<String, Object> record) {
        return Integer.parseInt(record.get("REFER_CODE").toString()) > 0;
    }

    /*
     * (non-Javadoc)
     * @see com.barclays.middleware.handler.AbstractTableHandler#getTableName()
     */
    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

}
