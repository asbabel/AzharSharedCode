package com.barclays.middleware.handler;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.barclays.generic.data.SQLConnection;
import com.barclays.middleware.brains.TRC_L;
import com.barclays.middleware.exception.ProcessFailedException;
import com.barclays.middleware.util.Constants;
import com.barclays.middleware.util.SQLConnectionHelper;

/**
 * Transaction Code Table Handler. This class invokes TRC_L token and saves the
 * results from Brains to MWDB.TransactionCode table
 * 
 * @see AbstractTableHandler
 * 
 */

/*
 * DATE        REFERENCE   		WHO  		VERSION  	COMMENTS 
 * ---------   ---------   		---  		-------  	------- 
 * 26Nov2014   WP680BNET    	Prachi		1a			Created
 */

public class TransactionCodeTableHandler extends AbstractTableHandler {

    private static final String TABLE_NAME = "TransactionCode";

    @Override
    public int populateStagingTable() throws ProcessFailedException {
        TRC_L token = new TRC_L();
        token.setVersionNumber(1);
        int rowCount = 0;
        SQLConnection conn = SQLConnectionHelper.getConnection();
        List<? extends Map<String, Object>> accountTypeCurrencyConf = executeToken(token);
        HashMap<String, Object> argsMap = new HashMap<String, Object>();
        for (Map<String, Object> accountTypeCurrency : accountTypeCurrencyConf) {
            argsMap.clear();
            argsMap.put("country", getParameter(Constants.PARAMETER_COUNTRY));
            argsMap.put("offshoreInd", getParameter(Constants.PARAMETER_OFFSHORE));
            argsMap.put("transactionCode", accountTypeCurrency.get("TRANSACTION_CODE"));
            argsMap.put("debitsAllowedInd", accountTypeCurrency.get("DEBITS_ALLOWED_IND"));
            argsMap.put("creditsAllowedInd", accountTypeCurrency.get("CREDITS_ALLOWED_IND"));
            argsMap.put("narrativeInd", accountTypeCurrency.get("NARRATIVE_IND"));
            argsMap.put("valueDateInd", accountTypeCurrency.get("VALUE_DATE_IND"));
            argsMap.put("unclearedEffectInd", accountTypeCurrency.get("UNCLEARED_EFFECT_IND"));
            argsMap.put("serialNumberInd", accountTypeCurrency.get("SERIAL_NUMBER_IND"));
            argsMap.put("ledgerFeeChargeInd", accountTypeCurrency.get("LEDGER_FEE_CHARGE_IND"));
            argsMap.put("unclearedPeriodCode", accountTypeCurrency.get("UNCLEARED_PERIOD_CODE"));
            argsMap.put("standardNarrative", accountTypeCurrency.get("STANDARD_NARRATIVE"));
            argsMap.put("crCode", accountTypeCurrency.get("CR_CODE"));
            argsMap.put("drCode", accountTypeCurrency.get("DR_CODE"));
            argsMap.put("compoundInd", accountTypeCurrency.get("COMPOUND_IND"));
            argsMap.put("ledgerInd", accountTypeCurrency.get("LEDGER_IND"));
            argsMap.put("intrstInd", accountTypeCurrency.get("INTRST_IND"));
            argsMap.put("prvstmInd", accountTypeCurrency.get("PRVSTM_IND"));
            argsMap.put("stpchkInd", accountTypeCurrency.get("STPCHK_IND"));
            argsMap.put("brbalInd", accountTypeCurrency.get("BRBAL_IND"));
            argsMap.put("socorrInd", accountTypeCurrency.get("SOCORR_IND"));
            argsMap.put("chequeInd", accountTypeCurrency.get("CHEQUE_IND"));
            argsMap.put("stfsalInd", accountTypeCurrency.get("STFSAL_IND"));
            argsMap.put("closInd", accountTypeCurrency.get("CLOS_IND"));
            argsMap.put("takeonInd", accountTypeCurrency.get("TAKEON_IND"));
            argsMap.put("directMemoInd", accountTypeCurrency.get("DIRECT_MEMO_IND"));
            argsMap.put("manPostInd", accountTypeCurrency.get("MAN_POST_IND"));
            argsMap.put("bulkInd", accountTypeCurrency.get("BULK_IND"));
            argsMap.put("corrInd", accountTypeCurrency.get("CORR_IND"));
            argsMap.put("ecorrInd", accountTypeCurrency.get("ECORR_IND"));
            argsMap.put("returnInd", accountTypeCurrency.get("RETURN_IND"));
            argsMap.put("mixcrInd", accountTypeCurrency.get("MIXCR_IND"));
            argsMap.put("standOrdInd", accountTypeCurrency.get("STAND_ORD_IND"));

            try {
                conn.executeUpdate("ext_populateStaging" + getTableName(), argsMap);
            } catch (SQLException e) {
                SQLConnectionHelper.handleSQLException(e);
                throw new ProcessFailedException("SQL Exception thrown out when processing table " + getTableName(), e);
            }
            rowCount++;
        }
        SQLConnectionHelper.closeConnection(conn);
        return rowCount;
    }

    @Override
    protected String getTableName() {
        return TABLE_NAME;
    }

}
