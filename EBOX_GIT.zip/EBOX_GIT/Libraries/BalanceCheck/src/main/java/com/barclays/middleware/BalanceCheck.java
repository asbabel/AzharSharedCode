/*
 * BalanceCheck.java
 *
 * Created on 29 March 2011, 10:00
 */

package com.barclays.middleware;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

/**
 * IM100988089 - A class used by the BankSvcRqSplitter map to help ensure that
 * balance checks are handled serially
 * 
 * @author HITCHCOCKP
 */
/*
 * DATE        REFERENCE    WHO   VERSION  COMMENTS
 * -------     ---------    ---   -------  -----------------------------------------
 * 21/04/2011  IM100988089  PHH   1.0      Created
 * 09/09/2016  WP711        PHH   1.1      Resolved Sonar issues and changed the 
 *                                         default log location
 */
public class BalanceCheck {
    public static final int CONSTRUCTOR_PARAM_COUNT = 2;
    public static final int DEFAULT_WAIT_TIME = 10;
    public static final int SLEEP_TIME = 1000;
    public static final String NEW_LINE = "\r\n";

    private String mapID = null;
    private String accountDetails = null;

    // Location for storing the holding files
    private String holdPath = null;
    // Location where the logs are stored if debugging is enabled
    private String logPath = null;
    // Path to log file (set to default value)
    private String logFullPath =
            "D:\\Applications\\ITX\\Logs\\BalanceCheck.log";

    // Holds whether the balance check control is enabled or not
    private boolean enabled = true;
    // Set to true if debug output should be logged
    private boolean debug = false;
    private int maxWaitTime = DEFAULT_WAIT_TIME;

    // Used to output text to a log when debugging is enabled
    private OutputStreamWriter logFileWriter = null;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    /**
     * Constructor method - Loads the required properties from the property file
     * and sets up initial variables
     *
     * @param ID of the map instance that called this method
     * @param Account details containing the country and originator
     * branch/account
     *
     */
    public BalanceCheck(String mapID, String accountDetails) {
        this.mapID = mapID;
        this.accountDetails = accountDetails;

        loadProperties();

        enabled = "true".equalsIgnoreCase(getProperty("enabled", "true"));
        maxWaitTime = getProperty("maximum_wait", maxWaitTime);
        holdPath = getProperty("hold_path", holdPath);
        logPath = getProperty("log_path", logPath);
        debug = "true".equalsIgnoreCase(getProperty("debug", "false"));

        if (logPath == null || "".equals(logPath) || holdPath == null
                || "".equals(holdPath)) {
            enabled = false;
            try {
                appendErrorToLog("Failed to load properties file");
            } finally {
                closeLog();
            }
        } else {
            logFullPath = logPath + "\\balancecheck_" + this.mapID + ".log";
        }
    }

    /**
     * Tries to create the given file
     *
     * @return true if the file was successfully created, otherwise false.
     */
    private boolean createFile(File file) {
        boolean createdFile = false;
        try {
            createdFile = file.createNewFile();
        } catch (IOException ioe) { // NOSONAR
            appendErrorToLog(
                    "Failed to create holding file, will continue to try");
            appendErrorToLog(Arrays.toString(ioe.getStackTrace()));
        }
        return createdFile;
    }

    /**
     * Tries to create a holding file for the account details given (waits up to
     * MAX_SECONDS)
     *
     * @throws IOException
     */
    public void start() {
        if (enabled) {
            int i = 0;
            try {
                File holdFile = new File(
                        holdPath + "\\balancecheck_hold_" + accountDetails);

                while (!createFile(holdFile) && i++ < maxWaitTime) {
                    sleep(i);
                }
                if (i < maxWaitTime) {
                    appendToLog(
                            "Created hold file " + holdFile.getAbsolutePath());
                } else {
                    appendErrorToLog(
                            "Waited for maximum time, couldn't create hold file "
                                    + holdFile.getAbsolutePath());
                }
            } catch (Exception e) { // NOSONAR
                appendErrorToLog(e.getMessage());
                appendErrorToLog(Arrays.toString(e.getStackTrace()));
            } finally {
                closeLog();
            }
        }
    }

    /**
     * Deletes the matching holding file if found for the account details
     *
     * @param ID of the map instance that called this method
     * @param Account details containing the country and originator
     * branch/account
     * 
     * @throws IOException
     */
    public void finish() {
        if (enabled) {
            try {
                File holdFile = new File(
                        holdPath + "\\balancecheck_hold_" + accountDetails);

                if (holdFile.exists()) {
                    holdFile.delete();
                    appendToLog("Deleted " + holdFile.getAbsolutePath());
                } else {
                    appendToLog("Couldn't delete " + holdFile.getAbsolutePath()
                            + " as it doesn't exist");
                }
            } catch (Exception e) { // NOSONAR
                appendErrorToLog(e.getMessage());
                appendErrorToLog(Arrays.toString(e.getStackTrace()));
            } finally {
                closeLog();
            }
        }
    }

    /**
     * Opens a log file ready for output
     *
     * @param text to output
     * 
     * @throws IOException
     */
    private void openLog(String fileName) throws IOException {
        if (logFileWriter == null) {
            logFileWriter =
                    new OutputStreamWriter(new FileOutputStream(fileName, true),
                            StandardCharsets.UTF_8);
        }
    }

    /**
     * Appends output to the current log file
     *
     * @param text to output
     * 
     * @throws IOException
     */
    private void appendErrorToLog(String text) {
        Date now = new Date();
        try {
            if (logFileWriter == null) {
                openLog(logFullPath);
            }
            logFileWriter.write(
                    sdf.format(now) + " : ERROR : " + text + NEW_LINE);
        } catch (IOException e) { // NOSONAR
        }
    }

    /**
     * Appends output to the current log file
     *
     * @param text to output
     * 
     * @throws IOException
     */
    private void appendToLog(String text) {
        Date now = new Date();
        if (debug) {
            try {
                if (logFileWriter == null) {
                    openLog(logFullPath);
                }
                logFileWriter.write(sdf.format(now) + " : " + text + NEW_LINE);
            } catch (IOException e) { // NOSONAR
            }
        }
    }

    /**
     * Closes the log file if it is open
     *
     * @throws IOException
     */
    private void closeLog() {
        if (logFileWriter != null) {
            try {
                logFileWriter.close();
                logFileWriter = null;
            } catch (IOException ioe) { // NOSONAR
            }
        }
    }

    /**
     * Sleeps for the required SLEEP_TIME after outputting the sleeping attempt
     * number.
     * 
     * @param attempt
     */
    private void sleep(int attempt) {
        try {
            appendToLog("Sleeping " + attempt);
            // sleep for 1 second
            Thread.sleep(SLEEP_TIME);
        } catch (InterruptedException e) { // NOSONAR
        }
    }

    /**
     * Load configuration properties
     *
     * @param pathName
     * 
     * @return Properties
     * 
     * @throws FileNotFoundException
     * @throws IOException
     */
    private static void loadProperties() {
        if (System.getProperty("hold_path") == null) {
            try {
                System.getProperties().load(new java.io.FileInputStream(
                        System.getProperty("balanceCheck.properties")));
            } catch (IOException ioe) { // NOSONAR
            }
        }
    }

    /**
     * Returns the selected property value if set, otherwise returns the default
     * value provided
     * 
     * @param property name
     * @param defaultValue
     * @return property value if set or the default value provided
     */
    private String getProperty(String name, String defaultValue) {
        String value = System.getProperty(name);
        return (value == null || "".equals(value) ? defaultValue : value);
    }

    /**
     * Returns the selected property value if set, otherwise returns the default
     * value provided
     * 
     * @param property name
     * @param defaultValue
     * @return property value if set or the default value provided
     */
    private int getProperty(String name, int defaultValue) {
        int number;
        try {
            number = Integer.valueOf(System.getProperty(name));
        } catch (NumberFormatException e) {
            number = defaultValue;
        }
        return number;
    }

    /**
     * Main method (only used for testing)
     * 
     * @param args
     */
    public static void main(String[] args) {
        if (args.length < CONSTRUCTOR_PARAM_COUNT) {
            System.out.println("Usage: main <mapId> <accountDetails>"); // NOSONAR
            System.exit(1);
        }
        BalanceCheck bc = new BalanceCheck(args[0], args[1]);
        bc.start();
        bc.finish();
    }
}
