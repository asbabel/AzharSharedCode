/*
 * This code is based on the apache code but changed to allow multi-threaded authentication
 * 
 * */

/*
 * Copyright 1999-2002,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.barclays.generic.realm;

import static org.jboss.web.CatalinaMessages.MESSAGES;

import java.io.IOException;
import java.security.Principal;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.CompositeName;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.ServiceUnavailableException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.realm.GenericPrincipal;
import org.apache.catalina.realm.RealmBase;
import org.apache.catalina.util.Base64;
import org.apache.tomcat.util.buf.ByteChunk;
import org.apache.tomcat.util.buf.CharChunk;
import org.jboss.as.web.security.JBossGenericPrincipal;

import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.kerberos.BorrowPoolConnection;
import com.barclays.generic.kerberos.ContextGetAttributes;
import com.barclays.generic.kerberos.ContextSearch;
import com.barclays.generic.kerberos.KerberosConnection;
import com.barclays.generic.pool.LdapPool;
/**
 * Own version of JNDIRealm class so authorise method is no longer synchronised
 * Was going to extend but have issues with User class if not in same package as 
 * base class
 * 
 * Changed so all connections use Kerberos
 * @author  EARLEB
 **/
/*
 * DATE     REFERENCE   WHO   	VERSION  COMMENTS
 * -------  ---------   ---   	-------  ---------------------------------------------------
 * 06Oct06  -           EARLB   1.0a     Created
 * 27Aug08	PAT2379		SHINDED 2.0		 Changed to catch the error if 'change user password at next logon for the logged in user is set.
 * 09Feb10	PAT03027	SAMANTS	1a		 WP359 - Kerberos implementation for authentication
 * 07May10	PAT03027	EARLEB  		 Uses Kerberos for all connections
 * 										 Put logging back in (lost after tomcat six upgrade)
 * 										 Reflected the changes made to Tomcat 6 JndiRealm class into this
 * 22Aug11	Release003	EARLEB			 Clean up 
 * 30Jul15  eSat        MG              Replacing Tomcat dependencies with JBoss
 * 05Sep16  eSAT        RM              Updating LDAP pool to get instance rather than create a new instance. Re-introducing logging.
 * 17Jan2020 WP808      AK		        Domain and port Code Changes for AD Migration along with verifying  ebox security group access
 * 21Apr2021 ICP        ShwetaK		    ICP csc user login issue fix applied
 */

public class JNDIRealm extends RealmBase {
    
    private static final LoggerConnection logger = new LoggerConnection(
            JNDIRealm.class);

	protected static final String ERROR_PASSWORD_EXPIRED = "Password has expired";
	protected static final String LIVE = "live";
	protected static final String DEVELOPMENT = "development";
	protected static final String ERROR_CODE_PASSWORD_RESET = "data 773";
    protected static final String ERROR_CODE_PASSWORD_EXPIRED = "data 532";
    protected static final String LDAP_BIND_PORT = "636";
    protected static final String EBOX_DEV_ALL_USERS="CN=EBOX-DEV-ALL-USERS,OU=Security,OU=Groups,OU=OCORP Accounts,DC=ocorp,DC=dsarena,DC=com";
    protected static final String EBOX_PROD_ALL_USERS="CN=EBOX-PROD-ALL-USERS,OU=Security,OU=Groups,OU=CORP Accounts,DC=corp,DC=dsarena,DC=com";    
    // ----------------------------------------------------- Instance Variables

    private String errorType = null;
    /**
     *  The type of authentication to use
     */
    protected String authentication = null;

    /**
     * The Fallback connection username for the server we will contact.
     */
    protected String fallBackConnectionName = null;


    /**
     * The Fallback connection password for the server we will contact.
     */
    protected String fallBackConnectionPassword = null;


    /**
     * The FallBack connection URL for the server we will contact.
     */
    protected String fallBackConnectionURL = null;

    
    /**
     * The connection username for the server we will contact.
     */
    protected String connectionName = null;


    /**
     * The connection password for the server we will contact.
     */
    protected String connectionPassword = null;


    /**
     * The connection URL for the server we will contact.
     */
    protected String connectionURL = null;

    /**
     * The JNDI context factory used to acquire our InitialContext.  By
     * default, assumes use of an LDAP server using the standard JNDI LDAP
     * provider.
     */
    protected String contextFactory = "com.sun.jndi.ldap.LdapCtxFactory";


    /**
     * Descriptive information about this Realm implementation.
     */
    protected static final String info =
        "org.apache.catalina.realm.JNDIRealm/1.0";
    
    /**
     * Descriptive information about this Realm implementation.
     */
    protected static final String name = "JNDIRealm";


    /**
     * The protocol that will be used in the communication with the
     * directory server.
     */
    protected String protocol = null;


    /**
     * How should we handle referrals?  Microsoft Active Directory can't handle
     * the default case, so an application authenticating against AD must
     * set referrals to "follow".
     */
    protected String referrals = null;


    /**
     * The base element for user searches.
     */
    protected String userBase = "";


    /**
     * The message format used to search for a user, with "{0}" marking
     * the spot where the username goes.
     */
    protected String userSearch = null;


    /**
     * The MessageFormat object associated with the current
     * <code>userSearch</code>.
     */
    protected MessageFormat userSearchFormat = null;


    /**
     * Should we search the entire subtree for matching users?
     */
    protected boolean userSubtree = false;


    /**
     * The attribute name used to retrieve the user password.
     */
    protected String userPassword = null;


    /**
     * A string of LDAP user patterns or paths, ":"-separated
     * These will be used to form the distinguished name of a
     * user, with "{0}" marking the spot where the specified username
     * goes.
     * This is similar to userPattern, but allows for multiple searches
     * for a user.
     */
    protected String[] userPatternArray = null;


    /**
     * The message format used to form the distinguished name of a
     * user, with "{0}" marking the spot where the specified username
     * goes.
     */
    protected String userPattern = null;


    /**
     * An array of MessageFormat objects associated with the current
     * <code>userPatternArray</code>.
     */
    protected MessageFormat[] userPatternFormatArray = null;


    /**
     * The base element for role searches.
     */
    protected String roleBase = "";


    /**
     * The MessageFormat object associated with the current
     * <code>roleSearch</code>.
     */
    protected MessageFormat roleFormat = null;


    /**
     * The name of an attribute in the user's entry containing
     * roles for that user
     */
    protected String userRoleName = null;


    /**
     * The name of the attribute containing roles held elsewhere
     */
    protected String roleName = null;


    /**
     * The message format used to select roles for a user, with "{0}" marking
     * the spot where the distinguished name of the user goes.
     */
    protected String roleSearch = null;


    /**
     * Should we search the entire subtree for matching memberships?
     */
    protected boolean roleSubtree = false;

    /**
     * An alternate URL, to which, we should connect if connectionURL fails.
     */
    protected String alternateURL;

    /**
     * The number of connection attempts.  If greater than zero we use the
     * alternate url.
     */
    protected int connectionAttempt = 0;

    /**
     * The current user pattern to be used for lookup and binding of a user.
     */
    protected int curUserPattern = 0;
    
    /**
     * Holds the environment, developers currently can't use Kerberos.
     */
    protected String environment = LIVE;
    
    protected String connectionPrincipleName = null;
    
    protected LoginContext loginContext = null;
    
	/* * AD Migration changes Security Group For eBOX  */
    protected String eboxSecurityGroup=null;
    
    /* * ICP changes for allowing particular country users  */
    protected String allowedCountries=null;
    
    /**
     * a pool of connections to ldap 
     */
    protected LdapPool pool;
    
    /**
	 * @return the fallBackConnectionName
	 */
	public String getFallBackConnectionName() {
		return fallBackConnectionName;
	}

	/**
	 * @param fallBackConnectionName the fallBackConnectionName to set
	 */
	public void setFallBackConnectionName(String fallBackConnectionName) {
		this.fallBackConnectionName = fallBackConnectionName;
	}

	/**
	 * @return the fallBackConnectionPassword
	 */
	public String getFallBackConnectionPassword() {
		return fallBackConnectionPassword;
	}

	/**
	 * @param fallBackConnectionPassword the fallBackConnectionPassword to set
	 */
	public void setFallBackConnectionPassword(String fallBackConnectionPassword) {
		this.fallBackConnectionPassword = fallBackConnectionPassword;
	}

	/**
	 * @return the fallBackConnectionURL
	 */
	public String getFallBackConnectionURL() {
		return fallBackConnectionURL;
	}

	/**
	 * @param fallBackConnectionURL the fallBackConnectionURL to set
	 */
	public void setFallBackConnectionURL(String fallBackConnectionURL) {
		this.fallBackConnectionURL = fallBackConnectionURL;
	}

	/**
	 * @return the pool
	 */
	public LdapPool getPool() {
		return pool;
	}

	/**
	 * @param pool the pool to set
	 */
	public void setPool(LdapPool pool) {
		this.pool = pool;
	}

	/**
     * a pool of encrypted connections to ldap 
     */
    protected LdapPool kerberosPool;

    // ------------------------------------------------------------- Properties

    /**
     * Return the type of authentication to use.
     */
    public String getAuthentication() {

        return authentication;

    }

    /**
     * Set the type of authentication to use.
     *
     * @param authentication The authentication
     */
    public void setAuthentication(String authentication) {

        this.authentication = authentication;

    }

    /**
     * Return the connection username for this Realm.
     */
    public String getConnectionName() {

        return (this.connectionName);

    }


    /**
     * Set the connection username for this Realm.
     *
     * @param connectionName The new connection username
     */
    public void setConnectionName(String connectionName) {

        this.connectionName = connectionName;

    }


    /**
     * Return the connection password for this Realm.
     */
    public String getConnectionPassword() {

        return (this.connectionPassword);

    }


    /**
     * Set the connection password for this Realm.
     *
     * @param connectionPassword The new connection password
     */
    public void setConnectionPassword(String connectionPassword) {

        this.connectionPassword = connectionPassword;

    }


    /**
     * Return the connection URL for this Realm.
     */
    public String getConnectionURL() {

        return (this.connectionURL);

    }


    /**
     * Set the connection URL for this Realm.
     *
     * @param connectionURL The new connection URL
     */
    public void setConnectionURL(String connectionURL) {

        this.connectionURL = connectionURL;

    }


    /**
     * Return the JNDI context factory for this Realm.
     */
    public String getContextFactory() {

        return (this.contextFactory);

    }


    /**
     * Set the JNDI context factory for this Realm.
     *
     * @param contextFactory The new context factory
     */
    public void setContextFactory(String contextFactory) {

        this.contextFactory = contextFactory;

    }


    /**
     * Return the protocol to be used.
     */
    public String getProtocol() {

        return protocol;

    }

    /**
     * Set the protocol for this Realm.
     *
     * @param protocol The new protocol.
     */
    public void setProtocol(String protocol) {

        this.protocol = protocol;

    }


    /**
     * Returns the current settings for handling JNDI referrals.
     */
    public String getReferrals () {
        return referrals;
    }


    /**
     * How do we handle JNDI referrals? ignore, follow, or throw
     * (see javax.naming.Context.REFERRAL for more information).
     */
    public void setReferrals (String referrals) {
        this.referrals = referrals;
    }


    /**
     * Return the base element for user searches.
     */
    public String getUserBase() {

        return (this.userBase);

    }


    /**
     * Set the base element for user searches.
     *
     * @param userBase The new base element
     */
    public void setUserBase(String userBase) {

        this.userBase = userBase;

    }


    /**
     * Return the message format pattern for selecting users in this Realm.
     */
    public String getUserSearch() {

        return (this.userSearch);

    }


    /**
     * Set the message format pattern for selecting users in this Realm.
     *
     * @param userSearch The new user search pattern
     */
    public void setUserSearch(String userSearch) {

        this.userSearch = userSearch;
        if (userSearch == null)
            userSearchFormat = null;
        else
            userSearchFormat = new MessageFormat(userSearch);

    }


    /**
     * Return the "search subtree for users" flag.
     */
    public boolean getUserSubtree() {

        return (this.userSubtree);

    }


    /**
     * Set the "search subtree for users" flag.
     *
     * @param userSubtree The new search flag
     */
    public void setUserSubtree(boolean userSubtree) {

        this.userSubtree = userSubtree;

    }


    /**
     * Return the user role name attribute name for this Realm.
     */
    public String getUserRoleName() {

        return userRoleName;
    }


    /**
     * Set the user role name attribute name for this Realm.
     *
     * @param userRoleName The new userRole name attribute name
     */
    public void setUserRoleName(String userRoleName) {

        this.userRoleName = userRoleName;

    }


    /**
     * Return the base element for role searches.
     */
    public String getRoleBase() {

        return (this.roleBase);

    }


    /**
     * Set the base element for role searches.
     *
     * @param roleBase The new base element
     */
    public void setRoleBase(String roleBase) {

        this.roleBase = roleBase;

    }


    /**
     * Return the role name attribute name for this Realm.
     */
    public String getRoleName() {

        return (this.roleName);

    }


    /**
     * Set the role name attribute name for this Realm.
     *
     * @param roleName The new role name attribute name
     */
    public void setRoleName(String roleName) {

        this.roleName = roleName;

    }


    /**
     * Return the message format pattern for selecting roles in this Realm.
     */
    public String getRoleSearch() {

        return (this.roleSearch);

    }


    /**
     * Set the message format pattern for selecting roles in this Realm.
     *
     * @param roleSearch The new role search pattern
     */
    public void setRoleSearch(String roleSearch) {

        this.roleSearch = roleSearch;
        if (roleSearch == null)
            roleFormat = null;
        else
            roleFormat = new MessageFormat(roleSearch);

    }


    /**
     * Return the "search subtree for roles" flag.
     */
    public boolean getRoleSubtree() {

        return (this.roleSubtree);

    }


    /**
     * Set the "search subtree for roles" flag.
     *
     * @param roleSubtree The new search flag
     */
    public void setRoleSubtree(boolean roleSubtree) {

        this.roleSubtree = roleSubtree;

    }


    /**
     * Return the password attribute used to retrieve the user password.
     */
    public String getUserPassword() {

        return (this.userPassword);

    }


    /**
     * Set the password attribute used to retrieve the user password.
     *
     * @param userPassword The new password attribute
     */
    public void setUserPassword(String userPassword) {

        this.userPassword = userPassword;

    }


    /**
     * Return the message format pattern for selecting users in this Realm.
     */
    public String getUserPattern() {

        return (this.userPattern);

    }


    /**
     * Set the message format pattern for selecting users in this Realm.
     * This may be one simple pattern, or multiple patterns to be tried,
     * separated by parentheses. (for example, either "cn={0}", or
     * "(cn={0})(cn={0},o=myorg)" Full LDAP search strings are also supported,
     * but only the "OR", "|" syntax, so "(|(cn={0})(cn={0},o=myorg))" is
     * also valid. Complex search strings with &, etc are NOT supported.
     *
     * @param userPattern The new user pattern
     */
    public void setUserPattern(String userPattern) {

        this.userPattern = userPattern;
        if (userPattern == null)
            userPatternArray = null;
        else {
            userPatternArray = parseUserPatternString(userPattern);
            int len = this.userPatternArray.length;
            userPatternFormatArray = new MessageFormat[len];
            for (int i=0; i < len; i++) {
                userPatternFormatArray[i] =
                    new MessageFormat(userPatternArray[i]);
            }
        }
    }


    /**
     * Getter for property alternateURL.
     *
     * @return Value of property alternateURL.
     */
    public String getAlternateURL() {

        return this.alternateURL;

    }


    /**
     * Setter for property alternateURL.
     *
     * @param alternateURL New value of property alternateURL.
     */
    public void setAlternateURL(String alternateURL) {

        this.alternateURL = alternateURL;

    }
	
	public String getEboxSecurityGroup() {
		return eboxSecurityGroup;
	}

	public void setEboxSecurityGroup(String eboxSecurityGroup) {
		this.eboxSecurityGroup = eboxSecurityGroup;
	}
	
	public String getAllowedCountries() {
		return allowedCountries;
	}

	public void setAllowedCountries(String allowedCountries) {
		this.allowedCountries = allowedCountries;
	}

    // ---------------------------------------------------------- Realm Methods


    /**
     * Return the Principal associated with the specified username and
     * credentials, if there is one; otherwise return <code>null</code>.
     *
     * If there are any errors with the JDBC connection, executing
     * the query or anything we return null (don't authenticate). This
     * event is also logged, and the connection will be closed so that
     * a subsequent request will automatically re-open it.
     *
     * @param username Username of the Principal to look up
     * @param credentials Password or other credentials to use in
     *  authenticating this username
     */
    public Principal authenticate(String username, String credentials) {
    	DirContext context = null;
        Principal principal = null;

        try {

            // Ensure that we have a directory context available
            context = open(username);

            // Occasionally the directory context will timeout.  Try one more
            // time before giving up.
            try {
            	// Authenticate the specified username if possible
                principal = authenticate(context, username, credentials);

            } catch (Exception e) {
                logger.warn("authentication failed, retrying", e);
                // close the connection so we know it will be reopened.
            	if (context != null)
            		close(context, username);
            	
            	// open a new directory context.
            	context = open(username);

            	// Try the authentication again.
            	principal = authenticate(context, username, credentials);
            	
            } 


            // Release this context
            release(context, username);

            // Return the authenticated Principal (if any)
            return (principal);

        } catch (Exception e) {

            // Log the problem for posterity
            logger.error("Inside Connection failed - ", e);
       	
            // Close the connection 
            if (context != null)
                close(context, username);

            // Return "not authenticated" for this request
            return (null);

        }

    }


    // -------------------------------------------------------- Package Methods


    // ------------------------------------------------------ Protected Methods


    /**
     * Return the Principal associated with the specified username and
     * credentials, if there is one; otherwise return <code>null</code>.
     *
     * @param context The directory context
     * @param username Username of the Principal to look up
     * @param credentials Password or other credentials to use in
     *  authenticating this username
     *
     * @exception NamingException if a directory server error occurs
     */
    public Principal authenticate(DirContext context,
                                               String username,
                                               String credentials)
        throws NamingException {
        if (username == null || username.equals("")
            || credentials == null || credentials.equals(""))
            return (null);

        // Retrieve user information
        User user = getUser(context, username);
        
        if (user == null)
            return (null);
        
        // Check the user's credentials
        if (!checkCredentials(context, user, credentials))
            return (null);
        
        // Search for additional roles
        List<String> roles = getRoles(context, user);
        
        // Create and return a suitable Principal for this user
        return (new JBossGenericPrincipal( this, username, credentials, roles));
    }


    /**
     * Return a User object containing information about the user
     * with the specified username, if found in the directory;
     * otherwise return <code>null</code>.
     *
     * If the <code>userPassword</code> configuration attribute is
     * specified, the value of that attribute is retrieved from the
     * user's directory entry. If the <code>userRoleName</code>
     * configuration attribute is specified, all values of that
     * attribute are retrieved from the directory entry.
     *
     * @param context The directory context
     * @param username Username to be looked up
     *
     * @exception NamingException if a directory server error occurs
     */
    protected User getUser(DirContext context, String username)
        throws NamingException {
        User user = null;

        // Get attributes to retrieve from user entry
        ArrayList<String> list = new ArrayList<String>();
        if (userPassword != null)
            list.add(userPassword);
        if (userRoleName != null)
            list.add(userRoleName);
        String[] attrIds = new String[list.size()];
        list.toArray(attrIds);

        // Use pattern or search for user entry
        if (userPatternFormatArray != null) {
            user = getUserByPattern(context, username, attrIds);
        } else {
            user = getUserBySearch(context, username, attrIds);
        }

        return user;
    }


    /**
     * Use the <code>UserPattern</code> configuration attribute to
     * locate the directory entry for the user with the specified
     * username and return a User object; otherwise return
     * <code>null</code>.
     *
     * @param context The directory context
     * @param username The username
     * @param attrIds String[]containing names of attributes to
     * retrieve.
     *
     * @exception NamingException if a directory server error occurs
     */
    protected User getUserByPattern(DirContext context,
                                              String username,
                                              String[] attrIds)
        throws NamingException {

    	if (username == null || userPatternFormatArray[curUserPattern] == null)
            return (null);

        // Form the dn from the user pattern
        String dn = userPatternFormatArray[curUserPattern].format(new String[] {username.substring(0,username.indexOf("@")).toUpperCase()});

        // Get required attributes from user entry
        Attributes attrs = null;
        try {
            attrs = contextGetAttributes(context, dn, attrIds, username);
        } catch (NameNotFoundException e) {
            logger.error("Username not found", e);
            return (null);
        }
        if (attrs == null)
            return (null);

        // Retrieve value of userPassword
        String password = null;
        if (userPassword != null)
            password = getAttributeValue(userPassword, attrs);

        // Retrieve values of userRoleName attribute
        ArrayList<String> roles = null;
        if (userRoleName != null)
            roles = addAttributeValues(userRoleName, attrs, roles);
        if (isValidCscUser(roles))
			return new User(username, dn, password, roles);
		else {
			logger.info("User:" +username +" do not have access to eBOX Security Group.");
			return null;
		}
        
    }


    /**
     * Search the directory to return a User object containing
     * information about the user with the specified username, if
     * found in the directory; otherwise return <code>null</code>.
     *
     * @param context The directory context
     * @param username The username
     * @param attrIds String[]containing names of attributes to retrieve.
     *
     * @exception NamingException if a directory server error occurs
     */
    protected User getUserBySearch(DirContext context,
                                           String username,
                                           String[] attrIds)
        throws NamingException {
    	if (username == null || userSearchFormat == null)
            return (null);

        // Form the search filter
        String filter = userSearchFormat.format(new String[] {username.substring(0,username.indexOf("@")).toUpperCase()});

        // Set up the search controls
        SearchControls constraints = new SearchControls();

        if (userSubtree) {
            constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        }
        else {
            constraints.setSearchScope(SearchControls.ONELEVEL_SCOPE);
        }

        // Specify the attributes to be retrieved
        if (attrIds == null)
            attrIds = new String[0];
        constraints.setReturningAttributes(attrIds);
        
        NamingEnumeration<SearchResult> results = contextSearch(
        		context,
        		userBase,
        		filter, 
				constraints,
				username);
        
        // Fail if no entries found
        if (results == null || !results.hasMore()) {
        	logger.info("username " + username + " not found in AD Server against search Criteria.Returning JBoss Principle as null");
            return (null);
        }

        // Get result for the first entry found
        SearchResult result = results.next();

        // Check no further entries were found
        if (results.hasMore()) {
            logger.info("username " + username + " has multiple entries");
            return (null);
        }

        // Get the entry's distinguished name
        NameParser parser = context.getNameParser("");
        Name contextName = parser.parse(context.getNameInNamespace());
        Name baseName = parser.parse(userBase);

        // Bugzilla 32269
        Name entryName = parser.parse(new CompositeName(result.getName()).get(0));

        Name name = contextName.addAll(baseName);
        name = name.addAll(entryName);
        String dn = name.toString();
        
        logger.debug("  entry found for " + username + " with dn " + dn);

        // Get the entry's attributes
        Attributes attrs = result.getAttributes();
        if (attrs == null)
            return null;

        // Retrieve value of userPassword
        String password = null;
        if (userPassword != null)
            password = getAttributeValue(userPassword, attrs);

        // Retrieve values of userRoleName attribute
        ArrayList<String> roles = null;
        if (userRoleName != null)
            roles = addAttributeValues(userRoleName, attrs, roles);
        
        //Code changes for AD Migration. Verify Security Group for User 
       
		if (isValidCscUser(roles))
			return new User(username, dn, password, roles);
		else {
			if (errorType.equals("InvalidCountry"))
			logger.info("User:" +username +" does not belong to allowed country.");
			else
			logger.info("User:" +username +" do not have access to eBOX Security Group.");
			return null;
		}
		 
    }


    /**
     * Check whether the given User can be authenticated with the
     * given credentials. If the <code>userPassword</code>
     * configuration attribute is specified, the credentials
     * previously retrieved from the directory are compared explicitly
     * with those presented by the user. Otherwise the presented
     * credentials are checked by binding to the directory as the
     * user.
     *
     * @param user The User to be authenticated
     * @param credentials The credentials presented by the user
     *
     * @exception NamingException if a directory server error occurs
     */
    protected boolean checkCredentials(
    		DirContext context,
    		User user,
            String credentials)
    throws NamingException {

    	boolean validated = false;

    	if(useKerberos(user.username))
    	{
    		validated = kerberosAuthenticate(user, credentials);
    	}
    	else
    	{
    		// developers can't use Kerberos so do it the old way
    		validated = bindAsUser(context, user, credentials);
    	}
        
            if (validated) {
                logger.debug("jndiRealm.authenticateSuccess "+ user.username);
            } else {
                logger.debug("jndiRealm.authenticateFailure "+ user.username);
            }
        return (validated);
    }


    /**
     * Check credentials by binding to the directory as the user
     *
     * @param context The directory context
     * @param user The User to be authenticated
     * @param credentials Authentication credentials
     *
     * @exception NamingException if a directory server error occurs
     */
    protected boolean bindAsUser(
    		 DirContext context,
             User user,
             String credentials)
    throws NamingException 
    {
    	if (credentials == null || user == null)
            return (false);
        String dn = user.dn;
        if (dn == null)
            return (false);
        // Validate the credentials specified by the user
        	logger.debug("validating credentials by binding as the user");
       
        // changed to instantiate own connection to LDAP to bind with
        // which are pooled
        // try to login as this user, to verify password
        // reuse existing connection just make sure set user name 
        // and password back to the default at the end
        DirContext bindCtx = null;
        try{
        	bindCtx = pool.borrowObject(LDAP_BIND_PORT);
        }
        catch (Exception e){
            logger.error("bindAsUser method failed - ", e);
        	// wrap up the error
         	NamingException ex = new NamingException(
         			"Error borrowing connection from pool.");
         	ex.setRootCause(e);
         	throw ex;
        }
        
        boolean validated = false;
        Object oldUser = null;
        Object oldPassword = null;
        try{
 	        oldUser = bindCtx.removeFromEnvironment(
 	        		Context.SECURITY_PRINCIPAL);
 	        oldPassword = bindCtx.removeFromEnvironment(
 	        		Context.SECURITY_CREDENTIALS);
 	        bindCtx.addToEnvironment(Context.SECURITY_PRINCIPAL, dn);
 	        bindCtx.addToEnvironment(Context.SECURITY_CREDENTIALS, credentials);
 	        try {
 	        	// test the connection
 	        	contextGetAttributes(bindCtx, "", null, user.username);
 	        	validated = true;
 	        }
 	        catch (AuthenticationException e) {	        		        	
 	        	if(e.getMessage().contains(ERROR_CODE_PASSWORD_RESET) || 
 	        			e.getMessage().contains(ERROR_CODE_PASSWORD_EXPIRED)){
 	        		validated = true;
 	        	}
 	        	logger.error("Inside AuthenticationFailed:",e);
 	        	logger.debug("  bind attempt failed");
       }
        }
        finally{
        	// return the connection to how we found it
        	if(oldUser != null) {
        		bindCtx.addToEnvironment(Context.SECURITY_PRINCIPAL, oldUser);
        	}
        	if(oldPassword != null) {
        		bindCtx.addToEnvironment(Context.SECURITY_CREDENTIALS, oldPassword);
        	}
        	
         	try{
         		pool.returnObject(LDAP_BIND_PORT, bindCtx);
         	} 
         	catch(Exception e){
         	    logger.error("Error returning connection to the pool", e);
        	}
        }
        
        return (validated);
    }
     
    /**
     * Authenticates the user with Kerberos
     * 
     * @param user
     * @param credentials
     * @return true if a valid user or password expired, false otherwise
     */
    private boolean kerberosAuthenticate(User user, String credentials) {
    	boolean validated = false;
    	try {
    		String username = user.username.substring(0, user.username.indexOf("@") + 1) +
    				user.username.substring(user.username.indexOf("@") + 1).toUpperCase();
        	LoginContext context = KerberosConnection.authenticate(
        			username, 
        			credentials);
        	context.logout();
        	validated = true;
        	
        } 
    	catch (LoginException e) {
    		logger.error("Login Failed", e);
			if (e.getMessage().contains(ERROR_PASSWORD_EXPIRED)) {
				validated = true;
			}
		}
    	
		return validated;
	}

	/**
     * Check whether the credentials presented by the user match those
     * retrieved from the directory.
     *
     * @param context The directory context
     * @param info The User to be authenticated
     * @param credentials Authentication credentials
     *
     * @exception NamingException if a directory server error occurs
     */
    protected boolean compareCredentials(DirContext context,
            User info,
            String credentials)
    throws NamingException {

    	if (info == null || credentials == null)
    		return (false);

    	String password = info.password;
    	if (password == null)
    		return (false);

    		logger.debug(" validating credentials");

    	boolean validated = false;
    	if (hasMessageDigest()) {
    		// iPlanet support if the values starts with {SHA1}
    		// The string is in a format compatible with Base64.encode not
    		// the Hex encoding of the parent class.
    		if (password.startsWith("{SHA}")) {
    			/* sync since super.digest() does this same thing */
    			synchronized (this) {
    				password = password.substring(5);
    				md.reset();
    				md.update(credentials.getBytes());
    				String digestedPassword =
    					new String(Base64.encode(md.digest()));
    				validated = password.equals(digestedPassword);
    			}
    		} else if (password.startsWith("{SSHA}")) {
    			// Bugzilla 32938
    			/* sync since super.digest() does this same thing */
    			synchronized (this) {
    				password = password.substring(6);

    				md.reset();
    				md.update(credentials.getBytes());

    				// Decode stored password.
    				ByteChunk pwbc = new ByteChunk(password.length());
    				try {
    					pwbc.append(password.getBytes(), 0, password.length());
    				} catch (IOException e) {
    					// Should never happen
    					logger.error("Could not append password bytes to chunk: ", e);
    				}

    				CharChunk decoded = new CharChunk();
    				Base64.decode(pwbc, decoded);
    				char[] pwarray = decoded.getBuffer();

    				// Split decoded password into hash and salt.
    				final int saltpos = 20;
    				byte[] hash = new byte[saltpos];
    				for (int i=0; i< hash.length; i++) {
    					hash[i] = (byte) pwarray[i];
    				}

    				byte[] salt = new byte[pwarray.length - saltpos];
    				for (int i=0; i< salt.length; i++)
    					salt[i] = (byte)pwarray[i+saltpos];

    				md.update(salt);
    				byte[] dp = md.digest();

    				validated = Arrays.equals(dp, hash);
    			} // End synchronized(this) block
    		} else {
    			// Hex hashes should be compared case-insensitive
    			validated = (digest(credentials).equalsIgnoreCase(password));
    		}
    	} else
    		validated = (digest(credentials).equals(password));
    	return (validated);

    }

    /**
     * Return a List of roles associated with the given User.  Any
     * roles present in the user's directory entry are supplemented by
     * a directory search. If no roles are associated with this user,
     * a zero-length List is returned.
     *
     * @param context The directory context we are searching
     * @param user The User to be checked
     *
     * @exception NamingException if a directory server error occurs
     */
    protected List<String> getRoles(DirContext context, User user)
        throws NamingException {

        if (user == null)
            return (null);

        String dn = user.dn;
        String username = user.username;

        if (dn == null || username == null)
            return (null);
        
        logger.debug("  getRoles(" + dn + ")");
    
        // Start with roles retrieved from the user entry
        ArrayList<String> list = user.roles;
        if (list == null) {
            list = new ArrayList<String>();
        }

        // Are we configured to do role searches?
        if ((roleFormat == null) || (roleName == null))
            return (list);

        // Set up parameters for an appropriate search
        String filter = roleFormat.format(new String[] { doRFC2254Encoding(dn), username });
        SearchControls controls = new SearchControls();
        if (roleSubtree)
            controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        else
            controls.setSearchScope(SearchControls.ONELEVEL_SCOPE);
        controls.setReturningAttributes(new String[] {roleName});
        
        NamingEnumeration<SearchResult> results = contextSearch(
        		context,
        		userBase,
				filter,
				controls,
				user.username);
        
        if (results == null)
            return (list);  // Should never happen, but just in case ...
        while (results.hasMore()) {
            SearchResult result = results.next();
            Attributes attrs = result.getAttributes();
            if (attrs == null)
                continue;
            list = addAttributeValues(roleName, attrs, list);
        }
        
        //re-adding useful debugging information just in case. 
        if (list != null) {
            logger.debug("  Returning " + list.size() + " roles");
            for (int i=0; i<list.size(); i++)
                logger.debug(  "  Found role " + list.get(i));
            } else {
                logger.debug("  getRoles about to return null ");
            }
        
        return (list);
    }


    /**
     * Return a String representing the value of the specified attribute.
     *
     * @param attrId Attribute name
     * @param attrs Attributes containing the required value
     *
     * @exception NamingException if a directory server error occurs
     */
    private String getAttributeValue(String attrId, Attributes attrs)
        throws NamingException {
        
        logger.debug("  retrieving attribute " + attrId);

        if (attrId == null || attrs == null)
            return null;

        Attribute attr = attrs.get(attrId);
        if (attr == null)
            return (null);
        Object value = attr.get();
        if (value == null)
            return (null);
        String valueString = null;
        if (value instanceof byte[])
            valueString = new String((byte[]) value);
        else
            valueString = value.toString();

        return valueString;
    }



    /**
     * Add values of a specified attribute to a list
     *
     * @param attrId Attribute name
     * @param attrs Attributes containing the new values
     * @param values ArrayList containing values found so far
     *
     * @exception NamingException if a directory server error occurs
     */
    private ArrayList<String> addAttributeValues(String attrId,
                                         Attributes attrs,
                                         ArrayList<String> values)
        throws NamingException{
        
        logger.debug("  retrieving values for attribute " + attrId);
        if (attrId == null || attrs == null)
            return values;
        if (values == null)
            values = new ArrayList<String>();
        Attribute attr = attrs.get(attrId);
        if (attr == null)
            return (values);
        NamingEnumeration<?> e = attr.getAll();
        while(e.hasMore()) {
            String value = (String)e.next();
            values.add(value);
        }
        return values;
    }


    /**
     * Close any open connection to the directory server for this Realm.
     *
     * @param context The directory context to be closed
     */
    protected void close(DirContext context, String username) {

        // Do nothing if there is no opened connection
        if (context == null)
            return;

        // Close our opened connection
        try {
            logger.debug("Return connection to pool.");
            if (useKerberos(username)) {
            	kerberosPool.returnObject("default", context);
            }
            else {
            	pool.returnObject("default", context);
            }
        } catch (Exception e) {
            logger.error("Error returning socket connnection", e);
        }
    }


    /**
     * Return a short name for this Realm implementation.
     */
    protected String getName() {

        return (name);

    }

    /**
     * Return the password associated with the given principal's user name.
     */
    protected String getPassword(String username) {

        return (null);

    }

    /**
     * Return the Principal associated with the given user name.
     */
    protected Principal getPrincipal(String username) {

        DirContext context = null;
        Principal principal = null;

        try {

            // Ensure that we have a directory context available
            context = open(username);

            // Occasionally the directory context will timeout.  Try one more
            // time before giving up.
            try {

                // Authenticate the specified username if possible
                principal = getPrincipal(context, username);

            } catch (CommunicationException e) {
              
                // log the exception so we know it's there.
                logger.warn("Unable to communicate, retrying", e);

                // close the connection so we know it will be reopened.
                if (context != null)
                    close(context, username);

                // open a new directory context.
                context = open(username);

                // Try the authentication again.
                principal = getPrincipal(context, username);

            } catch (ServiceUnavailableException e) {
                
                logger.warn("Service Unavailable, retrying", e);

                // close the connection so we know it will be reopened.
                if (context != null)
                    close(context, username);

                // open a new directory context.
                context = open(username);

                // Try the authentication again.
                principal = getPrincipal(context, username);

            }


            // Release this context
            release(context, username);

            // Return the authenticated Principal (if any)
            return (principal);

        } catch (Exception e) {
            logger.info("Unable to return authenticated Principal - " + e.getMessage());
            logger.error("Unable to return authenticated Principal", e);

            // Close the connection 
            if (context != null)
                close(context, username);

            // Return "not authenticated" for this request
            return (null);
        }
    }


    /**
     * Return the Principal associated with the given user name.
     */
    protected synchronized Principal getPrincipal(DirContext context,
                                                  String username)
        throws NamingException {
        
        User user = getUser(context, username);
        
        return new GenericPrincipal(this,user.username, user.password ,
                getRoles(context, user));
    }



    /**
     * Open a pooled connection and return a connection to the configured
     * directory server for this Realm.
     *
     * @exception NamingException if a directory server error occurs
     */
    protected DirContext open(String username) throws Exception {
    	
    	// pooling negates the alternate url
    	// we could setup up a second pool but we would need to keep 
    	// track of which pool the connection came from
    	// as we don't use the alternate url, I haven't done this
    	DirContext context = null;
    	try {
    		context = borrowContext(username);
    	}
    	catch (AuthenticationException e) {
    	    logger.info("AuthenticationException - " + e.getMessage());
    	    logger.warn("Failed to borrow Object. Logging back in and retrying", e);
    	    
    	 // If Kerberos ticket times out then borrowing an object will fail 
            // retry once after logging back in
    		loginContext = KerberosConnection.authenticate(
    				connectionPrincipleName, 
	    			connectionPassword);
    		context = borrowContext(username);
    	}
    	
    	return context;
    }

    /**
	 * Wraps up making a call to pool.borrowObject with or with out Kerberos 
	 * @param context
	 * @param name
	 * @param filter
	 * @param constraints
	 * @return
	 * @throws NamingException
	 */
	private DirContext borrowContext(String username) throws Exception {
		DirContext context = null;
    	if (useKerberos(username)) {
    		BorrowPoolConnection operation = new BorrowPoolConnection(
    				kerberosPool,
    				"default",
    				containerLog);
    		context = Subject.doAs(loginContext.getSubject(), operation);
			if(operation.getException() != null) 
			{
				throw operation.getException();
			}
    	}
    	else
    	{
    		context = pool.borrowObject("default");
    	}
    	
        return context;
	}

	/**
	 * Based on the domain the user is in and the environment config determine
	 * if should use kerberos.
	 * Only root and managed domains have been configured for kerberos
	 * @param username
	 * @return
	 */
    private boolean useKerberos(String username) {
      
    	if (username == null) {
    		username = "";
    	}
    	
    	return LIVE.equalsIgnoreCase(environment) && 
				(username.toLowerCase().indexOf("@ocorp.dsarena.") > 0 ||
						username.toLowerCase().indexOf("@corp.dsarena") > 0);
	}

	/**
     * Release our use of this connection so that it can be recycled.
     *
     * @param context The directory context to release
     */
    protected void release(DirContext context, String username) throws Exception {
    	close(context, username);
    }


    // ------------------------------------------------------ Lifecycle Methods


    /**
     * Prepare for active use of the public methods of this Component.
     *
     * @exception LifecycleException if this component detects a fatal error
     *  that prevents it from being started
     */
    public void initialize() throws LifecycleException {

    	try {
            // So we never pass the service account details in the clear get the 
	    	// pooled contexts to use kerberos, unless in domain on live (until users migrated) not 
    		// configured for kerberos or in development.
    		
    		
	    	// instantiate the pool
	        HashMap<String, String> param = new HashMap<String, String>();
	        param.put("Directory/INITIAL_CONTEXT_FACTORY", contextFactory);
	        param.put("Directory/PROVIDER_URL", connectionURL);
	        param.put("Directory/REFERRALS", referrals);
	        param.put("Directory/CONNECTION_NAME", connectionName);
	        param.put("Directory/CONNECTION_PASSWORD", connectionPassword);
	        param.put("Directory/SECURITY_PROTOCOL", protocol);
	        param.put("Directory/SECURITY_AUTHENTICATION", "simple");
	        
	        pool = LdapPool.getInstance(new RealmLdapPoolFactory(param));
	        
	        // Validate that we can open our connection(s), borrowing an item from the pool will 
	        // open a connection as pool just created with invalid account
	        DirContext context = open("a@notocorp.dsarena.com");
	        pool.returnObject("default", context);
            
	        // if not on development then configure and test kerberos
	        if(LIVE.equalsIgnoreCase(environment)) {
	        	HashMap<String, String> kerberosParam = new HashMap<String, String>();
	        	kerberosParam.putAll(param);
	        	kerberosParam.put("Directory/SECURITY_AUTHENTICATION", "GSSAPI");
	            // will be logged in for the life of the app
		    	loginContext = KerberosConnection.authenticate(
		    			connectionPrincipleName, 
		    			connectionPassword);
		        kerberosPool = LdapPool.getInstance(new RealmLdapPoolFactory(kerberosParam));
		        String domain=connectionPrincipleName.substring(connectionPrincipleName.indexOf('@')+1).toLowerCase();
		        String userName=connectionPrincipleName.substring(0,connectionPrincipleName.indexOf("@")+1)+domain;
	        	DirContext secondContext = open(userName);
		        kerberosPool.returnObject("default", secondContext);
	        }
	        
        } catch (Exception e) {
          throw new LifecycleException(MESSAGES.authenticationFailure()
        			, e);
        }
        
    }


    /**
     * Gracefully shut down active use of the public methods of this Component.
     *
     * @exception LifecycleException if this component detects a fatal error
     *  that needs to be reported
     */
    public void remove() throws LifecycleException {

        // Perform normal superclass finalization
        super.stop();

        // Close any open directory server connections and logout
        try {
	        pool.close();
	        if (kerberosPool != null) {
	        	kerberosPool.close();
	        }
	        
	        if(loginContext != null)
	        {
	        	loginContext.logout();
	        }
        }
        catch (Exception e){
          throw new LifecycleException("Error closing DirContext pool.", e);
        }
    }

    /**
     * Given a string containing LDAP patterns for user locations (separated by
     * parentheses in a pseudo-LDAP search string format -
     * "(location1)(location2)", returns an array of those paths.  Real LDAP
     * search strings are supported as well (though only the "|" "OR" type).
     *
     * @param userPatternString - a string LDAP search paths surrounded by
     * parentheses
     */
    protected String[] parseUserPatternString(String userPatternString) {

        if (userPatternString != null) {
            ArrayList<String> pathList = new ArrayList<String>();
            int startParenLoc = userPatternString.indexOf('(');
            if (startParenLoc == -1) {
                // no parens here; return whole thing
                return new String[] {userPatternString};
            }
            int startingPoint = 0;
            while (startParenLoc > -1) {
                int endParenLoc = 0;
                // weed out escaped open parens and parens enclosing the
                // whole statement (in the case of valid LDAP search
                // strings: (|(something)(somethingelse))
                while ( (userPatternString.charAt(startParenLoc + 1) == '|') ||
                        (startParenLoc != 0 && userPatternString.charAt(startParenLoc - 1) == '\\') ) {
                    startParenLoc = userPatternString.indexOf("(", startParenLoc+1);
                }
                endParenLoc = userPatternString.indexOf(")", startParenLoc+1);
                // weed out escaped end-parens
                while (userPatternString.charAt(endParenLoc - 1) == '\\') {
                    endParenLoc = userPatternString.indexOf(")", endParenLoc+1);
                }
                String nextPathPart = userPatternString.substring
                    (startParenLoc+1, endParenLoc);
                pathList.add(nextPathPart);
                startingPoint = endParenLoc+1;
                startParenLoc = userPatternString.indexOf('(', startingPoint);
            }
            return pathList.toArray(new String[] {});
        }
        return null;

    }


    /**
     * Given an LDAP search string, returns the string with certain characters
     * escaped according to RFC 2254 guidelines.
     * The character mapping is as follows:
     *     char ->  Replacement
     *    ---------------------------
     *     *  -> \2a
     *     (  -> \28
     *     )  -> \29
     *     \  -> \5c
     *     \0 -> \00
     * @param inString string to escape according to RFC 2254 guidelines
     * @return String the escaped/encoded result
     */
    protected String doRFC2254Encoding(String inString) {
        StringBuffer buf = new StringBuffer(inString.length());
        for (int i = 0; i < inString.length(); i++) {
            char c = inString.charAt(i);
            switch (c) {
                case '\\':
                    buf.append("\\5c");
                    break;
                case '*':
                    buf.append("\\2a");
                    break;
                case '(':
                    buf.append("\\28");
                    break;
                case ')':
                    buf.append("\\29");
                    break;
                case '\0':
                    buf.append("\\00");
                    break;
                default:
                    buf.append(c);
                    break;
            }
        }
        return buf.toString();
    }

	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * @return the connectionPrincipleName
	 */
	public String getConnectionPrincipleName() {
		return connectionPrincipleName;
	}

	/**
	 * @param connectionPrincipleName the connectionPrincipleName to set
	 */
	public void setConnectionPrincipleName(String connectionPrincipleName) {
		this.connectionPrincipleName = connectionPrincipleName;
	}

	/**
	 * Wraps up making a call to DirContext.getAttributes with or with out Kerberos 
	 * @param context
	 * @param attrIds
	 * @param name
	 * @return
	 * @throws NamingException
	 */
	private Attributes contextGetAttributes(
			DirContext context,
			String name,
			String[] attrIds,
			String username) throws NamingException {
		Attributes attrs;
          logger.info("Inside contextGetAttributes -");
          logger.info("context is not null ? - " + context != null);
          logger.info("name - " + name);
          logger.info("attrIds - " + attrIds);
          logger.info("username - " + username);
		if(useKerberos(username)){
			ContextGetAttributes operation = new ContextGetAttributes(
					context,
					name,
					attrIds,
					containerLog);
			attrs = Subject.doAs(loginContext.getSubject(), operation);
			if(operation.getException() != null) 
			{
				throw operation.getException();
			}
		}
		else
		{
			attrs = context.getAttributes(name, attrIds);
		}
		return attrs;
	}

	/**
	 * Wraps up making a call to DirContext.search with or with out Kerberos 
	 * @param context
	 * @param name
	 * @param filter
	 * @param constraints
	 * @return
	 * @throws NamingException
	 */
	private NamingEnumeration<SearchResult> contextSearch(
			DirContext context,
			String name, 
			String filter, 
			SearchControls constraints,
			String username) throws NamingException {
		NamingEnumeration<SearchResult> results = null;
        if(useKerberos(username)){
        	ContextSearch operation = new ContextSearch(
    				context,
    				name, 
    				filter, 
    				constraints,
    				containerLog);
        	results = Subject.doAs(loginContext.getSubject(), operation);
			if(operation.getException() != null) 
			{
				throw operation.getException();
			}
    	}
    	else
    	{
    		results = context.search(name, filter, constraints);
    	}
		return results;
	}
	/**Method to verify User has a eBOX Security Role assigned
     * @param roles
     * @return
     */
    private  boolean isValidCscUser(List<String>roles) {
		boolean validcscUser = false;
		boolean validCountryUser = false;
		for (String role : roles) {

			if (role.contains("OU=Country")) {
				String[] roleSplit = role.split("=|-|,");
				String country = roleSplit[1];
				String[] allowedCountriesSplit = allowedCountries.split("-");
				if (allowedCountriesSplit.length == 1) {
					if (allowedCountriesSplit[0].contains(country) || allowedCountriesSplit[0].contains("*")) {
						validCountryUser = true;
					} else {
						errorType = "InvalidCountry";
					}
				} else if (allowedCountriesSplit.length > 1) {
					if (allowedCountriesSplit[1].contains(country)) {
						errorType = "InvalidCountry";
					} else {
						validCountryUser = true;
					}
				}
				break;
			}
		}
		if (validCountryUser) {
			for (String role : roles) {

				if (eboxSecurityGroup != null && eboxSecurityGroup.equalsIgnoreCase(role)) {
					validcscUser = true;
					break;
				}
			}
		}
		return validcscUser;
    }
}

// ------------------------------------------------------ Private Classes

/**
 * A private class representing a User
 */
class User {
    String username = null;
    String dn = null;
    String password = null;
    ArrayList<String> roles = null;

    User(String username, String dn, String password, ArrayList<String> roles) {
        this.username = username;
        this.dn = dn;
        this.password = password;
        this.roles = roles;
        
    }
}
