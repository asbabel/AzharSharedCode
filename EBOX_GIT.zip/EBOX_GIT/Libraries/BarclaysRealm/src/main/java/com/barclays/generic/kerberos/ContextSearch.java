package com.barclays.generic.kerberos;

import java.security.PrivilegedAction;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.jboss.logging.Logger;


/**
 * Wrap up a call to DirContext.search
 * So can be run using Kerberos 
 * 
 * @author EARLEB
 */
/*
 * DATE     REFERENCE   WHO   	VERSION COMMENTS
 * -------  ---------   -------	------- -----------------------------------------
 * 07May10	PAT03027	EARLEB	1.0		Created
 * 30Jul15  eSat        MG              Replacing Tomcat dependencies with JBoss
 */
public class ContextSearch implements PrivilegedAction<NamingEnumeration<SearchResult>> 
{
	private DirContext context = null;
	private String name = null;
	private String filter = null;
	private SearchControls controls = null;
	private Logger log = null;
	private NamingException exception = null;
	
	public ContextSearch(DirContext context, String name, String filter, SearchControls controls, Logger log) 
	{
		this.context = context;
		this.name = name;
		this.filter = filter;
		this.controls = controls;
		this.log = log;
	}

	@Override
	public NamingEnumeration<SearchResult> run() {
		NamingEnumeration<SearchResult> results = null;
		try {
			results = context.search(name, filter, controls);
		}
		catch(NamingException e)
		{
			log.error(e.toString(), e);
			exception = e;
		}
		
		return results;
	}
	
	public NamingException getException()
	{
		return exception;
	}
}
