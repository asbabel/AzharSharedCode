package com.barclays.generic.kerberos;

import java.security.PrivilegedAction;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;

import org.jboss.logging.Logger;


/**
 * Wrap up a call to DirContext.getAttributes
 * So can be run using Kerberos 
 * 
 * @author EARLEB
 */
/*
 * DATE     REFERENCE   WHO   	VERSION COMMENTS
 * -------  ---------   -------	------- -----------------------------------------
 * 07May10	PAT03027	EARLEB	1.0		Created
 * 30Jul15  eSat        MG              Replacing Tomcat dependencies with JBoss
 */
public class ContextGetAttributes implements PrivilegedAction<Attributes> 
{
	private DirContext context = null;
	private String name = null;
	private String[] attrIds = null;
	private Logger log = null;
	private NamingException exception = null;
	
	public ContextGetAttributes(DirContext context, String name, String[] attrIds, Logger log) 
	{
		this.context = context;
		this.name = name;
		this.attrIds = attrIds;
		this.log = log;
	}

	@Override
	public Attributes run() {
		Attributes attributes = null;
		try {
			attributes = context.getAttributes(name, attrIds);
		}
		catch(NamingException e)
		{
			log.error(e.toString(), e);
			exception = e;
		}
		
		return attributes;
	}
	
	public NamingException getException()
	{
		return exception;
	}
}
