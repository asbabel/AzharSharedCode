package com.barclays.generic.kerberos;

import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

/**
 * Used to authenticate a user against Kerberos
 * 
 **/
/*
 * DATE     REFERENCE   WHO   	VERSION  COMMENTS
 * -------  ---------   ---   	-------  ---------------------------------------------------
 * 09Feb10  PAT03027    SAMANTS 1a       WP359 - Created to implement Kerberos connection
 * 
 */

public class KerberosConnection {
	
	/**
	 * Logs into kerberos
	 * Kerberos configuration is set in C:\Windows\krb5.ini
	 * Login configuration is set in C:\cluster\jaas.conf
	 * @param userName
	 * @param userPassword
	 * @return if successful the LoginContext (so can logout) else error thrown;
	 * @throws LoginException
	 */
	public static LoginContext authenticate(
			String userName,
			String userPassword) 
	throws LoginException {
		
		KerberosCallbackHandler cbh = new KerberosCallbackHandler(userName, userPassword);
		LoginContext loginContext = new LoginContext("GenericADModule", cbh);
		loginContext.login();
	
		return loginContext;
	}
}