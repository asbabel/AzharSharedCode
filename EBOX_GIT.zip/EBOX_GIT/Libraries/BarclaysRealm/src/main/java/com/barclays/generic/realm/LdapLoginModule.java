package com.barclays.generic.realm;
import java.io.IOException;
import java.security.Principal;
import java.util.StringTokenizer;

import javax.management.JMException;
import javax.management.ObjectName;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.connector.Request;
import org.apache.catalina.deploy.LoginConfig;
import org.jboss.as.web.security.ExtendedFormAuthenticator;

import com.barclays.generic.business.utils.LoggerConnection;

/**
 * Custom LDAP Login Module for eBox
 *  
 * 
 * @author MangeshG
 */
/*
 * DATE     REFERENCE   WHO   	VERSION COMMENTS
 * -------  ---------   -------	------- -----------------------------------------
 * 12/12/14	eSatPOC		MG		1.0		Created
 * 15May15	eSat    	MG				Using ExtendedFormAuth, also suppressing redundent LDAP calls.
 * 30Jul15  eSat        MG              Replacing Tomcat dependencies with JBoss
 * 05Sep16  eSat        RM              Added error logging using log4j.
 */
public class LdapLoginModule extends ExtendedFormAuthenticator {
    
    private static final LoggerConnection logger = new LoggerConnection(
            LdapLoginModule.class);
    
	/**
	 * @param sessionCookieForSSOAuth the sessionCookieForSSOAuth to set
	 */
	public void setSessionCookieForSSOAuth(String sessionCookieForSSOAuth) {
		this.sessionCookieForSSOAuth = sessionCookieForSSOAuth;
	}


	/**
	 * @param connectionURL the connectionURL to set
	 */
	public void setConnectionURL(String connectionURL) {
		this.connectionURL = connectionURL;
	}


	/**
	 * @param connectionName the connectionName to set
	 */
	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}


	/**
	 * @param connectionPassword the connectionPassword to set
	 */
	public void setConnectionPassword(String connectionPassword) {
		this.connectionPassword = connectionPassword;
	}


	/**
	 * @param referrals the referrals to set
	 */
	public void setReferrals(String referrals) {
		this.referrals = referrals;
	}


	/**
	 * @param userBase the userBase to set
	 */
	public void setUserBase(String userBase) {
		this.userBase = userBase;
	}


	/**
	 * @param userSearch the userSearch to set
	 */
	public void setUserSearch(String userSearch) {
		this.userSearch = userSearch;
	}


	/**
	 * @param userRoleName the userRoleName to set
	 */
	public void setUserRoleName(String userRoleName) {
		this.userRoleName = userRoleName;
	}


	/**
	 * @param roleName the roleName to set
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}


	/**
	 * @param roleBase the roleBase to set
	 */
	public void setRoleBase(String roleBase) {
		this.roleBase = roleBase;
	}


	/**
	 * @param roleSearch the roleSearch to set
	 */
	public void setRoleSearch(String roleSearch) {
		this.roleSearch = roleSearch;
	}


	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}


	/**
	 * @param connectionPrincipleName the connectionPrincipleName to set
	 */
	public void setConnectionPrincipleName(String connectionPrincipleName) {
		this.connectionPrincipleName = connectionPrincipleName;
	}
	
	/**
	 * @param eboxSecurityGroup the security Group For eBOX
	 */
	public void setEboxSecurityGroup(String eboxSecurityGroup) {
		this.eboxSecurityGroup = eboxSecurityGroup;
	}
	
	/**
	 * @param allowedCountries the security Group For eBOX
	 */
	public void setAllowedCountries(String allowedCountries) {
		this.allowedCountries = allowedCountries;
	}
	
	private String httpHeaderForSSOAuth = null;
	private String sessionCookieForSSOAuth = null;
	private String connectionURL;
	private String connectionName;
	private String connectionPassword;
	private String referrals;
	private String userBase;
	private String userSearch;
	private String userRoleName;
	private String roleName;
	private String roleBase;
	private String roleSearch;
	private String environment;
	private String connectionPrincipleName;
	private String eboxSecurityGroup;
	private String allowedCountries;
	
	 public boolean authenticate(Request request, HttpServletResponse response,
			LoginConfig config) throws IOException {
		Principal principal = request.getUserPrincipal();
		
		if (principal != null) {
			//Already Authenticated
			return true;
		}

		String userPrincipalName = readCookie(request.getCookies(),
		"CscUserInfo");
		if (userPrincipalName != null) {
			String domain = readCookie(request.getCookies(),
			"CscUserDomain");
			String username = userPrincipalName + "@" + domain;
			String password = request
			.getParameter("j_password");
			// Check if there is sso id as well as sessionkey
			if (username == null || password == null) {
				return super.authenticate(request, response, config);
			}
			
			// Construct JNDI Realm and Call Authenticate.
			
			JNDIRealm realm = new JNDIRealm();
			try {
				initializeRealm(realm);
			} catch (LifecycleException e) {
                  logger.info("LdapLoginModule authenticate  failed - " + e.getMessage());

				forwardToErrorPage(request, response, config);
				return false;
			}
			principal = realm.authenticate(username, password);
			if (principal == null) {
				forwardToErrorPage(request, response, config);
				return false;
			}

			request.setUserPrincipal(principal);
			register(request, response, principal,
					HttpServletRequest.FORM_AUTH, username, password);
			return true;
		}
		return false;
	}


	private void initializeRealm(JNDIRealm realm) throws LifecycleException {
		realm.setContextFactory("com.sun.jndi.ldap.LdapCtxFactory");
		realm.setConnectionURL(connectionURL);
		realm.setReferrals(referrals);
		realm.setConnectionName(connectionName);
		realm.setConnectionPassword(connectionPassword);
		realm.setProtocol(null);
		realm.setUserBase(userBase);
		realm.setUserSearch(userSearch);
		realm.setUserSubtree(true);
		realm.setUserRoleName(userRoleName);
		realm.setRoleName(roleName);
		realm.setRoleBase(roleBase);
		realm.setRoleSearch(roleSearch);
		realm.setEnvironment(environment);
		realm.setConnectionPrincipleName(connectionPrincipleName);
		realm.setEboxSecurityGroup(eboxSecurityGroup);
		realm.setAllowedCountries(allowedCountries);
		realm.initialize();
	}


	protected String getUserId(Request request) {
		String ssoid = null;
		// We can have a comma-separated ids
		String ids = "";
		try {
			ids = this.getIdentityHeaderId();
		} catch (JMException e) {
		    logger.info("LdapLoginModule  getUserId error  - " + e.getMessage());
		    logger.error("LdapLoginModule  error", e);
		}
		if (ids == null || ids.length() == 0)
			throw new IllegalStateException(
			        "Http headers configuration missing");
		StringTokenizer st = new StringTokenizer(ids, ",");
		while (st.hasMoreTokens()) {
			ssoid = request.getHeader(st.nextToken());
			if (ssoid != null)
				break;
		}

		return ssoid;
	}


/*
* Obtain the session cookie from the request
*
* @ param request
* @ return
*/
	protected String getSessionCookie(Request request) {
		Cookie[] cookies = request.getCookies();
		int numCookies = cookies != null ? cookies.length : 0;
		// We can have com m a-separated ids
		String ids = "";
		try {
			ids = this.getSessionCookieId();
		} catch (JMException e) {
		    logger.info("LdapLoginModule  getSessionCookie error  - " + e.getMessage());
		    logger.error("LdapLoginModule  error", e);
		}
		if (ids == null || ids.length() == 0)
			throw new IllegalStateException(
					"Session cookies configuration in JBoss service missing");
		StringTokenizer st = new StringTokenizer(ids, ",");
		while (st.hasMoreTokens()) {
			String cookieToken = st.nextToken();
			String val = getCookieValue(cookies, numCookies, cookieToken);
			if (val != null)
				return val;
		}
		return null;
	}
	
	protected String getSessionCookieId() throws JMException {
		if (this.sessionCookieForSSOAuth != null)
			return this.sessionCookieForSSOAuth;
		return (String) mserver.getAttribute(new ObjectName(
				"jboss.web:service=WebServer"), "SessionCookieForSSOAuth");
	}


	/**
	 * @param httpHeaderForSSOAuth the httpHeaderForSSOAuth to set
	 */
	public void setHttpHeaderForSSOAuth(String httpHeaderForSSOAuth) {
		this.httpHeaderForSSOAuth = httpHeaderForSSOAuth;
	}


	/**
	 * @return the httpHeaderForSSOAuth
	 */
	public String getHttpHeaderForSSOAuth() {
		return httpHeaderForSSOAuth;
	}
	
	protected String getIdentityHeaderId() throws JMException {
		if (this.httpHeaderForSSOAuth != null)
			return this.httpHeaderForSSOAuth;
		return (String) mserver.getAttribute(new ObjectName(
		"jboss.web:service=WebServer"), "HttpHeaderForSSOAuth");
	}
	
	protected String getCookieValue(Cookie[] cookies, int numCookies,
			String token) {
		for (int i = 0; i < numCookies; i++) {
			Cookie cookie = cookies[i];
			if (token.equals(cookie.getName())) {

				return cookie.getValue();
			}
		}
		return null;
	}
	
    
    /**
     * Value of the named cookie, or <code>null</code> if not present.
     */
    private String readCookie(
        Cookie[] cookies,
        String name)
    {
        if (cookies != null)
        {
            for (int i = 0; i < cookies.length; i++){
                if (cookies[i].getName().equals(name)){
                    return cookies[i].getValue();
                }
            }
        }
        return null;
    }
}
