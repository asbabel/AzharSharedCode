package com.barclays.generic.kerberos;

import java.security.PrivilegedAction;

import javax.naming.directory.DirContext;

import org.jboss.logging.Logger;

import com.barclays.generic.pool.LdapPool;

/**
 * An action that borrows a socket from a pool. 
 * If the pool connection uses kerberos then creating the connection requires 
 * we have a valid LoginContext (so run as a Subject of the LoginContext)
 * 
 * @author EARLEB
 */
/*
 * DATE     REFERENCE   WHO   	VERSION COMMENTS
 * -------  ---------   -------	------- -----------------------------------------
 * 07May10	PAT03027	EARLEB	1.0		Created
 * 30Jul15  eSat        MG              Replacing Tomcat dependencies with JBoss
 */
public class BorrowPoolConnection implements PrivilegedAction<DirContext> 
{
	private LdapPool pool = null;
	private String key = null;
	private Logger log = null;
	private Exception exception = null;
	
	public BorrowPoolConnection(LdapPool pool, String key, Logger log) 
	{
		this.pool = pool;
		this.key = key;
		this.log = log;
	}

	@Override
	public DirContext run() {
		DirContext context = null;
		try {
			context = pool.borrowObject(key);
		}
		catch(Exception e)
		{
			log.error(e.toString(), e);
			exception = e;
		}
		
		return context;
	}
	
	public Exception getException()
	{
		return exception;
	}
}
