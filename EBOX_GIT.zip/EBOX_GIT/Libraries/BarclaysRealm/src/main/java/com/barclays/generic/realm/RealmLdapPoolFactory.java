package com.barclays.generic.realm;


import java.util.HashMap;
import java.util.Hashtable;

import javax.naming.Context;


import com.barclays.generic.pool.BarclaysDirContext;
import com.barclays.generic.pool.LdapPoolFactory;


/**
 * A LdapPool factory for the custom Tomcat login Realm
 * If using Kerberos (Authentication = GSSAPI), have to be running within a PriviledgeedAction 
 * for this to work. 
 * 
 * @author EARLB
 */
/*
 * DATE     REFERENCE   WHO   	VERSION COMMENTS
 * -------  ---------   -------	------- -----------------------------------------
 * 06May10	?			EARLEB	1.0		Created
 * 22Aug11	Release003	EARLEB			Added connection and read timeouts
 * 05Sep16  eSAT        RM              Removed unused abstract logging method. 
 * 
 */
public class RealmLdapPoolFactory extends LdapPoolFactory {
	
	
	public RealmLdapPoolFactory(HashMap<String, String> value) {
		super(value);
	}

	
	@Override
	public Object makeObject (Object key) throws Exception {
		if (key == null || !(key instanceof String) || ((String)key).length() == 0 )
			throw new IllegalArgumentException("Invalid key specified");
		
		if(params == null){
			throw new Exception("The LdapPoolFactory class has been constructed without any connection paramters.");
		}
		
		String port = (String)key;
		// determine which port we are using 
		String url = params.get("Directory/PROVIDER_URL"); 
		if (!port.equals("default")){
			// remove existing port and use supplied port
			url = url.substring(0, url.lastIndexOf(":")+1) + port;
		}
		
		Hashtable<String, String> config = new Hashtable<String, String>();
		config.put(Context.INITIAL_CONTEXT_FACTORY, 
				params.get("Directory/INITIAL_CONTEXT_FACTORY"));
		config.put(Context.PROVIDER_URL, url);
        if(params.get("Directory/REFERRALS") != null)
        	config.put(Context.REFERRAL, 
        			params.get("Directory/REFERRALS"));
        
        config.put(Context.SECURITY_PRINCIPAL, 
        		params.get("Directory/CONNECTION_NAME"));
        config.put(Context.SECURITY_CREDENTIALS, 
        		params.get("Directory/CONNECTION_PASSWORD"));
        if(params.get("Directory/SECURITY_PROTOCOL") != null)
        	config.put(Context.SECURITY_PROTOCOL,
        			params.get("Directory/SECURITY_PROTOCOL"));
        
        if(params.get("Directory/SECURITY_AUTHENTICATION") != null) 
        {
        	String authentication = params.get("Directory/SECURITY_AUTHENTICATION");
        	config.put(Context.SECURITY_AUTHENTICATION, authentication);
        	if("GSSAPI".equals(authentication)) 
        	{
        		config.put("javax.security.sasl.server.authentication", "true");
        		config.put("javax.security.sasl.qop", "auth");
        	}
        }
        
        config.put(CONNECT_TIMEOUT, FIVE_MINUTES_IN_MILLISECONDS);
		config.put(READ_TIMEOUT, FIVE_MINUTES_IN_MILLISECONDS);
            	
        return new BarclaysDirContext(config);
	}

}