package com.barclays.generic.kerberos;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

/**
 * CallbackHandler which passes the user's credentials obtained via
 * the web interface to the Kerberos server
 */

/*
 * DATE     REFERENCE   WHO   	VERSION  COMMENTS
 * -------  ---------   ---   	-------  ---------------------------------------------------
 * 09Feb10  PAT3027     SAMANTS 1a       WP359 - Created to implement Kerberos connection
 * 
 */
public class KerberosCallbackHandler implements CallbackHandler {
	private String user = "";
    private String pass = "";
    
	public KerberosCallbackHandler(String username, String passwd) {
		user = username;
		pass = passwd;
	}
	
	public void handle(Callback[] callbacks)
    	throws IOException, UnsupportedCallbackException {
        
		for (int i = 0; i < callbacks.length; i++) {
            
        	if (callbacks[i] instanceof NameCallback) {
                NameCallback nameCb = (NameCallback)callbacks[i];
                nameCb.setName(user);
            }
        	
        	else if(callbacks[i] instanceof PasswordCallback) {
                PasswordCallback passCb = (PasswordCallback)callbacks[i];
                passCb.setPassword(pass.toCharArray());
            }
            
            else {
                throw(new UnsupportedCallbackException(callbacks[i],
                    "Callback class not supported"));
             }
        }
    }
}