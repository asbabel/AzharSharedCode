package com.barclays.ebox.pay.common.statemachine.util;

import com.barclays.ebox.pay.common.statemachine.State;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;


public class StateUtil {
    public static List<State> transitionList(State ... states) {
        List<State> allowableTransitions = new ArrayList<>();
        Stream.of(states).forEach(allowableTransitions::add);
        return allowableTransitions;
    }
}
