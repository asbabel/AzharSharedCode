package com.barclays.ebox.pay.common.statemachine;

import com.barclays.generic.business.utils.LoggerConnection;

/**
 * Enums implementing this class can define a default value which will be returned
 * by getNullSafeValue when Enum.valueOf would throw an exception.
 *
 * @param <T> A generic Enum type.
 */
public interface NullSafeEnumMatcher<T extends Enum<T>> {
    LoggerConnection logger = new LoggerConnection(NullSafeEnumMatcher.class);

    default T getNullSafeValue(T source, String value) {
        try {
            return Enum.valueOf(source.getDeclaringClass(), value);
        } catch (Exception e) {
            // value not found in enum, return the default
            logger.debug("Non-existent enum value requested. Type:"+source.getClass()+"; Value:"+value+"; Using default:"+defaultValue() +"; "+e);
            return defaultValue();
        }
    }

    default boolean matches(T source, String value) {
        return (value != null) && value.equals(getNullSafeValue(source, value).name());
    }

    T defaultValue();
}
