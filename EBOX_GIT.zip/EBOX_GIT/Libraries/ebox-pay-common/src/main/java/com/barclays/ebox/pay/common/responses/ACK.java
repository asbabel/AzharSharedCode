package com.barclays.ebox.pay.common.responses;

public class ACK extends InitialResponse {
    public ACK(Long id) {
        super(Type.ACK, id);
    }
}
