package com.barclays.ebox.pay.common.statemachine.impl;

import com.barclays.ebox.pay.common.statemachine.NullSafeEnumMatcher;
import com.barclays.ebox.pay.common.statemachine.State;
import com.barclays.ebox.pay.common.statemachine.util.StateUtil;

import java.util.List;

/**
 * State machine for RequestHeader objects
 */
public enum RequestHeaderState implements State, NullSafeEnumMatcher<RequestHeaderState> {
    START, //Processing of the file has been initiated by the Request Handler
    RETRYLOAD,
    READY, //The file has passed basic validation, with its payment requests stored to the system by the Request Handler. It is awaiting processing by the Payment Pre-Processor
    REJECT, //The payment file has been rejected (due to a business error)
    RETRY, //The payment file could not be successfully processed (due to a technical / unexpected or repairable issue) and will be resubmitted for processing
    ERROR, //The file failed to process due to a technical / unexpected error and will not be retried further
    PROCESSED, //The Payment  File has been successfully processed by the File Receiver
    UNDEFINED;

    @Override
    public boolean matches(String value) {
        return matches(this, value);
    }

    @Override
    public RequestHeaderState defaultValue() {
        return UNDEFINED;
    }

    @Override
    public List<State> allowableTransitions() {
        switch (this) {
            case START:
                return StateUtil.transitionList(RETRYLOAD, READY);
            case RETRYLOAD:
                return StateUtil.transitionList(START);
            case READY:
                return StateUtil.transitionList(RETRY, REJECT, PROCESSED, ERROR);
            case RETRY:
                return StateUtil.transitionList(ERROR, READY);
            case PROCESSED:
                return StateUtil.transitionList(); // Final State
            case ERROR:
                return StateUtil.transitionList(); // Final State
            default:
                return StateUtil.transitionList(START);
        }
    }
}
