package com.barclays.ebox.pay.common.statemachine;

import com.barclays.generic.business.utils.LoggerConnection;

/**
 * Thrown when an invalid state transition is attempted .
 *
 */
public class InvalidStateTransitionException extends Exception {
    protected LoggerConnection logger = new LoggerConnection(InvalidStateTransitionException.class);

    public InvalidStateTransitionException(State from, State to) {
        logger.warn("Invalid state transition from:["+from+"] to:["+to+"]");
        logger.debug("Allowed transitions for "+from+": "+ (from!=null?from.allowableTransitions():null));
    }

    public InvalidStateTransitionException(String from, State to) {
        logger.warn("Invalid state transition from:["+from+"] to:["+to+"]");
    }
}
