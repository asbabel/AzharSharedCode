package com.barclays.ebox.pay.common.statemachine;

import java.util.List;

/**
 * Repesents a State in which a Domain object may be at a given time
 * Such as READY, RETRY, etc.
 *
 * Each State should have knowledge of the States it is allowed to transition to.
 */
public interface State {

    /**
     * This State will only allow transitions to a finite number of other States
     * This method is to return a list of all the States to which the current State is allowed to
     * transition to.
     *
     * @return List<State>
     */
    List<State> allowableTransitions();

    /**
     * Returns true if the String passed matches this State
     *
     * @param value String representing a State
     * @return true if this String corresponds to this State.
     */
    boolean matches(String value);

    /**
     * Returns true if transitioning to the State represented by the passed in String
     * is allowed
     *
     * @param to String representing the State we want to transition to
     * @return true if the transition is allowed for this State.
     */
    default boolean isTransitionAllowed(String to) {
        return allowableTransitions().stream().anyMatch(state -> state.matches(to));
    }

    /**
     * Returns true if transitioning to the State passed in is allowed
     *
     * @param to State we want to transition to
     * @return true if the transition is allowed for the current State.
     */
    default boolean isTransitionAllowed(State to) {
        return allowableTransitions().contains(to);
    }
}
