package com.barclays.ebox.pay.common.dao.util;

import com.barclays.generic.business.utils.LoggerConnection;

public class ResourceUtil {
    private static LoggerConnection logger = new LoggerConnection(ResourceUtil.class);

    public static void releaseResources(AutoCloseable... resources) {
        for (AutoCloseable resource : resources) {
            try {
                if (resource != null) {
                    resource.close();
                }
            } catch (Exception e) {
                logger.error(e.getClass().getName() + ":" + e.getMessage(), e);
            }
        }
    }
}

