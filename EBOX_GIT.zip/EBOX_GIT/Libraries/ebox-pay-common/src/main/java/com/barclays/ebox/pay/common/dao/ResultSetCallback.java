package com.barclays.ebox.pay.common.dao;

import java.sql.ResultSet;

import com.barclays.ebox.pay.domain.exception.DAOException;
import com.barclays.ebox.pay.domain.exception.FailAppException;

/**
 * A ResultSetCallback instance is able to Process a ResultSet without the
 * responsibility for closing the resource which belongs in the relevant DAO.
 * 
 * This interface is used to separate the responsibility of:
 * - Managing ResultSet resources [belongs in a DAO]
 * - Executing business logic on the result [belongs in a business rule class.]
 * 
 * An extra generic parameter can be provided.
 * 
 * @author G01025860
 *
 * @param <T>
 *            The type of the extra parameter to be provided.
 */
@FunctionalInterface
public interface ResultSetCallback<T> {
	/**
	 * Process the results of a DB query
	 * 
	 * @param rs
	 *            The ResultSet from a DB query
	 * @param param
	 *            An optional Parameter of Generic Type.
	 * @throws DAOException
	 *             DAO exception
	 * @throws FailAppException
	 *             FailAppException
	 */
	void handleResultSet(ResultSet rs, T param) throws DAOException, FailAppException;
}
