package com.barclays.ebox.pay.common.statemachine.impl;

import com.barclays.ebox.pay.common.statemachine.NullSafeEnumMatcher;
import com.barclays.ebox.pay.common.statemachine.State;
import com.barclays.ebox.pay.common.statemachine.util.StateUtil;

import java.util.List;

/**
 * State machine for Transaction objects
 */
public enum TransactionState implements State, NullSafeEnumMatcher<TransactionState> {
    READY, // The transaction has been stored to MWDB and is awaiting processing by the Payment Pre-Processor
    UNDEFINED;

    @Override
    public boolean matches(String value) {
        return matches(this, value);
    }

    @Override
    public TransactionState defaultValue() {
        return UNDEFINED;
    }

    @Override
    public List<State> allowableTransitions() {
        switch (this) {
            case READY:
                return StateUtil.transitionList();
            default:
                return StateUtil.transitionList(READY);
        }
    }
}
