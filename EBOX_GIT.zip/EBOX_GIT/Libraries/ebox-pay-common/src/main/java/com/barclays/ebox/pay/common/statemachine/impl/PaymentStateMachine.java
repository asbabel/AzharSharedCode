package com.barclays.ebox.pay.common.statemachine.impl;

import com.barclays.ebox.pay.common.statemachine.InvalidStateTransitionException;
import com.barclays.ebox.pay.common.statemachine.NullSafeEnumMatcher;
import com.barclays.ebox.pay.common.statemachine.State;
import com.barclays.ebox.pay.common.statemachine.StateMachine;
import org.springframework.stereotype.Component;

/**
 * Purpose of this component is to check is a State transition is allowed.
 *
 * Throws exception is not allowed, does nothing if allowed.
 */
@Component
public class PaymentStateMachine implements StateMachine {
    @Override
    public void changeState(State fromState, State toState) throws InvalidStateTransitionException {
        if (!fromState.allowableTransitions().contains(toState)) {
            throw new InvalidStateTransitionException(fromState, toState);
        }
    }

    @SuppressWarnings("unchecked")
    public <T extends Enum<T>, E extends NullSafeEnumMatcher<T>> void changeState(String fromState, State toState) throws InvalidStateTransitionException {
        try {
            this.changeState((State) ((E) toState).getNullSafeValue((T) toState, fromState), toState);
        } catch (ClassCastException cce) {
            throw new InvalidStateTransitionException(fromState, toState);
        }
    }
}
