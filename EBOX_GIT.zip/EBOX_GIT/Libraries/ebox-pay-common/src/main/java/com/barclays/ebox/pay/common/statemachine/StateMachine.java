package com.barclays.ebox.pay.common.statemachine;

public interface StateMachine {
    void changeState(State fromState, State toState) throws InvalidStateTransitionException;
}
