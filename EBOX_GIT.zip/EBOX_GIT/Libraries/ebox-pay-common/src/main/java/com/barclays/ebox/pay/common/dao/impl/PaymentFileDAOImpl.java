package com.barclays.ebox.pay.common.dao.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BasicDynaBean;
import org.apache.commons.beanutils.RowSetDynaClass;
import org.springframework.stereotype.Component;

import com.barclays.ebox.pay.common.dao.PaymentFileDAO;
import com.barclays.ebox.pay.common.dao.ResultSetCallback;
import com.barclays.ebox.pay.domain.PaymentRequest;
import com.barclays.ebox.pay.domain.RequestHeader;
import com.barclays.ebox.pay.domain.RequestHeader.Builder;
import com.barclays.ebox.pay.domain.Transaction;
import com.barclays.ebox.pay.domain.exception.DAOException;
import com.barclays.ebox.pay.domain.exception.FailAppException;

/**
 * Data Access Objects for all Payment related database interactions
 * 
 * @author abrma5s
 *
 */
@Component("paymentFileDao")
public class PaymentFileDAOImpl extends BaseDAOImpl implements PaymentFileDAO {

	private static final String STATUS = "status";
	private static final String READY = "READY";
	private static final String TRANSACTION_ID = "transactionId";
	private static final String REQUEST_HEADER_ID = "requestHeaderId";
	private static final String REQUESTHEADERID_OUTPUT = "requestheaderid";
	private static final String PAYMENT_REQUEST_ID = "paymentRequestId";
	private static final String LAST_PROCESSED_TRANSACTION_ID = "LastProcessedTransactionId";
	private static final String PROCESSING_ENGINE_NAME = "processingEngineName";

	@Override
	public long insertRequestHeader(File paymentFile) throws DAOException {
		Integer requestHeaderId;

		Map<String, Object> inputArgs = new HashMap<>();

		inputArgs.put("fileName", paymentFile.getName());
		inputArgs.put(STATUS, "START");

		RowSetDynaClass result = executeResultSet("wfe_ioPaymentsRequestHeaderInsert", inputArgs);
		BasicDynaBean resultRow = (BasicDynaBean) result.getRows().get(0);
		requestHeaderId = (Integer) resultRow.get(REQUESTHEADERID_OUTPUT);

		return requestHeaderId;
	}

	@Override
	public void updateRequestHeader(RequestHeader requestHeader) throws DAOException {

		Map<String, Object> inputArgs = new HashMap<>();

		inputArgs.put(REQUEST_HEADER_ID, requestHeader.getRequestHeaderId());
		inputArgs.put("messageId", requestHeader.getMessageId());
		inputArgs.put(TRANSACTION_ID, requestHeader.getTransactionId());
		inputArgs.put("accountingToken", requestHeader.getAccountingToken());
		inputArgs.put("sourceApplName", requestHeader.getSourceApplName());
		inputArgs.put("sourceApplFunc", requestHeader.getSourceApplFunc());
		inputArgs.put("projectId", requestHeader.getProjectId());
		inputArgs.put("targetCountry", requestHeader.getTargetCountry());
		inputArgs.put("propertyOffshoreInd", requestHeader.getPropertyOffshoreInd());
		inputArgs.put("propertyAdjustBalance", requestHeader.getPropertyAdjustBalance());
		inputArgs.put("propertyCheckAccount", requestHeader.getPropertyCheckAccount());
		inputArgs.put("propertyBatch", requestHeader.getPropertyBatch());
		inputArgs.put("propertyCheckOrigAccExists", requestHeader.getPropertyCheckOrigAccExists());
		inputArgs.put("propertyCheckOrigAccOpen", requestHeader.getPropertyCheckOrigAccOpen());
		inputArgs.put("PropertyCheckOrigAccCurrency", requestHeader.getPropertyCheckOrigAccCurrency());
		inputArgs.put("PropertyCheckOrigAccBalance", requestHeader.getPropertyCheckOrigAccBalance());
		inputArgs.put("PropertyCheckCounterpartyAcc", requestHeader.getPropertyCheckCounterpartyAcc());
		inputArgs.put("PropertyUser_id", requestHeader.getPropertyUserId());
		inputArgs.put("PropertyLocation_code", requestHeader.getPropertyLocationCode());
		inputArgs.put("RespondToType", requestHeader.getRespondToType());
		inputArgs.put("RespondTo", requestHeader.getRespondTo());
		inputArgs.put("ReplayFlag", requestHeader.getReplayFlag());
		inputArgs.put("UserIdentifier", requestHeader.getUserIdentity());
		inputArgs.put("UserPassword", requestHeader.getUserPassword());

		executeCommand("wfe_ioPaymentsRequestHeaderUpdate", inputArgs);
	}

	@Override
	public long insertPaymentRequest(PaymentRequest paymentRequest, Connection con) throws DAOException {
		Integer paymentRequestId;

		Map<String, Object> inputArgs = new HashMap<>();

		inputArgs.put(REQUEST_HEADER_ID, paymentRequest.getRequestHeader().getRequestHeaderId());
		inputArgs.put("UserId", paymentRequest.getUserId());
		inputArgs.put(STATUS, READY);
		inputArgs.put("debitCreditInd", paymentRequest.getDebitCreditInd());
		inputArgs.put("type", paymentRequest.getType());
		inputArgs.put("typeDescription", paymentRequest.getTypeDescription());
		inputArgs.put("branchId", paymentRequest.getBranchId());
		inputArgs.put("accountNumber", paymentRequest.getAccountNo());
		inputArgs.put("ccy", paymentRequest.getCcy());
		inputArgs.put("OriginatorName", paymentRequest.getOriginatorName());
		inputArgs.put("OriginatorAddress1", paymentRequest.getOriginatorAddress1());
		inputArgs.put("OriginatorAddress2", paymentRequest.getOriginatorAddress2());
		inputArgs.put("OriginatorAddress3", paymentRequest.getOriginatorAddress3());
		inputArgs.put("OriginatorCode", paymentRequest.getOriginatorCode());
		inputArgs.put("RemittanceInformation", paymentRequest.getRemittanceInformation());
		inputArgs.put("CustomerNumber1", paymentRequest.getCustomerNo1());
		inputArgs.put("CustomerNumber2", paymentRequest.getCustomerNo2());
		inputArgs.put("SerialNumber", paymentRequest.getSerialNo());
		inputArgs.put("LocationCode", paymentRequest.getLocationCode());
		inputArgs.put("Amount", paymentRequest.getAmount());
		inputArgs.put("Narrative", paymentRequest.getNarrative());
		inputArgs.put("TransactionsInGroup", paymentRequest.getTransactionsInGroup());

		RowSetDynaClass result = executeResultSet(con, "wfe_ioPaymentsPaymentRequestInsert", inputArgs);
		BasicDynaBean resultRow = (BasicDynaBean) result.getRows().get(0);
		paymentRequestId = (Integer) resultRow.get("paymentrequestid");

		return paymentRequestId;
	}

	@Override
	public void insertTransaction(Transaction transaction, PaymentRequest paySource, Connection con)
			throws DAOException {

		Map<String, Object> inputArgs = new HashMap<>();

		inputArgs.put(REQUEST_HEADER_ID, paySource.getRequestHeader().getRequestHeaderId());
		inputArgs.put(PAYMENT_REQUEST_ID, paySource.getPaymentRequestId());
		inputArgs.put(STATUS, READY);

		try {
			try(ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(baos)) {
				oos.writeObject(transaction);
				inputArgs.put("transactionObject", baos.toByteArray());

				executeCommand(con, "wfe_ioPaymentsTransactionInsert", inputArgs);
			}
		} catch (IOException e) {
			throw new DAOException(e);
		}
	}

	@Override
	public void getTransactions(PaymentRequest pr, ResultSetCallback<PaymentRequest> rsHandler,
			long lastProcessedTransactionId) 
			throws DAOException, FailAppException {
		Map<String, Object> inputArgs = new HashMap<>();
		
		inputArgs.put(PAYMENT_REQUEST_ID, pr.getPaymentRequestId());
		inputArgs.put(LAST_PROCESSED_TRANSACTION_ID, lastProcessedTransactionId);
		try (Connection con = dataSource.getConnection()) {
			try (ResultSet rs = getResultSet(con, "wfe_ioPaymentsTransactionGet", inputArgs) ) {
				rsHandler.handleResultSet(rs, pr);
			}
		} catch (SQLException e) {
			logger.error(e);
		}
	}

	@Override
	public void getRetryTransactions(PaymentRequest pr, ResultSetCallback<PaymentRequest> rsHandler)
			throws DAOException, FailAppException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(PAYMENT_REQUEST_ID, pr.getPaymentRequestId());

		try (Connection con = dataSource.getConnection()) {
			try (ResultSet rs = getResultSet(con, "wfe_ioPaymentsRetryTransactionGet", inputArgs)) {
				rsHandler.handleResultSet(rs, pr);
			}
		} catch (SQLException e) {
			logger.error(e);
		}

	}

	@Override
	public RequestHeader getRequestHeaderById(long requestHeaderId) throws DAOException {

		RequestHeader.Builder requestHeader = new RequestHeader.Builder();

		Map<String, Object> inputArgs = new HashMap<>();

		inputArgs.put(REQUEST_HEADER_ID, requestHeaderId);

		RowSetDynaClass result = executeResultSet("wfe_ioPaymentsRequestHeaderGetById", inputArgs);
		if (!result.getRows().isEmpty()) {
			populateRequestHeader(requestHeaderId, requestHeader, result);
		} else {
			return null;
		}
		return requestHeader.build();
	}

	private void populateRequestHeader(Long requestHeaderId, Builder requestHeader, RowSetDynaClass result) {
		BasicDynaBean resultRow = (BasicDynaBean) result.getRows().get(0);
		if (requestHeaderId == null) {
			requestHeader.setRequestHeaderId((long) resultRow.get(REQUESTHEADERID_OUTPUT));
		} else {
			requestHeader.setRequestHeaderId(requestHeaderId);
		}
		populateRequestHeader(resultRow, requestHeader);
	}

	private void populateRequestHeader(BasicDynaBean resultRow, RequestHeader.Builder requestHeader) {
	
		requestHeader.setMessageId(trimString(resultRow.get("messageid")));
		requestHeader.setTransactionId(trimString(resultRow.get("transactionid")));
		requestHeader.setAccountingToken(trimString(resultRow.get("accountingtoken")));
		requestHeader.setSourceApplName(trimString(resultRow.get("sourceapplname")));
		requestHeader.setSourceApplFunc(trimString(resultRow.get("sourceapplfunc")));
		requestHeader.setFileName(trimString(resultRow.get("filename")));
		requestHeader.setStatus(trimString(resultRow.get(STATUS)));
		Short errorCode = (Short) resultRow.get("errorcode");
		requestHeader.setErrorCode(errorCode == null ? 0 : errorCode);
		requestHeader.setProjectId(trimString(resultRow.get("projectid")));
		requestHeader.setTargetCountry(trimString(resultRow.get("targetcountry")));
		Boolean propertyoffshoreind = (Boolean) resultRow.get("propertyoffshoreind");
		requestHeader.setPropertyOffshoreInd((propertyoffshoreind != null && propertyoffshoreind) ? 1 : 0);
		requestHeader.setPropertyAdjustBalance(trimString(resultRow.get("propertyadjustbalance")));
		requestHeader.setPropertyCheckAccount(trimString(resultRow.get("propertycheckaccount")));
		requestHeader.setPropertyBatch(trimString(resultRow.get("propertybatch")));
		requestHeader.setPropertyCheckOrigAccExists(trimString(resultRow.get("propertycheckorigaccexists")));
		requestHeader.setPropertyCheckOrigAccBalance(trimString(resultRow.get("propertycheckorigaccbalance")));
		requestHeader.setPropertyCheckOrigAccCurrency(trimString(resultRow.get("propertycheckorigacccurrency")));
		requestHeader.setPropertyCheckOrigAccOpen(trimString(resultRow.get("propertycheckorigaccopen")));
		requestHeader.setPropertyUserId(trimString(resultRow.get("propertyuser_id")));
		requestHeader.setPropertyLocationCode(trimString(resultRow.get("propertylocation_code")));
		requestHeader.setRespondTo(trimString(resultRow.get("respondto")));
		requestHeader.setRespondToType(trimString(resultRow.get("respondtotype")));
		requestHeader.setReplayFlag(trimString(resultRow.get("replayflag")));
		Short retryCount = (Short) resultRow.get("retrycount");
		requestHeader.setRetryCount(retryCount == null ? 0 : retryCount);
		Boolean retryInd = (Boolean) resultRow.get("retryind");
		requestHeader.setRetry(retryInd == null ? false : retryInd);
		requestHeader.setRepliedOn((Timestamp)resultRow.get("repliedon"));
		requestHeader.setUserIdentity(trimString(resultRow.get("userindentifier")));
		requestHeader.setUserPassword(trimString(resultRow.get("userpassword")));
	}

	private String trimString(Object string) {
		return (string == null) ? null : ((String) string).trim();
	}

	@Override
	public List<RequestHeader> getRequestHeaderByStatus(String status) throws DAOException {
		List<RequestHeader> requestHeaderList = new ArrayList<>();

		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(STATUS, status);

		RowSetDynaClass result = executeResultSet("wfe_ioPaymentsRequestHeaderGetByStatus", inputArgs);
		if (!result.getRows().isEmpty()) {
			for (Object obj : result.getRows()) {
				BasicDynaBean resultRow = (BasicDynaBean) obj;
				RequestHeader.Builder rHBuilder = new RequestHeader.Builder();
				rHBuilder.setRequestHeaderId((Integer) resultRow.get(REQUESTHEADERID_OUTPUT));
				populateRequestHeader(resultRow, rHBuilder);
				RequestHeader rh = rHBuilder.build();
				requestHeaderList.add(rh);
			}
		}
		return requestHeaderList;
	}

	@Override
	public List<PaymentRequest> getPaymentRequests(long requestHeaderId) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(REQUEST_HEADER_ID, requestHeaderId);

		List<PaymentRequest> paymentRequestList = new ArrayList<>();

		RequestHeader rh = getRequestHeaderById(requestHeaderId);

		RowSetDynaClass result = executeResultSet("wfe_ioPaymentsGetPaymentRequest", inputArgs);
		for (Object row : result.getRows()) {
			BasicDynaBean resultRow = (BasicDynaBean) row;
			PaymentRequest paymentRequest = new PaymentRequest.Builder().build();
			paymentRequest.setRequestHeader(rh);
			paymentRequest.setPaymentRequestId(((Integer) resultRow.get("paymentrequestid")).longValue());
			paymentRequest.setUserId(trimString(resultRow.get("userid")));
			paymentRequest.setDebitCreditInd(trimString(resultRow.get("debitcreditind")));
			paymentRequest.setType(trimString(resultRow.get("type")));
			paymentRequest.setTypeDescription(trimString(resultRow.get("typedescription")));
			paymentRequest.setBranchId(trimString(resultRow.get("branchid")));
			paymentRequest.setAccountNo(trimString(resultRow.get("accountnumber")));
			paymentRequest.setCcy(trimString(resultRow.get("ccy")));
			com.ibm.math.BigDecimal amount = (com.ibm.math.BigDecimal) resultRow.get("amount");
			paymentRequest.setAmount(amount == null ? null : amount.toBigDecimal());
			paymentRequest.setNarrative(trimString(resultRow.get("narrative")));
			paymentRequest.setOriginatorName(trimString(resultRow.get("originatorname")));
			paymentRequest.setOriginatorAddress1(trimString(resultRow.get("originatoraddress1")));
			paymentRequest.setOriginatorAddress2(trimString(resultRow.get("originatoraddress2")));
			paymentRequest.setOriginatorAddress3(trimString(resultRow.get("originatoraddress3")));
			paymentRequest.setOriginatorCode(trimString(resultRow.get("originatorcode")));
			paymentRequest.setRemittanceInformation(trimString(resultRow.get("remittanceinformation")));
			paymentRequest.setSerialNo(trimString(resultRow.get("serialnumber")));
			paymentRequest.setCustomerNo1((Integer) resultRow.get("customernumber1"));
			paymentRequest.setCustomerNo2((Integer) resultRow.get("customernumber2"));
			paymentRequest.setLocationCode(trimString(resultRow.get("locationcode")));
			paymentRequest.setTransactionsInGroup((Integer) resultRow.get("transactionsingroup"));
			paymentRequest.setLastProcessedTransactionId((Integer)resultRow.get("lastprocessedtransactionid"));
			paymentRequestList.add(paymentRequest);
		}

		return paymentRequestList;
	}

	@Override
	public void updateRequestHeaderStatus(long requestHeaderId, String status, int errorCode) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(REQUEST_HEADER_ID, requestHeaderId);
		inputArgs.put(STATUS, status);
		inputArgs.put("errorCode", errorCode);

		executeCommand("wfe_ioPaymentsRequestHeaderUpdateStatus", inputArgs);
	}

	@Override
	public void updatePaymentRequestStatus(long paymentRequestId, String status) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(PAYMENT_REQUEST_ID, paymentRequestId);
		inputArgs.put(STATUS, status);

		executeCommand("wfe_ioPaymentsPaymentRequestUpdateStatus", inputArgs);
	}
	
	@Override
	public void updatePaymentRequestLastTransaction(long paymentRequestId, long lastProcessedTransactionId) 
			throws DAOException{
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(PAYMENT_REQUEST_ID, paymentRequestId);
		inputArgs.put(LAST_PROCESSED_TRANSACTION_ID, lastProcessedTransactionId);

		executeCommand("wfe_ioPaymentsPaymentRequestUpdateLastTransaction", inputArgs);
	}

	@Override
	public void updateTransactionStatus(long transactionId, String status) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(TRANSACTION_ID, transactionId);
		inputArgs.put(STATUS, status);

		executeCommand("wfe_ioPaymentsTransactionUpdateStatus", inputArgs);
	}

	@Override
	public void deleteRequestHeader(long requestHeaderId) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(REQUEST_HEADER_ID, requestHeaderId);

		executeCommand("wfe_ioPaymentsRequestHeaderDelete", inputArgs);
	}

	@Override
	public void deletePaymentRequest(long paymentRequestId) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(PAYMENT_REQUEST_ID, paymentRequestId);

		executeCommand("wfe_ioPaymentsPaymentRequestDelete", inputArgs);
	}

	@Override
	public void deleteTransaction(long transactionId) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(TRANSACTION_ID, transactionId);

		executeCommand("wfe_ioPaymentsTransactionDelete", inputArgs);
	}

	@Override
	public void updatePaymentCount(long paymentRequestId, int count, Connection con) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(PAYMENT_REQUEST_ID, paymentRequestId);
		inputArgs.put("count", count);

		executeCommand(con, "wfe_ioPaymentsPaymentRequestUpdate", inputArgs);
	}

	/**
	 * Resolve the given alias to a proper destination according to the given
	 * type.
	 */
	@Override
	public String resolveAlias(String alias, String type) throws DAOException {
		String result = null;

		Map<String, Object> inputArgs = new HashMap<>();

		inputArgs.put("_alias", alias);
		inputArgs.put("_respond_method", type);
		ResultSet rs = null;

		try (Connection con = dataSource.getConnection()) {
			rs = getResultSet(con, "MW_RESOLVE_RESPONDTO_ALIAS", inputArgs);
			if (rs.next()) {
				result = rs.getString("ADAPTER_COMMAND").trim();
			}
		} catch (SQLException e) {
			throw new DAOException(e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					logger.error(e);
				}
			}
		}

		return result;
	}

	@Override
	public void updateRequestHeaderResponseStatus(long requestHeaderId) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(REQUEST_HEADER_ID, requestHeaderId);

		executeCommand("wfe_ioPaymentsRequestHeaderUpdateResponseStatus", inputArgs);
	}

	@Override
	public void updateRequestHeaderLastRetry(long requestHeaderId, String status, int retryCount,
			boolean isRetry) 
			throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(REQUEST_HEADER_ID, requestHeaderId);
		inputArgs.put(STATUS, status);
		inputArgs.put("retryCount", retryCount);
		inputArgs.put("retryInd", isRetry ? 1 : 0);

		executeCommand("wfe_ioPaymentsRequestHeaderLastRetryUpdate", inputArgs);
	}

	/**
	 * Sets the RetryCount on the RequestHeader
	 */
	@Override
	public void setRequestHeaderRetryCount(long requestHeaderId, int retryCountLimit) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(REQUEST_HEADER_ID, requestHeaderId);
		inputArgs.put("retryCount", retryCountLimit);

		executeCommand("wfe_ioPaymentsRequestHeaderRetryCountUpdate", inputArgs);
	}
	
	/**
	 * Sets the RetryCount on the RequestHeader
	 */
	@Override
	public int getRetryCount(String processingEngineName) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put(PROCESSING_ENGINE_NAME, processingEngineName);
		RowSetDynaClass result = executeResultSet("usp_ProcessingEngineGetNoRetries", inputArgs);
		return (short)((BasicDynaBean)result.getRows().get(0)).get("numberofretries");
	}

	@Override
	public String getFileIntegritySalt(String sourceSystem) throws DAOException {
		Map<String, Object> inputArgs = new HashMap<>();
		inputArgs.put("SourceSystem", sourceSystem);

		RowSetDynaClass rs = executeResultSet("wfe_ioPaymentsGetSaltForSourceSystem", inputArgs);
		BasicDynaBean resultRow = (BasicDynaBean) rs.getRows().get(0);
		if (resultRow != null) {
			return (String) resultRow.get("salt");
		} else {
			throw new DAOException("No salt found for sourceSystem "+ sourceSystem);
		}
	}

}
