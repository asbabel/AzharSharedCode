package com.barclays.ebox.pay.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;


/**
 * PropertiesConfig - to point at XML config initially.
 * 
 * @author ABSN994
 */
@Configuration
public class EboxPayProperties {
	
	@Value("${datasource.mwdb.user}")
	private String mwdbCSCUser;
	@Value("${datasource.mwdb.password}")
	private String mwdbPassword;
	@Value("${datasource.mwdb.driver}")
	private String mwdbDriver;
	@Value("${datasource.mwdb.url}")
	private String mwdbUrl;
	@Value("${datasource.mwdb.max}")
	private String mwdbMax;
	@Value("${datasource.mwdb.timeout}")
	private String mwdbTimeout;
	@Value("${datasource.mwdb.eboxsupport.user}")
	private String mwdbEboxSupportUser;
	@Value("${datasource.mwdb.eboxsupport.password}")
	private String mwdbEboxSupportPassword;
	
	@Value("${INCOMINGFOLDER}")
	private String incomingFolder;
	@Value("${DONEFOLDER}")
	private String doneFolder;
	@Value("${RETRYFOLDER}")
	private String retryFolder;
	@Value("${REJECTFOLDER}")
	private String rejectFolder;
	
	@Value("${mq.port}")
	private String mqPort;
	@Value("${mq.hostname}")
	private String mqHostName;
	@Value("${mq.channel}")
	private String mqChannel;
	@Value("${mq.QManager}")
	private String mqQManager;
	@Value("${mq.inputQName}")
	private String mqInputQName;
	@Value("${mq.outputQName}")
	private String mqOutputQName;
	@Value("${max.queue.depth}")
	private int maxQueueDepth;
	@Value("${mq.polling.time}")
	private int mqPollingTime;
	@Value("${cmf.batch.size}")
	private int cmfBatchSize;
	
	@Value("${response.polling.time.minutes}")
	private int responsePollingTimeInMinutes;
	@Value("${retry.polling.time.minutes}")
	private int retryPollingTimeInMinutes;
	/**
	 * @return the mwdbCSCUser
	 */
	public String getMwdbCSCUser() {
		return mwdbCSCUser;
	}
	/**
	 * @param mwdbCSCUser the mwdbCSCUser to set
	 */
	public void setMwdbCSCUser(String mwdbCSCUser) {
		this.mwdbCSCUser = mwdbCSCUser;
	}
	/**
	 * @return the mwdbPassword
	 */
	public String getMwdbPassword() {
		return mwdbPassword;
	}
	/**
	 * @param mwdbPassword the mwdbPassword to set
	 */
	public void setMwdbPassword(String mwdbPassword) {
		this.mwdbPassword = mwdbPassword;
	}
	/**
	 * @return the mwdbDriver
	 */
	public String getMwdbDriver() {
		return mwdbDriver;
	}
	/**
	 * @param mwdbDriver the mwdbDriver to set
	 */
	public void setMwdbDriver(String mwdbDriver) {
		this.mwdbDriver = mwdbDriver;
	}
	/**
	 * @return the mwdbUrl
	 */
	public String getMwdbUrl() {
		return mwdbUrl;
	}
	/**
	 * @param mwdbUrl the mwdbUrl to set
	 */
	public void setMwdbUrl(String mwdbUrl) {
		this.mwdbUrl = mwdbUrl;
	}
	/**
	 * @return the mwdbMax
	 */
	public String getMwdbMax() {
		return mwdbMax;
	}
	/**
	 * @param mwdbMax the mwdbMax to set
	 */
	public void setMwdbMax(String mwdbMax) {
		this.mwdbMax = mwdbMax;
	}
	/**
	 * @return the mwdbTimeout
	 */
	public String getMwdbTimeout() {
		return mwdbTimeout;
	}
	/**
	 * @param mwdbTimeout the mwdbTimeout to set
	 */
	public void setMwdbTimeout(String mwdbTimeout) {
		this.mwdbTimeout = mwdbTimeout;
	}
	/**
	 * @return the mwdbEboxSupportUser
	 */
	public String getMwdbEboxSupportUser() {
		return mwdbEboxSupportUser;
	}
	/**
	 * @param mwdbEboxSupportUser the mwdbEboxSupportUser to set
	 */
	public void setMwdbEboxSupportUser(String mwdbEboxSupportUser) {
		this.mwdbEboxSupportUser = mwdbEboxSupportUser;
	}
	/**
	 * @return the mwdbEboxSupportPassword
	 */
	public String getMwdbEboxSupportPassword() {
		return mwdbEboxSupportPassword;
	}
	/**
	 * @param mwdbEboxSupportPassword the mwdbEboxSupportPassword to set
	 */
	public void setMwdbEboxSupportPassword(String mwdbEboxSupportPassword) {
		this.mwdbEboxSupportPassword = mwdbEboxSupportPassword;
	}
	/**
	 * @return the incomingFolder
	 */
	public String getIncomingFolder() {
		return incomingFolder;
	}
	/**
	 * @param incomingFolder the incomingFolder to set
	 */
	public void setIncomingFolder(String incomingFolder) {
		this.incomingFolder = incomingFolder;
	}
	/**
	 * @return the doneFolder
	 */
	public String getDoneFolder() {
		return doneFolder;
	}
	/**
	 * @param doneFolder the doneFolder to set
	 */
	public void setDoneFolder(String doneFolder) {
		this.doneFolder = doneFolder;
	}
	/**
	 * @return the retryFolder
	 */
	public String getRetryFolder() {
		return retryFolder;
	}
	/**
	 * @param retryFolder the retryFolder to set
	 */
	public void setRetryFolder(String retryFolder) {
		this.retryFolder = retryFolder;
	}
	/**
	 * @return the rejectFolder
	 */
	public String getRejectFolder() {
		return rejectFolder;
	}
	/**
	 * @param rejectFolder the rejectFolder to set
	 */
	public void setRejectFolder(String rejectFolder) {
		this.rejectFolder = rejectFolder;
	}
	/**
	 * @return the mqPort
	 */
	public String getMqPort() {
		return mqPort;
	}
	/**
	 * @param mqPort the mqPort to set
	 */
	public void setMqPort(String mqPort) {
		this.mqPort = mqPort;
	}
	/**
	 * @return the mqHostName
	 */
	public String getMqHostName() {
		return mqHostName;
	}
	/**
	 * @param mqHostName the mqHostName to set
	 */
	public void setMqHostName(String mqHostName) {
		this.mqHostName = mqHostName;
	}
	/**
	 * @return the mqChannel
	 */
	public String getMqChannel() {
		return mqChannel;
	}
	/**
	 * @param mqChannel the mqChannel to set
	 */
	public void setMqChannel(String mqChannel) {
		this.mqChannel = mqChannel;
	}
	/**
	 * @return the mqQManager
	 */
	public String getMqQManager() {
		return mqQManager;
	}
	/**
	 * @param mqQManager the mqQManager to set
	 */
	public void setMqQManager(String mqQManager) {
		this.mqQManager = mqQManager;
	}
	/**
	 * @return the mqInputQName
	 */
	public String getMqInputQName() {
		return mqInputQName;
	}
	/**
	 * @param mqInputQName the mqInputQName to set
	 */
	public void setMqInputQName(String mqInputQName) {
		this.mqInputQName = mqInputQName;
	}
	/**
	 * @return the mqOutputQName
	 */
	public String getMqOutputQName() {
		return mqOutputQName;
	}
	/**
	 * @param mqOutputQName the mqOutputQName to set
	 */
	public void setMqOutputQName(String mqOutputQName) {
		this.mqOutputQName = mqOutputQName;
	}
	public int getMaxQueueDepth() {
		return maxQueueDepth;
	}
	public void setMaxQueueDepth(int maxQueueDepth) {
		this.maxQueueDepth = maxQueueDepth;
	}
	public int getMqPollingTime() {
		return mqPollingTime;
	}
	public void setMqPollingTime(int mqPollingTime) {
		this.mqPollingTime = mqPollingTime;
	}
	/**
	 * @return the cmfBatchSize
	 */
	public int getCmfBatchSize() {
		return cmfBatchSize;
	}
	/**
	 * @param cmfBatchSize the cmfBatchSize to set
	 */
	public void setCmfBatchSize(int cmfBatchSize) {
		this.cmfBatchSize = cmfBatchSize;
	}
	/**
	 * @return the responsePollingTimeInMinutes
	 */
	public int getResponsePollingTimeInMinutes() {
		return responsePollingTimeInMinutes;
	}
	/**
	 * @param responsePollingTimeInMinutes the responsePollingTimeInMinutes to set
	 */
	public void setResponsePollingTimeInMinutes(int responsePollingTimeInMinutes) {
		this.responsePollingTimeInMinutes = responsePollingTimeInMinutes;
	}
	/**
	 * @return the retryPollingTimeInMinutes
	 */
	public int getRetryPollingTimeInMinutes() {
		return retryPollingTimeInMinutes;
	}
	/**
	 * @param retryPollingTimeInMinutes the retryPollingTimeInMinutes to set
	 */
	public void setRetryPollingTimeInMinutes(int retryPollingTimeInMinutes) {
		this.retryPollingTimeInMinutes = retryPollingTimeInMinutes;
	}
	
	
}
