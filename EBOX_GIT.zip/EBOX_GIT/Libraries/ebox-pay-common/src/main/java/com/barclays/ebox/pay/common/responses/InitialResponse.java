package com.barclays.ebox.pay.common.responses;

import java.io.Serializable;

public abstract class InitialResponse implements Serializable {
    private Type responseType;
    private Long id;

    public enum Type {
        ACK, NAK
    }

    public InitialResponse(Type responseType, Long id) {
        this.responseType = responseType;
        this.id = id;
    }

    public Type getResponseType() {
        return responseType;
    }

    public void setResponseType(Type responseType) {
        this.responseType = responseType;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InitialResponse that = (InitialResponse) o;

        if (responseType != that.responseType) return false;
        return id.equals(that.id);

    }

    @Override
    public int hashCode() {
        int result = responseType.hashCode();
        result = 31 * result + id.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "InitialResponse{" +
                "responseType=" + responseType +
                ", id=" + id +
                '}';
    }
}
