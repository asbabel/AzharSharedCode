package com.barclays.ebox.pay.common.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.sql.DataSource;

import com.barclays.ebox.pay.common.dao.util.ResourceUtil;
import org.apache.commons.beanutils.RowSetDynaClass;
import org.springframework.beans.factory.annotation.Autowired;
import com.barclays.ebox.pay.domain.exception.DAOException;
import com.barclays.generic.business.utils.LoggerConnection;

/**
 * Super class for all DAOImpl. It provides the datasource / connection and low
 * level stored procedure operations
 * 
 * @author abrma5s
 *
 */
public class BaseDAOImpl {
	@Autowired
	protected DataSource dataSource;
	protected LoggerConnection logger = new LoggerConnection(BaseDAOImpl.class);

	/**
	 * Standard method to execute Store procedures that returns a value and uses
	 * the provided connection which is part of a transaction
	 * 
	 * @param con Connection to use
	 * @param procedureName SP name
	 * @param inParameters SP params
	 * @return RowSetDynaClass The result of the query
	 * @throws DAOException
	 */
	RowSetDynaClass executeResultSet(Connection con, String procedureName, Map<String, Object> inParameters)
			throws DAOException {
		RowSetDynaClass returnValue = null;
		CallableStatement cs = null;
		try {
			cs = prepareStatement(con, procedureName, inParameters);
			returnValue = executeCallableStatement(cs);
		} catch (SQLException se) {
			throw new DAOException(se);
		} finally {
			releaseResources(cs);
		}
		return returnValue;
	}

	/**
	 * Standard method to execute Store procedures that returns a value
	 * @param procedureName SP name
	 * @param inParameters SP params
	 * @return RowSetDynaClass results of query
	 * @throws DAOException
     */
	protected RowSetDynaClass executeResultSet(String procedureName, Map<String, Object> inParameters)
			throws DAOException {
		RowSetDynaClass returnValue = null;
		CallableStatement cs = null;
		Connection con = null;
		try {
			con = getConnection();
			cs = prepareStatement(con, procedureName, inParameters);
			returnValue = executeCallableStatement(cs);
		} catch (SQLException se) {
			throw new DAOException(se);
		} finally {
			releaseResources(cs, con);
		}
		return returnValue;
	}

	protected Connection getConnection() throws DAOException {
		try {
			return dataSource.getConnection();
		} catch (SQLException sqle) {
			throw new DAOException(sqle);
		}
	}

	/**
	 * Standard method to execute Store procedures that returns a ResultSet and
	 * uses the provided connection which is part of a transaction
	 * 
	 * @param con Connection to use
	 * @param procedureName SP name
	 * @param inParameters SP params
	 * @return ResultSet the result of the query
	 * @throws DAOException
	 */
	protected ResultSet getResultSet(Connection con, String procedureName, Map<String, Object> inParameters)
			throws DAOException {

		ResultSet returnValue;
		CallableStatement cs;
		try {
			cs = prepareStatement(con, procedureName, inParameters);
			returnValue = cs.executeQuery();
		} catch (SQLException se) {
			throw new DAOException(se);
		}
		return returnValue;
	}

	/**
	 * Standard method to execute Store procedures that returns a ResultSet
	 *
	 * @param procedureName SP name
	 * @param inParameters SP params
	 * @return ResultSet the result of this query
	 * @throws DAOException
	 */
	public ResultSet getResultSet(String procedureName, Map<String, Object> inParameters) throws DAOException {
		ResultSet returnValue = null;
		CallableStatement cs = null;
		Connection con = null;
		try {
			con = getConnection();
			cs = prepareStatement(con, procedureName, inParameters);
			returnValue = cs.executeQuery();
		} catch (SQLException se) {
			throw new DAOException(se);
		} finally {
			releaseResources(cs, con);
		}
		return returnValue;
	}

	/**
	 * Standard method to execute Store procedures that do not return a value
	 * 
	 * @param procedureName SP name
	 * @param inParameters SP params
	 * @throws DAOException
	 */
	protected void executeCommand(String procedureName, Map<String, Object> inParameters) throws DAOException {
		CallableStatement cs = null;
		Connection con = null;
		try {
			con = getConnection();
			cs = prepareStatement(con, procedureName, inParameters);
			cs.executeUpdate();
		} catch (SQLException se) {
			throw new DAOException(se);
		} finally {
			releaseResources(cs, con);
		}
	}

	/**
	 * Standard method to execute Store procedures that do not return a value
	 * and uses the provided connection which is part of a transaction
	 * 
	 * @param con The Connection to use
	 * @param procedureName SP name
	 * @param inParameters SP params
	 * @throws DAOException
	 */
	void executeCommand(Connection con, String procedureName, Map<String, Object> inParameters)
			throws DAOException {

		CallableStatement cs = null;
		try {
			cs = prepareStatement(con, procedureName, inParameters);
			cs.executeUpdate();
		} catch (SQLException se) {
			throw new DAOException(se);
		} finally {
			releaseResources(cs);
		}
	}

	private CallableStatement prepareStatement(Connection con, String procedureName, Map<String, Object> inParameters)
			throws SQLException {
		CallableStatement cs = con.prepareCall(buildStoredProcedureSQL(procedureName, inParameters));
		if (inParameters != null) {
			int pos = 1;
			for (Entry<String, Object> entry : inParameters.entrySet()) {
				String name = entry.getKey();
				if (inParameters.get(name) == null) {
					cs.setNull(pos, java.sql.Types.VARCHAR);
				} else {
					setParameter(inParameters, cs, pos, name);
				}
				pos++;
			}
		}
		return cs;
	}

	private void setParameter(Map<String, Object> inParameters, CallableStatement cs, int pos, String name)
			throws SQLException {
		Object tmpObj = inParameters.get(name);
		if (tmpObj instanceof com.ibm.math.BigDecimal) {
			tmpObj = new java.math.BigDecimal(tmpObj.toString());
		}
		cs.setObject(pos, tmpObj);
	}

	private RowSetDynaClass executeCallableStatement(CallableStatement cs) throws DAOException {
		RowSetDynaClass returnValue;
		try (ResultSet rs = cs.executeQuery()) {
			returnValue = new RowSetDynaClass(rs);
		} catch (SQLException se) {
			throw new DAOException(se);
		}
		return returnValue;
	}

	private String buildStoredProcedureSQL(String procedureName, Map<String, Object> parameters) {
		StringBuilder sql = new StringBuilder();
		sql.append("exec ");
		sql.append(procedureName);
		if (parameters != null) {
			for (Iterator<String> i = parameters.keySet().iterator(); i.hasNext();) {
				String name = i.next();
				sql.append(" @");
				sql.append(name);
				sql.append("=?");
				if (i.hasNext()) {
					sql.append(",");
				}
			}
		}
		return sql.toString();
	}

	private void releaseResources(AutoCloseable... resources) {
		ResourceUtil.releaseResources(resources);
	}
}
