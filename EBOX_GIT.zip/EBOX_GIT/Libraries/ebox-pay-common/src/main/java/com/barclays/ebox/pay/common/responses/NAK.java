package com.barclays.ebox.pay.common.responses;

public class NAK extends InitialResponse {
    public NAK(Long id) {
        super(Type.NAK, id);
    }
}
