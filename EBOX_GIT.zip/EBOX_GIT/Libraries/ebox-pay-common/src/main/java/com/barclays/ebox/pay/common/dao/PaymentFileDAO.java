package com.barclays.ebox.pay.common.dao;

import java.io.File;
import java.sql.Connection;
import java.util.List;

import com.barclays.ebox.pay.domain.PaymentRequest;
import com.barclays.ebox.pay.domain.RequestHeader;
import com.barclays.ebox.pay.domain.Transaction;
import com.barclays.ebox.pay.domain.exception.DAOException;
import com.barclays.ebox.pay.domain.exception.FailAppException;

/**
 * Data Access Object for PaymentRequest , RequestHeader and Transaction related
 * Database operations
 * 
 * @author abrma5s
 *
 */
public interface PaymentFileDAO {
	/**
	 * Inserts a RequestHeader record contained in the provided file
	 * 
	 * @param paymentFile The bulk payment file
	 * @return the request header id of the newly inserted bulk payment file
	 * @throws DAOException
	 */
	long insertRequestHeader(File paymentFile) throws DAOException;

	/**
	 * Inserts a PaymentRequest record
	 * 
	 * @param paymentRequest The Payment request object to insert
	 * @param con The Connection object to use
	 * @return The Id of the inserted Payment Request
	 * @throws DAOException
	 */
	long insertPaymentRequest(PaymentRequest paymentRequest, Connection con) throws DAOException;

	/**
	 * Inserts a Transaction record
	 * 
	 * @param transaction The Transaction object to insert
	 * @param paySource The Payment request object on which to insert a Transaction
	 * @param con The Connection object to use
	 * @throws DAOException
	 */
	void insertTransaction(Transaction transaction, PaymentRequest paySource, Connection con) throws DAOException;

	/**
	 * Retrieves ReuqestHeader by the provided RequestHeaderId
	 * 
	 * @param requestHeaderId the request header id we seek
	 * @return The RequestHeader object found
	 * @throws DAOException
	 */
	RequestHeader getRequestHeaderById(long requestHeaderId) throws DAOException;

	/**
	 * Retrieves ReuqestHeader by the provided Status
	 * 
	 * @param status The Status to filter Request headers by
	 * @return A List of RequestHeaders that match the provided status.
	 * @throws DAOException
	 */
	List<RequestHeader> getRequestHeaderByStatus(String status) throws DAOException;

	/**
	 * Retrieves all PaymentRequests associated with the provided
	 * RequestHeaderId
	 * 
	 * @param requestHeaderId the request header id
	 * @return A List of PaymentRequest objects that match the provided request header id
	 * @throws DAOException
	 */
	List<PaymentRequest> getPaymentRequests(long requestHeaderId) throws DAOException;

	/**
	 * Retrieves all Transactions associated with a PaymentRequest
	 * 
	 * @param pr The Payment request object
	 * @param rsHandler The ResultSetCallBack class that will handle the result of this query
	 * @throws DAOException
	 */
	void getTransactions(PaymentRequest pr, ResultSetCallback<PaymentRequest> rsHandler,
			long lastProcessedTransactionId) 
			throws DAOException, FailAppException;

	/**
	 * Retrieves all Transactions associated with a PaymentRequest whose
	 * RequestHeader status = RETRY
	 * 
	 * @param pr The Payment request object
	 * @param rsHandler The ResultSetCallBack class that will handle the result of this query
	 * @throws DAOException
	 */
	void getRetryTransactions(PaymentRequest pr, ResultSetCallback<PaymentRequest> rsHandler) 
			throws DAOException, FailAppException;

	/**
	 * Updates a RequestHeader
	 * 
	 * @param header the RequestHeader object to update
	 * @throws DAOException
	 */
	void updateRequestHeader(RequestHeader header) throws DAOException;

	/**
	 * Updates a RequestHeader with the provided status and error code
	 * 
	 * @param requestHeaderId the request header id
	 * @param status The status to set on the Request Header
	 * @param errorCode The Error code to set on the Request Header
	 * @throws DAOException
	 */
	void updateRequestHeaderStatus(long requestHeaderId, String status, int errorCode) throws DAOException;

	/**
	 * Updates a PaymentRequest with the provided status
	 * 
	 * @param paymentRequestId The Payment request Id
	 * @param status The status to set on the Payment Request
	 * @throws DAOException
	 */
	void updatePaymentRequestStatus(long paymentRequestId, String status) throws DAOException;
	
	
	/**
	 * Updates a PaymentRequest with the last processed transaction id of batch
	 * 
	 * @param paymentRequestId The Payment request Id
	 * @param lastProcessedTransactionId the last successfully processed transaction id for this payment request
	 * @throws DAOException
	 */
	void updatePaymentRequestLastTransaction(long paymentRequestId, long lastProcessedTransactionId) 
			throws DAOException;

	/**
	 * Updates a Transaction with the provided status
	 * 
	 * @param transactionId The Transaction id
	 * @param status The status to set on this Transaction
	 * @throws DAOException
	 */
	void updateTransactionStatus(long transactionId, String status) throws DAOException;

	/**
	 * Deletes a RequestHeader
	 * 
	 * @param requestHeaderId the request header id
	 * @throws DAOException
	 */
	void deleteRequestHeader(long requestHeaderId) throws DAOException;

	/**
	 * Deletes a PaymentRequest
	 * 
	 * @param paymentRequestId The Payment request Id
	 * @throws DAOException
	 */
	void deletePaymentRequest(long paymentRequestId) throws DAOException;

	/**
	 * Deletes a Transaction
	 * 
	 * @param transactionId The Transaction Id of the Transaction to delete
	 * @throws DAOException
	 */
	void deleteTransaction(long transactionId) throws DAOException;

	/**
	 * updates the Payment Item Count
	 * 
	 * @param paymentRequestId The Payment request Id
	 * @param count The number of Transactions attached to this payment request
	 * @param con The Connection object to use
	 * @throws DAOException
	 */
	void updatePaymentCount(long paymentRequestId, int count, Connection con) throws DAOException;

	/**
	 * Gets the MQ Response Queue
	 * 
	 * @param alias The MQ alias
	 * @param type Q type
	 * @return The MQ response Q name
	 * @throws DAOException
	 */
	String resolveAlias(String alias, String type) throws DAOException;

	/**
	 * Updates the RequestHeader response status
	 * 
	 * @param requestHeaderId the request header id
	 * @throws DAOException
	 */
	void updateRequestHeaderResponseStatus(long requestHeaderId) throws DAOException;

	/**
	 * Decreases the Retry count and retry date when a RequestHeader is
	 * reprocessed
	 * 
	 * @param requestHeaderId ID of the RequestHeader object to update
	 * @throws DAOException
	 */
	void updateRequestHeaderLastRetry(long requestHeaderId, String status, int retryCount,
			boolean isRetry) throws DAOException;

	/**
	 * Sets the maximum retry count for a request header dependent on the
	 * processing engine
	 * 
	 * @param requestHeaderId the request header id
	 * @param retryCountLimit The retry count limit to set
	 * @throws DAOException
	 */
	void setRequestHeaderRetryCount(long requestHeaderId, int retryCountLimit) throws DAOException;
	
	/***
	 * Get the retry count for given processing engine name
	 * @param processingEngineName
	 * @return
	 * @throws DAOException
	 */
	public int getRetryCount(String processingEngineName) throws DAOException;

	/**
	 * Retrieves the Salt string for a given source system
	 *
	 * @param sourceSytem The source system for which we are seeking a Salt String
	 * @return The Salt for the requested Source System
	 * @throws DAOException
     */
	String getFileIntegritySalt(String sourceSytem) throws DAOException;
}
