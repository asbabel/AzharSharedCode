package com.barclays.ebox.pay.common.statemachine.impl;

import com.barclays.ebox.pay.common.statemachine.NullSafeEnumMatcher;
import com.barclays.ebox.pay.common.statemachine.State;
import com.barclays.ebox.pay.common.statemachine.util.StateUtil;

import java.util.List;

/**
 * State machine for PaymentRequest objects
 *
 */
public enum PaymentRequestState implements State, NullSafeEnumMatcher<PaymentRequestState> {
    READY, // The payment has been stored to MWDB and is awaiting processing by the Payment Pre-Processor
    PROCESSED, // The payment has been successfully processed by the File Receiver
    UNDEFINED;

    @Override
    public boolean matches(String value) {
        return matches(this, value);
    }

    @Override
    public PaymentRequestState defaultValue() {
        return UNDEFINED;
    }

    @Override
    public List<State> allowableTransitions() {
        switch (this) {
            case READY:
                return StateUtil.transitionList(PROCESSED);
            case PROCESSED:
                return StateUtil.transitionList();
            case UNDEFINED:
                return StateUtil.transitionList(READY);
            default:
                return StateUtil.transitionList();
        }
    }
}
