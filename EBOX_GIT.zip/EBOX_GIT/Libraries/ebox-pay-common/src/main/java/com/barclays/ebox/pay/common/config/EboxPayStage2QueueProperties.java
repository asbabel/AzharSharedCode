package com.barclays.ebox.pay.common.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * PropertiesConfig.
 *  Value for small medium and large queue are [0] = qName [1]= qRoute and are comma separated on the properties file
 * @author ABSN994
 */

@Configuration
public class EboxPayStage2QueueProperties {
	
	@Value("${medium.queue.threshold}")
	private int mediumQueueThreshold ;
	@Value("${large.queue.threshold}")
	private int largeQueueThreshold;
	@Value("${stage.to.queue.small}")
	private String[] smallQueue;
	@Value("${stage.to.queue.medium}")
	private String[] meduimQueue;
	@Value("${stage.to.queue.large}")
	private String[] largeQueue;
	/**
	 * @return the mediumQueueThreshold
	 */
	public int getMediumQueueThreshold() {
		return mediumQueueThreshold;
	}
	/**
	 * @param mediumQueueThreshold the mediumQueueThreshold to set
	 */
	public void setMediumQueueThreshold(int mediumQueueThreshold) {
		this.mediumQueueThreshold = mediumQueueThreshold;
	}
	/**
	 * @return the largeQueueThreshold
	 */
	public int getLargeQueueThreshold() {
		return largeQueueThreshold;
	}
	/**
	 * @param largeQueueThreshold the largeQueueThreshold to set
	 */
	public void setLargeQueueThreshold(int largeQueueThreshold) {
		this.largeQueueThreshold = largeQueueThreshold;
	}
	/**
	 * @return the smallQueue [0] = qName [1]= qRoute
	 */
	public String[] getSmallQueue() {
		return smallQueue;
	}
	/**
	 * @param smallQueue the smallQueue to set
	 */
	public void setSmallQueue(String[] queue) {
		if(queue != null) {
			this.smallQueue = Arrays.copyOf(queue, queue.length);
		}
		
	}
	/**
	 * @return the meduimQueue  [0] = qName [1]= qRoute
	 */
	public String[] getMeduimQueue() {
		return meduimQueue;
	}
	/**
	 * @param meduimQueue the meduimQueue to set
	 */
	public void setMeduimQueue(String[] medium) {
		if(medium != null){
			this.meduimQueue = Arrays.copyOf(medium, medium.length);
		}
	}
	/**
	 * @return the largeQueue [0] = qName [1]= qRoute
	 */
	public String[] getLargeQueue() {
		return largeQueue;
	}
	/**
	 * @param largeQueue the largeQueue to set
	 */
	public void setLargeQueue(String[] large) {
		if(large != null) {
			this.largeQueue = Arrays.copyOf(large, large.length);
		}
	}
}
