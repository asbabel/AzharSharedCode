package com.barclays.ebox.pay.common.dao.impl;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.barclays.ebox.pay.common.dao.ResultSetCallback;
import com.barclays.ebox.pay.domain.PaymentRequest;
import com.barclays.ebox.pay.domain.RequestHeader;
import com.barclays.ebox.pay.domain.Transaction;
import com.barclays.ebox.pay.domain.exception.DAOException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring/Beans.xml")
@DirtiesContext
public class PaymentFileDAOImplTestNonBuild {

	@Autowired
	private PaymentFileDAOImpl paymentFileDao;
	
	@Autowired
	private DataSource dataSource;

	@Test
	public void testPaymenDao() throws Exception {
		File paymentFile = new File("src/test/resources/testfiles/BIR_junit.xml");
		long requestHeaderId = paymentFileDao.insertRequestHeader(paymentFile);
		RequestHeader.Builder requestHeader = new RequestHeader.Builder();
		
		requestHeader.setRequestHeaderId(requestHeaderId);
		requestHeader.setAccountingToken("BIR");
		requestHeader.setMessageId("60907268-087b-11e6-9602-2335338d0000");
		requestHeader.setProjectId("BIR");
		requestHeader.setPropertyAdjustBalance("YES");
		requestHeader.setPropertyBatch("NO");
		requestHeader.setPropertyCheckAccount("YES");
		
		requestHeader.setPropertyUserId("IFE");
		requestHeader.setRespondTo("ECHANNEL_RESPONSE_QUEUE");
		requestHeader.setRespondToType("Queue");
		requestHeader.setSourceApplFunc("PostPayment");
		requestHeader.setSourceApplName("BIR");
		requestHeader.setTargetCountry("ZM");
		requestHeader.setTransactionId("14613236041235");
		requestHeader.setUserIdentity("WDC");
		requestHeader.setUserPassword("product1on");
		
		RequestHeader rh = requestHeader.build();
		
		paymentFileDao.updateRequestHeader(rh);
		
		PaymentRequest.Builder paymentRequest = new PaymentRequest.Builder();
		
		paymentRequest.setRequestHeader(rh);
		paymentRequest.setAccountNo("1029379");
		paymentRequest.setType("TRANSFER");
		paymentRequest.setDebitCreditInd("D");
		paymentRequest.setCcy("GBP");
		paymentRequest.setBranchId("55");
		paymentRequest.setAmount(new BigDecimal("13000.0"));
		paymentRequest.setTypeDescription("TRANSFER");
		paymentRequest.setOriginatorName("WILKINSON HARRIET ELIZABETH");
		paymentRequest.setOriginatorAddress1("Address 1");
		paymentRequest.setOriginatorAddress2("Address 2");
		paymentRequest.setOriginatorAddress3("Address 3");
		paymentRequest.setNarrative("hhd expenses");
		paymentRequest.setTransactionsInGroup(1);
		
		PaymentRequest pr = paymentRequest.build();
		
		long paymentRequestId = paymentFileDao.insertPaymentRequest(pr, dataSource.getConnection());
		pr.setPaymentRequestId(paymentRequestId);
		
		Transaction.Builder trx = new Transaction.Builder();
		
		
		trx.setAccountNumber("1022587");
		trx.setCcy("ZMW");
		trx.setBranchId("55");
		trx.setAmount(new BigDecimal("13000.0"));
		trx.setCounterPartyName("WILKINSON HARRIET ELIZABETH");
		trx.setCptyAddress1("Address 1");
		trx.setCptyAddress2("Address 2");
		trx.setCptyAddress3("Address 3");
		trx.setCounterPartyNarrative("hhd expenses");
		trx.setBankCode("50");
		trx.setRemittanceInfo("hhd expenses");
		trx.setDealRate("0.07522471");
		trx.setDealId("23");
		
		Transaction transaction = trx.build();

		paymentFileDao.insertTransaction(transaction, pr, dataSource.getConnection());
		
		RequestHeader rhGet = paymentFileDao.getRequestHeaderById(requestHeaderId);
		
		Assert.assertTrue(rhGet.getAccountingToken().equalsIgnoreCase("BIR"));
		Assert.assertTrue(rhGet.getMessageId().equalsIgnoreCase("60907268-087b-11e6-9602-2335338d0000"));
		Assert.assertTrue(rhGet.getProjectId().equalsIgnoreCase("BIR"));
		Assert.assertTrue(rhGet.getPropertyAdjustBalance().equalsIgnoreCase("YES"));
		Assert.assertTrue(rhGet.getPropertyBatch().equalsIgnoreCase("NO"));
		Assert.assertTrue(rhGet.getPropertyCheckAccount().equalsIgnoreCase("YES"));
		Assert.assertTrue(rhGet.getPropertyUserId().equalsIgnoreCase("IFE"));
		Assert.assertTrue(rhGet.getRespondTo().equalsIgnoreCase("ECHANNEL_RESPONSE_QUEUE"));
		Assert.assertTrue(rhGet.getRespondToType().equalsIgnoreCase("Queue"));
		Assert.assertTrue(rhGet.getSourceApplFunc().equalsIgnoreCase("PostPayment"));
		Assert.assertTrue(rhGet.getSourceApplName().equalsIgnoreCase("BIR"));
		Assert.assertTrue(rhGet.getTargetCountry().equalsIgnoreCase("ZM"));
		Assert.assertTrue(rhGet.getTransactionId().equalsIgnoreCase("14613236041235"));
		Assert.assertTrue(rhGet.getUserIdentity().equalsIgnoreCase("WDC"));
		Assert.assertTrue(rhGet.getUserPassword().equalsIgnoreCase("product1on"));

		List<PaymentRequest> paymentRequestList = paymentFileDao.getPaymentRequests(requestHeaderId);
		Assert.assertEquals(paymentRequestList.get(0).getAccountNo(), "1029379");
		Assert.assertEquals(paymentRequestList.get(0).getType(), "TRANSFER");
		Assert.assertEquals(paymentRequestList.get(0).getDebitCreditInd(), "D");
		Assert.assertEquals(paymentRequestList.get(0).getCcy(), "GBP");
		Assert.assertEquals(paymentRequestList.get(0).getBranchId(), "55");
		Assert.assertEquals(paymentRequestList.get(0).getAmount().toString().substring(0, 7), "13000.0");
		Assert.assertEquals(paymentRequestList.get(0).getTypeDescription(), "TRANSFER");
		Assert.assertEquals(paymentRequestList.get(0).getOriginatorName(), "WILKINSON HARRIET ELIZABETH");
		Assert.assertEquals(paymentRequestList.get(0).getOriginatorAddress1(), "Address 1");
		Assert.assertEquals(paymentRequestList.get(0).getOriginatorAddress2(), "Address 2");
		Assert.assertEquals(paymentRequestList.get(0).getOriginatorAddress3(), "Address 3");
		Assert.assertEquals(paymentRequestList.get(0).getNarrative(), "hhd expenses");
		Assert.assertEquals(paymentRequestList.get(0).getTransactionsInGroup(), 1);

		ResultSetCallback<PaymentRequest> rsHandler = new ResultSetCallback<PaymentRequest>() {

			@Override
			public void handleResultSet(ResultSet rs, PaymentRequest pr) throws DAOException {
				try {
					while (rs.next()) {
						byte[] transactionAsBytes = rs.getBytes("transactionObject");
						Transaction trx = getTransaction(transactionAsBytes);
						trx.setTransactionId(rs.getLong("transactionId"));
						Assert.assertEquals(trx.getAccountNumber(), "1022587");
						Assert.assertEquals(trx.getCcy(), "ZMW");
						Assert.assertEquals(trx.getBranchId(), "55");
						Assert.assertEquals(trx.getAmount().toString(), "13000.0");
						Assert.assertEquals(trx.getCounterPartyName(), "WILKINSON HARRIET ELIZABETH");
						Assert.assertEquals(trx.getCptyAddress1(), "Address 1");
						Assert.assertEquals(trx.getCptyAddress2(), "Address 2");
						Assert.assertEquals(trx.getCptyAddress3(), "Address 3");
						Assert.assertEquals(trx.getCounterPartyNarrative(), "hhd expenses");
						Assert.assertEquals(trx.getBankCode(), "50");
						Assert.assertEquals(trx.getRemittanceInfo(), "hhd expenses");
						Assert.assertEquals(trx.getDealRate(), "0.07522471");
						Assert.assertEquals(trx.getDealId(), "23");

						paymentFileDao.deleteTransaction(trx.getTransactionId());
					}
				} catch (SQLException | ClassNotFoundException | IOException e) {
					throw new DAOException(e);
				}
			}
		};

		for (PaymentRequest prr : paymentRequestList) {
			paymentFileDao.getTransactions(prr, rsHandler, 0);
			paymentFileDao.deletePaymentRequest(prr.getPaymentRequestId());
		}

		List<PaymentRequest> paymentRequestListAfterDelete = paymentFileDao
				.getPaymentRequests(rh.getRequestHeaderId());

		Assert.assertEquals(0, paymentRequestListAfterDelete.size());

		paymentFileDao.deleteRequestHeader(rh.getRequestHeaderId());

		RequestHeader rHeaderPostDelete = paymentFileDao.getRequestHeaderById(rh.getRequestHeaderId());

		Assert.assertEquals(null, rHeaderPostDelete);

	}

	private Transaction getTransaction(byte[] transactionAsBytes) throws ClassNotFoundException, IOException {

		ByteArrayInputStream bais = new ByteArrayInputStream(transactionAsBytes);
		ObjectInputStream ois = new ObjectInputStream(bais);
		Transaction tx = (Transaction) ois.readObject();

		return tx;
	}

}
