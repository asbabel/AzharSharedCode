package com.barclays.ebox.pay.common.statemachine.impl

import com.barclays.ebox.pay.common.statemachine.State
import spock.lang.Specification
import spock.lang.Stepwise
import spock.lang.Unroll

import static com.barclays.ebox.pay.common.statemachine.impl.RequestHeaderState.*

@Stepwise
class RequestHeaderStateTest extends Specification {

    @Unroll
    def "RequestHeader allowable transitions for #fromState"(State fromState, List<State> expectedAllowedTransitions) {
        given:
        List<State> actualAllowedTransitions = new ArrayList<>()

        when:
        actualAllowedTransitions = fromState.allowableTransitions()

        then:
        actualAllowedTransitions == expectedAllowedTransitions

        where:
        fromState | expectedAllowedTransitions
        START     | [RETRYLOAD, READY]
        RETRYLOAD | [START]
        READY     | [RETRY, REJECT, PROCESSED, ERROR]
        RETRY     | [ERROR, READY]
        PROCESSED | []
        ERROR     | []
        UNDEFINED | [START]
    }
}
