package com.barclays.ebox.pay.common.statemachine.impl

import com.barclays.ebox.pay.common.statemachine.State
import spock.lang.Specification
import spock.lang.Stepwise
import spock.lang.Unroll

import static com.barclays.ebox.pay.common.statemachine.impl.TransactionState.*

@Stepwise
class TransactionStateTest extends Specification {

    @Unroll
    def "Transaction allowable transitions for #fromState"(State fromState, List<State> expectedAllowedTransitions) {
        given:
        List<State> actualAllowedTransitions = new ArrayList<>()

        when:
        actualAllowedTransitions = fromState.allowableTransitions()

        then:
        assert actualAllowedTransitions == expectedAllowedTransitions

        where:
        fromState | expectedAllowedTransitions
        READY     | []
        UNDEFINED | [READY]
    }
}
