package com.barclays.ebox.pay.common.statemachine;

import com.barclays.ebox.pay.common.statemachine.impl.PaymentRequestState;
import com.barclays.ebox.pay.common.statemachine.impl.PaymentStateMachine;
import com.barclays.ebox.pay.common.statemachine.impl.RequestHeaderState;
import com.barclays.ebox.pay.common.statemachine.impl.TransactionState;
import org.junit.Assert;
import org.junit.Assume;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import java.util.function.Consumer;
import java.util.stream.Stream;

public class PaymentStateMachineTest {
    private PaymentStateMachine sut ;

    @Before
    public void setUp() throws Exception {
        sut = new PaymentStateMachine();
    }

    @Test
    public void changeState_RH_validTransitions() throws Exception {
        Stream.of(RequestHeaderState.values()).forEach( testAllAllowableStateTransitions() );
        Assert.assertTrue(true);
    }

    @Test
    public void changeState_PR_validTransitions() throws Exception {
        Stream.of(PaymentRequestState.values()).forEach( testAllAllowableStateTransitions() );
        Assert.assertTrue(true);
    }

    @Test
    public void changeState_TX_validTransitions() throws Exception {
        Stream.of(TransactionState.values()).forEach( testAllAllowableStateTransitions() );
        Assert.assertTrue(true);
    }

    @Test (expected = InvalidStateTransitionException.class)
    public void changeState_RH_invalidTransition() throws Exception {
        RequestHeaderState invalidFrom = RequestHeaderState.PROCESSED;
        RequestHeaderState invalidTo = RequestHeaderState.RETRYLOAD;

        // check this transition is invalid
        Assert.assertFalse(invalidFrom.allowableTransitions().contains(invalidTo));

        // try to change state should throw exception
        testChangeState(invalidFrom, invalidTo);
    }

    @Test (expected = InvalidStateTransitionException.class)
    public void changeState_PR_invalidTransition() throws Exception {
        PaymentRequestState invalidFrom = PaymentRequestState.PROCESSED;
        PaymentRequestState invalidTo = PaymentRequestState.READY;

        // check this transition is invalid
        Assert.assertFalse(invalidFrom.allowableTransitions().contains(invalidTo));

        // try to change state should throw exception
        testChangeState(invalidFrom, invalidTo);
    }

    @Test (expected = InvalidStateTransitionException.class)
    public void changeState_TX_invalidTransition() throws Exception {
        TransactionState invalidFrom = TransactionState.READY;
        TransactionState invalidTo = TransactionState.READY;

        // check this transition is invalid
        Assert.assertFalse(invalidFrom.allowableTransitions().contains(invalidTo));

        // try to change state should throw exception
        testChangeState(invalidFrom, invalidTo);
    }

    // Iterates through all State.allowableTransitions, and checks the State machine will allow
    //  all transitions without throwing an exception.
    private <T extends State> Consumer<T> testAllAllowableStateTransitions() {
        return stateFrom -> stateFrom.allowableTransitions().forEach(
            stateTo -> {
                try {
                    testChangeState(stateFrom, stateTo);
                } catch (InvalidStateTransitionException e) {
                    Assert.fail("State machine did not allow a Transition that should be allowable for ["+ stateFrom.getClass().getName()+"]: "+stateFrom + "->"+ stateTo);
                }
            }
        );
    }

    private void testChangeState(State from, State to) throws InvalidStateTransitionException {
        System.out.print("Testing transition for ["+ from.getClass().getName()+"]:"+ from + "->"+ to);
        try {
            sut.changeState(from, to);
        } catch (InvalidStateTransitionException e) {
            System.out.println(" FAIL");
            throw e;
        }
        System.out.println(" OK");
    }
}