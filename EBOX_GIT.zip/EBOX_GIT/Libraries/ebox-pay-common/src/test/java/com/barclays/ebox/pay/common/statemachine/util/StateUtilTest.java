package com.barclays.ebox.pay.common.statemachine.util;

import com.barclays.ebox.pay.common.statemachine.State;
import com.barclays.ebox.pay.common.statemachine.impl.PaymentRequestState;
import com.barclays.ebox.pay.common.statemachine.impl.RequestHeaderState;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.Assert.*;

/**
 * Created by g01025860 on 01/03/2017.
 */
public class StateUtilTest {
    @Test
    public void transitionsListTest () {
        State[] states = {
                PaymentRequestState.READY,
                PaymentRequestState.PROCESSED,
                RequestHeaderState.RETRY,
                RequestHeaderState.RETRYLOAD,
                RequestHeaderState.START};

        List<State> stateList = StateUtil.transitionList(states);

        // assert both ways
        assertTrue(Stream.of(states).allMatch(stateList::contains));
        assertTrue(stateList.stream().allMatch(state -> Arrays.asList(states).contains(state) ) );
    }

    @Test
    public void transitionsListTestNegativeTest () {
        State[] states = {
                PaymentRequestState.READY,
                PaymentRequestState.PROCESSED,
                RequestHeaderState.RETRY,
                RequestHeaderState.RETRYLOAD,
                RequestHeaderState.START};

        List<State> stateList = StateUtil.transitionList(states);
        stateList.add(RequestHeaderState.UNDEFINED);

        // assert both ways
        assertTrue(Stream.of(states).allMatch(stateList::contains));
        assertFalse(stateList.stream().allMatch(state -> Arrays.asList(states).contains(state) ) );
    }
}