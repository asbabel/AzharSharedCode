package com.barclays.ebox.pay.domain;

import java.util.Date;

import com.barclays.ebox.pay.domain.builder.BuilderPattern;

/**
 * This POJO represents fields that are not directly obtained from the input
 * File/MQ and must be computed by eBOX/BRAINS in various ways.
 * 
 * This may include enriched information about the originator, counterparty,
 * amounts, etc.
 */
@SuppressWarnings("all")
public final class EnrichedFields implements DomainObject {
	private static final long serialVersionUID = -2576427780664247201L;

	private String rqUID;
	private String settlementDays;
	private String exchangeRate;
	private String exchangeRateFormat;
	private String exchangeDetails;
	private String originatorRatePackage;
	private String originatorRate;
	private String originatorSellMarkup;
	private String originatorBuyMarkup;
	private String originatorMidRate;
	private String cptyTransactionAmtRate;
	private String cptyRatePackage;
	private String cptyRate;
	private String cptySellMarkup;
	private String cptyBuyMarkup;
	private String cptyMidRate;

	// AdditionalRef
	private String originatorStpLimit;
	private String cptyStpLimit;
	private String deferClientEntry;
	private boolean localPayment;
	private Date timestamp;

	private EnrichedFields(Builder builder) {
		this.rqUID = builder.rqUID;
		this.settlementDays = builder.settlementDays;
		this.exchangeRate = builder.exchangeRate;
		this.exchangeRateFormat = builder.exchangeRateFormat;
		this.exchangeDetails = builder.exchangeDetails;
		this.originatorRatePackage = builder.originatorRatePackage;
		this.originatorRate = builder.originatorRate;
		this.originatorSellMarkup = builder.originatorSellMarkup;
		this.originatorBuyMarkup = builder.originatorBuyMarkup;
		this.originatorMidRate = builder.originatorMidRate;
		this.cptyTransactionAmtRate = builder.cptyTransactionAmtRate;
		this.cptyRatePackage = builder.cptyRatePackage;
		this.cptyRate = builder.cptyRate;
		this.cptySellMarkup = builder.cptySellMarkup;
		this.cptyBuyMarkup = builder.cptyBuyMarkup;
		this.cptyMidRate = builder.cptyMidRate;
		this.originatorStpLimit = builder.originatorStpLimit;
		this.cptyStpLimit = builder.cptyStpLimit;
		this.deferClientEntry = builder.deferClientEntry;
		this.localPayment = builder.localPayment;
		this.timestamp = builder.timestamp;
	}

	public String getRqUID() {
		return rqUID;
	}

	public void setRqUID(String rqUID) {
		this.rqUID = rqUID;
	}

	public String getSettlementDays() {
		return settlementDays;
	}

	public void setSettlementDays(String settlementDays) {
		this.settlementDays = settlementDays;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getExchangeRateFormat() {
		return exchangeRateFormat;
	}

	public void setExchangeRateFormat(String exchangeRateFormat) {
		this.exchangeRateFormat = exchangeRateFormat;
	}

	public String getExchangeDetails() {
		return exchangeDetails;
	}

	public void setExchangeDetails(String exchangeDetails) {
		this.exchangeDetails = exchangeDetails;
	}

	public String getOriginatorRatePackage() {
		return originatorRatePackage;
	}

	public void setOriginatorRatePackage(String originatorRatePackage) {
		this.originatorRatePackage = originatorRatePackage;
	}

	public String getOriginatorRate() {
		return originatorRate;
	}

	public void setOriginatorRate(String originatorRate) {
		this.originatorRate = originatorRate;
	}

	public String getOriginatorSellMarkup() {
		return originatorSellMarkup;
	}

	public void setOriginatorSellMarkup(String originatorSellMarkup) {
		this.originatorSellMarkup = originatorSellMarkup;
	}

	public String getOriginatorBuyMarkup() {
		return originatorBuyMarkup;
	}

	public void setOriginatorBuyMarkup(String originatorBuyMarkup) {
		this.originatorBuyMarkup = originatorBuyMarkup;
	}

	public String getOriginatorMidRate() {
		return originatorMidRate;
	}

	public void setOriginatorMidRate(String originatorMidRate) {
		this.originatorMidRate = originatorMidRate;
	}

	public String getCptyTransactionAmtRate() {
		return cptyTransactionAmtRate;
	}

	public void setCptyTransactionAmtRate(String cptyTransactionAmtRate) {
		this.cptyTransactionAmtRate = cptyTransactionAmtRate;
	}

	public String getCptyRatePackage() {
		return cptyRatePackage;
	}

	public void setCptyRatePackage(String cptyRatePackage) {
		this.cptyRatePackage = cptyRatePackage;
	}

	public String getCptyRate() {
		return cptyRate;
	}

	public void setCptyRate(String cptyRate) {
		this.cptyRate = cptyRate;
	}

	public String getCptySellMarkup() {
		return cptySellMarkup;
	}

	public void setCptySellMarkup(String cptySellMarkup) {
		this.cptySellMarkup = cptySellMarkup;
	}

	public String getCptyBuyMarkup() {
		return cptyBuyMarkup;
	}

	public void setCptyBuyMarkup(String cptyBuyMarkup) {
		this.cptyBuyMarkup = cptyBuyMarkup;
	}

	public String getCptyMidRate() {
		return cptyMidRate;
	}

	public void setCptyMidRate(String cptyMidRate) {
		this.cptyMidRate = cptyMidRate;
	}

	public String getOriginatorStpLimit() {
		return originatorStpLimit;
	}

	public void setOriginatorStpLimit(String originatorStpLimit) {
		this.originatorStpLimit = originatorStpLimit;
	}

	public String getCptyStpLimit() {
		return cptyStpLimit;
	}

	public void setCptyStpLimit(String cptyStpLimit) {
		this.cptyStpLimit = cptyStpLimit;
	}

	public String getDeferClientEntry() {
		return deferClientEntry;
	}

	public void setDeferClientEntry(String deferClientEntry) {
		this.deferClientEntry = deferClientEntry;
	}

	public boolean isLocalPayment() {
		return localPayment;
	}

	public void setLocalPayment(boolean localPayment) {
		this.localPayment = localPayment;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "EnrichedFields [rqUID=" + rqUID 
				+ ", settlementDays=" + settlementDays + ", exchangeRate=" + exchangeRate + ", exchangeRateFormat="
				+ exchangeRateFormat + ", exchangeDetails=" + exchangeDetails 
				+ ", originatorRatePackage=" + originatorRatePackage + ", originatorRate=" + originatorRate
				+ ", originatorSellMarkup=" + originatorSellMarkup + ", originatorBuyMarkup=" + originatorBuyMarkup
				+ ", originatorMidRate=" + originatorMidRate + ", cptyTransactionAmtRate=" + cptyTransactionAmtRate
				+ ", cptyRatePackage=" + cptyRatePackage + ", cptyRate=" + cptyRate + ", cptySellMarkup="
				+ cptySellMarkup + ", cptyBuyMarkup=" + cptyBuyMarkup + ", cptyMidRate=" + cptyMidRate
				+ ", originatorStpLimit=" + originatorStpLimit + ", cptyStpLimit="
				+ cptyStpLimit + ", deferClientEntry=" + deferClientEntry + ", localPayment=" + localPayment
				+ ", timestamp=" + timestamp + "]";
	}

	@Override
	public String toStringShort() {
		return toString();
	}

	/**
	 * Builder for EnrichedFields
	 */
	public static class Builder implements BuilderPattern<EnrichedFields> {
		private Date timestamp;
		private String rqUID;
		private String settlementDays;
		private String exchangeRate;
		private String exchangeRateFormat;
		private String exchangeDetails;
		private String originatorBankId;
		private String originatorRatePackage;
		private String originatorRate;
		private String originatorSellMarkup;
		private String originatorBuyMarkup;
		private String originatorMidRate;
		private String cptyTransactionAmtRate;
		private String cptyRatePackage;
		private String cptyRate;
		private String cptySellMarkup;
		private String cptyBuyMarkup;
		private String cptyMidRate;

		// AdditionalRef
		private String originatorStpLimit;
		private String cptyStpLimit;
		private String deferClientEntry;
		private boolean localPayment;

		@Override
		public EnrichedFields build() {
			if (timestamp == null) {
				timestamp = new Date();
			}
			return new EnrichedFields(this);
		}

		public Builder setTimestamp(Date timestamp) {
			this.timestamp = timestamp;
			return this;
		}

		public Builder setLocalPayment(boolean localPayment) {
			this.localPayment = localPayment;
			return this;
		}

		public Builder setRqUID(String rqUID) {
			this.rqUID = rqUID;
			return this;
		}

		public Builder setSettlementDays(String settlementDays) {
			this.settlementDays = settlementDays;
			return this;
		}

		public Builder setExchangeRate(String exchangeRate) {
			this.exchangeRate = exchangeRate;
			return this;
		}

		public Builder setExchangeRateFormat(String exchangeRateFormat) {
			this.exchangeRateFormat = exchangeRateFormat;
			return this;
		}

		public Builder setExchangeDetails(String exchangeDetails) {
			this.exchangeDetails = exchangeDetails;
			return this;
		}

		public Builder setOriginatorBankId(String originatorBankId) {
			this.originatorBankId = originatorBankId;
			return this;
		}

		public Builder setOriginatorRatePackage(String originatorRatePackage) {
			this.originatorRatePackage = originatorRatePackage;
			return this;
		}

		public Builder setOriginatorRate(String originatorRate) {
			this.originatorRate = originatorRate;
			return this;
		}

		public Builder setOriginatorSellMarkup(String originatorSellMarkup) {
			this.originatorSellMarkup = originatorSellMarkup;
			return this;
		}

		public Builder setOriginatorBuyMarkup(String originatorBuyMarkup) {
			this.originatorBuyMarkup = originatorBuyMarkup;
			return this;
		}

		public Builder setOriginatorMidRate(String originatorMidRate) {
			this.originatorMidRate = originatorMidRate;
			return this;
		}

		public Builder setCptyTransactionAmtRate(String cptyTransactionAmtRate) {
			this.cptyTransactionAmtRate = cptyTransactionAmtRate;
			return this;
		}

		public Builder setCptyRatePackage(String cptyRatePackage) {
			this.cptyRatePackage = cptyRatePackage;
			return this;
		}

		public Builder setCptyRate(String cptyRate) {
			this.cptyRate = cptyRate;
			return this;
		}

		public Builder setCptySellMarkup(String cptySellMarkup) {
			this.cptySellMarkup = cptySellMarkup;
			return this;
		}

		public Builder setCptyBuyMarkup(String cptyBuyMarkup) {
			this.cptyBuyMarkup = cptyBuyMarkup;
			return this;
		}

		public Builder setCptyMidRate(String cptyMidRate) {
			this.cptyMidRate = cptyMidRate;
			return this;
		}

		public Builder setOriginatorStpLimit(String originatorStpLimit) {
			this.originatorStpLimit = originatorStpLimit;
			return this;
		}

		public Builder setCptyStpLimit(String cptyStpLimit) {
			this.cptyStpLimit = cptyStpLimit;
			return this;
		}

		public Builder setDeferClientEntry(String deferClientEntry) {
			this.deferClientEntry = deferClientEntry;
			return this;
		}
	}
}
