package com.barclays.ebox.pay.domain;

import java.math.BigDecimal;

import com.barclays.ebox.pay.domain.builder.BuilderPattern;

/**
 * A Transaction represents 1 Debit or Credit It is linked to a PaymentRequest
 * (The Originator) and Optionally may provide a reference to the RequestHeader
 * (the enclosing Bulk payment file)
 * 
 * To build a Transaction object, you must use the Builder, setting only the
 * values that are known, for example: Transaction t = new
 * Transaction.Builder().setTransactionId(1234L). setPaymentRequestId(4321L).
 * setBankCode(1).build();
 */
@SuppressWarnings("all")
public final class Transaction implements DomainObject {
	private static final long serialVersionUID = -8835777773943233138L;

	private long transactionId;

	// these 2 are provided for convenience but need to be manually set
	private PaymentRequest paymentRequest;
	private EnrichedFields enrichedFields;
	private String bankCode;
	private String branchId;
	private String regionCode;
	private String accountNumber;
	private BigDecimal amount;
	private BigDecimal localAmount;
	private BigDecimal originatorAmount;
	private BigDecimal originatorLocalAmount;
	private BigDecimal calculatedAmount;
	private BigDecimal calculatedLocalAmount;
	private BigDecimal calculatedOriginatorAmount;
	private String counterPartyNarrative;
	private String counterPartyName;
	private int transactionCounter;
	private String ccy;
	private String baseCcy;
	private String swiftCode;
	private String swiftValueDate;
	private String valueDateInd;
	private String valueDays;
	private String debitCreditInd;
	private String typeDescription;
	private String sendersRef;
	private String preferedIntermediary;
	private String sameDayValueInd;
	private String displayCode;
	private String remittanceInfo;
	private String chargeOption;
	private String cptyAddress1;
	private String cptyAddress2;
	private String cptyAddress3;
	private String serialNo;
	private String bopCode;
	private String dealRate;
	private String dealId;
	private String rateStatus;
	private String relatedRef;
	private String senderToReceiver;
	private String clearingCode;
	private String branchName;
	private String policy1;
	private String policy2;
	private String remarks;
	private String bopSubCode;
	private String processingEngineName;
	private String marketSegment;
	private String exchangeOn;
	private String exchangeRate;
	private String outputCmf;

	private Transaction(Builder builder) {
		this.transactionId = builder.transactionId;
		this.enrichedFields = builder.enrichedFields;
		this.paymentRequest = builder.paymentRequest;
		this.bankCode = builder.bankCode;
		this.branchId = builder.branchId;
		this.regionCode = builder.regionCode;
		this.accountNumber = builder.accountNumber;
		this.amount = builder.amount;
		this.originatorAmount = builder.originatorAmount;
		this.originatorLocalAmount = builder.originatorLocalAmount;
		this.localAmount = builder.localAmount;
		this.counterPartyNarrative = builder.counterPartyNarrative;
		this.counterPartyName = builder.counterPartyName;
		this.transactionCounter = builder.transactionCounter;
		this.ccy = builder.ccy;
		this.baseCcy = builder.baseCcy;
		this.swiftCode = builder.swiftCode;
		this.swiftValueDate = builder.swiftValueDate;
		this.valueDays = builder.valueDays;
		this.valueDateInd = builder.valueDateInd;
		this.debitCreditInd = builder.debitCreditInd;
		this.typeDescription = builder.typeDescription;
		this.sendersRef = builder.sendersRef;
		this.preferedIntermediary = builder.preferedIntermediary;
		this.sameDayValueInd = builder.sameDayValueInd;
		this.displayCode = builder.displayCode;
		this.remittanceInfo = builder.remittanceInfo;
		this.chargeOption = builder.chargeOption;
		this.cptyAddress1 = builder.cptyAddress1;
		this.cptyAddress2 = builder.cptyAddress2;
		this.cptyAddress3 = builder.cptyAddress3;
		this.serialNo = builder.serialNo;
		this.bopCode = builder.bopCode;
		this.dealRate = builder.dealRate;
		this.dealId = builder.dealId;
		this.relatedRef = builder.relatedRef;
		this.senderToReceiver = builder.senderToReceiver;
		this.clearingCode = builder.clearingCode;
		this.branchName = builder.branchName;
		this.policy1 = builder.policy1;
		this.policy2 = builder.policy2;
		this.remarks = builder.remarks;
		this.bopSubCode = builder.bopSubCode;
		this.rateStatus = builder.rateStatus;
		this.processingEngineName = builder.processingEngineName;
		this.marketSegment = builder.marketSegment;
		this.exchangeOn = builder.exchangeOn;
		this.exchangeRate = builder.exchangeRate;
		this.outputCmf = builder.outputCmf;
		this.calculatedAmount = builder.calculatedAmount;
		this.calculatedOriginatorAmount = builder.calculatedOriginatorAmount;
		this.calculatedLocalAmount = builder.calculatedLocalAmount;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public PaymentRequest getPaymentRequest() {
		return paymentRequest;
	}

	public void setPaymentRequest(PaymentRequest paymentRequest) {
		this.paymentRequest = paymentRequest;
	}

	public int getTransactionCounter() {
		return transactionCounter;
	}

	public void setTransactionCounter(int transactionCounter) {
		this.transactionCounter = transactionCounter;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public String getBaseCcy() {
		return baseCcy;
	}

	public void setBaseCcy(String baseCcy) {
		this.baseCcy = baseCcy;
	}

	/**
	 * @return the swiftCode
	 */
	public String getSwiftCode() {
		return swiftCode;
	}

	/**
	 * @param swiftCode the swiftCode to set
	 */
	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}

	/**
	 * @return the swiftValueDate
	 */
	public String getSwiftValueDate() {
		return swiftValueDate;
	}

	/**
	 * @param swiftValueDate the swiftValueDate to set
	 */
	public void setSwiftValueDate(String swiftValueDate) {
		this.swiftValueDate = swiftValueDate;
	}

	/**
	 * @return the valueDateInd
	 */
	public String getValueDateInd() {
		return valueDateInd;
	}

	/**
	 * @param valueDateInd the valueDateInd to set
	 */
	public void setValueDateInd(String valueDateInd) {
		this.valueDateInd = valueDateInd;
	}

	/**
	 * @return the valueDays
	 */
	public String getValueDays() {
		return valueDays;
	}

	/**
	 * @param valueDays the valueDays to set
	 */
	public void setValueDays(String valueDays) {
		this.valueDays = valueDays;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCounterPartyNarrative() {
		return counterPartyNarrative;
	}

	public void setCounterPartyNarrative(String counterPartyNarrative) {
		this.counterPartyNarrative = counterPartyNarrative;
	}

	public String getCounterPartyName() {
		return counterPartyName;
	}

	public void setCounterPartyName(String counterPartyName) {
		this.counterPartyName = counterPartyName;
	}

	public EnrichedFields getEnrichedFields() {
		return enrichedFields;
	}

	public void setEnrichedFields(EnrichedFields enrichedFields) {
		this.enrichedFields = enrichedFields;
	}

	public String getTypeDescription() {
		return typeDescription;
	}

	public void setTypeDescription(String typeDescription) {
		this.typeDescription = typeDescription;
	}

	public String getSendersRef() {
		return sendersRef;
	}

	public void setSendersRef(String sendersRef) {
		this.sendersRef = sendersRef;
	}

	public String getPreferedIntermediary() {
		return preferedIntermediary;
	}

	public void setPreferedIntermediary(String preferedIntermediary) {
		this.preferedIntermediary = preferedIntermediary;
	}

	public String getSameDayValueInd() {
		return sameDayValueInd;
	}

	public void setSameDayValueInd(String sameDayValueInd) {
		this.sameDayValueInd = sameDayValueInd;
	}

	public String getDisplayCode() {
		return displayCode;
	}

	public void setDisplayCode(String displayCode) {
		this.displayCode = displayCode;
	}

	public String getRemittanceInfo() {
		return remittanceInfo;
	}

	public void setRemittanceInfo(String remittanceInfo) {
		this.remittanceInfo = remittanceInfo;
	}

	public String getChargeOption() {
		return chargeOption;
	}

	public void setChargeOption(String chargeOption) {
		this.chargeOption = chargeOption;
	}

	public String getCptyAddress1() {
		return cptyAddress1;
	}

	public void setCptyAddress1(String cptyAddress1) {
		this.cptyAddress1 = cptyAddress1;
	}

	public String getCptyAddress2() {
		return cptyAddress2;
	}

	public void setCptyAddress2(String cptyAddress2) {
		this.cptyAddress2 = cptyAddress2;
	}

	public String getCptyAddress3() {
		return cptyAddress3;
	}

	public void setCptyAddress3(String cptyAddress3) {
		this.cptyAddress3 = cptyAddress3;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getBopCode() {
		return bopCode;
	}

	public void setBopCode(String bopCode) {
		this.bopCode = bopCode;
	}

	public String getDealRate() {
		return dealRate;
	}

	public void setDealRate(String dealRate) {
		this.dealRate = dealRate;
	}

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getRelatedRef() {
		return relatedRef;
	}

	public void setRelatedRef(String relatedRef) {
		this.relatedRef = relatedRef;
	}

	public String getSenderToReceiver() {
		return senderToReceiver;
	}

	public void setSenderToReceiver(String senderToReceiver) {
		this.senderToReceiver = senderToReceiver;
	}

	public String getClearingCode() {
		return clearingCode;
	}

	public void setClearingCode(String clearingCode) {
		this.clearingCode = clearingCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getPolicy1() {
		return policy1;
	}

	public void setPolicy1(String policy1) {
		this.policy1 = policy1;
	}

	public String getPolicy2() {
		return policy2;
	}

	public void setPolicy2(String policy2) {
		this.policy2 = policy2;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getBopSubCode() {
		return bopSubCode;
	}

	public void setBopSubCode(String bopSubCode) {
		this.bopSubCode = bopSubCode;
	}

	public BigDecimal getLocalAmount() {
		return localAmount;
	}

	public void setLocalAmount(BigDecimal localAmount) {
		this.localAmount = localAmount;
	}

	public String getDebitCreditInd() {
		return debitCreditInd;
	}

	public void setDebitCreditInd(String debitCreditInd) {
		this.debitCreditInd = debitCreditInd;
	}

	public String getRateStatus() {
		return rateStatus;
	}

	public void setRateStatus(String rateStatus) {
		this.rateStatus = rateStatus;
	}

	public BigDecimal getOriginatorAmount() {
		return originatorAmount;
	}

	public void setOriginatorAmount(BigDecimal originatorAmount) {
		this.originatorAmount = originatorAmount;
	}

	public BigDecimal getOriginatorLocalAmount() {
		return originatorLocalAmount;
	}

	public void setOriginatorLocalAmount(BigDecimal originatorLocalAmount) {
		this.originatorLocalAmount = originatorLocalAmount;
	}

	public String getProcessingEngineName() {
		return processingEngineName;
	}

	public void setProcessingEngineName(String processingEngineName) {
		this.processingEngineName = processingEngineName;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getExchangeOn() {
		return exchangeOn;
	}

	public void setExchangeOn(String exchangeOn) {
		this.exchangeOn = exchangeOn;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	/**
	 * @return the outputCmf
	 */
	public String getOutputCmf() {
		return outputCmf;
	}

	/**
	 * @param outputCmf the outputCmf to set
	 */
	public void setOutputCmf(String outputCmf) {
		this.outputCmf = outputCmf;
	}

	public BigDecimal getCalculatedAmount() {
		return calculatedAmount;
	}

	public void setCalculatedAmount(BigDecimal calculatedAmount) {
		this.calculatedAmount = calculatedAmount;
	}

	public BigDecimal getCalculatedOriginatorAmount() {
		return calculatedOriginatorAmount;
	}

	public void setCalculatedOriginatorAmount(BigDecimal calculatedOriginatorAmount) {
		this.calculatedOriginatorAmount = calculatedOriginatorAmount;
	}

	public BigDecimal getCalculatedLocalAmount() {
		return calculatedLocalAmount;
	}

	public void setCalculatedLocalAmount(BigDecimal calculatedLocalAmount) {
		this.calculatedLocalAmount = calculatedLocalAmount;
	}

	@Override
	public String toString() {
		return "Transaction [" +
				"transactionId=" + transactionId +
				", paymentRequest=" + paymentRequest +
				", enrichedFields=" + enrichedFields +
				", bankCode='" + bankCode + '\'' +
				", branchId='" + branchId + '\'' +
				", regionCode='" + regionCode + '\'' +
				", accountNumber='" + accountNumber + '\'' +
				", amount=" + amount +
				", localAmount=" + localAmount +
				", originatorAmount=" + originatorAmount +
				", originatorLocalAmount=" + originatorLocalAmount +
				", calculatedAmount=" + calculatedAmount +
				", calculatedLocalAmount=" + calculatedLocalAmount +
				", calculatedOriginatorAmount=" + calculatedOriginatorAmount +
				", counterPartyNarrative='" + counterPartyNarrative + '\'' +
				", counterPartyName='" + counterPartyName + '\'' +
				", transactionCounter=" + transactionCounter +
				", ccy='" + ccy + '\'' +
				", baseCcy='" + baseCcy + '\'' +
				", swiftCode='" + swiftCode + '\'' +
				", swiftValueDate='" + swiftValueDate + '\'' +
				", valueDateInd='" + valueDateInd + '\'' +
				", valueDays='" + valueDays + '\'' +
				", debitCreditInd='" + debitCreditInd + '\'' +
				", typeDescription='" + typeDescription + '\'' +
				", sendersRef='" + sendersRef + '\'' +
				", preferedIntermediary='" + preferedIntermediary + '\'' +
				", sameDayValueInd='" + sameDayValueInd + '\'' +
				", displayCode='" + displayCode + '\'' +
				", remittanceInfo='" + remittanceInfo + '\'' +
				", chargeOption='" + chargeOption + '\'' +
				", cptyAddress1='" + cptyAddress1 + '\'' +
				", cptyAddress2='" + cptyAddress2 + '\'' +
				", cptyAddress3='" + cptyAddress3 + '\'' +
				", serialNo='" + serialNo + '\'' +
				", bopCode='" + bopCode + '\'' +
				", dealRate='" + dealRate + '\'' +
				", dealId='" + dealId + '\'' +
				", rateStatus='" + rateStatus + '\'' +
				", relatedRef='" + relatedRef + '\'' +
				", senderToReceiver='" + senderToReceiver + '\'' +
				", clearingCode='" + clearingCode + '\'' +
				", branchName='" + branchName + '\'' +
				", policy1='" + policy1 + '\'' +
				", policy2='" + policy2 + '\'' +
				", remarks='" + remarks + '\'' +
				", bopSubCode='" + bopSubCode + '\'' +
				", processingEngineName='" + processingEngineName + '\'' +
				", marketSegment='" + marketSegment + '\'' +
				", exchangeOn='" + exchangeOn + '\'' +
				", exchangeRate='" + exchangeRate + '\'' +
				", outputCmf='" + outputCmf + '\'' +
				']';
	}

	@Override
	public String toStringShort() {
		return "Transaction [transactionId=" + this.transactionId + ", accountNumber=" + this.accountNumber
				+ ", amount=" + this.amount + "]";
	}

	/**
	 * Builder for Transaction
	 */
	public static class Builder implements BuilderPattern<Transaction> {
		private long transactionId;
		private PaymentRequest paymentRequest;
		private EnrichedFields enrichedFields;
		private String bankCode;
		private String branchId;
		private String regionCode;
		private String accountNumber;
		private BigDecimal amount;
		private BigDecimal localAmount;
		private BigDecimal originatorAmount;
		private BigDecimal originatorLocalAmount;
		private BigDecimal calculatedAmount;
		private BigDecimal calculatedLocalAmount;
		private BigDecimal calculatedOriginatorAmount;
		private String counterPartyNarrative;
		private String counterPartyName;
		private int transactionCounter;;
		private String ccy;
		private String baseCcy;
		private String swiftCode;
		private String swiftValueDate;
		private String valueDateInd;
		private String valueDays;
		private String debitCreditInd;
		private String typeDescription;
		private String sendersRef;
		private String preferedIntermediary;
		private String sameDayValueInd;
		private String displayCode;
		private String remittanceInfo;
		private String chargeOption;
		private String cptyAddress1;
		private String cptyAddress2;
		private String cptyAddress3;
		private String serialNo;
		private String bopCode;
		private String dealRate;
		private String dealId;
		private String rateStatus;
		private String relatedRef;
		private String senderToReceiver;
		private String clearingCode;
		private String branchName;
		private String policy1;
		private String policy2;
		private String remarks;
		private String bopSubCode;
		private String processingEngineName;
		private String marketSegment;
		private String exchangeOn;
		private String exchangeRate;
		private String outputCmf;

		@Override
		public Transaction build() {
			if (this.enrichedFields == null) {
				this.setEnrichedFields(new EnrichedFields.Builder().build());
			}
			return new Transaction(this);
		}

		public Builder setTransactionId(long transactionId) {
			this.transactionId = transactionId;
			return this;
		}

		public Builder setEnrichedFields(EnrichedFields enrichedFields) {
			this.enrichedFields = enrichedFields;
			return this;
		}

		public Builder setPaymentRequest(PaymentRequest paymentRequest) {
			this.paymentRequest = paymentRequest;
			return this;
		}

		public Builder setBankCode(String bankCode) {
			this.bankCode = bankCode;
			return this;
		}

		public Builder setBranchId(String branchId) {
			this.branchId = branchId;
			return this;
		}

		public Builder setRegionCode(String regionCode) {
			this.regionCode = regionCode;
			return this;
		}

		public Builder setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
			return this;
		}

		public Builder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}

		public Builder setLocalAmount(BigDecimal localAmount) {
			this.localAmount = localAmount;
			return this;
		}

		public Builder setOriginatorAmount(BigDecimal originatorAmount) {
			this.originatorAmount = originatorAmount;
			return this;
		}

		public Builder setOriginatorLocalAmount(BigDecimal originatorLlocalAmount) {
			this.originatorLocalAmount = originatorLlocalAmount;
			return this;
		}

		public Builder setCounterPartyNarrative(String counterPartyNarrative) {
			this.counterPartyNarrative = counterPartyNarrative;
			return this;
		}

		public Builder setCounterPartyName(String counterPartyName) {
			this.counterPartyName = counterPartyName;
			return this;
		}

		public Builder setTransactionCounter(int transactionCounter) {
			this.transactionCounter = transactionCounter;
			return this;
		}

		public Builder setCcy(String ccy) {
			this.ccy = ccy;
			return this;
		}

		public Builder setBaseCcy(String baseCcy) {
			this.baseCcy = baseCcy;
			return this;
		}
		
		public Builder setSwiftValueDate(String swftValueDate) {
			this.swiftValueDate = swftValueDate;
			return this;
		}
		
		
		public Builder setSwiftCode(String swiftCode) {
			this.swiftCode = swiftCode;
			return this;
		}
		
		public Builder setValueDaye(String valueDaye) {
			this.valueDays = valueDays;
			return this;
		}
		
		public Builder setValueDateInd(String valueDateInd) {
			this.valueDateInd = valueDateInd;
			return this;
		}

		public Builder setDebitCreditInd(String debitCreditInd) {
			this.debitCreditInd = debitCreditInd;
			return this;
		}

		public Builder setTypeDescription(String typeDescription) {
			this.typeDescription = typeDescription;
			return this;
		}

		public Builder setSendersRef(String sendersRef) {
			this.sendersRef = sendersRef;
			return this;
		}

		public Builder setPreferedIntermediary(String preferedIntermediary) {
			this.preferedIntermediary = preferedIntermediary;
			return this;
		}

		public Builder setSameDayValueInd(String sameDayValueInd) {
			this.sameDayValueInd = sameDayValueInd;
			return this;
		}

		public Builder setDisplayCode(String displayCode) {
			this.displayCode = displayCode;
			return this;
		}

		public Builder setRemittanceInfo(String remittanceInfo) {
			this.remittanceInfo = remittanceInfo;
			return this;
		}

		public Builder setChargeOption(String chargeOption) {
			this.chargeOption = chargeOption;
			return this;
		}

		public Builder setCptyAddress1(String cptyAddress1) {
			this.cptyAddress1 = cptyAddress1;
			return this;
		}

		public Builder setCptyAddress2(String cptyAddress2) {
			this.cptyAddress2 = cptyAddress2;
			return this;
		}

		public Builder setCptyAddress3(String cptyAddress3) {
			this.cptyAddress3 = cptyAddress3;
			return this;
		}

		public Builder setSerialNo(String serialNo) {
			this.serialNo = serialNo;
			return this;
		}

		public Builder setBopCode(String bopCode) {
			this.bopCode = bopCode;
			return this;
		}

		public Builder setDealRate(String dealRate) {
			this.dealRate = dealRate;
			return this;
		}

		public Builder setDealId(String dealId) {
			this.dealId = dealId;
			return this;
		}

		public Builder setRelatedRef(String relatedRef) {
			this.relatedRef = relatedRef;
			return this;
		}

		public Builder setSenderToReceiver(String senderToReceiver) {
			this.senderToReceiver = senderToReceiver;
			return this;
		}

		public Builder setClearingCode(String clearingCode) {
			this.clearingCode = clearingCode;
			return this;
		}

		public Builder setBranchName(String branchName) {
			this.branchName = branchName;
			return this;
		}

		public Builder setPolicy1(String policy1) {
			this.policy1 = policy1;
			return this;
		}

		public Builder setPolicy2(String policy2) {
			this.policy2 = policy2;
			return this;
		}

		public Builder setRemarks(String remarks) {
			this.remarks = remarks;
			return this;
		}

		public Builder setBopSubCode(String bopSubCode) {
			this.bopSubCode = bopSubCode;
			return this;
		}

		public Builder setRateStatus(String rateStatus) {
			this.rateStatus = rateStatus;
			return this;
		}

		public Builder setProcessingEngineName(String processingEngineName) {
			this.processingEngineName = processingEngineName;
			return this;
		}

		public Builder setMarketSegment(String marketSegment) {
			this.marketSegment = marketSegment;
			return this;
		}

		public Builder setExchangeOn(String exchangeOn) {
			this.exchangeOn = exchangeOn;
			return this;
		}

		public Builder setExchangeRate(String exchangeRate) {
			this.exchangeRate = exchangeRate;
			return this;
		}
		
		public Builder setOutputCmf(String outputCmf) {
			this.outputCmf = outputCmf;
			return this;
		}

		public Builder setCalculatedAmount(BigDecimal calculatedAmount) {
			this.calculatedAmount = calculatedAmount;
			return this;
		}

		public Builder setCalculatedOriginatorAmount(BigDecimal calculatedOriginatorAmount) {
			this.calculatedOriginatorAmount = calculatedOriginatorAmount;
			return this;
		}

		public Builder setCalculatedLocalAmount(BigDecimal calculatedLocalAmount) {
			this.calculatedLocalAmount = calculatedLocalAmount;
			return this;
		}
	}
}
