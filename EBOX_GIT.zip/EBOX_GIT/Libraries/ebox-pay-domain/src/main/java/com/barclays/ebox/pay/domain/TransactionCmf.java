package com.barclays.ebox.pay.domain;

public class TransactionCmf {
	
	private long transactionId;
	private String Cmf;
	String qParam;
	
	/**
	 * @return the transactionId
	 */
	public long getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the cmf
	 */
	public String getCmf() {
		return Cmf;
	}
	/**
	 * @param cmf the cmf to set
	 */
	public void setCmf(String cmf) {
		Cmf = cmf;
	}
	/**
	 * @return the qParam
	 */
	public String getqParam() {
		return qParam;
	}
	/**
	 * @param qParam the qParam to set
	 */
	public void setqParam(String qParam) {
		this.qParam = qParam;
	}

}
