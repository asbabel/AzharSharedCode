package com.barclays.ebox.pay.domain.exception;

/**
 * Exception thrown when there is a Database Error
 * 
 * @author abrma5s
 *
 */
public class DAOException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Default Constructor
	 * 
	 * @param message
	 */
	public DAOException(String message) {
		super(message);

	}

	/**
	 * Constructor that accepts a throwable. This is used when propagating
	 * another exception and also adding a custom message
	 * 
	 * @param message
	 * @param throwable
	 */
	public DAOException(String message, Throwable throwable) {
		super(message, throwable);
	}

	/**
	 * Constructor that accepts a throwable. This is used when propagating
	 * another exception and also adding a custom message
	 * 
	 * @param throwable
	 */
	public DAOException(Throwable throwable) {
		super(throwable);
	}
}