package com.barclays.ebox.pay.domain;

/**
 * Currency Info DTO
 * 
 * @author abrma5s
 *
 */
public class CurrencyInformation implements DomainObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private short currencyMask;
	private short currencyUnit;

	public short getCurrencyUnit() {
		return currencyUnit;
	}

	public void setCurrencyUnit(short currencyUnit) {
		this.currencyUnit = currencyUnit;
	}

	public short getCurrencyMask() {
		return currencyMask;
	}

	public void setCurrencyMask(short currencyMask) {
		this.currencyMask = currencyMask;
	}

	@Override
	public String toString() {
		return "CurrencyInformation [currencyMask=" + currencyMask + ", currencyUnit=" + currencyUnit + "]";
	}

	@Override
	public String toStringShort() {
		return toString();
	}
}
