package com.barclays.ebox.pay.domain;

/**
 * A class representing the 3 queues that are used as input to WTX Stage 2
 * within eBOX Bulk Payments processing.
 * 
 * Depending on the amount of Transactions, different queues are used. S - up to
 * 99 transactions, M - between 100 and 999 transactions and L - 1000+
 * transactions.
 */
public class Stage2Queue implements java.io.Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String qName;
	private String qRoute;
	/**
	 * @param qName
	 * @param qRoute
	 */
	public Stage2Queue(String qName, String qRoute) {
		this.qName = qName;
		this.qRoute = qRoute;
	}
	/**
	 * 
	 */
	public Stage2Queue() {
		super();
	}
	/**
	 * @return the qName
	 */
	public String getQName() {
		return qName;
	}
	/**
	 * @param qName the qName to set
	 */
	public void setQName(String qName) {
		this.qName = qName;
	}
	/**
	 * @return the qRoute
	 */
	public String getQRoute() {
		return qRoute;
	}
	/**
	 * @param qRoute the qRoute to set
	 */
	public void setQRoute(String qRoute) {
		this.qRoute = qRoute;
	}
	
	
	

	
}
