package com.barclays.ebox.pay.domain;

import java.math.BigDecimal;
import java.util.Map;

import com.barclays.ebox.pay.domain.builder.BuilderPattern;

/**
 * A PaymentRequest holds information on the Originator for a Transaction In a
 * Bulk Payment scenario, multiple Transactions will be linked to 1
 * PaymentRequest
 */
@SuppressWarnings("all")
public final class PaymentRequest implements DomainObject {
	private static final long serialVersionUID = -8885837146690474196L;

	private RequestHeader requestHeader;

	private long paymentRequestId;
	private long lastProcessedTransactionId;
	private String debitCreditInd;
	private String type;
	private String typeDescription;
	private String branchId;
	private String accountNo;
	private String ccy;
	private String localCcy;
	private BigDecimal amount;
	private String narrative;
	private String originatorName;
	private String originatorAddress1;
	private String originatorAddress2;
	private String originatorAddress3;
	private String originatorCode;
	private String remittanceInformation;
	private int customerNo1;
	private int customerNo2;
	private short originatorCcyMask;
	private short originatorCcyUnit;
	private String groupId;
	private int transactionsInGroup;
	private Stage2Queue stage2Queue;
	private String userId;
	private String activityCode;
	private String chargePackage;
	private String mlCheck;
	private String callback;
	private String callbackReason;
	private String callbackDate;
	private String branchName;
	private String serialNo;
	private short localCcyMask;
	private short localCcyUnit;
	private String iban;
	private String referCode;
	private String marketSegment;
	private String locationCode;
	private Map<Long, TransactionSummary> transactionSummaries;

	private PaymentRequest(Builder builder) {
		this.requestHeader = builder.requestHeader;
		this.paymentRequestId = builder.paymentRequestId;
		this.lastProcessedTransactionId = builder.lastProcessedTransactionId;
		this.debitCreditInd = builder.debitCreditInd;
		this.type = builder.type;
		this.typeDescription = builder.typeDescription;
		this.branchId = builder.branchId;
		this.accountNo = builder.accountNo;
		this.ccy = builder.ccy;
		this.localCcy = builder.localCcy;
		this.amount = builder.amount;
		this.narrative = builder.narrative;
		this.originatorName = builder.originatorName;
		this.originatorAddress1 = builder.originatorAddress1;
		this.originatorAddress2 = builder.originatorAddress2;
		this.originatorAddress3 = builder.originatorAddress3;
		this.originatorCode = builder.originatorCode;
		this.remittanceInformation = builder.remittanceInformation;
		this.customerNo1 = builder.customerNo1;
		this.customerNo2 = builder.customerNo2;
		this.userId = builder.userId;
		this.activityCode = builder.activityCode;
		this.chargePackage = builder.chargePackage;
		this.mlCheck = builder.mlCheck;
		this.callback = builder.callback;
		this.callbackReason = builder.callbackReason;
		this.callbackDate = builder.callbackDate;
		this.branchName = builder.branchName;
		this.serialNo = builder.serialNo;
		this.originatorCcyMask = builder.originatorCcyMask;
		this.originatorCcyUnit = builder.originatorCcyUnit;
		this.groupId = builder.groupId;
		this.transactionsInGroup = builder.transactionsInGroup;
		this.localCcyMask = builder.localCcyMask;
		this.localCcyUnit = builder.localCcyUnit;
		this.iban = builder.iban;
		this.referCode = builder.referCode;
		this.marketSegment = builder.marketSegment;
		this.locationCode = builder.locationCode;
		this.transactionSummaries = builder.transactionSummaries;
		this.stage2Queue = builder.stage2Queue;
	}

	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	public String getDebitCreditInd() {
		return debitCreditInd;
	}

	public void setDebitCreditInd(String debitCreditInd) {
		this.debitCreditInd = debitCreditInd;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBranchId() {
		return branchId;
	}

	public long getPaymentRequestId() {
		return paymentRequestId;
	}

	public void setPaymentRequestId(long paymentRequestId) {
		this.paymentRequestId = paymentRequestId;
	}

	/**
	 * @return the lastProcessedTransactionId
	 */
	public long getLastProcessedTransactionId() {
		return lastProcessedTransactionId;
	}

	/**
	 * @param lastProcessedTransactionId the lastProcessedTransactionId to set
	 */
	public void setLastProcessedTransactionId(long lastProcessedTransactionId) {
		this.lastProcessedTransactionId = lastProcessedTransactionId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String currency) {
		this.ccy = currency;
	}

	public String getLocalCcy() {
		return localCcy;
	}

	public void setLocalCcy(String localCcy) {
		this.localCcy = localCcy;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getNarrative() {
		return narrative;
	}

	public void setNarrative(String narrative) {
		this.narrative = narrative;
	}

	public String getOriginatorName() {
		return originatorName;
	}

	public void setOriginatorName(String originatorName) {
		this.originatorName = originatorName;
	}

	public String getTypeDescription() {
		return typeDescription;
	}

	public void setTypeDescription(String typeDescription) {
		this.typeDescription = typeDescription;
	}

	public String getOriginatorAddress1() {
		return originatorAddress1;
	}

	public void setOriginatorAddress1(String originatorAddress1) {
		this.originatorAddress1 = originatorAddress1;
	}

	public String getOriginatorAddress2() {
		return originatorAddress2;
	}

	public void setOriginatorAddress2(String originatorAddress2) {
		this.originatorAddress2 = originatorAddress2;
	}

	public String getOriginatorAddress3() {
		return originatorAddress3;
	}

	public void setOriginatorAddress3(String originatorAddress3) {
		this.originatorAddress3 = originatorAddress3;
	}

	public String getOriginatorCode() {
		return originatorCode;
	}

	public void setOriginatorCode(String originatorCode) {
		this.originatorCode = originatorCode;
	}

	public String getRemittanceInformation() {
		return remittanceInformation;
	}

	public void setRemittanceInformation(String remittanceInformation) {
		this.remittanceInformation = remittanceInformation;
	}

	public int getCustomerNo1() {
		return customerNo1;
	}

	public void setCustomerNo1(int customerNo1) {
		this.customerNo1 = customerNo1;
	}

	public int getCustomerNo2() {
		return customerNo2;
	}

	public void setCustomerNo2(int customerNo2) {
		this.customerNo2 = customerNo2;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getActivityCode() {
		return activityCode;
	}

	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}

	public String getChargePackage() {
		return chargePackage;
	}

	public void setChargePackage(String chargePackage) {
		this.chargePackage = chargePackage;
	}

	public String getMlCheck() {
		return mlCheck;
	}

	public void setMlCheck(String mlCheck) {
		this.mlCheck = mlCheck;
	}

	public String getCallback() {
		return callback;
	}

	public void setCallback(String callback) {
		this.callback = callback;
	}

	public String getCallbackReason() {
		return callbackReason;
	}

	public void setCallbackReason(String callbackReason) {
		this.callbackReason = callbackReason;
	}

	public String getCallbackDate() {
		return callbackDate;
	}

	public void setCallbackDate(String callbackDate) {
		this.callbackDate = callbackDate;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public short getOriginatorCcyMask() {
		return originatorCcyMask;
	}

	public void setOriginatorCcyMask(short originatorCcyMask) {
		this.originatorCcyMask = originatorCcyMask;
	}

	public short getOriginatorCcyUnit() {
		return originatorCcyUnit;
	}

	public void setOriginatorCcyUnit(short originatorCcyUnit) {
		this.originatorCcyUnit = originatorCcyUnit;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public int getTransactionsInGroup() {
		return transactionsInGroup;
	}

	public void setTransactionsInGroup(int transactionsInGroup) {
		this.transactionsInGroup = transactionsInGroup;
	}

	public short getLocalCcyMask() {
		return localCcyMask;
	}

	public void setLocalCcyMask(short localCcyMask) {
		this.localCcyMask = localCcyMask;
	}

	public short getLocalCcyUnit() {
		return localCcyUnit;
	}

	public void setLocalCcyUnit(short localCcyUnit) {
		this.localCcyUnit = localCcyUnit;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getReferCode() {
		return referCode;
	}

	public void setReferCode(String referCode) {
		this.referCode = referCode;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	/**
	 * @return the locationCode
	 */
	public String getLocationCode() {
		return locationCode;
	}

	/**
	 * @param locationCode the locationCode to set
	 */
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public Stage2Queue getStage2Queue() {
		return stage2Queue;
	}

	public void setStage2Queue(Stage2Queue stage2Queue) {
		this.stage2Queue = stage2Queue;
	}

	public Map<Long, TransactionSummary> getTransactionSummaries() {
		return transactionSummaries;
	}

	public void setTransactionSummaries(Map<Long, TransactionSummary> transactionSummaries) {
		this.transactionSummaries = transactionSummaries;
	}

	@Override
	public String toString() {
		return "PaymentRequest [requestHeader=" + requestHeader + ", paymentRequestId=" + paymentRequestId
				+ ", lastProcessedTransactionId=" + lastProcessedTransactionId + ", debitCreditInd=" + debitCreditInd
				+ ", type=" + type + ", typeDescription=" + typeDescription
				+ ", branchId=" + branchId + ", accountNo=" + accountNo + ", ccy=" + ccy + ", localCcy=" + localCcy
				+ ", amount=" + amount + ", narrative=" + narrative + ", originatorName=" + originatorName
				+ ", originatorAddress1=" + originatorAddress1 + ", originatorAddress2=" + originatorAddress2
				+ ", originatorAddress3=" + originatorAddress3 + ", originatorCode=" + originatorCode
				+ ", remittanceInformation=" + remittanceInformation + ", customerNo1=" + customerNo1 + ", customerNo2="
				+ customerNo2 + ", originatorCcyMask=" + originatorCcyMask + ", originatorCcyUnit=" + originatorCcyUnit
				+ ", groupId=" + groupId + ", transactionsInGroup=" + transactionsInGroup + ", stage2Queue="
				+ stage2Queue + ", userId=" + userId + ", activityCode=" + activityCode + ", chargePackage="
				+ chargePackage + ", mlCheck=" + mlCheck + ", callback=" + callback + ", callbackReason="
				+ callbackReason + ", callbackDate=" + callbackDate + ", branchName=" + branchName + ", serialNo="
				+ serialNo + ", localCcyMask=" + localCcyMask + ", localCcyUnit=" + localCcyUnit + ", iban=" + iban
				+ ", referCode=" + referCode + ", marketSegment=" + marketSegment + ", locationCode=" 
				+ locationCode + ", transactionSummaries="+ transactionSummaries + "]";
	}

	@Override
	public String toStringShort() {
		return "PaymentRequest [header ID="+ (this.getRequestHeader()!=null?this.getRequestHeader().getRequestHeaderId():"undefined")
				+ ", paymentRequest ID="+ this.paymentRequestId+", accNo=" + this.accountNo
				+ ", transactions=" + this.transactionsInGroup + "]";
	}

	/**
	 * Builder for PaymentRequest
	 */

	public static class Builder implements BuilderPattern<PaymentRequest> {
		private RequestHeader requestHeader;
		private long paymentRequestId;
		private long lastProcessedTransactionId = 0;
		private String debitCreditInd;
		private String type;
		private String typeDescription;
		private String branchId;
		private String accountNo;
		private String ccy;
		private String localCcy;
		private BigDecimal amount;
		private String narrative;
		private String originatorName;
		private String originatorAddress1;
		private String originatorAddress2;
		private String originatorAddress3;
		private String originatorCode;
		private String remittanceInformation;
		private int customerNo1;
		private int customerNo2;
		private short originatorCcyMask;
		private short originatorCcyUnit;
		private short bankCode;
		private String userId;
		private String activityCode;
		private String chargePackage;
		private String mlCheck;
		private String callback;
		private String callbackReason;
		private String callbackDate;
		private String branchName;
		private String serialNo;
		private String groupId;
		private int transactionsInGroup;
		private short localCcyUnit;
		private short localCcyMask;
		private String iban;
		private String referCode;
		private String marketSegment;
		private String locationCode;
		private Map<Long, TransactionSummary> transactionSummaries;
		private boolean localPaymentOnly;
		private Stage2Queue stage2Queue;

		@Override
		public PaymentRequest build() {
			return new PaymentRequest(this);
		}

		public Builder setRequestHeader(RequestHeader requestHeader) {
			this.requestHeader = requestHeader;
			return this;
		}

		public Builder setPaymentRequestId(long paymentRequestId) {
			this.paymentRequestId = paymentRequestId;
			return this;
		}
		
		public Builder setLastProcessedTransactionId(long lastProcessedTransactionId) {
			this.lastProcessedTransactionId = lastProcessedTransactionId;
			return this;
		}

		public Builder setDebitCreditInd(String debitCreditInd) {
			this.debitCreditInd = debitCreditInd;
			return this;
		}

		public Builder setType(String type) {
			this.type = type;
			return this;
		}

		public Builder setTypeDescription(String typeDescription) {
			this.typeDescription = typeDescription;
			return this;
		}

		public Builder setBranchId(String branchId) {
			this.branchId = branchId;
			return this;
		}

		public Builder setAccountNo(String accountNo) {
			this.accountNo = accountNo;
			return this;
		}

		public Builder setCcy(String ccy) {
			this.ccy = ccy;
			return this;
		}

		public Builder setLocalCcy(String localCcy) {
			this.localCcy = localCcy;
			return this;
		}

		public Builder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}

		public Builder setNarrative(String narrative) {
			this.narrative = narrative;
			return this;
		}

		public Builder setOriginatorName(String originatorName) {
			this.originatorName = originatorName;
			return this;
		}

		public Builder setOriginatorAddress1(String originatorAddress1) {
			this.originatorAddress1 = originatorAddress1;
			return this;
		}

		public Builder setOriginatorAddress2(String originatorAddress2) {
			this.originatorAddress2 = originatorAddress2;
			return this;
		}

		public Builder setOriginatorAddress3(String originatorAddress3) {
			this.originatorAddress3 = originatorAddress3;
			return this;
		}

		public Builder setOriginatorCode(String originatorCode) {
			this.originatorCode = originatorCode;
			return this;
		}

		public Builder setRemittanceInformation(String remittanceInformation) {
			this.remittanceInformation = remittanceInformation;
			return this;
		}

		public Builder setCustomerNo1(int customerNo1) {
			this.customerNo1 = customerNo1;
			return this;
		}

		public Builder setCustomerNo2(int customerNo2) {
			this.customerNo2 = customerNo2;
			return this;
		}

		public Builder setUserId(String userId) {
			this.userId = userId;
			return this;
		}

		public Builder setActivityCode(String activityCode) {
			this.activityCode = activityCode;
			return this;
		}

		public Builder setChargePackage(String chargePackage) {
			this.chargePackage = chargePackage;
			return this;
		}

		public Builder setMlCheck(String mlCheck) {
			this.mlCheck = mlCheck;
			return this;
		}

		public Builder setCallback(String callback) {
			this.callback = callback;
			return this;
		}

		public Builder setCallbackReason(String callbackReason) {
			this.callbackReason = callbackReason;
			return this;
		}

		public Builder setCallbackDate(String callbackDate) {
			this.callbackDate = callbackDate;
			return this;
		}

		public Builder setBranchName(String branchName) {
			this.branchName = branchName;
			return this;
		}

		public Builder setSerialNo(String serialNo) {
			this.serialNo = serialNo;
			return this;
		}

		public Builder setOriginatorCcyMask(short originatorCcyMask) {
			this.originatorCcyMask = originatorCcyMask;
			return this;
		}

		public Builder setLocationOriginatorCcyUnit(short originatorCcyUnit) {
			this.originatorCcyUnit = originatorCcyUnit;
			return this;
		}

		public Builder setGroupId(String groupId) {
			this.groupId = groupId;
			return this;
		}

		public Builder setTransactionsInGroup(int transactionsInGroup) {
			this.transactionsInGroup = transactionsInGroup;
			return this;
		}

		public Builder setLocalCcyMask(short localCcyMask) {
			this.localCcyMask = localCcyMask;
			return this;
		}

		public Builder setLocalCcyUnit(short localCcyUnit) {
			this.localCcyUnit = localCcyUnit;
			return this;
		}

		public Builder setIban(String iban) {
			this.iban = iban;
			return this;
		}

		public Builder setReferCode(String referCode) {
			this.referCode = referCode;
			return this;
		}

		public Builder setMarketSegment(String marketSegment) {
			this.marketSegment = marketSegment;
			return this;
		}
		
		public Builder setLocationCode(String locationCode) {
			this.locationCode = locationCode;
			return this;
		}

		public Builder setTransactionSummaries(Map<Long, TransactionSummary> transactionSummaries) {
			this.transactionSummaries = transactionSummaries;
			return this;
		}

		public Builder setStage2Queue(Stage2Queue stage2Queue) {
			this.stage2Queue = stage2Queue;
			return this;
		}
	}
}
