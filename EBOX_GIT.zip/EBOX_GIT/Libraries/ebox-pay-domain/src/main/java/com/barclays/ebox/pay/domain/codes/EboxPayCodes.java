package com.barclays.ebox.pay.domain.codes;

/**
 * Rules Engine Status code constants.
 * 
 */
/* 
* DATE      REFERENCE   WHO        VERSION     COMMENTS
* --------  ---------   ---        -------     ----------------------
* 24/05/17  WP714       Vaibhav Z   0.1         Added Code MISSING_CUSTOMER_INFO
* */
public final class EboxPayCodes {
	public static final int BRAINS_ACCOUNT_CLOSED = 91;
	public static final int FAILED_TO_EARMARK_FUNDS = 92;
	public static final int INSUFFIENT_FUNDS = 94;
	public static final int ORIGINATOR_ACCOUNT_NOT_EXISTS = 95;
	public static final int INVALID_CURRENCY = 96;
	public static final int COUNTERPARTY_CURRENCY_INVALID_STATUS = 97;
	public static final int MISSING_MANDATORY_NVP_STATUS = 98; // This error code can mean several things
	public static final int FAILED_TO_PROCESS_REQUEST = 98; // This error code can mean several things
	public static final int BRAINS_COMMUNICATION_ERROR = 99;
	public static final int INVALID_ACCOUNT_NUMBER = 200;
	public static final String MANDATORY_ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
	public static final String MANDATORY_BRANCH_ID = "BRANCH_ID";
	public static final String MANDATORY_CURRENCY = "CURRENCY";
	public static final String MANDATORY_BANK_CODE = "BANK_CODE";
	public static final String MANDATORY_DR_CR_IND = "DR_CR_IND";
	public static final String MANDATORY_TYPE = "TYPE";
	public static final String MANDATORY_TYPE_DESCRIPTION = "TYPE_DESCRIPTION";
	public static final String MANDATORY_ORIGINATOR_CODE = "ORIGINATOR_CODE";
	public static final String MANDATORY_COUNTERPARTY_NAME = "COUNTERPARTY_NAME";
	public static final String MANDATORY_SENDERS_REFERENCE = "SENDERS_REFERENCE";
	public static final String SWIFT_PROCESSING_ENGINE = "SWIFT";
	public static final String SWIFTRTGS_PROCESSING_ENGINE = "SWIFTRTGS";
	public static final String PERAGO_PROCESSING_ENGINE = "PERAGO";
	public static final String MANDATORY_ORIGINATOR_AMOUNT = "ORIGINATOR_AMOUNT";
	public static final String MANDATORY_AMOUNT = "AMOUNT";
	public static final String EXCHANGE_ON_ORIGINATOR = "ORIGINATOR";
	public static final String EXCHANGE_ON_COUNTERPARTY = "COUNTERPARTY";
	public static final String CROSS_BORDER_TYPE = "XBORDER";
	public static final String TRANSFER_TYPE = "TRANSFER";
	public static final String URGENT_TYPE = "URGENT";
	public static final String DESTINATION_OTHERBANK = "OTHERBANK";
	public static final String DESTINATION_BARCLAYS = "BARCLAYS";
	public static final String BARCLAYS_BARCLAYS_BANK_CODE = "BarclaysBankCode";
	public static final String LOCAL_RATE_STATUS = "LOCAL";
	public static final String PROVIDED_RATE_STATUS = "PROVIDED";
	public static final String INDICATIVE_DEAL_RATE_STATUS = "INDICATIVE-DEAL";
	public static final String OFFERED_AUTO_RATE_STATUS = "OFFERED-AUTO";
	public static final String INDICATIVE_RATE_STATUS = "INDICATIVE";
	public static final int AUTO_PROCESS_DEAL_ONE = 1;
	public static final String NO = "N";
	public static final String AUTO_PROCESS_CROSS_DEAL = "Auto Process Cross Deal";
	public static final String PAYMENT_EARMARK_MATURITY_PERIOD = "Payment Earmark Maturity Period";
	public static final String BRAINS_TOKEN_NO_DATA_RETURNED = "-1";
	public static final String BRAINS_ACCOUNT_OPEN = "0";
	public static final String ORIGINATOR_ACCOUNT_DEBIT = "D";
	public static final String ORIGINATOR_ACCOUNT_CREDIT = "C";
	public static final int DEFAULT_LIMIT = -1;
	public static final String CLP_LOG_PREFIX = "BPI Error - ";
	public static final String CLP_LOG_PREFIX_INFO = "BPI INFO - ";
	public static final int BRAINS_DEVICE_ID = 8888;
	public static final int ROUDING_SCALE_8 = 8;
	public static final int ROUDING_SCALE_30 = 30;
	public static final int ERROR_DUPLICATE_PAYMENT = 100;
	public static final int BRAINS_DISABLED_FOR_COUNTRY = 102;
	public static final int SQL_ERROR = 104;
	public static final int MESSAGE_NOT_ROUTABLE = 104;
	public static final int TOO_MANY_ITEMS = 110;
	public static final int MISSING_MSG_TYPE = 300;
	public static final int MISSING_FORMAT = 301;
	public static final int MISSING_ACCOUNTING_TOKEN = 302;
	public static final int MISSING_SOURCEAPPLNAME = 303;
	public static final int MISSING_SOURCEAPPLFUNC = 304;
	public static final int MISSING_TARGET_COUNTRY = 305;
	public static final int MISSING_MSG_ID = 306;
	public static final int MISSING_TRANSACTION_ID = 307;
	public static final int MISSING_SENT_DATE = 308;
	public static final int MISSING_USER_IDENTIFIER = 309;
	public static final int MISSING_USER_PASSWORD = 310;
	public static final int TWO_LETTERS = 2;
	public static final int MEDIUM_QUEUE_THRESHOLD = 100;
	public static final int LARGE_QUEUE_THRESHOLD = 1000;
	public static final long MILLISECONDS_IN_SECOND = 1000;
	public static final long SECONDS_IN_MINUTE = 60;
	public static final int ACCOUNT_NUMBER_LENGTH = 7;
	public static final int OPENING_TAG_EVENT = 1;
	public static final int CLOSING_TAG_EVENT = 2;
	public static final int MISSING_CUSTOMER_INFO=89;

	private EboxPayCodes() {
	}
}
