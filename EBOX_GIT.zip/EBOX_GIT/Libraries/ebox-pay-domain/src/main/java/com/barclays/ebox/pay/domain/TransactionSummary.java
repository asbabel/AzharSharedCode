package com.barclays.ebox.pay.domain;

import java.math.BigDecimal;

import com.barclays.ebox.pay.domain.Transaction.Builder;
import com.barclays.ebox.pay.domain.builder.BuilderPattern;

/**
 * A TransactionSummary stores key information about a Transaction that must be
 * known for all Transactions before individual validation can take place.
 */
@SuppressWarnings("all")
public final class TransactionSummary implements DomainObject {
	private static final long serialVersionUID = 7070383354640035347L;

	private long transactionId;
	private String bankCode;
	private String baseCcy;
	private String ccy;
	private BigDecimal amount;
	private BigDecimal localAmount;
	private BigDecimal originatorAmount;
	private BigDecimal originatorLocalAmount;
	private BigDecimal calculatedAmount;
	private BigDecimal calculatedLocalAmount;
	private BigDecimal calculatedOriginatorAmount;
	private BigDecimal calculatedOriginatorLocalAmount;
	private String exchangeOn;
	private String dealRate;
	private String cptyRate;
	private short cptyCcyMask;
	private short cptyCcyUnit;
	private String exchangeRate;
	private String rateIExchangeRate;
	private String exchangeRateFormat;
	private int settlementDate;
	private String deferClientEntry;
	private String counterpartyRatePackage;
	private String counterpartySellMarkup;
	private String counterpartyBuyMarkup;
	private String counterpartyMidRate;
	private String counterpartyStpLimit;
	private String originatorRatePackage;
	private String originatorRate;
	private String originatorSellMarkup;
	private String originatorBuyMarkup;
	private String originatorMidRate;
	private String originatorStpLimit;
	private boolean localPayment;
	private String debitCreditInd;
	private int transactionCounter;

	private TransactionSummary(Builder builder) {
		this.transactionId = builder.transactionId;
		this.bankCode = builder.bankCode;
		this.baseCcy = builder.baseCcy;
		this.ccy = builder.ccy;
		this.amount = builder.amount;
		this.localAmount = builder.localAmount;
		this.originatorAmount = builder.originatorAmount;
		this.originatorLocalAmount = builder.originatorLocalAmount;
		this.exchangeOn = builder.exchangeOn;
		this.dealRate = builder.dealRate;
		this.cptyRate = builder.cptyRate;
		this.cptyCcyMask = builder.cptyCcyMask;
		this.cptyCcyUnit = builder.cptyCcyUnit;
		this.exchangeRate = builder.exchangeRate;
		this.rateIExchangeRate = builder.rateIExchangeRate;
		this.exchangeRateFormat = builder.exchangeRateFormat;
		this.settlementDate = builder.settlementDate;
		this.deferClientEntry = builder.deferClientEntry;
		this.counterpartyRatePackage = builder.counterpartyRatePackage;
		this.counterpartySellMarkup = builder.counterpartySellMarkup;
		this.counterpartyBuyMarkup = builder.counterpartyBuyMarkup;
		this.counterpartyMidRate = builder.counterpartyMidRate;
		this.counterpartyStpLimit = builder.counterpartyStpLimit;
		this.originatorRatePackage = builder.originatorRatePackage;
		this.originatorRate = builder.originatorRate;
		this.originatorSellMarkup = builder.originatorSellMarkup;
		this.originatorBuyMarkup = builder.originatorBuyMarkup;
		this.originatorMidRate = builder.originatorMidRate;
		this.originatorStpLimit = builder.originatorStpLimit;
		this.localPayment = builder.localPayment;
		this.debitCreditInd = builder.debitCreditInd;
		this.transactionCounter = builder.transactionCounter;
		// this.calculatedOriginatorAmount = builder.calculatedOriginatorAmount;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBaseCcy() {
		return baseCcy;
	}

	public void setBaseCcy(String baseCcy) {
		this.baseCcy = baseCcy;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getExchangeOn() {
		return exchangeOn;
	}

	public void setExchangeOn(String exchangeOn) {
		this.exchangeOn = exchangeOn;
	}

	public String getDealRate() {
		return dealRate;
	}

	public void setDealRate(String dealRate) {
		this.dealRate = dealRate;
	}

	public String getCptyRate() {
		return cptyRate;
	}

	public void setCptyRate(String cptyRate) {
		this.cptyRate = cptyRate;
	}

	public short getCptyCcyMask() {
		return cptyCcyMask;
	}

	public void setCptyCcyMask(short cptyCcyMask) {
		this.cptyCcyMask = cptyCcyMask;
	}

	public short getCptyCcyUnit() {
		return cptyCcyUnit;
	}

	public void setCptyCcyUnit(short cptyCcyUnit) {
		this.cptyCcyUnit = cptyCcyUnit;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getExchangeRateFormat() {
		return exchangeRateFormat;
	}

	public void setExchangeRateFormat(String exchangeRateFormat) {
		this.exchangeRateFormat = exchangeRateFormat;
	}

	public int getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(int settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getDeferClientEntry() {
		return deferClientEntry;
	}

	public void setDeferClientEntry(String deferClientEntry) {
		this.deferClientEntry = deferClientEntry;
	}

	public String getCounterpartyRatePackage() {
		return counterpartyRatePackage;
	}

	public void setCounterpartyRatePackage(String counterpartyRatePackage) {
		this.counterpartyRatePackage = counterpartyRatePackage;
	}

	public String getCounterpartySellMarkup() {
		return counterpartySellMarkup;
	}

	public void setCounterpartySellMarkup(String counterpartySellMarkup) {
		this.counterpartySellMarkup = counterpartySellMarkup;
	}

	public String getCounterpartyBuyMarkup() {
		return counterpartyBuyMarkup;
	}

	public void setCounterpartyBuyMarkup(String counterpartyBuyMarkup) {
		this.counterpartyBuyMarkup = counterpartyBuyMarkup;
	}

	public String getCounterpartyMidRate() {
		return counterpartyMidRate;
	}

	public void setCounterpartyMidRate(String counterpartyMidRate) {
		this.counterpartyMidRate = counterpartyMidRate;
	}

	public String getCounterpartyStpLimit() {
		return counterpartyStpLimit;
	}

	public void setCounterpartyStpLimit(String counterpartyStpLimit) {
		this.counterpartyStpLimit = counterpartyStpLimit;
	}

	public String getOriginatorRatePackage() {
		return originatorRatePackage;
	}

	public void setOriginatorRatePackage(String originatorRatePackage) {
		this.originatorRatePackage = originatorRatePackage;
	}

	public String getOriginatorRate() {
		return originatorRate;
	}

	public void setOriginatorRate(String originatorRate) {
		this.originatorRate = originatorRate;
	}

	public String getOriginatorSellMarkup() {
		return originatorSellMarkup;
	}

	public void setOriginatorSellMarkup(String originatorSellMarkup) {
		this.originatorSellMarkup = originatorSellMarkup;
	}

	public String getOriginatorBuyMarkup() {
		return originatorBuyMarkup;
	}

	public void setOriginatorBuyMarkup(String originatorBuyMarkup) {
		this.originatorBuyMarkup = originatorBuyMarkup;
	}

	public String getOriginatorMidRate() {
		return originatorMidRate;
	}

	public void setOriginatorMidRate(String originatorMidRate) {
		this.originatorMidRate = originatorMidRate;
	}

	public String getOriginatorStpLimit() {
		return originatorStpLimit;
	}

	public void setOriginatorStpLimit(String originatorStpLimit) {
		this.originatorStpLimit = originatorStpLimit;
	}

	public boolean isLocalPayment() {
		return localPayment;
	}

	public void setLocalPayment(boolean localPayment) {
		this.localPayment = localPayment;
	}

	public BigDecimal getLocalAmount() {
		return localAmount;
	}

	public void setLocalAmount(BigDecimal localAmount) {
		this.localAmount = localAmount;
	}

	public BigDecimal getOriginatorAmount() {
		return originatorAmount;
	}

	public void setOriginatorAmount(BigDecimal originatorAmount) {
		this.originatorAmount = originatorAmount;
	}

	public BigDecimal getOriginatorLocalAmount() {
		return originatorLocalAmount;
	}

	public void setOriginatorLocalAmount(BigDecimal originatorLocalAmount) {
		this.originatorLocalAmount = originatorLocalAmount;
	}

	public String getDebitCreditInd() {
		return debitCreditInd;
	}

	public void setDebitCreditInd(String debitCreditInd) {
		this.debitCreditInd = debitCreditInd;
	}

	public int getTransactionCounter() {
		return transactionCounter;
	}

	public void setTransactionCounter(int transactionCounter) {
		this.transactionCounter = transactionCounter;
	}

	public String getRateIExchangeRate() {
		return rateIExchangeRate;
	}

	public void setRateIExchangeRate(String rateIExchangeRate) {
		this.rateIExchangeRate = rateIExchangeRate;
	}

	public BigDecimal getCalculatedAmount() {
		return calculatedAmount;
	}

	public void setCalculatedAmount(BigDecimal calculatedAmount) {
		this.calculatedAmount = calculatedAmount;
	}

	public BigDecimal getCalculatedLocalAmount() {
		return calculatedLocalAmount;
	}

	public void setCalculatedLocalAmount(BigDecimal calculatedLocalAmount) {
		this.calculatedLocalAmount = calculatedLocalAmount;
	}

	public BigDecimal getCalculatedOriginatorAmount() {
		return calculatedOriginatorAmount;
	}

	public void setCalculatedOriginatorAmount(BigDecimal calculatedOriginatorAmount) {
		this.calculatedOriginatorAmount = calculatedOriginatorAmount;
	}

	public BigDecimal getCalculatedOriginatorLocalAmount() {
		return calculatedOriginatorLocalAmount;
	}

	public void setCalculatedOriginatorLocalAmount(BigDecimal calculatedOriginatorLocalAmount) {
		this.calculatedOriginatorLocalAmount = calculatedOriginatorLocalAmount;
	}

	@Override
	public String toString() {
		return "TransactionSummary [transactionId=" + transactionId + ", bankCode=" + bankCode + ", baseCcy=" + baseCcy
				+ ", ccy=" + ccy + ", amount=" + amount + ", localAmount=" + localAmount + ", originatorAmount="
				+ originatorAmount + ", originatorLocalAmount=" + originatorLocalAmount + ", calculatedAmount="
				+ calculatedAmount + ", calculatedLocalAmount=" + calculatedLocalAmount
				+ ", calculatedOriginatorAmount=" + calculatedOriginatorAmount + ", calculatedOriginatorLocalAmount="
				+ calculatedOriginatorLocalAmount + ", exchangeOn=" + exchangeOn + ", dealRate=" + dealRate
				+ ", cptyRate=" + cptyRate + ", cptyCcyMask=" + cptyCcyMask + ", cptyCcyUnit=" + cptyCcyUnit
				+ ", exchangeRate=" + exchangeRate + ", rateIExchangeRate=" + rateIExchangeRate
				+ ", exchangeRateFormat=" + exchangeRateFormat + ", settlementDate=" + settlementDate
				+ ", deferClientEntry=" + deferClientEntry + ", counterpartyRatePackage=" + counterpartyRatePackage
				+ ", counterpartySellMarkup=" + counterpartySellMarkup + ", counterpartyBuyMarkup="
				+ counterpartyBuyMarkup + ", counterpartyMidRate=" + counterpartyMidRate + ", counterpartyStpLimit="
				+ counterpartyStpLimit + ", originatorRatePackage=" + originatorRatePackage + ", originatorRate="
				+ originatorRate + ", originatorSellMarkup=" + originatorSellMarkup + ", originatorBuyMarkup="
				+ originatorBuyMarkup + ", originatorMidRate=" + originatorMidRate + ", originatorStpLimit="
				+ originatorStpLimit + ", localPayment=" + localPayment + ", debitCreditInd=" + debitCreditInd
				+ ", transactionCounter=" + transactionCounter + "]";
	}

	@Override
	public String toStringShort() {
		return "TransactionSummary [transactionId=" + ", ccy=" + ccy + ", amount=" + amount + ", transactionCounter="
				+ transactionCounter + "]";
	}

	/**
	 * Builder for TransactionSummary
	 */
	public static class Builder implements BuilderPattern<TransactionSummary> {
		private long transactionId;
		private String bankCode;
		private String baseCcy;
		private String ccy;
		private BigDecimal amount;
		private BigDecimal localAmount;
		private BigDecimal originatorAmount;
		private BigDecimal originatorLocalAmount;
		private BigDecimal calculatedAmount;
		private BigDecimal calculatedLocalAmount;
		private BigDecimal calculatedOriginatorAmount;
		private BigDecimal calculatedOriginatorLocalAmount;
		private String exchangeOn;
		private String dealRate;
		private String cptyRate;
		private short cptyCcyMask;
		private short cptyCcyUnit;
		private String exchangeRate;
		private String rateIExchangeRate;
		private String exchangeRateFormat;
		private int settlementDate;
		private String deferClientEntry;
		private String counterpartyRatePackage;
		private String counterpartySellMarkup;
		private String counterpartyBuyMarkup;
		private String counterpartyMidRate;
		private String counterpartyStpLimit;
		private String originatorRatePackage;
		private String originatorRate;
		private String originatorSellMarkup;
		private String originatorBuyMarkup;
		private String originatorMidRate;
		private String originatorStpLimit;
		private boolean localPayment;
		private String debitCreditInd;
		private int transactionCounter;

		@Override
		public TransactionSummary build() {
			return new TransactionSummary(this);
		}

		public Builder setTransactionId(long transactionId) {
			this.transactionId = transactionId;
			return this;
		}

		public Builder setBankCode(String bankCode) {
			this.bankCode = bankCode;
			return this;
		}

		public Builder setBaseCcy(String baseCcy) {
			this.baseCcy = baseCcy;
			return this;
		}

		public Builder setCcy(String ccy) {
			this.ccy = ccy;
			return this;
		}

		public Builder setLocalAmount(BigDecimal localAmount) {
			this.localAmount = localAmount;
			return this;
		}

		public Builder setAmount(BigDecimal amount) {
			this.amount = amount;
			return this;
		}

		public Builder setOriginatorAmount(BigDecimal originatorAmount) {
			this.originatorAmount = originatorAmount;
			return this;
		}

		public Builder setOriginatorLocalAmount(BigDecimal originatorLlocalAmount) {
			this.originatorLocalAmount = originatorLlocalAmount;
			return this;
		}

		public Builder setExchangeOn(String exchangeOn) {
			this.exchangeOn = exchangeOn;
			return this;
		}

		public Builder setDealRate(String dealRate) {
			this.dealRate = dealRate;
			return this;
		}

		public Builder setCptyRate(String cptyRate) {
			this.cptyRate = cptyRate;
			return this;
		}

		public Builder setCptyCcyMask(short cptyCcyMask) {
			this.cptyCcyMask = cptyCcyMask;
			return this;
		}

		public Builder setCptyCcyUnit(short cptyCcyUnit) {
			this.cptyCcyUnit = cptyCcyUnit;
			return this;
		}

		public Builder setExchangeRate(String exchangeRate) {
			this.exchangeRate = exchangeRate;
			return this;
		}

		public Builder setRateIExchangeRate(String rateIExchangeRate) {
			this.rateIExchangeRate = rateIExchangeRate;
			return this;
		}

		public Builder setExchangeRateFormat(String exchangeRateFormat) {
			this.exchangeRateFormat = exchangeRateFormat;
			return this;
		}

		public Builder setSettlementDate(int settlementDate) {
			this.settlementDate = settlementDate;
			return this;
		}

		public Builder setDeferClientEntry(String deferClientEntry) {
			this.deferClientEntry = deferClientEntry;
			return this;
		}

		public Builder setCounterpartyRatePackage(String counterpartyRatePackage) {
			this.counterpartyRatePackage = counterpartyRatePackage;
			return this;
		}

		public Builder setCounterpartySellMarkup(String counterpartySellMarkup) {
			this.counterpartySellMarkup = counterpartySellMarkup;
			return this;
		}

		public Builder setCounterpartyBuyMarkup(String counterpartyBuyMarkup) {
			this.counterpartyBuyMarkup = counterpartyBuyMarkup;
			return this;
		}

		public Builder setCounterpartyMidRate(String counterpartyMidRate) {
			this.counterpartyMidRate = counterpartyMidRate;
			return this;
		}

		public Builder setCounterpartyStpLimit(String counterpartyStpLimit) {
			this.counterpartyStpLimit = counterpartyStpLimit;
			return this;
		}

		public Builder setOriginatorRatePackage(String originatorRatePackage) {
			this.originatorRatePackage = originatorRatePackage;
			return this;
		}

		public Builder setOriginatorRate(String originatorRate) {
			this.originatorRate = originatorRate;
			return this;
		}

		public Builder setOriginatorSellMarkup(String originatorSellMarkup) {
			this.originatorSellMarkup = originatorSellMarkup;
			return this;
		}

		public Builder setOriginatorBuyMarkup(String originatorBuyMarkup) {
			this.originatorBuyMarkup = originatorBuyMarkup;
			return this;
		}

		public Builder setOriginatorMidRate(String originatorMidRate) {
			this.originatorMidRate = originatorMidRate;
			return this;
		}

		public Builder setOriginatorStpLimit(String originatorStpLimit) {
			this.originatorStpLimit = originatorStpLimit;
			return this;
		}

		public Builder setLocalPayment(boolean localPayment) {
			this.localPayment = localPayment;
			return this;
		}

		public Builder setDebitCreditInd(String debitCreditInd) {
			this.debitCreditInd = debitCreditInd;
			return this;
		}

		public Builder setTransactionCounter(int transactionCounter) {
			this.transactionCounter = transactionCounter;
			return this;
		}

		public Builder setCalculatedAmount(BigDecimal calculatedAmount) {
			this.calculatedAmount = calculatedAmount;
			return this;
		}

		public Builder setCalculatedLocalAmount(BigDecimal calculatedLocalAmount) {
			this.calculatedLocalAmount = calculatedLocalAmount;
			return this;
		}

		public Builder setCalculatedOriginatorLocalAmount(BigDecimal calculatedOriginatorLocalAmount) {
			this.calculatedOriginatorLocalAmount = calculatedOriginatorLocalAmount;
			return this;
		}

		public Builder setCalculatedOriginatorAmount(BigDecimal calculatedOriginatorAmount) {
			this.calculatedOriginatorAmount = calculatedOriginatorAmount;
			return this;
		}
	}
}
