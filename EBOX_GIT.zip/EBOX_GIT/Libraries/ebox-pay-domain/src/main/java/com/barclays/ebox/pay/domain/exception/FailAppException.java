package com.barclays.ebox.pay.domain.exception;

/**
 * Exception thrown when there is a Validation or Technical Error
 * 
 * @author abrma5s
 *
 */
public class FailAppException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default Constructor
	 * 
	 * @param message
	 */
	public FailAppException(String message) {
		super(message);

	}

	/**
	 * Constructor that accepts a throwable. This is used when propagating
	 * another exception and also adding a custom message
	 * 
	 * @param message
	 * @param throwable
	 */
	public FailAppException(String message, Throwable throwable) {
		super(message, throwable);
	}
}