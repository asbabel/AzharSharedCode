package com.barclays.ebox.pay.domain;

import java.io.Serializable;

/**
 * Marker Interface to identify supported Domain objects.
 * 
 * @author g01025860
 */
@FunctionalInterface
public interface DomainObject extends Serializable {
	/**
	 * Constructs a cut down version of toString. Typically this will involve
	 * printing the Primary Key attributes.
	 * 
	 * @return String the short String version of the object
	 */
	String toStringShort();
}
