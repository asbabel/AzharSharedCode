package com.barclays.ebox.pay.domain.builder;

/**
 * Implemented by classes who wish to Implement a Builder Pattern
 * 
 * @author g01025860
 *
 * @param <T>
 *            The Type of Objects this Builder builds.
 */
@FunctionalInterface
public interface BuilderPattern<T> {
	/**
	 * Builds the object of type <T>.
	 * 
	 * @return <T> The Object of type <T>
	 */
	T build();
}
