package com.barclays.ebox.pay.domain;

import java.util.Date;

import com.barclays.ebox.pay.domain.builder.BuilderPattern;

/**
 * A RequestHeader represents information about the incoming REQUEST Which could
 * be a File, or an MQ message, or other type.
 */
@SuppressWarnings("all")
public class RequestHeader implements DomainObject {
	private static final long serialVersionUID = 1625688249193144503L;
	private long requestHeaderId;
	private String fileName;
	private String messageType;
	private String format;
	private String messageId;
	private String transactionId;
	private String accountingToken;
	private String sourceApplName;
	private String sourceApplFunc;
	private Date sentDate;
	private String userIdentity;
	private String userPassword;
	private String targetCountry;
	private String status;
	private int errorCode;
	private String projectId;
	private int propertyOffshoreInd;
	private String propertyAdjustBalance;
	private String propertyCheckAccount;
	private String propertyBatch;
	private String propertyCheckOrigAccExists;
	private String propertyCheckOrigAccOpen;
	private String propertyCheckOrigAccCurrency;
	private String propertyCheckOrigAccBalance;
	private String propertyCheckCounterpartyAcc;
	private String propertyUserId;
	private String propertyLocationCode;
	private String respondToType;
	private String respondTo;
	private String replayFlag;
	private String requestSource;
	private String postDate;
	private int retryCount;
	private Date repliedOn;
	private String encodedCountry;
	private String bankCode;
	private String sourceLocationBranch;
	private String terminalNumber;
	private boolean isRetry;

	private RequestHeader(Builder builder) {
		this.requestHeaderId = builder.requestHeaderId;
		this.fileName = builder.fileName;
		this.messageType = builder.messageType;
		this.format = builder.format;
		this.messageId = builder.messageId;
		this.transactionId = builder.transactionId;
		this.accountingToken = builder.accountingToken;
		this.sourceApplName = builder.sourceApplName;
		this.sourceApplFunc = builder.sourceApplFunc;
		this.sentDate = builder.sentDate;
		this.userIdentity = builder.userIdentity;
		this.userPassword = builder.userPassword;
		this.targetCountry = builder.targetCountry;
		this.status = builder.status;
		this.errorCode = builder.errorCode;
		this.projectId = builder.projectId;
		this.propertyOffshoreInd = builder.propertyOffshoreInd;
		this.propertyAdjustBalance = builder.propertyAdjustBalance;
		this.propertyCheckAccount = builder.propertyCheckAccount;
		this.propertyBatch = builder.propertyBatch;
		this.propertyCheckOrigAccExists = builder.propertyCheckOrigAccExists;
		this.propertyCheckOrigAccOpen = builder.propertyCheckOrigAccOpen;
		this.propertyCheckOrigAccCurrency = builder.propertyCheckOrigAccCurrency;
		this.propertyCheckOrigAccBalance = builder.propertyCheckOrigAccBalance;
		this.propertyCheckCounterpartyAcc = builder.propertyCheckCounterpartyAcc;
		this.propertyUserId = builder.propertyUserId;
		this.propertyLocationCode = builder.propertyLocationCode;
		this.respondToType = builder.respondToType;
		this.respondTo = builder.respondTo;
		this.replayFlag = builder.replayFlag;
		this.requestSource = builder.requestSource;
		this.postDate = builder.postDate;
		this.retryCount = builder.retryCount;
		this.repliedOn = builder.repliedOn;
		this.encodedCountry = builder.encodedCountry;
		this.bankCode = builder.bankCode;
		this.sourceLocationBranch = builder.sourceLocationBranch;
		this.terminalNumber = builder.terminalNumber;
		this.isRetry = builder.isRetry;
	}

	public long getRequestHeaderId() {
		return requestHeaderId;
	}

	public void setRequestHeaderId(long requestHeaderId) {
		this.requestHeaderId = requestHeaderId;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getRespondToType() {
		return respondToType;
	}

	public void setRespondToType(String respondToType) {
		this.respondToType = respondToType;
	}

	public String getRespondTo() {
		return respondTo;
	}

	public void setRespondTo(String respondTo) {
		this.respondTo = respondTo;
	}

	public String getReplayFlag() {
		return replayFlag;
	}

	public void setReplayFlag(String replayFlag) {
		this.replayFlag = replayFlag;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getAccountingToken() {
		return accountingToken;
	}

	public void setAccountingToken(String accountingToken) {
		this.accountingToken = accountingToken;
	}

	public String getSourceApplName() {
		return sourceApplName;
	}

	public void setSourceApplName(String sourceApplName) {
		this.sourceApplName = sourceApplName;
	}

	public String getSourceApplFunc() {
		return sourceApplFunc;
	}

	public void setSourceApplFunc(String sourceApplFunc) {
		this.sourceApplFunc = sourceApplFunc;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	public String getUserIdentity() {
		return userIdentity;
	}

	public void setUserIdentity(String userIdentity) {
		this.userIdentity = userIdentity;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getTargetCountry() {
		return targetCountry;
	}

	public void setTargetCountry(String targetCountry) {
		this.targetCountry = targetCountry;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public int getPropertyOffshoreInd() {
		return propertyOffshoreInd;
	}

	public void setPropertyOffshoreInd(int propertyOffshoreInd) {
		this.propertyOffshoreInd = propertyOffshoreInd;
	}

	public String getPropertyAdjustBalance() {
		return propertyAdjustBalance;
	}

	public void setPropertyAdjustBalance(String propertyAdjustBalance) {
		this.propertyAdjustBalance = propertyAdjustBalance;
	}

	public String getPropertyCheckAccount() {
		return propertyCheckAccount;
	}

	public void setPropertyCheckAccount(String propertyCheckAccount) {
		this.propertyCheckAccount = propertyCheckAccount;
	}

	public String getPropertyBatch() {
		return propertyBatch;
	}

	public void setPropertyBatch(String propertyBatch) {
		this.propertyBatch = propertyBatch;
	}

	public String getPropertyCheckOrigAccExists() {
		return propertyCheckOrigAccExists;
	}

	public void setPropertyCheckOrigAccExists(String propertyCheckOrigAccExists) {
		this.propertyCheckOrigAccExists = propertyCheckOrigAccExists;
	}

	public String getPropertyCheckOrigAccOpen() {
		return propertyCheckOrigAccOpen;
	}

	public void setPropertyCheckOrigAccOpen(String propertyCheckOrigAccOpen) {
		this.propertyCheckOrigAccOpen = propertyCheckOrigAccOpen;
	}

	public String getPropertyCheckOrigAccCurrency() {
		return propertyCheckOrigAccCurrency;
	}

	public void setPropertyCheckOrigAccCurrency(String propertyCheckOrigAccCurrency) {
		this.propertyCheckOrigAccCurrency = propertyCheckOrigAccCurrency;
	}

	public String getPropertyCheckOrigAccBalance() {
		return propertyCheckOrigAccBalance;
	}

	public void setPropertyCheckOrigAccBalance(String propertyCheckOrigAccBalance) {
		this.propertyCheckOrigAccBalance = propertyCheckOrigAccBalance;
	}

	public String getPropertyCheckCounterpartyAcc() {
		return propertyCheckCounterpartyAcc;
	}

	public void setPropertyCheckCounterpartyAcc(String propertyCheckCounterpartyAcc) {
		this.propertyCheckCounterpartyAcc = propertyCheckCounterpartyAcc;
	}

	public String getPropertyUserId() {
		return propertyUserId;
	}

	public void setPropertyUserId(String propertyUserId) {
		this.propertyUserId = propertyUserId;
	}

	public String getPropertyLocationCode() {
		return propertyLocationCode;
	}

	public void setPropertyLocationCode(String propertyLocationCode) {
		this.propertyLocationCode = propertyLocationCode;
	}

	public String getRequestSource() {
		return requestSource;
	}

	public void setRequestSource(String requestSource) {
		this.requestSource = requestSource;
	}

	public String getPostDate() {
		return postDate;
	}

	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}

	public int getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}

	/**
	 * @return the repliedOn
	 */
	public Date getRepliedOn() {
		return repliedOn;
	}

	/**
	 * @param repliedOn the repliedOn to set
	 */
	public void setRepliedOn(Date repliedOn) {
		this.repliedOn = repliedOn;
	}

	public String getEncodedCountry() {
		return encodedCountry;
	}

	public void setEncodedCountry(String encodedCountry) {
		this.encodedCountry = encodedCountry;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getSourceLocationBranch() {
		return sourceLocationBranch;
	}

	public void setSourceLocationBranch(String sourceLocationBranch) {
		this.sourceLocationBranch = sourceLocationBranch;
	}

	public String getTerminalNumber() {
		return terminalNumber;
	}

	public void setTerminalNumber(String terminalNumber) {
		this.terminalNumber = terminalNumber;
	}

	/**
	 * @return the isRetry
	 */
	public boolean isRetry() {
		return isRetry;
	}

	/**
	 * @param isRetry the isRetry to set
	 */
	public void setRetry(boolean isRetry) {
		this.isRetry = isRetry;
	}

	@Override
	public String toString() {
		return "RequestHeader [requestHeaderId=" + requestHeaderId + ", fileName =" + fileName + ", messageType=" + messageType + ", "
				+ "format=" + format + ", messageId=" + messageId + ", transactionId=" + transactionId + ", accountingToken="
				+ accountingToken + ", sourceApplName=" + sourceApplName + ", sourceApplFunc=" + sourceApplFunc
				+ ", sentDate=" + sentDate + ", userIdentity=" + userIdentity + ", userPassword=" + userPassword
				+ ", targetCountry=" + targetCountry + ", status=" + status + ", errorCode=" + errorCode
				+ ", projectId=" + projectId + ", propertyOffshoreInd=" + propertyOffshoreInd
				+ ", propertyAdjustBalance=" + propertyAdjustBalance + ", propertyCheckAccount=" + propertyCheckAccount
				+ ", propertyBatch=" + propertyBatch + ", propertyCheckOrigAccExists=" + propertyCheckOrigAccExists
				+ ", propertyCheckOrigAccOpen=" + propertyCheckOrigAccOpen + ", propertyCheckOrigAccCurrency="
				+ propertyCheckOrigAccCurrency + ", propertyCheckOrigAccBalance=" + propertyCheckOrigAccBalance
				+ ", propertyCheckCounterpartyAcc=" + propertyCheckCounterpartyAcc + ", propertyUserId="
				+ propertyUserId + ", propertyLocationCode=" + propertyLocationCode + ", respondToType=" + respondToType
				+ ", respondTo=" + respondTo + ", replayFlag=" + replayFlag + ", requestSource=" + requestSource
				+ ", postDate=" + postDate + ", retryCount=" + retryCount + ", encodedCountry=" + encodedCountry
				+ ", bankCode=" + bankCode + ", sourceLocationBranch=" + sourceLocationBranch + ", terminalNumber="
				+ terminalNumber + "]";
	}

	@Override
	public String toStringShort() {
		return "RequestHeader [filename=" + this.fileName + ", header ID=" + this.requestHeaderId
				+ ", transaction ID=" + this.transactionId + ", status=" + status + "]";
	}

	/**
	 * Builder for RequestHeader
	 */
	public static class Builder implements BuilderPattern<RequestHeader> {
		private long requestHeaderId;
		private String fileName;
		private String messageType;
		private String format;
		private String messageId;
		private String transactionId;
		private String accountingToken;
		private String sourceApplName;
		private String sourceApplFunc;
		private Date sentDate;
		private String userIdentity;
		private String userPassword;
		private String targetCountry;
		private String status;
		private int errorCode;
		private String projectId;
		private int propertyOffshoreInd;
		private String propertyAdjustBalance;
		private String propertyCheckAccount;
		private String propertyBatch;
		private String propertyCheckOrigAccExists;
		private String propertyCheckOrigAccOpen;
		private String propertyCheckOrigAccCurrency;
		private String propertyCheckOrigAccBalance;
		private String propertyCheckCounterpartyAcc;
		private String propertyUserId;
		private String propertyLocationCode;
		private String respondToType;
		private String respondTo;
		private String replayFlag;
		private String requestSource;
		private String postDate;
		private int retryCount;
		private Date repliedOn;
		private String encodedCountry;
		private String bankCode;
		private String sourceLocationBranch;
		private String terminalNumber;
		private boolean isRetry;

		@Override
		public RequestHeader build() {
			if (null == this.sentDate) {
				this.setSentDate(new Date());
			}
			return new RequestHeader(this);
		}

		public Builder setRequestHeaderId(long requestHeaderId) {
			this.requestHeaderId = requestHeaderId;
			return this;
		}
		
		public Builder setFileName(String fileName) {
			this.fileName = fileName;
			return this;
		}

		public Builder setMessageType(String messageType) {
			this.messageType = messageType;
			return this;
		}

		public Builder setFormat(String format) {
			this.format = format;
			return this;
		}

		public Builder setMessageId(String messageID) {
			this.messageId = messageID;
			return this;
		}

		public Builder setTransactionId(String transactionId) {
			this.transactionId = transactionId;
			return this;
		}

		public Builder setAccountingToken(String accountingToken) {
			this.accountingToken = accountingToken;
			return this;
		}

		public Builder setSourceApplName(String sourceApplName) {
			this.sourceApplName = sourceApplName;
			return this;
		}

		public Builder setSourceApplFunc(String sourceApplFunc) {
			this.sourceApplFunc = sourceApplFunc;
			return this;
		}

		public Builder setSentDate(Date sentDate) {
			this.sentDate = sentDate;
			return this;
		}

		public Builder setUserIdentity(String userIdentity) {
			this.userIdentity = userIdentity;
			return this;
		}

		public Builder setUserPassword(String userPassword) {
			this.userPassword = userPassword;
			return this;
		}

		public Builder setTargetCountry(String targetCountry) {
			this.targetCountry = targetCountry;
			return this;
		}

		public Builder setStatus(String status) {
			this.status = status;
			return this;
		}

		public Builder setErrorCode(int errorCode) {
			this.errorCode = errorCode;
			return this;
		}

		public Builder setProjectId(String projectId) {
			this.projectId = projectId;
			return this;
		}

		public Builder setPropertyOffshoreInd(int propertyOffshoreInd) {
			this.propertyOffshoreInd = propertyOffshoreInd;
			return this;
		}

		public Builder setPropertyAdjustBalance(String propertyAdjustBalance) {
			this.propertyAdjustBalance = propertyAdjustBalance;
			return this;
		}

		public Builder setPropertyCheckAccount(String propertyCheckAccount) {
			this.propertyCheckAccount = propertyCheckAccount;
			return this;
		}

		public Builder setPropertyBatch(String propertyBatch) {
			this.propertyBatch = propertyBatch;
			return this;
		}

		public Builder setPropertyCheckOrigAccExists(String propertyCheckOrigAccExists) {
			this.propertyCheckOrigAccExists = propertyCheckOrigAccExists;
			return this;
		}

		public Builder setPropertyCheckOrigAccOpen(String propertyCheckOrigAccOpen) {
			this.propertyCheckOrigAccOpen = propertyCheckOrigAccOpen;
			return this;
		}

		public Builder setPropertyCheckOrigAccCurrency(String propertyCheckOrigAccCurrency) {
			this.propertyCheckOrigAccCurrency = propertyCheckOrigAccCurrency;
			return this;
		}

		public Builder setPropertyCheckOrigAccBalance(String propertyCheckOrigAccBalance) {
			this.propertyCheckOrigAccBalance = propertyCheckOrigAccBalance;
			return this;
		}

		public Builder setPropertyCheckCounterpartyAcc(String propertyCheckCounterpartyAcc) {
			this.propertyCheckCounterpartyAcc = propertyCheckCounterpartyAcc;
			return this;
		}

		public Builder setPropertyUserId(String propertyUserId) {
			this.propertyUserId = propertyUserId;
			return this;
		}

		public Builder setPropertyLocationCode(String propertyLocationCode) {
			this.propertyLocationCode = propertyLocationCode;
			return this;
		}

		public Builder setRespondToType(String respondToType) {
			this.respondToType = respondToType;
			return this;
		}

		public Builder setRespondTo(String respondTo) {
			this.respondTo = respondTo;
			return this;
		}

		public Builder setReplayFlag(String replayFlag) {
			this.replayFlag = replayFlag;
			return this;
		}

		public Builder setRequestSource(String requestSource) {
			this.requestSource = requestSource;
			return this;
		}

		public Builder setPostDate(String postDate) {
			this.postDate = postDate;
			return this;
		}

		public Builder setRetryCount(int retryCount) {
			this.retryCount = retryCount;
			return this;
		}

		/**
		 * @param repliedOn the repliedOn to set
		 */
		public Builder setRepliedOn(Date repliedOn) {
			this.repliedOn = repliedOn;
			return this;
		}

		public Builder setEncodedCountry(String encodedCountry) {
			this.encodedCountry = encodedCountry;
			return this;
		}

		public Builder setBankCode(String bankCode) {
			this.bankCode = bankCode;
			return this;
		}

		public Builder setSourceLocationBranch(String sourceLocationBranch) {
			this.sourceLocationBranch = sourceLocationBranch;
			return this;
		}

		public Builder setTerminalNumber(String terminalNumber) {
			this.terminalNumber = terminalNumber;
			return this;
		}

		/**
		 * @param isRetry the isRetry to set
		 */
		public void setRetry(boolean isRetry) {
			this.isRetry = isRetry;
		}
	}
}
