package com.barclays.mail;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.commons.lang.StringUtils;

import com.barclays.generic.business.utils.LoggerConnection;

/**
 * Provide Email alerting functionality.
 * 
 * @author ABNSA31
 */
public class EmailAlertsUtility {

	private static final LoggerConnection logger = new LoggerConnection(EmailAlertsUtility.class);
	private static final String SMTP_HOST = "mail.smtp.host";

	/**
	 * Sends mail to only to single recipient
	 * 
	 * @param subject
	 *            : Mail subject
	 * @param body
	 *            : Mail body
	 * @param from
	 * @param recipient
	 *            : List of recipient
	 * @param host
	 *            : SMTP host name
	 */
	public static void sendMail(String subject, String body, String from, String recipient, String host) {

		Properties properties = System.getProperties();
		// Setting up mail server
		properties.put(SMTP_HOST, host);
		Session session = Session.getInstance(properties);
		Message message = new MimeMessage(session);
		try {

			if (StringUtils.isNotBlank(from)) {
				message.setFrom(new InternetAddress(from));
			} else {
				logger.error("Sender is empty/blank");
				return;
			}

			if (StringUtils.isNotBlank(recipient)) {
				message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
			} else {
				logger.error("Recipient is empty/blank");
				return;
			}

			message.setSubject(subject);
			message.setText(body);
			Transport.send(message);

		} catch (MessagingException e) {
			logger.error("Sending email failed" + " : " +e.getMessage());
		} catch (Exception e) {
			logger.error("Sending email failed" + e.getMessage());
		}
	}
	
	/**
	 * Sends mail to only to single recipient with attachment
	 * 
	 * @param subject : Mail subject
	 * @param body: Mail body
	 * @param from
	 * @param recipient: List of recipient
	 * @param host : SMTP host name
	 * @param attachFiles : Complete Filepath+FileName
	 */
	public static void sendMailAttachment(String subject, String body, String from, String recipient, String host, String attachFiles) {

		Properties properties = System.getProperties();
		// 1) Setting up mail server
		properties.put(SMTP_HOST, host);
		Session session = Session.getInstance(properties);
		Message message = new MimeMessage(session);
		MimeMessage mimemessage = new MimeMessage(session);
		
		// 2) compose message
		try {
			if (StringUtils.isNotBlank(from)) {
				mimemessage.setFrom(new InternetAddress(from));
			} else {
				logger.error("Sender is empty/blank");
				return;
			}

			if (StringUtils.isNotBlank(recipient)) {
				mimemessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
			} else {
				logger.error("Recipient is empty/blank");
				return;
			}
			mimemessage.setSubject("CPB MDMC Report");

			// 3) create MimeBodyPart object and set your message text
			BodyPart messageBodyPart1 = new MimeBodyPart();
			messageBodyPart1.setText(body);

			// 4) create new MimeBodyPart object and set DataHandler object to this object
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();
			DataSource source = new FileDataSource(attachFiles);
			messageBodyPart2.setDataHandler(new DataHandler(source));
			messageBodyPart2.setFileName(attachFiles);

			// 5) create Multipart object and add MimeBodyPart objects to this object
			Multipart multipart1 = new MimeMultipart();
			multipart1.addBodyPart(messageBodyPart1);
			multipart1.addBodyPart(messageBodyPart2);

			// 6) set the multiplart object to the message object
			mimemessage.setContent(multipart1);

			message.setSubject(subject);
			Transport.send(mimemessage);

		} catch (MessagingException e) {
			logger.error("Sending email failed" + " : " + e.getMessage());
		} catch (Exception e) {
			logger.error("Sending email failed" + e.getMessage());
		}
	}
}
