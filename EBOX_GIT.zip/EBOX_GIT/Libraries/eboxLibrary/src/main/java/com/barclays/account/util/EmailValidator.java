package com.barclays.account.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Validates an email an spits out validation messages
 * 
 * @author Adam Slater
 * 
 */
/* 
 * DATE      REFERENCE   WHO     	VERSION  	COMMENTS
 * --------  ---------   ---     	-------  	----------------------
 * 30/05/13				SLATERA					Created
 * 01/08/13             STANLEYR                Added new message for start/end 
 *                                              with an @ character
 */
public class EmailValidator {

	private static final String ONE_AT_SIGN = 
		"The email address must contain only one @ character";
	private static final String LOCAL_PART_CHARS = 
		"The local (first) part of the email address can contain " +
			"only English letters (a-z, A-Z), digits 0-9, - (hyphen) ," +
			" _ (underscore) and . (dot)";
	private static final String DOMAIN_PART_CHARS = 
		"The domain (last) part of the email address can contain only " +
		"English letters (a-z, A-Z), digits 0-9, -(hyphen) and .(dot)";
	private static final String DOMAIN_PART_DOT = 
		"The domain (last) part of the email address must " +
		"contain at least one .(dot) and one alpha character";
	private static final String DOMAIN_PART_HYPHEN = 
		"The domain (last) part of the email address cannot contain " +
		"a - (hyphen) which is the first or last character, or is " +
		"immediately before or after a . (dot)";
	private static final String EMAIL_DOT = 
		"The email address cannot start or end with a . (dot) and a ." +
		"(dot) cannot appear two or more times consecutively";
	private static final String START_END_AT_SIGN =
		"The email address must not start or end with an @ charcater";
	
	/**
	 * Validates an email
	 * @param email the email address to validate
	 * @return A list of validation errors
	 */
	public static List<String> validateEmail(String email){
		List<String> errors = new ArrayList<String>();
		
		
		if(email.startsWith("@")||email.endsWith("@"))
		{
			errors.add(START_END_AT_SIGN);
			return errors;
		}
		
		String[] emailSplit = email.split("@");
		if(emailSplit.length!=2){
			errors.add(ONE_AT_SIGN);
			return errors;
		}
		
		String localPart=emailSplit[0];
		String domainPart=emailSplit[1];
		
		if(!matchesPattern(localPart, "^[A-Za-z0-9_.-]+$")){
			errors.add(LOCAL_PART_CHARS);
		}
		
		if(!matchesPattern(domainPart, "^[A-Za-z0-9.-]+$")){
			errors.add(DOMAIN_PART_CHARS);
		}
		if(matchesPattern(domainPart, "^[^A-Za-z]+$")||
				matchesPattern(domainPart, "^[^.]+$")){
			errors.add(DOMAIN_PART_DOT);
		}
		if(domainPart.startsWith("-")||domainPart.endsWith("-")
				||domainPart.contains("-.")||domainPart.contains(".-")){
			errors.add(DOMAIN_PART_HYPHEN);
		}
		if(domainPart.startsWith(".")||domainPart.endsWith(".")
				||localPart.startsWith(".")||localPart.endsWith(".")
				||email.contains("..")){
			errors.add(EMAIL_DOT);
		}
		return errors;
	}
	
	/**
	 * Validates a value against a pattern
	 * @param value the value to match
	 * @param pattern the pattern to match against
	 * @return
	 */
	protected static boolean matchesPattern(String value,String pattern){
		Pattern patternMatcher = Pattern.compile(pattern);
		Matcher  matcher = patternMatcher.matcher(value);
		return matcher.matches();
	}
	
}
