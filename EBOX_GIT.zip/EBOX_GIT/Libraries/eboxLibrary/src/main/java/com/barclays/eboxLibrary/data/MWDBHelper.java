package com.barclays.eboxLibrary.data;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.generic.transactions.DataAccess;
import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.bean.Country;
/**
 * Wraps up some helper methods when connecting to the db
 * 
 * @author goodlifw
 *
 */
/* 
 * DATE      REFERENCE   WHO     VERSION  COMMENTS
 * --------  ---------   ---     -------  --------------------------------------
 * 26/01/12  WP615       WIG     R5M2  	  Created using code from the eboxService.
 * 02/08/13	 WP623		 VAIBHAV		  Added getNextEboxReference() and 
 * 											getTwoCharCountryCode() methods
 */
public class MWDBHelper {
	
    /**
     * A fresh database connection.
     */
    public static SQLConnection getDatabaseConnection()
        throws
            SQLException
    {
        return new SQLConnection(
                DataSourceDirectory.getInstance().getDataSource(
                        "mwdb").getConnection());
    }
	 
    /**
     * Gets MW_RefValues Description for a given code and domain
     * @return
     */
    public static String getMWRefValue(
    		String country, 
    		boolean offshore, 
    		String domain, 
    		String code)
    throws Exception
    {
    	String output = null;
    	SortedMap<String, Object> args = new TreeMap<String, Object>();
    	args.put("Country", country);
        args.put("OffshoreInd", offshore ? "1" : "0");
        args.put("Domain", domain);
        args.put("Code", code);
    	SQLConnection database = getDatabaseConnection();
        try{
	        CallableStatement st = database.prepareCall(
	                "dbo.wfe_adminMWRefValueGet",
	                args);
	        try {
	            ResultSet rs = database.executeQuery(st, args);
	            if (rs.next())
	            {
	            	output = rs.getString("Description");
	            }
	        }
	        finally { st.close(); }
	    }
        finally { database.close(); }  
        return output;
    }

	/**
	 * This method returns the activity reference for the given country & task
	 * code
	 * 
	 * @param country
	 * @param taskCode
	 * @return
	 * @throws Exception
	 */
	public static String getNextEboxReference(Country country, String taskCode)
			throws Exception
	{
		String output = null;
		DataAccess txData = new DataAccess();
		SQLConnection conn = null;
		try
		{
			conn = getDatabaseConnection();
			txData.setDatabase(conn);
			output = txData.nextEBoxReference(country, taskCode);
		}
		finally
		{
			if (conn != null)
			{
				conn.close();
			}
		}
		return output;
	}

	/**
	 * This method is used to get the 2 character country code for the given
	 * country
	 * 
	 * @param country
	 * @return
	 * @throws Exception
	 */
	public static String getTwoCharCountryCode(String country) throws Exception
	{
		String twoCharCountryCode = null;
		SQLConnection con = null;
		try
		{
			con = getDatabaseConnection();
			SortedMap<String, Object> args = new TreeMap<String, Object>();
			args.put("_country",
					con.makeInputOutputParameter(Types.CHAR, country));
			Map<?, ?> output = con.execute("csc_get2AlphaCountry", args);
			twoCharCountryCode = (String) output.get("_country");
			if (twoCharCountryCode != null)
				twoCharCountryCode = twoCharCountryCode.trim();
		}
		finally
		{
			if (con != null)
			{
				con.close();
			}
		}
		return twoCharCountryCode;
	}
}
