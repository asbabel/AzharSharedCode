package com.barclays.account.data.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Represents a request for a duplicate historic statement.
 * 
 * @author  DIXONS
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 25Sep12  WP616RqStm DIXONS 1a       Created.
 */
public class HistoricStatementRequest implements Serializable {
	
	/**
	 * appease the serialisation gods
	 */
	private static final long serialVersionUID = -6432598521632088530L;
	
	private String eboxActivityReference;
	private int branchNumber;
	private int accountNumber;
	private Date dateFrom;
	private Date dateTo;
	private int customerNumber;
	private String customerName;
	private String staffwareCaseNumber;
	
	public String getEboxActivityReference() {
		return eboxActivityReference;
	}
	public void setEboxActivityReference(String eboxActivityReference) {
		this.eboxActivityReference = eboxActivityReference;
	}
	public int getBranchNumber() {
		return branchNumber;
	}
	public void setBranchNumber(int branchNumber) {
		this.branchNumber = branchNumber;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Date getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}
	public Date getDateTo() {
		return dateTo;
	}
	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}
	public int getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(int customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getStaffwareCaseNumber() {
		return staffwareCaseNumber;
	}
	public void setStaffwareCaseNumber(String staffwareCaseNumber) {
		this.staffwareCaseNumber = staffwareCaseNumber;
	}
	
	/**
	 * Returns a string describing the request, suitable for displaying on the
	 * Statement View screen.<br/>
	 * The format is [Ebox Activity Reference] [Customer Display Name] From [Date From] To [Date To].
	 * 
	 * @return String describing the request
	 */
	public String getRequestedByString() {
		StringBuffer requestedBy = new StringBuffer("");
		if (!"".equals(eboxActivityReference)) {
			requestedBy.append(eboxActivityReference);
			requestedBy.append(" ");
		}
		if (!"".equals(customerName)) {
			requestedBy.append(customerName);
			requestedBy.append(" ");
		}
		if (dateFrom != null && dateTo != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
			requestedBy.append(dateFormat.format(dateFrom));
			requestedBy.append(" To ");
			requestedBy.append(dateFormat.format(dateTo));
		}
		return requestedBy.toString();
	}
}
