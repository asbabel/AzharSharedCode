package com.barclays.generic.util;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.eboxLibrary.data.MWDBHelper;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.bean.Currency;

/**
 * Utility class providing methods for retrieving currency information.
 * 
 * @author DIXONS
 */
/* 
 * DATE     REFERENCE   WHO   		VERSION  COMMENTS
 * -------  ---------   ---   		-------  ---------
 * 15Nov12	WP616RqStm  SD			1		 Created. The getCurrencyByNumber
 * 											 method was poached from the
 * 											 OutwardMessageProcessor's 
 * 											 Database.fetchCurrencyDetail method.
 */
public class CurrencyUtil {

	public static Currency getCurrencyByNumber(
			String country,
			boolean isOffshore,
			String currencyNumber) throws java.sql.SQLException {
		SQLConnection conn = MWDBHelper.getDatabaseConnection();

		SortedMap<String, Object> args = new TreeMap<String, Object>();
		args.put("country", country);
		args.put("offshore", new Integer(isOffshore ? 1 : 0));
		args.put("currencyNumber", currencyNumber);

		Currency currency = null;
		try {
			CallableStatement st = conn.prepareCall("usp_CurrencyNameGet", args);
			try {
				ResultSet rs = conn.executeQuery(st, args);
				if (rs.next()) {
					currency = new Currency(rs.getString("Currency"));
					currency.setMask((Integer) rs.getObject("Mask"));
					currency.setName(rs.getString("Name"));
					currency.setNumber((Integer) rs.getObject("Number"));
					currency.setUnit((Integer) rs.getObject("Unit"));
				}
			} finally {
				st.close();
			}
		} finally {
			conn.close();
		}
		return currency;
	}
}
