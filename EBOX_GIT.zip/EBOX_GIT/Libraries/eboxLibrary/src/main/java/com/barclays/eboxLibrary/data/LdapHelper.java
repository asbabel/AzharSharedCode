package com.barclays.eboxLibrary.data;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.RowSetDynaClass;

import com.barclays.generic.connection.GenericSQLConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.dataAccess.DataAccessException;

/**
 * Helper class to contain all database functionality for Ldap Connections.
 * @author G07162832
 *
 */
/* 
 * DATE      REFERENCE   WHO     VERSION  COMMENTS
 * --------  ---------   ---     -------  --------------------------------------
 * 03/12/15  WP654       Shane     1.0    Created.
 * 
 *                                          
 */
public class LdapHelper {

    /**
     * This method gets a set of comparison data directly from the SQL database. This allows
     * validation of our BarclaysDirContext obj which will be used in connecting to Active Directory.
     * @param processingEngineName = What server type are you attempting to connect to i.e. LDAP-MAINT.
     * @return = dataset for processing engine selected i.e. LDAP-MANAGED
     * @throws SQLException
     * @throws DataAccessException
     */
    public static DynaBean getConnectionDetailsForComparison(String processingEngineName) 
            throws SQLException, DataAccessException{
        HashMap<String, Object> inParams = new HashMap<String, Object>();
        inParams.put("engine", processingEngineName);
        inParams.put("country", "*");
        inParams.put("offshore", 0);
        GenericSQLConnection conn = new GenericSQLConnection();
        
        return extractFirstRow((RowSetDynaClass) conn.executeResultSet("wfe_EChannelConnectionGet", inParams));
    }
    
    /**
     * This method uses a specified SQLConnection object to access the database
     * and not a GenericSQLConnection. This method gets a set of comparison data
     * directly from the SQL database. This allows validation of our
     * BarclaysDirContext obj which will be used in connecting to Active
     * Directory.
     * 
     * @param processingEngineName = What server type are you attempting to
     * connect to i.e. LDAP-MAINT.
     * @param sqlConnection The SQL connection used to access the database.
     * @return = dataset for processing engine selected i.e. LDAP-MANAGED
     * @throws SQLException
     * @throws DataAccessException
     */
    public static DynaBean getConnectionDetailsForComparison(
            String processingEngineName,
            SQLConnection sqlConnection)
            throws SQLException,
            DataAccessException {

        SortedMap<String, Object> inParams = new TreeMap<>();
        inParams.put("engine", processingEngineName);
        inParams.put("country", "*");
        inParams.put("offshore", 0);

        CallableStatement statement =
                sqlConnection.prepareCall("wfe_EChannelConnectionGet", inParams);
        ResultSet resultSet = sqlConnection.executeQuery(statement, inParams);
        RowSetDynaClass rowSet = new RowSetDynaClass(resultSet);

        return extractFirstRow(rowSet);
    }

    /**
     * Gets the first row from the result set.
     * 
     * @param resultSet The result set to get the row from.
     * @return A DynaBean object representing the first row.
     */
    private static DynaBean extractFirstRow(RowSetDynaClass resultSet){
        return (DynaBean) resultSet.getRows().get(0);
    }
    
}
