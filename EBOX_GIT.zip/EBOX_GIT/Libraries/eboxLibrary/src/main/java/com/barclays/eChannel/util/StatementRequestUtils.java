package com.barclays.eChannel.util;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.absa.ebox.rest.api.client.EboxRestApiClient;
import com.absa.ebox.rest.api.client.JsonHelper;
import com.absa.ebox.rest.api.client.model.json.request.ActivityTrackingSearchRequest;
import com.barclays.account.data.bean.CurrentStatementRequest;
import com.barclays.account.data.bean.HistoricStatementRequest;
import com.barclays.eChannel.data.bean.BrainsCountry;
import com.barclays.eboxLibrary.data.MWDBHelper;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.bean.Country;
import com.barclays.generic.jbpm.JbpmServer;
import com.barclays.generic.transactions.DataAccess;
import com.barclays.generic.transactions.Posting;
import com.barclays.middleware.brains.ACC_IA;
import com.barclays.middleware.brains.BrainsToken;
import com.barclays.middleware.brains.CUS_I;
import com.barclays.middleware.brains.NFA_ST;
import com.barclays.middleware.brains.REQ_D;
import com.barclays.middleware.brains.REQ_L;
import com.fasterxml.jackson.core.type.TypeReference;

/**
 * Utility class for performing actions related to making and deleting statement
 * requests.
 * 
 * @author GX
 */
/*
 * DATE     REFERENCE   WHO   		VERSION  COMMENTS
 * -------  ---------   ---   		-------  ---------
 * 05Jul12  WP616       GX          1       WP616 - UT Replacement - Request 
 * 													Statement P1
 * 01Oct10	WP616		SD			1b		Rewritten a lot of this to make it usable by
 * 											both csc and eboxService.
 */
public class StatementRequestUtils {
	private static final String STAFFWARE_CASE_ADMIN_ROLE = "Staffware Case Admin";

	private static LoggerConnection logger = new LoggerConnection(StatementRequestUtils.class);

	/**
	 * Cancel a statement request in BRAINS by calling REQ_D
	 * 
	 * @param country
	 * @param offshore
	 * @param branch
	 * @param account
	 * @param terminalNumber
	 * @param sequenceNumber
	 * @param sourceLocation
	 * @param originatingBranch
	 * @param sourceSystem
	 * @param inputDate
	 * @param requestCode
	 * @throws Exception
	 */
	public static void cancelStatement(String country, boolean offshore, int branch, int account, int terminalNumber,
			int sequenceNumber, int originatingBranch, String sourceSystem, Date inputDate, String requestCode)
			throws Exception {

		// call REQ_D
		REQ_D token = new REQ_D();
		token.setCountry(country);
		token.setOffshore(offshore);
		token.setBranchNumber(branch);
		token.setAccountNumber(account);
		token.setOriginatingBranch(originatingBranch);
		token.setSourceSystem(sourceSystem);
		token.setInputDate(inputDate);
		token.setTerminalNumber(terminalNumber);
		token.setTerminalSequenceNumber(sequenceNumber);
		token.setRequestCode(requestCode);
		token.execute();
	}

	/**
	 * Sends a statement request to BRAINS by calling NFA_ST
	 * 
	 * @param country
	 * @param offshore
	 * @param branch
	 * @param account
	 * @param terminalNumber
	 * @param sequenceNumber
	 * @param sourceLocation
	 * @return
	 * @throws Exception
	 */
	public static NFA_ST requestStatement(String country, boolean offshore, int branch, int account, int terminalNumber,
			int sequenceNumber, int sourceLocation, String sourceSystem, String userId, String dateTime,
			String locationCode) throws Exception {

		// call NFA-ST
		NFA_ST token = new NFA_ST();
		token.setCountry(country);
		token.setOffshore(offshore);
		token.setCustomerAccountNumber(account);
		token.setCustomerBranchNumber(branch);
		token.setTerminalNumber(terminalNumber);
		token.setTerminalSequenceNumber(sequenceNumber);
		token.setSourceLocation(sourceLocation);
		token.setSourceSystem(sourceSystem);
		token.setUserId(userId);
		token.setDateTime(dateTime);
		token.setLocationCode(locationCode);

		token.execute();
		return token;
	}

	/**
	 * Gets the terminal & sequence number of a given country and its source system
	 * 
	 * @param country
	 * @param sourceSystem
	 * @return
	 * @throws Exception
	 */
	public static TerminalNumberData getTerminalAndSequenceNumbers(Country country, String sourceSystem)
			throws Exception {
		TerminalNumberData numbers = new TerminalNumberData();
		SQLConnection connection = MWDBHelper.getDatabaseConnection();

		try {
			DataAccess dataAccess = new DataAccess();
			dataAccess.setDatabase(connection);
			BrainsCountry brainsCountry = BrainsCountryUtils.getBrainsCountry(country, sourceSystem);
			numbers.setTerminalNumber(brainsCountry.getTerminalNumber());
			numbers.setSourceLocation(brainsCountry.getSourceLocation());
			numbers.setSequenceNumber(
					dataAccess.allocateBrainsTransactionNumber(country, Posting.getBusinessDate(country)));
		} finally {
			connection.close();
		}

		return numbers;
	}

	/**
	 * Gets the statement frequency and due date for a given account of a country
	 * 
	 * @param country
	 * @param offshore
	 * @param branch
	 * @param account
	 * @return
	 * @throws Exception
	 */
	public static HashMap<String, String> getStatementFrequencyAndDueDate(String country, boolean offshore, int branch,
			int account) throws Exception {
		HashMap<String, String> frequencyAndDueDate = new HashMap<String, String>();

		// call ACC-IA
		HashMap<String, Object> result = getAccountInfo(country, offshore, branch, account);

		// get response of the token
		String statementType = (String) result.get("STATEMENT_TYPE");
		String statementFrequency = (String) result.get("STMT_FREQ");
		String statementFrequencyData = (String) result.get("STMT_FREQ_DATA");
		String nextDueDate = (String) result.get("NEXT_DUE_DATE");

		// get Statement Frequency
		String statementFrequencyResult = getStatementFrequency(statementType, statementFrequency,
				statementFrequencyData);

		// get Next Due Date
		String nextDueDateResult = getNextDueDate(statementType, nextDueDate);

		frequencyAndDueDate.put("statementFrequency", statementFrequencyResult);
		frequencyAndDueDate.put("nextDueDate", nextDueDateResult);
		return frequencyAndDueDate;
	}

	/**
	 * Gets the detail information of a given customer
	 * 
	 * @param country
	 * @param custNumber
	 * @return
	 * @throws Exception
	 */
	private static CUS_I getCustomerInfo(Country country, int custNumber) throws Exception {

		CUS_I customerInquiry = new CUS_I();
		customerInquiry.setCountry(country.getISOCode());
		customerInquiry.setOffshore(country.isOffshore());
		customerInquiry.setCustomerNumber(custNumber);
		customerInquiry.execute();

		return customerInquiry;
	}

	/**
	 * Gets requests list by calling REQ-L
	 * 
	 * @param country
	 * @param offshore
	 * @param branch
	 * @param account
	 * @param requestCode
	 * @return
	 * @throws Exception
	 */
	public static REQ_L getRequestsList(String country, boolean offshore, int branch, int account, String requestCode)
			throws Exception {
		// call REQ_L token
		REQ_L token = new REQ_L();
		token.setCountry(country);
		token.setOffshore(offshore);
		token.setAccountNumber(account);
		token.setBranchNumber(branch);
		token.setRequestCode(requestCode);
		token.execute();
		return token;
	}

	/**
	 * Gets next due date of the statement
	 * 
	 * @param statementType
	 * @param nextDueDate
	 * @return
	 */
	private static String getNextDueDate(String statementType, String nextDueDateString) {
		String nextDueDateResult = "";
		if (statementType.equalsIgnoreCase("Diarised")) {
			nextDueDateResult = nextDueDateString;
			try {
				// Try to format the date
				SimpleDateFormat originalFormat = BrainsToken.getBrainsDateFormat();
				SimpleDateFormat targetFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date nextDueDate = originalFormat.parse(nextDueDateString);
				nextDueDateResult = targetFormat.format(nextDueDate);
			} catch (ParseException e) {
				logger.warn("Error when parsing Next Due Date.", e);
			}
		} else {
			nextDueDateResult = "See entries";
		}

		return nextDueDateResult;
	}

	/**
	 * Gets detail information of the statement frequency
	 * 
	 * @param statmentType
	 * @param statementFrequency
	 * @param statementFrequencyData
	 * @return
	 */
	private static String getStatementFrequency(String statmentType, String statementFrequency,
			String statementFrequencyData) {
		String statementFrequencyResult;
		if (statmentType == null || statmentType.length() == 0) {
			statementFrequencyResult = "";
		} else if (!statmentType.equalsIgnoreCase("Diarised")) {
			statementFrequencyResult = statmentType;
		} else {
			String frequency = "";
			String frequencyData = "";
			if (statementFrequency.equals("D")) {
				frequency = "Daily";
				frequencyData = "";
			} else if (statementFrequency.equals("MF")) {
				frequency = "Monthly Fixed";

				String leadingZero = statementFrequencyData.substring(0, 2);

				if (leadingZero.equals("00")) {
					String dd = statementFrequencyData.substring(2);

					if (dd.equals("31")) {
						frequencyData = " on the last day of the month";
					} else {
						frequencyData = " on " + dd;
					}
				} else {
					String dd = statementFrequencyData.substring(0, 2);
					String ee = statementFrequencyData.substring(2);

					if (ee.equals("31")) {
						frequencyData = " on " + dd + " and the last day of the month";
					} else {
						frequencyData = " on " + dd + " and " + ee;
					}
				}
			} else if (statementFrequency.equals("MV")) {
				frequency = "Monthly Variable";

				String leadingZero = statementFrequencyData.substring(0, 2);

				if (leadingZero.equals("00")) {
					String o = statementFrequencyData.substring(2, 3);
					String w = statementFrequencyData.substring(3, 4);

					String occurrence = getOccurrence(o);
					String dayOfWeek = getDayOfWeek(w);

					frequencyData = " on the " + occurrence + " " + dayOfWeek + " of the month";
				} else {
					String o = statementFrequencyData.substring(0, 1);
					String w = statementFrequencyData.substring(1, 2);
					String p = statementFrequencyData.substring(2, 3);
					String x = statementFrequencyData.substring(3, 4);

					String occurrenceO = getOccurrence(o);
					String occurrenceP = getOccurrence(p);
					String dayOfWeekW = getDayOfWeek(w);
					String dayOfWeekX = getDayOfWeek(x);

					frequencyData = " on the " + occurrenceO + " " + dayOfWeekW + " of the month and the " + occurrenceP
							+ " " + dayOfWeekX + " of the month";
				}
			} else if (statementFrequency.equals("H")) {
				frequency = "Half Yearly";

				String dd = statementFrequencyData.substring(0, 2);
				String mm = statementFrequencyData.substring(2);

				String month = getMonth(mm);

				if (dd.equals("31")) {
					frequencyData = " on the last day of " + month;
				} else {
					frequencyData = " on " + dd + " of " + month;
				}
			} else if (statementFrequency.equals("Q")) {
				frequency = "Quarterly";

				String dd = statementFrequencyData.substring(0, 2);
				String mm = statementFrequencyData.substring(2);

				String month = getMonth(mm);

				if (dd.equals("31")) {
					frequencyData = " on the last day of " + month;
				} else {
					frequencyData = " on " + dd + " of " + month;
				}
			} else if (statementFrequency.equals("W")) {
				frequency = "Weekly";

				String w = statementFrequencyData.substring(3);

				String dayOfWeek = getDayOfWeek(w);

				frequencyData = " on " + dayOfWeek;
			} else if (statementFrequency.equals("Y")) {
				frequency = "Yearly";

				String dd = statementFrequencyData.substring(0, 2);
				String mm = statementFrequencyData.substring(2);

				String month = getMonth(mm);

				if (dd.equals("31")) {
					frequencyData = " on the last day of " + month;
				} else {
					frequencyData = " on " + dd + " of " + month;
				}
			}

			statementFrequencyResult = "Diarised " + frequency + frequencyData;
		}

		return statementFrequencyResult;
	}

	/**
	 * Gets the full name of a month
	 * 
	 * @param mm
	 * @return
	 */
	private static String getMonth(String mm) {
		String month = "";
		switch (Integer.valueOf(mm)) {
		case 1:
			month = "January";
			break;
		case 2:
			month = "February";
			break;
		case 3:
			month = "March";
			break;
		case 4:
			month = "April";
			break;
		case 5:
			month = "May";
			break;
		case 6:
			month = "June";
			break;
		case 7:
			month = "July";
			break;
		case 8:
			month = "August";
			break;
		case 9:
			month = "September";
			break;
		case 10:
			month = "October";
			break;
		case 11:
			month = "November";
			break;
		case 12:
			month = "December";
			break;
		}
		return month;
	}

	/**
	 * Gets the occurrence
	 * 
	 * @param o
	 * @return
	 */
	private static String getOccurrence(String o) {
		String occurrence = "";
		switch (Integer.valueOf(o)) {
		case 1:
			occurrence = "first";
			break;
		case 2:
			occurrence = "second";
			break;
		case 3:
			occurrence = "third";
			break;
		case 4:
			occurrence = "fourth";
			break;
		case 5:
			occurrence = "fifth";
			break;
		}
		return occurrence;
	}

	/**
	 * Gets the day of a week
	 * 
	 * @param w
	 * @return
	 */
	private static String getDayOfWeek(String w) {
		String dayOfWeek = "";
		switch (Integer.valueOf(w)) {
		case 0:
			dayOfWeek = "Sunday";
			break;
		case 1:
			dayOfWeek = "Monday";
			break;
		case 2:
			dayOfWeek = "Tuesday";
			break;
		case 3:
			dayOfWeek = "Wednesday";
			break;
		case 4:
			dayOfWeek = "Thursday";
			break;
		case 5:
			dayOfWeek = "Friday";
			break;
		case 6:
			dayOfWeek = "Saturday";
			break;
		}
		return dayOfWeek;
	}

	/**
	 * Gets account detail information from BRAINS
	 * 
	 * @param country
	 * @param offshore
	 * @param branch
	 * @param account
	 * @return
	 * @throws Exception
	 */
	private static HashMap<String, Object> getAccountInfo(String country, boolean offshore, int branch, int account)
			throws Exception {
		ACC_IA token = new ACC_IA();
		token = new ACC_IA();
		token.setCountry(country);
		token.setOffshore(offshore);
		token.setAccountNumber(account);
		token.setBranchId(branch);
		token.execute();

		HashMap<String, Object> result = token.getHeader();
		return result;
	}

	/**
	 * Get the SourceSystem where SourceSystem = REQ-L.Source_System
	 * 
	 * To return the original SOURCE_SYSTEM string if the source system cannot be
	 * found in MWDB
	 * 
	 * @param sourceSystem
	 * @return
	 * @throws SQLException
	 */
	private static String getSourceApplNameFromSourceSystem(String sourceSystem) throws SQLException {
		String output = sourceSystem;

		SQLConnection conn = MWDBHelper.getDatabaseConnection();
		SortedMap<String, Object> args = new TreeMap<String, Object>();
		args.put("SourceSystem", sourceSystem);
		try {
			CallableStatement st = conn.prepareCall("dbo.csc_getSourceSystemDetails", args);
			try {
				ResultSet rs = conn.executeQuery(st, args);
				if (rs.next()) {
					output = rs.getString("SourceApplName");
				}
			} finally {
				st.close();
			}
		} finally {
			conn.close();
		}
		return output;
	}

	/**
	 * Retrieve a lists of requests for new Brains statements for the specified
	 * account.
	 * 
	 * @param country       Country of the account
	 * @param branchNumber  Branch number of the account
	 * @param accountNumber Account number
	 * @return List of existing requests for new Brains
	 * @throws Exception
	 */
	public static List<CurrentStatementRequest> getCurrentStatementRequests(Country country, int branchNumber,
			int accountNumber) throws Exception {
		List<CurrentStatementRequest> requests = new ArrayList<CurrentStatementRequest>();

		REQ_L token = getRequestsList(country.getISOCode(), country.isOffshore(), branchNumber, accountNumber, "STATE");

		for (int i = 0; i < token.getRowCount(); i++) {
			HashMap<String, Object> row = token.getRow(i);
			CurrentStatementRequest request = new CurrentStatementRequest();
			request.setBranchNumber(branchNumber);
			request.setAccountNumber(accountNumber);
			request.setOriginatingBranch((Integer) row.get("ORIGINATING_BRANCH"));
			request.setTerminalNumber((Integer) row.get("TERMINAL_NUMBER"));
			request.setTerminalSequenceNumber((Integer) row.get("TERMINAL_SEQUENCE_NUMBER"));
			request.setInputDate((Date) row.get("INPUT_DATE"));
			request.setRequestCode(row.get("REQUEST_CODE").toString());
			request.setSourceSystem(row.get("SOURCE_SYSTEM").toString());
			request.setSourceApplName(getSourceApplNameFromSourceSystem(row.get("SOURCE_SYSTEM").toString()));
			request.setDateAndTime((Date) row.get("DATE_AND_DATE"));
			request.setLocationCode(row.get("LOCATION_CODE") == null ? "" : row.get("LOCATION_CODE").toString());
			request.setUserId(row.get("USER_ID") == null ? "" : row.get("USER_ID").toString());
			// There are other properties on the request which could be set
			// here,
			// but as they won't be used I have not done so.
			requests.add(request);
		}

		return requests;
	}

	/**
	 * Retrieves a list of requests for historic statement reprints for the
	 * specified account and date range.
	 * 
	 * @param country       Country of the account
	 * @param branchNumber  Branch number of the account
	 * @param accountNumber Number of the account
	 * @param dateFrom      Start date of the historic statement
	 * @param dateTo        End date of the historic statement
	 * @return A list of populated HistoricStatementRequest objects
	 * @throws Exception
	 */
	public static List<HistoricStatementRequest> getHistoricStatementRequests(Country country, int branchNumber,
			int accountNumber, Date dateFrom, Date dateTo) throws Exception {
		// Create list in which to store requests
		List<HistoricStatementRequest> requests = new ArrayList<HistoricStatementRequest>();

		Date currentDate = new Date();

		// Fetch the details of the request (namely eboxActivityReference and
		// CustomerNumber) from StaffwareTransition
		SQLConnection conn = MWDBHelper.getDatabaseConnection();
		SortedMap<String, Object> args = new TreeMap<String, Object>();
		args.put("Country", country.getTwoCharISOCode());
		args.put("BranchNumber", branchNumber);
		args.put("AccountNumber", accountNumber);
		args.put("DateFrom", dateFrom);
		args.put("DateTo", dateTo);
		args.put("CurrentDate", currentDate);
		try {
			CallableStatement st = conn.prepareCall("wfe_StaffwareTransitionGetHistoricStmtRequests", args);
			try {
				ResultSet rs = conn.executeQuery(st, args);
				while (rs.next()) {
					String eboxActivityReference = rs.getString("eboxActivityReference");
					// Check that a Staffware case still exists for this
					// reference.
					// If it does not, then the request has been deleted or
					// processed
					// so there is no need to include it in the list.
					String caseNumber = getJbpmCaseFromEboxActivityReference(eboxActivityReference);
					if (!"".equals(caseNumber)) {
						// Populate a request object and add it to the
						// collection
						HistoricStatementRequest request = new HistoricStatementRequest();
						request.setEboxActivityReference(eboxActivityReference);
						request.setBranchNumber(branchNumber);
						request.setAccountNumber(accountNumber);
						request.setDateFrom(rs.getDate("DateFrom"));
						request.setDateTo(rs.getDate("DateTo"));
						request.setCustomerNumber(rs.getInt("CustomerNumber"));
						request.setStaffwareCaseNumber(caseNumber);
						requests.add(request);
					}
				}
			} finally {
				st.close();
			}
		} finally {
			conn.close();
		}

		// Set the customer name for each request by calling CUS-I with the
		// customer number.
		for (HistoricStatementRequest request : requests) {
			String customerName = "";
			if (request.getCustomerNumber() > 0) {
				customerName = getCustomerNameFromCustomerNumber(country, request.getCustomerNumber());
			}
			request.setCustomerName(customerName);
		}

		return requests;
	}

	/**
	 * Calls the CUS-I token to get the customer display name for the specified
	 * customer number.
	 * 
	 * @param country        Country of customer
	 * @param CustomerNumber Customer number to look up
	 * @return Customer's display name
	 * @throws Exception
	 */
	private static String getCustomerNameFromCustomerNumber(Country country, int customerNumber) throws Exception {
		CUS_I token = getCustomerInfo(country, customerNumber);
		return token.getHeader().get("DISPLAY_NAME").toString();
	}

	/**
	 * Retrieves the Staffware case number corresponding to the eBox Activity
	 * Reference provided, if a case exists.
	 * 
	 * @param eboxActivityReference
	 * @return Case number, or an empty string if no case exists.
	 * @throws Exception
	 */
	public static String getJbpmCaseFromEboxActivityReference(String eboxActivityReference) throws Exception {

		String caseNumber = "";

		ActivityTrackingSearchRequest args = new ActivityTrackingSearchRequest();

		args.setActivityReferences(eboxActivityReference);
		// Doesn't matter what value we supply for this because we are only
		// looking
		// for the existence of a row and this parameter does not affect that
		// (it only affects the counts displayed in some of the output columns)
		args.setUrgentPriority("0");
		String response = EboxRestApiClient.getResponseAsStringForAnyRequestObject(
				JbpmServer.getJbpmMap(EboxRestApiClient.WFE_ACTIVITY_TRACKING), args, logger);
		List<Map<String, Object>> rows = JsonHelper.getObjectMapper().convertValue(
				JsonHelper.getObjectMapper().readTree(response), new TypeReference<List<Map<String, Object>>>() {
				});
		if (!rows.isEmpty()) {
			caseNumber = rows.get(0).get("casenumber").toString();
		}
		return caseNumber;
	}

	

	/**
	 * Bean to hold fields needed for saving a new statement request.
	 */
	public static class TerminalNumberData {
		private int sequenceNumber;
		private int terminalNumber;
		private int sourceLocation;

		/**
		 * @return the sequenceNumber
		 */
		public int getSequenceNumber() {
			return sequenceNumber;
		}

		/**
		 * @param sequenceNumber the sequenceNumber to set
		 */
		public void setSequenceNumber(int sequenceNumber) {
			this.sequenceNumber = sequenceNumber;
		}

		/**
		 * @return the terminalNumber
		 */
		public int getTerminalNumber() {
			return terminalNumber;
		}

		/**
		 * @param terminalNumber the terminalNumber to set
		 */
		public void setTerminalNumber(int terminalNumber) {
			this.terminalNumber = terminalNumber;
		}

		/**
		 * @return the sourceLocation
		 */
		public int getSourceLocation() {
			return sourceLocation;
		}

		/**
		 * @param sourceLocation the sourceLocation to set
		 */
		public void setSourceLocation(int sourceLocation) {
			this.sourceLocation = sourceLocation;
		}
	}
}