package com.barclays.account.util;

import java.util.regex.Pattern;

/**
 * This class creates regex from ebox text pattern format
 * i.e. aaannn = [A-Za-z]{3}[0-9]{3}
 * 
 * @author Adam Slater
 * 
 */
/* 
 * DATE      REFERENCE   WHO     	VERSION  	COMMENTS
 * --------  ---------   ---     	-------  	----------------------
 * 24/05/13				SLATERA					Moved from csc created by ???
 */
/*
 * Class to create regular expression based on the Pattern passed
 */
public class IdPattern {
	/*
	 * Error messages.
	 */
	private static final String INVALID_FORMAT = "Invalid Id format";

	/**
	 * Index of the characters in the pattern.
	 */
	protected int charIndex;

	/**
	 * Length of the characters in the pattern.
	 */
	protected int charLength;

	/**
	 * Index of the integers in the pattern.
	 */
	protected int intIndex;

	/**
	 * Length of integers in the pattern.
	 */
	protected int intLength;

	/**
	 * Compiled regular expression representation of this pattern.
	 */
	protected Pattern pattern;

	public IdPattern() {

	}

	//Returns the regular expression based on the format passed
	public String parsePattern(String format) throws java.text.ParseException {
		final String specials = "\\[].{}()^$?*+|";
		final int NORMAL = 0;
		final int chars = 1;
		final int integers = 2;
		final int ALPHANUMERIC = 3;

		int state = NORMAL;
		charIndex = -1;
		intIndex = -1;
		int alnumIndex = -1;

		StringBuffer regexp = new StringBuffer();

		for (int i = 0; i < format.length(); i++) {
			char ch = format.charAt(i);
			int newState = state;

			switch (Character.toLowerCase(ch)) {
			case 'n':
				if (state != integers) {
					newState = integers;
					intIndex = i;
				}
				break;

			case 'a':
				if (state != chars) {
					newState = chars;
					charIndex = i;
				}
				break;

			case 'z':
				if (state != ALPHANUMERIC) {
					newState = ALPHANUMERIC;
					alnumIndex = i;
				}
				break;

			default:
				newState = NORMAL;
				break;
			}

			if (newState != state) {
				switch (state) {
				case chars:
					charLength = i - charIndex;
					regexp.append("[A-Za-z]{" + charLength + "}");
					break;
				case integers:
					intLength = i - intIndex;
					regexp.append("\\d{" + intLength + "}");
					break;
				case ALPHANUMERIC:
					regexp.append("\\p{Alnum}{" + (i - alnumIndex) + "}");
					break;
				}
				state = newState;
			}

			if (state == NORMAL) {
				if (specials.indexOf(ch) != -1) {
					regexp.append('\\');
				}
				regexp.append(ch);
			}
		}

		switch (state) {
		case chars:
			charLength = format.length() - charIndex;
			regexp.append("[A-Za-z]{" + charLength + "}");
			break;
		case integers:
			intLength = format.length() - intIndex;
			regexp.append("\\d{" + intLength + "}");
			break;
		case ALPHANUMERIC:
			regexp.append("\\p{Alnum}{" + (format.length() - alnumIndex) + "}");
			break;
		}
		if (state == integers) {
			if (intIndex == -1) {
				throw new java.text.ParseException(INVALID_FORMAT, format
						.length());
			}
		}
		if (state == chars) {
			if (charIndex == -1) {
				throw new java.text.ParseException(INVALID_FORMAT, format
						.length());
			}
		}

		String regexpStr = "^" + regexp.toString() + "$";
		pattern = Pattern.compile(regexpStr);
		return regexpStr;
	}
}

