package com.barclays.account.data.bean;

import java.io.Serializable;
import java.util.Date;

import com.ibm.math.BigDecimal;

/**
 * Represents an object from the 'requests' table in Brains.
 * 
 * @author  DIXONS
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 28Sep12  WP616RsStm DIXONS 1a       Created. It might be more appropriate in future
 * 									   to rename this class to AccountRequest or similar,
 * 									   but at the moment it is specifically only being
 * 									   used for statement requests.
 */
public class CurrentStatementRequest implements Serializable {
	
	/**
	 * appease the serialisation gods
	 */
	private static final long serialVersionUID = -6285769393497482234L;
	
	private int branchNumber;
	private int accountNumber;
	private int originatingBranch;
	private int terminalNumber;
	private int terminalSequenceNumber;
	private Date inputDate;
	private int standingOrderSerialNo;
	private String requestCode;
	private int reversalTerminalNumber;
	private int reversalTerminalSeq;
	private int currencyNumber;
	private int systemDayNumber;
	private BigDecimal adjustmentAmount;
	private String actionCode;
	private Date backvalueDate;
	private String sourceSystem;
	private Date dateAndTime;
	private String locationCode;
	private String userId;
	private String sourceApplName;
	
	public int getBranchNumber() {
		return branchNumber;
	}
	public void setBranchNumber(int branchNumber) {
		this.branchNumber = branchNumber;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getOriginatingBranch() {
		return originatingBranch;
	}
	public void setOriginatingBranch(int originatingBranch) {
		this.originatingBranch = originatingBranch;
	}
	public int getTerminalNumber() {
		return terminalNumber;
	}
	public void setTerminalNumber(int terminalNumber) {
		this.terminalNumber = terminalNumber;
	}
	public int getTerminalSequenceNumber() {
		return terminalSequenceNumber;
	}
	public void setTerminalSequenceNumber(int terminalSequenceNumber) {
		this.terminalSequenceNumber = terminalSequenceNumber;
	}
	public Date getInputDate() {
		return inputDate;
	}
	public void setInputDate(Date inputDate) {
		this.inputDate = inputDate;
	}
	public int getStandingOrderSerialNo() {
		return standingOrderSerialNo;
	}
	public void setStandingOrderSerialNo(int standingOrderSerialNo) {
		this.standingOrderSerialNo = standingOrderSerialNo;
	}
	public String getRequestCode() {
		return requestCode;
	}
	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}
	public int getReversalTerminalNumber() {
		return reversalTerminalNumber;
	}
	public void setReversalTerminalNumber(int reversalTerminalNumber) {
		this.reversalTerminalNumber = reversalTerminalNumber;
	}
	public int getReversalTerminalSeq() {
		return reversalTerminalSeq;
	}
	public void setReversalTerminalSeq(int reversalTerminalSeq) {
		this.reversalTerminalSeq = reversalTerminalSeq;
	}
	public int getCurrencyNumber() {
		return currencyNumber;
	}
	public void setCurrencyNumber(int currencyNumber) {
		this.currencyNumber = currencyNumber;
	}
	public int getSystemDayNumber() {
		return systemDayNumber;
	}
	public void setSystemDayNumber(int systemDayNumber) {
		this.systemDayNumber = systemDayNumber;
	}
	public BigDecimal getAdjustmentAmount() {
		return adjustmentAmount;
	}
	public void setAdjustmentAmount(BigDecimal adjustmentAmount) {
		this.adjustmentAmount = adjustmentAmount;
	}
	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public Date getBackvalueDate() {
		return backvalueDate;
	}
	public void setBackvalueDate(Date backvalueDate) {
		this.backvalueDate = backvalueDate;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public Date getDateAndTime() {
		return dateAndTime;
	}
	public void setDateAndTime(Date dateAndTime) {
		this.dateAndTime = dateAndTime;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSourceApplName() {
		return sourceApplName;
	}
	public void setSourceApplName(String sourceApplName) {
		this.sourceApplName = sourceApplName;
	}
	
	/**
	 * Returns a string describing the request, suitable for displaying on the
	 * Statement View screen.<br/>
	 * The format is [SourceApplName] [Originating Branch] [Location Code] [UserId]<br/>
	 * or [SourceApplName] [Originating Branch] [Location Code] [TerminalNumber/TerminalSeqNum] if UserId is blank.
	 * 
	 * @return String describing the request
	 */
	public String getRequestedByString() {
		StringBuffer result = new StringBuffer("");
		if (!"".equals(sourceApplName)) {
			result.append(sourceApplName);
			result.append(" ");
		}
		if (originatingBranch > 0) {
			result.append("Branch ");
			result.append(originatingBranch);
			result.append(" ");
		}
		if (!"".equals(locationCode)) {
			result.append(locationCode);
			result.append(" ");
		}
		if(!"".equals(userId)) {
			result.append(userId);
		}
		else if (terminalNumber > 0 && terminalSequenceNumber > 0){
			result.append("Terminal ");
			result.append(terminalNumber);
			result.append("/");
			result.append(terminalSequenceNumber);
		}
		return result.toString();
	}
}
