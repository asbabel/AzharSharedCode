package com.barclays.account.data.dataAccess;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.barclays.account.data.bean.Sweep;
import com.barclays.eboxLibrary.data.MWDBHelper;
import com.barclays.generic.data.bean.Currency;
import com.barclays.generic.math.Decimal;
import com.barclays.middleware.brains.ACC_IA;
import com.barclays.middleware.brains.ATR_L;
import com.ibm.math.BigDecimal;

/**
 * Data Access methods related to auto transfers (sweeps)
 * @author goodlifw
 */
/*
 * DATE     REFERENCE   WHO   VERSION   COMMENTS
 * -------  ---------   ---   -------   ----------------------------------------
 * 25Jan11	WP615 (P4)  WIG   1         Created
 * 07Feb	OLEp4       ERIC  2         Re-factored code which can be reused.
 * 08Mar12				PGJ	  3			Extract automatic transfer properties 
										 into the sweep object.
 */
public class SweepsDataAccess {
	private static SimpleDateFormat fourYearDateFormatter = 
		new SimpleDateFormat("dd/MM/yyyy");
	
	/**
	 * Gets a list of any sweeps (automatic transfers) for the specified account
	 * 
	 * @param country The ISO code of the country that the account is in.
	 * @param offshore The offshoreInd of the country that the account is in.
	 * @param branch The branch that the account is in.
	 * @param account The account number of the account.
	 * @throws Exception if there is a data access issue etc.
	 **/
	public static ArrayList<Sweep> getSweeps(
			String country, 
			boolean offshore,
			int branch,
			int account,
			Currency accountCurrency) 
	throws Exception {
		ArrayList<Sweep> sweeps = new ArrayList<Sweep>();
		ATR_L token = new ATR_L();
		
		token.setCountry(country);
		token.setOffshore(offshore);
		token.setAccountNumber(account);
		token.setBranchNumber(branch);
		token.setVersionNumber(1);
		token.execute();
		
		for (int i = 0; i < token.getRowCount(); i++) {
			HashMap<String, Object> row = token.getRow(i);
			Sweep sweep = new Sweep();
			populateSweep(sweep, row, country, offshore, branch, account, 
					accountCurrency);
	    	sweeps.add(sweep);
		}
		
		return sweeps;
	}
	
	/**
	 * Using the information in the provided row of BRAINS data, loads the data 
	 * for a specific sweep in a more usable way.
	 *  
	 * @param sweep
	 * @param row
	 * @param country
	 * @param offshore
	 * @param branch
	 * @param offshore
	 * 
	 * @throws Exception 
	 **/
	private static void populateSweep(
			Sweep sweep, 
			HashMap<String, Object>  row,
			String country, 
			boolean offshore,
			int branch,
			int account,
			Currency accountCurrency) throws Exception {
		// Gather information
		String[] originatorAccount = 
				((String)row.get("ORIGINATOR_BRANCH_ACCOUNT")).split("/");
		int originatorBranchNumber = Integer.parseInt(originatorAccount[0]);
		int originatorAccountNumber = Integer.parseInt(originatorAccount[1]);

    	String[] counterpartyAccount = 
				((String)row.get("COUNTERPARTY_BRANCH_ACCOUNT")).split("/");
    	int counterpartyBranchNumber = Integer.parseInt(counterpartyAccount[0]); 
    	int counterpartyAccountNumber = Integer.parseInt(counterpartyAccount[1]);

    	boolean selectedAccountIsOriginator = 
	    		originatorBranchNumber == branch 
	    		&& originatorAccountNumber == account;

    	String transferType = (String)row.get("TRANSFER_TYPE");
    	boolean transfersInAllowed = "Y".equals(row.get("TRANSFERS_IN_ALLOWED"));
    	boolean transfersOutAllowed = "Y".equals(row.get("TRANSFERS_OUT_ALLOWED"));
   		String amountType = (String)row.get("AMOUNT_TYPE");
    	BigDecimal amount = (BigDecimal)row.get("AMOUNT");
    	String brainsFrequency = (String) row.get("FREQUENCY");
    	String frequncyData = (String) row.get("FREQUENCY_DATA");
    	Date nextDueDate = (Date) row.get("NEXT_DUE_DATE");

    	// Originator and Counterparty fields
    	populateAccountFields(country, offshore, sweep,
    			originatorBranchNumber, originatorAccountNumber, 
    			counterpartyBranchNumber, counterpartyAccountNumber);
		
    	sweep.setTrigger(getTrigger(transferType));
    	sweep.setFrequency(getFrequency(country, offshore,brainsFrequency, transferType));
   		sweep.setDay(getDay(brainsFrequency, frequncyData));

   		// Next Due 
   		if (!"M".equals(transferType)) {
   			sweep.setNextDue(nextDueDate);
   		}
   		
   		// Type
   		if ("A".equals(amountType)){
   			sweep.setType("Transfer Amount");
   		} else if ("B".equals(amountType)){
   			sweep.setType("Maintain Balance");
   		}
   		
    	// Amount
    	sweep.setAmount(amount);
    	sweep.setCurrency(accountCurrency);
    	
    	// Direction
    	sweep.setDirection(getDirection(transfersInAllowed, transfersOutAllowed));
   		
		// Description
    	HashMap<String, String> descriptionMap = generateDescription(
    			transferType,
    			transfersInAllowed, 
    			transfersOutAllowed, 
    			amountType, 
    			selectedAccountIsOriginator, 
    			counterpartyBranchNumber,
    			counterpartyAccountNumber,
    			originatorBranchNumber, 
    			originatorAccountNumber, 
    			amount,
    			sweep.getFrequency(),
    			sweep.getNextDue(),
    			accountCurrency
    	);
    	sweep.setDescription(descriptionMap);
    	sweep.setEODBalanceOn(descriptionMap.get("EOD_BALANCE_ON"));
    	sweep.setBecomes(
    			descriptionMap.get("CONDITION") + " " +
    			descriptionMap.get("FORMATTED_AMOUNT"));
    	sweep.setActionTransfer(
    			descriptionMap.get("TRANSFER_ACTION") + " " +
    			descriptionMap.get("COUNTERPARTY_ACCOUNT"));
	}

	/**
	 * Gets the trigger based on the input transfer type.
	 * 
	 * @param transferType
	 */
	public static String getTrigger(String transferType) {
		String response = "";
		if ("M".equals(transferType)) {
			response = Sweep.ON_MOVEMENT;
    	} else if ("D".equals(transferType)) {
    		response = Sweep.DIARISED;
    	}
		return response;
	}

	/**
	 * Gets the direction based on the given parameters. 
	 * 
	 * @param transfersInAllowed
	 * @param transfersOutAllowed
	 */
	public static String getDirection(
			boolean transfersInAllowed,
			boolean transfersOutAllowed) {
		String response = "";
		
		if (transfersOutAllowed && ! transfersInAllowed) {
			response = "Out";
		} else if (!transfersOutAllowed && transfersInAllowed) {
			response = "In";
		} else if (transfersOutAllowed && transfersInAllowed) {
			response = "In & Out";
		}
		
		return response;
	}
	
	/**
	 * Retrieves the frequency description from MW_RefValues
	 * 
	 * @param country
	 * @param offshore
	 * @param brainsFrequency
	 * @param transferType
	 * @return the frequency description
	 * @throws Exception 
	 **/
	public static String getFrequency (
			String country, 
			boolean offshore,
			String brainsFrequency, 
			String transferType) 
	throws Exception {
    	if (!"M".equals(transferType)) {
    		return MWDBHelper.getMWRefValue(country, offshore, "FREQ", 
    				brainsFrequency);
    	}
		
		return "";
	}
	
	
	/**
	 * Returns the due day in a more human friendly format.
	 * 
	 * @param brainsFrequency
	 * @param frequencyData
	 * @return Returns the due day in a more human friendly format.
	 **/
	public static String getDay(
			String brainsFrequency, 
			String frequncyData) {
		StringBuffer day = new StringBuffer();
		boolean addDay = false;
		
		if ("H".equals(brainsFrequency) 
				|| "Q".equals(brainsFrequency) 
				|| "Y".equals(brainsFrequency)){
			day.append(frequncyData);
		} else if ("MF".equals(brainsFrequency)) {
			day.append(frequncyData.substring(2));
		} else if ("W".equals(brainsFrequency)){
			addDay = true;
		} else if ("MV".equals(brainsFrequency)){
			switch (Integer.parseInt(frequncyData.substring(2, 3))) {
				case 1: day.append("1st ");
					break;
				case 2: day.append("2nd ");
					break;
				case 3: day.append("3rd ");
					break;
				case 4: day.append("4th ");
					break;
				case 5: day.append("5th ");
					break;
			}
			
			addDay = true;
		}
		
		if (addDay) {
			switch (Integer.parseInt(frequncyData.substring(3))) {
				case 0: day.append("Sunday");
					break;
				case 1: day.append("Monday");
					break;
				case 2: day.append("Tuesday");
					break;
				case 3: day.append("Wednesday");
					break;
				case 4: day.append("Thursday");
					break;
				case 5: day.append("Friday");
					break;
				case 6: day.append("Saturday");
					break;
			}
		}
		
		return day.toString();
	}
	
	/**
	 * Generates a description of the sweep (automatic transfer). 
	 * 
	 * @param transfersInAllowed
	 * @param transfersOutAllowed
	 * @param amountType
	 * @param selectedAccountIsOriginator
	 * @param counterpartyBranchNumber
	 * @param counterpartyAccountNumber
	 * @param originatorBranchNumber
	 * @param originatorAccountNumber
	 * @param amount
	 * @param accountCurrency
	 * @return A description map of the sweep
	 **/
	private static HashMap<String, String> generateDescription(
			String transferType, 
			boolean transfersInAllowed, 
			boolean transfersOutAllowed, 
			String amountType, 
			boolean selectedAccountIsOriginator, 
			int counterpartyBranchNumber, 
			int counterpartyAccountNumber, 
			int originatorBranchNumber, 
			int originatorAccountNumber, 
			BigDecimal amount,
			String frequency,
			Date nextDue,
			Currency accountCurrency) {
		
		String originatorAccount;
		String counterpartyAccount;
		String condition = "";
		String transferAction = "";
		String EODBalanceOn;
		
		String formattedAmount = 
				Decimal.getFormattedDecimal(
										amount, 
										accountCurrency.getMask().intValue(), 
										3) 
				+ " " + accountCurrency.getCurrency();;
        
		if (selectedAccountIsOriginator) { 
			originatorAccount = "this a/c";
			EODBalanceOn = "This a/c";
			counterpartyAccount = 
				counterpartyBranchNumber + "/" + counterpartyAccountNumber;
		} else {  
			originatorAccount = 
				originatorBranchNumber + "/" + originatorAccountNumber;
			EODBalanceOn = originatorAccount;
			counterpartyAccount = "this a/c";
		}
		
		if (transfersOutAllowed && !transfersInAllowed) {
			condition = ">";
			
			if ("B".equals(amountType)) {
				transferAction = "excess to"; 
			} else if ("A".equals(amountType)) {
				transferAction = formattedAmount + " to";
			}
		} else if (!transfersOutAllowed && transfersInAllowed) {
			condition = "<";
			
			if ("B".equals(amountType)) {
				transferAction = "shortfall (subject to funds) from"; 
			} else if ("A".equals(amountType)) {
				transferAction = formattedAmount + " (subject to funds) from";
			}
		} else if (transfersOutAllowed && transfersInAllowed) {
			condition = "not =";
			
			if ("B".equals(amountType)) {
				transferAction = "excess to or shortfall (subject to funds) from";
			} else if ("A".equals(amountType)) {
				transferAction = formattedAmount + " to/from (subject to funds)";
			}
		}

		String trigger = "";		
		if ("M".equalsIgnoreCase(transferType)) {
			trigger = "on movement";
		} else if ("D".equalsIgnoreCase(transferType)) {
			trigger = frequency.toLowerCase() + " (next due on " + 
					fourYearDateFormatter.format(nextDue) + ")";
		}
		HashMap<String, String> descriptionMap = new HashMap<String, String>();
		descriptionMap.put("TRIGGER", trigger);
		descriptionMap.put("ORIGINATOR_ACCOUNT", originatorAccount);
		descriptionMap.put("CONDITION", condition);
		descriptionMap.put("FORMATTED_AMOUNT", formattedAmount);
		descriptionMap.put("TRANSFER_ACTION", transferAction);
		descriptionMap.put("COUNTERPARTY_ACCOUNT", counterpartyAccount);
		descriptionMap.put("EOD_BALANCE_ON", EODBalanceOn);
		return descriptionMap; 
	}

	/**
	 * Calls ACC-IA to retrieve the account details that are required, and  
	 * uses the results to populate the sweep.
	 * 
	 * @param country The ISO code of the country that the account is in.
	 * @param offshore The offshoreInd of the country that the account is in.
	 * @param sweep The sweep that needs populating.
	 * @param originatorBranchNumber The branch that the originator account is in.
	 * @param originatorAccountNumber The account number of the originator account.
	 * @param counterpartyBranchNumber The branch that the counterparty account is in.
	 * @param counterpartyAccountNumber The account number of the counterparty account.
	 * 
	 * @throws Exception If there is a connection issue or similar problem.
	 **/
	private static void populateAccountFields(
			String country, 
			boolean offshore,
			Sweep sweep,
			int originatorBranchNumber, 
			int originatorAccountNumber, 
			int counterpartyBranchNumber, 
			int counterpartyAccountNumber) throws Exception {
		
		sweep.setOriginatorBranchNumber(originatorBranchNumber);
    	sweep.setOriginatorAccountNumber(originatorAccountNumber);
    	sweep.setCounterpartyBranchNumber(counterpartyBranchNumber);
    	sweep.setCounterpartyAccountNumber(counterpartyAccountNumber);
		
		ACC_IA token = new ACC_IA();
		
		// Counterparty.
		token.setCountry(country);
		token.setOffshore(offshore);
		token.setAccountNumber(counterpartyAccountNumber);
		token.setBranchId(counterpartyBranchNumber);
		token.execute();
		
		HashMap<String, Object> result = token.getHeader();
		sweep.setCounterpartyShortName((String)result.get("SHORT_NAME"));
		sweep.setCounterpartyProduct(
				result.get("ACCOUNT_TYPE").toString() 
				+ " - "
				+ result.get("TYPE_NARRATIVE").toString());
		
		// Originator.
		token = new ACC_IA();
		token.setCountry(country);
		token.setOffshore(offshore);
		token.setAccountNumber(originatorAccountNumber);
		token.setBranchId(originatorBranchNumber);
		token.execute();
		
		result = token.getHeader();
		
		sweep.setOriginatorShortName((String)result.get("SHORT_NAME"));
		sweep.setOriginatorProduct(
				result.get("ACCOUNT_TYPE").toString() 
				+ " - "
				+ result.get("TYPE_NARRATIVE").toString());
	}
}
