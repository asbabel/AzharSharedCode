package com.barclays.generic.connection;

import java.util.Iterator;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.RowSetDynaClass;

import com.barclays.generic.business.utils.MWDataSource;

/**
 * This connection connects to staffware db
 */
/* 
 * DATE      REFERENCE   WHO     VERSION  COMMENTS
 * --------  ---------   ---     -------  -----------------------------------------
 * 16/02/12  WP619       Eric.Ma       	  Created
 * 01/10/12	 WP616RqStm	 SDixon			  Moved to eboxLibrary. Contents unchanged.
 * 16/01/17  WP654       JDurman          Updated to use JDBC4 driver details.
 */
public class StaffwareDBSQLConnection extends GenericSQLConnection{

	private String dataSource = null;
	
	   /**
* Set the name of the data source you want to use.
* 
* @param dataSource Name of the data source resource
	 */
public void setDataSource(String dataSource) {
  this.dataSource = dataSource;
}
            
/** Creates a new instance of GenericSQLConnection for a given data source 
 * @return 
* @return */
public StaffwareDBSQLConnection(String dataSource) {
  this.dataSource = dataSource;
            }
 
public StaffwareDBSQLConnection() {
        }

protected DataSource getDataSource()
        throws NamingException
    {
        return (DataSource) new InitialContext().lookup(
        		"java:comp/env/" + dataSource);
        }

	}




