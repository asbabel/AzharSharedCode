package com.barclays.eChannel.util;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.eChannel.data.bean.BrainsCountry;
import com.barclays.eboxLibrary.data.MWDBHelper;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.bean.Country;

/**
 * Utility class for retrieving information from BrainsCountryDetails.
 * 
 * @author  DIXONS
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 25Sep12  WP616RsStm DIXONS 1a       Created.
 */
public class BrainsCountryUtils {
	static final String NO_BRAINS_COUNTRY_DETAILS_MESSAGE = "BRAINS country details not configured.";
	
	/**
	 * Gets BrainsCountry details for a given country and its source system
	 *
	 * @param country
	 * @param sourceSystem
	 * @return
	 * @throws Exception
	 */
	public static BrainsCountry getBrainsCountry(
			Country country, 
			String sourceSystem)
			throws Exception
	{
		SortedMap<String, Object> args = new TreeMap<String, Object>();
	    args.put("sourceSystem", sourceSystem);
	    args.put("country", country.getISOCode());
	    args.put("offshore", country.isOffshore() ? "1" : "0");
	    SQLConnection database = MWDBHelper.getDatabaseConnection();
	    BrainsCountry bc = new BrainsCountry();
	    try{
	        CallableStatement st = database.prepareCall(
	                "wfe_EChannelBrainsCountryGet",
	                args);
	        try {
	            ResultSet rs = database.executeQuery(st, args);
	            if (!rs.next())
	                throw new Exception(BrainsCountryUtils.NO_BRAINS_COUNTRY_DETAILS_MESSAGE);
	            else {
	                bc.setSourceLocation(rs.getInt("SourceLocation"));
	                bc.setTerminalNumber(rs.getInt("TerminalNumber"));
	                bc.setBankCode(rs.getInt("BankCode"));
	            }
	        }
	        finally { st.close(); }
	    }
	    finally { database.close(); }
	    return bc;
	}
}
