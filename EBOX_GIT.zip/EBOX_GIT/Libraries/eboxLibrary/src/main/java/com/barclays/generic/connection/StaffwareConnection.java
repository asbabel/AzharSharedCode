package com.barclays.generic.connection;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.SortedMap;
import java.util.TreeMap;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.security.Crypto;

/**
 * This class manages connections from the web server with Staffware.
 *
 * B EARLE BEWARE Staffware Objects are not the most robust of objects
 * instantiating one (other than SWEnterprise) before a connection has been made
 * to the server will cause evil jni errors
 *
 * Also be careful with arrays, if an array has a length of 3 but only two
 * objects and a null in it can cause the underlying C code of the Staffware
 * objects to knock your server out with a access violation
 *
 * @author Bonner Earle
 */
/*
 * DATE     REFERENCE   WHO  VERSION  COMMENTS
 * -------  ---------   ---  -------  ---------------------------------------------------
 * 05/03/10 WP419       BE   1        Created
 * 20/09/12 WP616RqStmt SD	 1.1	  Moved from ebosService to eboxLibrary so that
 * 									  this can be used by both csc and eboxService.
 * 									  I had to rework it a little so that it didn't
 * 									  assume that the role used for connection was
 * 									  "eboxService". The caller now supplies the role
 * 									  when they call the connect method. This is now
 * 									  more similar to the StaffwareConnection class in
 * 									  csc, and it would probably be advisable to
 * 									  combine the two at some point so that there is
 * 									  only one to maintain, but that is beyond the
 * 									  scope of this work.
 * 09/02/17 WP654       JWD  1.2      Removed a resource leak - database connection.
 */
public class StaffwareConnection {

    /* Static Members */
    private static String computerName;
    private static String nodeName;
    private static String ipAddress;
    private static int portNumber;
    private static int urgentPriority;
    private static LoggerConnection logger = new LoggerConnection(
            StaffwareConnection.class);

    /**
     * A fresh database connection.
     */
    private static SQLConnection getDatabaseConnection() throws SQLException {
        return new SQLConnection(
                DataSourceDirectory.getInstance().getDataSource("mwdb").getConnection());
    }

    /**
     * This method gets the configurations from the database
     * 
     * @throws - Exception exception
     */
    public static void initialize() throws Exception {

        SQLConnection conn = getDatabaseConnection();
        try {
            setServerConfiguration(conn);
        } finally {
            conn.close();
        }
        logger.info("StaffwareConnection initialized");
    }

    /**
     * Remembers the staffware server config for the lifetime of the app
     * 
     * @param conn
     * @throws SQLException
     */
    private static void setServerConfiguration(SQLConnection conn)
            throws SQLException {
        SortedMap<String, Object> args = new TreeMap<String, Object>();
        CallableStatement stm =
                conn.prepareCall("iop_GetStaffwareServer", args);
        try {
            ResultSet staffwareIp = conn.executeQuery(stm, args);
            String s = null;
            while (staffwareIp.next()) {
                ipAddress = staffwareIp.getString("sw_ipaddress");
                portNumber = staffwareIp.getInt("sw_portnumber");
                s = staffwareIp.getString("sw_priority");
                // s looks like
                // ServerName=snowy,Node=sw_africa,Priority=10
                String[] values = s.split(",");
                computerName = values[0].substring(values[0].indexOf("=") + 1);
                nodeName = values[1].substring(values[1].indexOf("=") + 1);
                urgentPriority =
                        Integer.parseInt(values[2].substring(values[2].indexOf("=") + 1));
            }
        } finally {
            stm.close();
        }
    }

    /**
     * <p>
     * "Urgent" priority level for Staffware work items.
     * </p>
     * <p>
     * Work items with priority less than or equal to this value are considered
     * urgent.
     * </p>
     */
    public static int getUrgentPriority() {
        return urgentPriority;
    }

    /**
     * The node name of the staffware instance e.g. "sw_africa".
     * 
     * @return
     */
    public static String getNodeName() {
        return nodeName;
    }
    
    /**
     * Decrypts the byte array provided to produce a string.
     * 
     * @param bytes byte array containing encrypted password.
     * @return
     * @throws Exception
     */
    private String decryptPassword(byte[] bytes) throws Exception {
        Crypto crypto = new Crypto();
        // trim result as end padded with spaces to make string fixed length
        return crypto.decrypt(bytes).trim();
    }
}
