package com.barclays.generic.connection;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaProperty;
import org.apache.commons.beanutils.RowSetDynaClass;

import com.barclays.generic.business.utils.DataSourceDirectory;
import com.barclays.generic.business.utils.LoggerConnection;
import com.barclays.generic.data.SQLConnection;
import com.barclays.generic.data.SQLConnection.OutputParameter;
import com.barclays.generic.data.dataAccess.DataAccessException;
import com.barclays.middleware.util.ExceptionUtil;


/**
 * Interface to the database server.
 * @author  EARLB
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 23Mar05  PAT01378   EARLB  1a       Created.
 * 01Dec05  PAT01526   KEMPD  1b       Added the `getDataSource(...)' method.
 * 22Mar06  PAT01623   EARLB  1c       new "friendly" error handling
 * 20Feb07  PAT01952   HUNTI  1d       AAO3 : Altereed to allow overriding to
 *                                        get multiple resultsets
 * 08Jan08  PAT02354   KEMPD  1e       WP144: Added `callFunction(...)' methods.
 * 20Sep12  WP616RqStm DIXONS 1f	   Moved to eboxLibrayr. Content unchanged.
 * 02Jul13	WP623	   VM	  1g	   Added executeStoredProcedure() method.
 */
public class GenericSQLConnection {
    
    protected final int SQL_SERVER_UNIQUE_INDEX_ERROR = 2601;
    protected final int SQL_SERVER_UNIQUE_CONSTRAINT_ERROR = 2627;
    protected final int SQL_SERVER_CONSTRAINT_ERROR = 547;
    protected final int SQL_SERVER_AD_HOC_ERROR = 50000;
    protected final int SQL_CONSTRAINT_ERROR = 55000;		
    protected final int SQL_SERVER_LCD_ADD = 55010;			
    
    protected final SimpleDateFormat SQL_DATE_FORMATTER = 
    	new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public static String SQL_ERROR_MSG = "Request has failed." + 
		" Failure occured at {0}," + 
		" please try again. If the problem persists please contact" + 
		" your system administrator. ";
	public static String INTERNAL_SQL_ERROR_MSG = 
		"Error encountered in SQL connection. Details: ";  

    
    protected Object returnValue;
    /**
     * Log4j logger instance for use in this class
     */
    private LoggerConnection logger = new LoggerConnection(
    		GenericSQLConnection.class);
    /** Creates a new instance of GenericSQLConnection */
    public GenericSQLConnection() {
    }
    
    /**
     * This method takes a sp name and some parameters, executes them and 
     * returns an Object containing the results 
     * @param   procedureName   stored procedure name
     * @param   parameters      name value pairs of input parameters (names 
     * 			correspond to the underlying sql parameter names)
     * 
     * @throws SQLException
     */
    public Object executeResultSet(String procedureName, Map parameters) 
    		throws SQLException,
            DataAccessException{
        return executeResultSet(procedureName, parameters, null);
    }
        /**
     * This method takes a sp name and some parameters, executes them and 
     * returns an Object containing the results
     * @param   procedureName   stored procedure name
     * @param   inParameters      name value pairs of input parameters 
     * 			(names correspond to the underlying sql parameter names)
     * @param   outParameters   name and OutputParameter object pairs of output 
     * 			parameters  
     * 
     * @throws SQLException
     */
    public Object executeResultSet(String procedureName, Map inParameters, 
    		Map outParameters) throws SQLException,
    		DataAccessException{
        return executeResultSet(null, procedureName, inParameters, outParameters);
    }
    /**
     * This method takes a sp name and some parameters, executes them and 
     * returns an Object containing the results
     * @param   dbconnection if null then connection will be created and droped 
     * 			within method
     * @param   procedureName   stored procedure name
     * @param   inParameters      name value pairs of input parameters (names 
     * 			correspond to the underlying sql parameter names)
     * @param   outParameters   name and OutputParameter object pairs of output 
     * 			parameters  
     * 
     * @throws SQLException
     */
    public Object executeResultSet(Connection con, String procedureName, 
    		Map inParameters, Map outParameters) throws SQLException,
            DataAccessException{
        // Calling method may want to control the transaction so can pass in its own 
        // connection. If not then a new one will be created
        boolean passedConnection = true;
        if (con == null) {
            passedConnection = false;
            con = getConnection();
             
        }
        CallableStatement cs = null;
        try {
            // create comamnd string
            cs = prepareStatement(
                    con,
                    procedureName,
                    inParameters,
                    outParameters);
            // Execute CallableStatement and format results
            executeCallableStatement(cs);
            // retrieve out params (this closes result set)
            if(outParameters!=null){
                // iterate through input params as they hold order params were added
                int pos=1;
                for (Iterator i = inParameters.keySet().iterator(); 
                		i.hasNext(); pos++){
                    String name = (String)i.next();
                    if(outParameters.containsKey(name)){
                        OutputParameter op = 
                        		(OutputParameter)outParameters.get(name);
                        op.setValue(cs.getObject(pos));
                    }
                }
            }
            // return results
            return returnValue;
        }
        catch (SQLException se) {
            // Ensure Exception is logged and then pass up to calling object
            logger.error(se.getClass().getName() 
            		+ ":" + se.getMessage(), se);
            throw wrapException(se);
        }
        // clean up
        finally {        	
            if (cs != null ) {
            	// R1M520129 - Because of incorrect data system may cause exception while closing statement
            	try {
            		cs.close();
            	} catch (Exception unknown) {
            		logger.error(unknown.getClass().getName() + ":" + unknown.getMessage(), unknown);
                }
            }
            // If the connection was not passed in by calling method then colse 
            // it here.
            // otherwise it is the responsibility if the calling mehtod to 
            // close the connection when it is ready
            if (!passedConnection) {
            	// R1M520129 - Because of incorrect data system may throw exception while closing connection
            	try {
            		con.close();
            	} catch (Exception unknown) {
            		logger.error(unknown.getClass().getName() + ":" + unknown.getMessage(), unknown);
                }
            }        	
        }
    }
    
    /**
     * Prepare a statement to execute a stored procedure on the given 
     * connection with the given arguments.
     *
     * @param con Database connection.
     * @param procedureName stored procedure name.
     * @param inParameters name-value pairs of input parameters; names
     *  correspond to stored procedure parameter names).
     * @param outParameters name-OutputParameter pairs.
     */
    public CallableStatement prepareStatement(
        Connection con,
        String procedureName,
        Map inParameters,
        Map outParameters)
        throws SQLException
    {
        CallableStatement cs = con.prepareCall(buildStoredProcedureSQL(
                procedureName,
                inParameters,
                outParameters));
        
        if (inParameters != null) {
            int pos = 1;   
            // set up param values and register out params
            for (Iterator i = inParameters.keySet().iterator();
                    i.hasNext();
                    pos++)
            {
                String name = (String)i.next();
                if (inParameters.get(name) == null)
                    cs.setNull(pos, java.sql.Types.VARCHAR);
                else {
                	Object tmpObj = inParameters.get(name);
                	if (tmpObj instanceof com.ibm.math.BigDecimal)
                		tmpObj = new java.math.BigDecimal(tmpObj.toString());
                    cs.setObject(pos, tmpObj);
                }
                if(outParameters!=null && outParameters.containsKey(name)){
                    OutputParameter op =
                            (OutputParameter)outParameters.get(name);
                    int type = op.getType();
                    if(type==Types.DECIMAL || type==Types.NUMERIC)
                        cs.registerOutParameter(pos, type, op.getScale());
                    else
                        cs.registerOutParameter(pos, type);
                }
            }
        }        
        return cs;
    }
    
    /**
     * This method takes a sp name and some parameters and executes them 
     * @param   procedureName   stored procedure name
     * @param   inParameters      name value pairs of input parameters (names 
     * 			correspond to the underlying sql parameter names)
     * 
     * @throws SQLException
     */
    public void executeCommand(String procedureName, Map inParameters) 
    		throws SQLException,
            DataAccessException{
        executeCommand(procedureName,inParameters,null);
    }
    /**
     * This method takes a sp name and some parameters and executes them 
     * @param   procedureName   stored procedure name
     * @param   inParameters      name value pairs of input parameters 
     * 			(names correspond to the underlying sql parameter names)
     * @param   outParameters   name and OutputParameter object pairs of 
     * 			output parameters  
     * 
     * @throws SQLException
     */
    public void executeCommand(String procedureName, Map inParameters, 
    		Map outParameters) throws SQLException,
            DataAccessException{
        executeCommand(null, procedureName, inParameters, outParameters);
    }
    /**
     * This method takes a sp name and some parameters and executes them 
     * @param   dbConnection    Database connection
     * @param   procedureName   stored procedure name
     * @param   inParameters      name value pairs of input parameters 
     * 			(names correspond to the underlying sql parameter names)
     * @param   outParameters   name and OutputParameter object pairs of output 
     * 			parameters  
     * 
     * @throws SQLException
     */
    public void executeCommand(Connection con, String procedureName, 
    		Map inParameters, Map outParameters) throws SQLException,
            DataAccessException{
        // Calling method may want to control the transaction so can pass in 
    	// its own connection. If not then a new one will be created
        boolean passedConnection = true;
        if (con == null) {
            passedConnection = false;
            con = getConnection();
             
        }
        CallableStatement cs = null;
        try {
            // create comamnd string
            cs = prepareStatement(
                    con,
                    procedureName,
                    inParameters,
                    outParameters);
            // execute
            cs.executeUpdate();
            // retrieve out params
            if(outParameters!=null){
                // iterate through input params as they hold order params were 
            	// added
                int pos=1;
                for (Iterator i = inParameters.keySet().iterator(); 
                		i.hasNext(); pos++){
                    String name = (String)i.next();
                    if(outParameters.containsKey(name)){
                        OutputParameter op = 
                        		(OutputParameter)outParameters.get(name);
                        op.setValue(cs.getObject(pos));
                    }
                }
            }
        }
        catch (SQLException se) {
            // Ensure Exception is logged and then pass up to calling object
            logger.error(se.getClass().getName() 
            		+ ":" + se.getMessage(), se);
            throw wrapException(se);
        }
        // clean up
        finally {
            if (cs != null ) {
                cs.close();
            }
            // If the connection was not passed in by calling method then colse 
            // it here.
            // otherwise it is the responsibility if the calling mehtod to close
            // the connection when it is ready
            if (!passedConnection) {
                con.close();
            }
        }
    }
    protected void formatResults(ResultSet rs) throws SQLException, 
    		DataAccessException{
        // this copies the data from the recordset into the RowSetDynaClass 
        returnValue = new RowSetDynaClass(rs);
    }
    
    /**
     * Executes the CallablStatement and calls the ResultSet formatResults 
     * @param cs The CallableStatement to execute
     * @throws SQLException
     * @throws DataAccessException
     */
    protected void executeCallableStatement(CallableStatement cs) 
    		throws SQLException, DataAccessException {
    	ResultSet rs = null;
    	try {
    		rs = cs.executeQuery();
    		formatResults(rs);
    	} finally {
            if (rs != null)
                rs.close();
    	}
    }
    
    protected static String buildStoredProcedureSQL(
        String procedureName,
        Map parameters,
        Map outParameters)
    {
        StringBuffer sql = new StringBuffer();
        sql.append("exec " + procedureName);
    
        if (parameters != null)
            for (Iterator i = parameters.keySet().iterator(); i.hasNext();) {
                String name = (String) i.next();
                sql.append(" @" + name + "=?");
                if (i.hasNext()) sql.append(",");
            }
        
        return sql.toString();        
    }
    
    /**
     * Call a database function with the given arguments.<p>
     * 
     * If the function is not specified with a two part name then it is assumed
     * to be owned by "dbo".
     */
    public Object callFunction(
        String functionName,
        Object[] args)
        throws
            java.sql.SQLException,
            DataAccessException
    {
        return callFunction(null, functionName, args);
    }
    
    /**
     * Call a database function with the given arguments.<p>
     * 
     * If the function is not specified with a two part name then it is assumed
     * to be owned by "dbo".
     */
    public Object callFunction(
        Connection con,
        String functionName,
        Object[] args)
        throws
            java.sql.SQLException,
            DataAccessException
    {
        StringBuffer sql = new StringBuffer();
        sql.append("select ");
        if (functionName.indexOf('.') == -1)
        {
            sql.append("dbo.");
        }
        sql.append(functionName);
        sql.append('(');
        for (int i = 0; i < args.length; i++)
        {
            if (i > 0) sql.append(", ");
            sql.append('?');
        }
        sql.append(')');
        
        boolean ownConnection = (con == null);
        if (ownConnection)
        {
            con = getConnection();
        }
        try
        {
            CallableStatement cs = con.prepareCall(sql.toString());
            try
            {
                for (int i = 0; i < args.length; i++)
                {
                    if (args[i] == null)
                    {
                        cs.setNull(i + 1, java.sql.Types.VARCHAR);
                    }
                    else
                    {
                    	Object tmpObj = args[i];
                    	if (tmpObj instanceof com.ibm.math.BigDecimal)
                    		tmpObj = new java.math.BigDecimal(tmpObj.toString());
                        cs.setObject(i + 1, tmpObj);
                    }
                }
                ResultSet rs = cs.executeQuery();
                rs.next();
                return rs.getObject(1);
            }
            catch (SQLException e)
            {
                throw wrapException(e);
            }
            finally { cs.close(); }
        }
        finally { if (ownConnection) con.close(); }
    }
    
     /**
      * A <code>DataAccessException</code> that wraps the given
      * <code>SQLException</code>.  Where possible an object of a more
      * specific type is returned, based on the MS SQL Server error code of
      * the original exception.
      */
    protected DataAccessException wrapException(
    		SQLException cause)
    {
    	switch (cause.getErrorCode()) {
    		case SQL_SERVER_UNIQUE_INDEX_ERROR:
    		case SQL_SERVER_UNIQUE_CONSTRAINT_ERROR:
    		case SQL_SERVER_CONSTRAINT_ERROR:
    		case SQL_SERVER_AD_HOC_ERROR:
    			// reduce the error message to just the message raised in the sp
    			String newMessage = cause.getMessage().substring(new String(
    					"[Microsoft][SQLServer 2000 Driver for JDBC][SQLServer]"
    					).length());
    			return new DataAccessException(newMessage ,cause);

    		default:
    			// turn error into "friendly" message
    			return new DataAccessException(
    					ExceptionUtil.handleException(cause, logger,
						SQL_ERROR_MSG, new Object[]{new java.util.Date()},
						INTERNAL_SQL_ERROR_MSG, null), 
						cause);
    	}
     }

    /** Method to create and return a database connection. This will allow 
     *  control over transactions by the business layer if required. Connection 
     *  created as auto-commit 
     *  if this method is used
     * @return connection
     */
     public Connection getConnection()  throws SQLException {
         return getConnection(true);
     }
     
    /**
     * Data source used to create database connections.
     */
    protected DataSource getDataSource()
        throws NamingException
    {
        return (DataSource) new InitialContext().lookup(
                "java:comp/env/jdbc/mwdb");
    }

    /** Method to create and return a database connection. This will allow 
     *  control over transactions by the business layer if required. Calling 
     *  method can choose if auto-commit or not
     * @param autoCommit 
     * @return connection
     */
     public Connection getConnection(boolean autoCommit)  throws SQLException {
        Connection con = null;
        try{
            con = getDataSource().getConnection();
            con.setAutoCommit(autoCommit);
        }
        catch(NamingException ne){
            // failure to connect
            throw new SQLException(
            		ExceptionUtil.handleException(ne, logger,
            		SQL_ERROR_MSG, new Object[]{new java.util.Date()},
            		INTERNAL_SQL_ERROR_MSG, null));
        }
        catch(SQLException se){
            // failure to connect
            throw new SQLException(ExceptionUtil.handleException(se, logger,
            		SQL_ERROR_MSG, new Object[]{new java.util.Date()},
            		INTERNAL_SQL_ERROR_MSG, null));
        }

        return con;
     }
     
     /**
      * Returns the result as a List of Maps
      * @param rs The resultset
      * @param lowerCase Should the Map keys be made lower case ?
      * @return List of Maps of results
      * @throws SQLException
      */
     protected List formatResultsAsMapList(ResultSet rs, boolean lowerCase) throws SQLException {
    	 RowSetDynaClass rsdc = new RowSetDynaClass(rs, lowerCase);
    	 DynaProperty[] properties = rsdc.getDynaProperties();
    	 List output = new ArrayList(); 
    	 for (Iterator iter = rsdc.getRows().iterator(); iter.hasNext(); ) {
    		 Map map = new HashMap();
    		 DynaBean row = (DynaBean) iter.next();
    		 for (int i = 0; i < properties.length; i++) {
    			 String name = properties[i].getName();
    			 map.put(name, row.get(name));
    		 }
    		 output.add(map);
    	 }
    	 return output;
     }
     
 	/**
 	 * This method accepts the stored proc name & parameters and fires the SP on
 	 * connection provided. If no connection is provided, a new connection is
 	 * prepared.
 	 * 
 	 * @con SQLConnection
 	 * @storedProc Stroed Procedure
 	 * @args arguments
 	 * @ArrayList<Hashmap<String, Object>> returns resultset
 	 * 
 	 */
 	public static ArrayList<HashMap<String, Object>>
 			executeStoredProcedure(SQLConnection con, String storedProc,
 					SortedMap<String, Object> args) throws SQLException
 	{
 		// If connection supplied is null, create a new connection
 		if (con == null)
 		{
			con = getDatabaseConnection();
 		}

 		CallableStatement stmt = con.prepareCall(storedProc, args);

 		ArrayList<HashMap<String, Object>> resultSet =
 				new ArrayList<HashMap<String, Object>>();
 		HashMap<String, Object> currentRow = null;
 		int columnCount = 0;

 		try
 		{
 			ResultSet rs = con.executeQuery(stmt, args);
 			columnCount = rs.getMetaData().getColumnCount();

 			while (rs.next())
 			{
 				currentRow = new HashMap<String, Object>();
 				for (int i = 1; i <= columnCount; i++)
 				{
 					currentRow.put(rs.getMetaData().getColumnName(i),
 							rs.getObject(i));
 				}
 				resultSet.add(currentRow);
 			}
 		}
 		finally
 		{
 			stmt.close();
 			con.close();
 		}
 		return resultSet;
 	}

 	/**
 	 * The below method creates a SQLConnection and returns back
 	 * 
 	 * @return
 	 * @throws SQLException
 	 */
	public static SQLConnection getDatabaseConnection() throws SQLException
	{
		return new SQLConnection(DataSourceDirectory.getInstance()
				.getDataSource("mwdb").getConnection());
	}
}

