package com.barclays.account.util;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.barclays.generic.data.dataAccess.DataAccessException;

/**
 * This class takes a validates data against ebox text pattern format
 * i.e. aaannn = [A-Za-z]{3}[0-9]{3}
 * 
 * @author Adam Slater
 * 
 */
/* 
 * DATE      REFERENCE   WHO     	VERSION  	COMMENTS
 * --------  ---------   ---     	-------  	----------------------
 * 24/05/13				SLATERA					Moved from csc created by ???
 */

public class IdMatcher {
	


	//This method Matches the MW_RefValues Patterns to the Input passed 
	public boolean validateMatches(List<String> patternList, String id)
	throws SQLException, DataAccessException,ParseException {

		String idCardPattern = null;

		IdPattern pat = new IdPattern();

		boolean idMatched = false;
		for (int i = 0; i < patternList.size(); i++) {
			idCardPattern = patternList.get(i);
			String idregEx = pat.parsePattern(idCardPattern);
			Pattern pattern = Pattern.compile(idregEx);
			Matcher matcher = pattern.matcher(id);

			if (matcher.matches()) {
				idMatched = true;
			}
		}
		return idMatched;
	}

}
