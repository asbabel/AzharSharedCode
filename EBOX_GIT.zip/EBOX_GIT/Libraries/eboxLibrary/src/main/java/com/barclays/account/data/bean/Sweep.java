package com.barclays.account.data.bean;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.Date;
import java.util.HashMap;

import com.barclays.generic.data.bean.Currency;
import com.ibm.math.BigDecimal;

/**
 * Sweep
 * 
 * Describes a sweep (auto transfer / automatic transfer)
 * @author goodlifw
 */
/*
 * DATE     REFERENCE  WHO    VERSION  COMMENTS
 * -------  ---------  ---    -------  -----------------------------------------
 * 25Jan12  WP615(P4)  WIG    1		   Created.
 * 08Mar12			   PGJ	  2		   Amended to include properties relating to
										textual automatic transfer details.
 * 
 */
public class Sweep implements Serializable{
	/**
	 * Appease the serialisation gods
	 */
	private static final long serialVersionUID = 11869913955362613L;
	
	public static final String ON_MOVEMENT = "On Movement";
	public static final String DIARISED = "Diarised";
	public static final String TRANSFER_AMOUNT = "Transfer Amount";
	public static final String MAINTAIN_BALANCE = "Maintain Balance";
	public static final String DESCRIPTION_FORMAT = "Triggered {0} when "
			+ "EOD balance on {1} becomes {2} {3}, transfer {4} {5}.";
	
	private Integer originatorBranchNumber;
	private Integer originatorAccountNumber;
	private String originatorProduct;
	private String originatorShortName;
	private Integer counterpartyBranchNumber;
	private Integer counterpartyAccountNumber;
	private String counterpartyProduct;
	private String counterpartyShortName;
	private Currency currency;
	private String trigger;
	private String frequency;
	private String day;
	private Date nextDue;
	private String type;
	private BigDecimal amount;
	private String direction;
	private String description;
	private String EODBalanceOn;
	private String becomes;
	private String actionTransfer;

	public Currency getCurrency() {
		return currency;
	}
	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public Integer getOriginatorBranchNumber() {
		return originatorBranchNumber;
	}
	public void setOriginatorBranchNumber(Integer originatorBranchNumber) {
		this.originatorBranchNumber = originatorBranchNumber;
	}
	public Integer getOriginatorAccountNumber() {
		return originatorAccountNumber;
	}
	public void setOriginatorAccountNumber(Integer originatorAccountNumber) {
		this.originatorAccountNumber = originatorAccountNumber;
	}
	public String getOriginatorProduct() {
		return originatorProduct;
	}
	public void setOriginatorProduct(String originatorProduct) {
		this.originatorProduct = originatorProduct;
	}
	public String getOriginatorShortName() {
		return originatorShortName;
	}
	public void setOriginatorShortName(String originatorShortName) {
		this.originatorShortName = originatorShortName;
	}
	public Integer getCounterpartyBranchNumber() {
		return counterpartyBranchNumber;
	}
	public void setCounterpartyBranchNumber(Integer counterpartyBranchNumber) {
		this.counterpartyBranchNumber = counterpartyBranchNumber;
	}
	public Integer getCounterpartyAccountNumber() {
		return counterpartyAccountNumber;
	}
	public void setCounterpartyAccountNumber(Integer counterpartyAccountNumber) {
		this.counterpartyAccountNumber = counterpartyAccountNumber;
	}
	public String getCounterpartyProduct() {
		return counterpartyProduct;
	}
	public void setCounterpartyProduct(String counterpartyProduct) {
		this.counterpartyProduct = counterpartyProduct;
	}
	public String getCounterpartyShortName() {
		return counterpartyShortName;
	}
	public void setCounterpartyShortName(String counterpartyShortName) {
		this.counterpartyShortName = counterpartyShortName;
	}
	public String getTrigger() {
		return trigger;
	}
	public void setTrigger(String trigger) {
		this.trigger = trigger;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public Date getNextDue() {
		return nextDue;
	}
	public void setNextDue(Date nextDue) {
		this.nextDue = nextDue;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getDirection() {		
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public void setDescription(HashMap<String, String> descriptionMap) {
		this.description = MessageFormat.format(DESCRIPTION_FORMAT,
    			descriptionMap.get("TRIGGER"),
    			descriptionMap.get("ORIGINATOR_ACCOUNT"),
    			descriptionMap.get("CONDITION"),
    			descriptionMap.get("FORMATTED_AMOUNT"),
    			descriptionMap.get("TRANSFER_ACTION"),
    			descriptionMap.get("COUNTERPARTY_ACCOUNT"));
	}
	
	/**
	 * @return A description of the sweep in the form: <br>
	 * <code>Trigger on movement when EOD balance on [ORIGINATOR ACCOUNT] becomes 
	 * [CONDITION] [AMOUNT], transfer [TRANSFER DESCRIPTION] [COUNTERPARTY ACCOUNT].</code> 
	 * <br>
	 * OR
	 * <br>
	 * <code>Triggered [FREQUENCY] (next due on [DUE]) when EOD balance on 
	 * [ORIGINATOR ACCOUNT] becomes [CONDITION] [AMOUNT], transfer [AMOUNT] to 
	 * [COUNTERPARTY ACCOUNT].</code>
	 **/
	public String getDescription() {
		return description;
	}
		
	public void setEODBalanceOn(String EODBalanceOn) {
		this.EODBalanceOn = EODBalanceOn;
	}
	
	public String getEODBalanceOn() {
		return this.EODBalanceOn;
	}
	
	public void setBecomes(String becomes) {
		this.becomes = becomes;
	}
	
	public String getBecomes() {
		return this.becomes;
	}
	
	public void setActionTransfer(String actionTransfer) {
		this.actionTransfer = actionTransfer;
	}
	
	public String getActionTransfer() {
		return this.actionTransfer;
	}
	
	/**
	 * @return Whether the originator and counterparty accounts are the same.
	 */
	public boolean originatorEqualsCounterparty() {
		return (originatorBranchNumber.equals(counterpartyBranchNumber)
			&& originatorAccountNumber.equals(counterpartyAccountNumber));
	}
}
