package com.barclays.eChannel.data.bean;
/**
 * Holds info from the BrainsCountryDetails table
 * 
 * @author EarleB
 *
 */
/* 
 * DATE      REFERENCE   WHO     VERSION  COMMENTS
 * --------  ---------   ---     -------  -----------------------------------------
 * 09/03/10  WP419       EARLEB       	  Created
 * 19/07/12  WP616       GX               Moved from eBox Services
 */
public class BrainsCountry {
	private int terminalNumber;
	private int sourceLocation;
	private int bankCode;
	
	public int getBankCode() {
		return bankCode;
	}

	public void setBankCode(int bankCode) {
		this.bankCode = bankCode;
	}

	public int getTerminalNumber() {
		return terminalNumber;
	}
	
	public void setTerminalNumber(int terminalNumber) {
		this.terminalNumber = terminalNumber;
	}
	
	public int getSourceLocation() {
		return sourceLocation;
	}
	
	public void setSourceLocation(int sourceLocation) {
		this.sourceLocation = sourceLocation;
	}
}
