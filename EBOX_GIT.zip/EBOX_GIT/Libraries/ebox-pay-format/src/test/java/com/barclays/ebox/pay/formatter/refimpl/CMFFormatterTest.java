package com.barclays.ebox.pay.formatter.refimpl;

import java.math.BigDecimal;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.barclays.ebox.pay.domain.EnrichedFields;
import com.barclays.ebox.pay.domain.PaymentRequest;
import com.barclays.ebox.pay.domain.RequestHeader;
import com.barclays.ebox.pay.domain.Stage2Queue;
import com.barclays.ebox.pay.domain.Transaction;
import com.barclays.ebox.pay.format.cmf.CMF;
import com.barclays.ebox.pay.format.util.DateService;

import static com.barclays.ebox.pay.format.util.DateService.DATEFORMAT;

/* 
* DATE      REFERENCE   WHO        VERSION     COMMENTS
* --------  ---------   ---        -------     ----------------------
* 26/05/17  WP714       Vaibhav Z   0.1       Enrich Originator address added to CMF
* */

public class CMFFormatterTest {
	private CMFFormatter sut;
	private Date fixedDate;
	
	

	@Before
	public void setUp() {
		sut = new CMFFormatter();
		// This is so we can compare expected vs actual CMFs while ignoring
		// bits that generate new Dates as those will never match
		fixedDate = new Date();
		sut.setDateService(new DateService() {
			@Override
			public Date newDate() {
				return fixedDate;
			}
		});
	}

	@Test
	public void format_returnsCMF() throws Exception {
		Transaction t = getBareBonesTransaction();

		Object result = sut.format(t);

		Assert.assertTrue(result instanceof CMF);
	}

	@Test
	public void format_returnsNonEmptyDocument() throws Exception {
		Transaction t = getBareBonesTransaction();

		CMF result = sut.format(t);

		Assert.assertTrue(result.getCmfXml().length() > 100);
	}

	// TODO The below testS could use a MAJOR rehaul.
	@Test
	public void format_convertsTransactionToCMFCorrectly() throws ParserConfigurationException, TransformerException {
		Transaction transaction = getBareBonesTransaction();

		String routedDate = DATEFORMAT.format(fixedDate), sentDate = routedDate, timestamp = routedDate,
				accId = "acc123", messageId = "messageId";

		int paymentsInGroup = 5, localAmount = 500, origTxAmt = 100, cptyLocalAmt = 500, cptyTxAmt = 10;

		transaction.setAccountNumber(accId);
		transaction.setValueDateInd("1");
		transaction.setValueDays("3");
		transaction.getPaymentRequest().getRequestHeader().setMessageId(messageId);
		transaction.getPaymentRequest().setTransactionsInGroup(paymentsInGroup);
		transaction.setAmount(new BigDecimal(cptyTxAmt));
		transaction.setLocalAmount(new BigDecimal(localAmount));
		transaction.setOriginatorAmount(new BigDecimal(origTxAmt));
		transaction.setCounterPartyNarrative("Counterparty narrative");

		final String EXPECTED_CMF = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><MWMS><MWMH><MWMH1>"
				+ "<MsgType>REQUEST</MsgType>" + "<Format>CMF</Format>" + "<TransactionId/>" + "<MsgId>" + messageId
				+ "</MsgId>" + "<MsgSeqNum/>" + "<RespondTo>" + "<Queue>ECHANNEL_RESPONSE_QUEUE</Queue>"
				+ "</RespondTo>" + "<AccountingToken>ECHANNEL</AccountingToken>"
				+ "<SourceApplName>ECHANNEL</SourceApplName>" + "<SourceApplFunc/>" + "<SentDate>" + sentDate
				+ "</SentDate>" + "<RoutedDate>" + routedDate + "</RoutedDate>"
				// this will break after any change in prod code and needs
				// updating each time
				+ "<OriginalLength>1519</OriginalLength>" + "<UserInfo>" + "<UserIdentifier>WDC</UserIdentifier>"
				+ "<UserPassword>production</UserPassword>" + "</UserInfo>" + "<TargetCountry>MUS</TargetCountry>"
				+ "<OffshoreIndicator/>" + "<EncodedCountry>MU0</EncodedCountry>" + "<PropertyInfo>"
				+ "<Property><Name>ROUTE_QUEUE</Name><Value>%ROUTE_Q1_PUT_PARAMS%</Value></Property>"
				+ "<Property><Name>$GroupId</Name><Value>1000</Value></Property>"
				+ "<Property><Name>$UseAutoResponder</Name><Value>false</Value></Property>" + "</PropertyInfo>"
				+ "<Replay>FALSE</Replay>" + "<ProjectId/>" + "</MWMH1></MWMH><MWMB>"
				+ "<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<IFX Internal=\"true\" Version=\"2\">"
				+ "<BankSvcRq>" + "<MsgRqHdr>" + "<Timestamp>" + timestamp + "</Timestamp>" + "<Country>MU0</Country>"
				+ "</MsgRqHdr>" + "<PaymentRq>" + "<RqUID>1000-0</RqUID>" + "<Group><Id>1000</Id>"
				+ "<NumberOfPaymentsInGroup>" + paymentsInGroup + "</NumberOfPaymentsInGroup>" + "</Group>"
				+ "<ValueDate><ValueDays>3</ValueDays><ValueDateInd>1</ValueDateInd></ValueDate>"
				+ "<SourceSystem>BIR</SourceSystem>" + "<PaymentInfo><Payment>LOCAL</Payment></PaymentInfo>"
				+ "<Exchange><ExchangeOn>COUNTERPARTY</ExchangeOn></Exchange>" + "<SWIFT/>"
				+ "<PostDate>2016-05-09T12:12:12.100</PostDate>" + "<SourceLocationBranch>37</SourceLocationBranch>"
				+ "<TerminalNumber>80</TerminalNumber>" + "<OriginatorAcctId>" + "<AcctCur/>"
				+ "<BankInfo><BankId/></BankInfo>" + "<LocalAmt>" + "<CompositeCurAmtType>Debit</CompositeCurAmtType>"
				+ "<CurAmt><Amt>" + localAmount + "</Amt></CurAmt>" + "</LocalAmt>" + "<TransactionAmt>"
				+ "<CompositeCurAmtType>Debit</CompositeCurAmtType>" + "<CurAmt><Amt>" + origTxAmt
				+ "</Amt></CurAmt></TransactionAmt>" + "<RateInfo/>" + "<RemittanceInformation></RemittanceInformation>"
				+ "</OriginatorAcctId>" + "<CounterpartyAcctId>" + "<AcctId>" + accId + "</AcctId>" + "<BankInfo/>"
				+ "<Narrative>Counterparty narrative</Narrative><LocalAmt>" + "<CompositeCurAmtType>Credit</CompositeCurAmtType>"
				+ "<CurAmt><Amt>" + cptyLocalAmt
				+ "</Amt><CurCode/></CurAmt></LocalAmt>" + "<TransactionAmt>"
				+ "<CompositeCurAmtType>Credit</CompositeCurAmtType>" + "<CurAmt><Amt>" + cptyTxAmt
				+ "</Amt></CurAmt></TransactionAmt>" + "<RateInfo/>" + "<DisplayCode/>"
				+ "<SWIFTCode/>" + "<OriginCode/>" + "<RemittanceInformation></RemittanceInformation>"
				+ "</CounterpartyAcctId>" + "<CompositeCurAmt><CurAmt><Amt>-100</Amt></CurAmt></CompositeCurAmt>"
				+ "</PaymentRq>" + "</BankSvcRq></IFX>]]></MWMB></MWMS>";

		String actual = sut.format(transaction).getCmfXml();

		Assert.assertEquals(EXPECTED_CMF, actual);
	}

	@Test
	public void format_convertsTransactionToCMFCorrectly_CounterPartyNarrativeFromOriginator() throws ParserConfigurationException, TransformerException {
		Transaction transaction = getBareBonesTransaction();

		String routedDate = DATEFORMAT.format(fixedDate), sentDate = routedDate, timestamp = routedDate,
				accId = "acc123", messageId = "messageId";

		int paymentsInGroup = 5, localAmount = 500, origTxAmt = 100, cptyLocalAmt = 500, cptyTxAmt = 10;

		transaction.setAccountNumber(accId);
		transaction.setValueDateInd("1");
		transaction.setValueDays("3");
		transaction.getPaymentRequest().getRequestHeader().setMessageId(messageId);
		transaction.getPaymentRequest().setTransactionsInGroup(paymentsInGroup);
		transaction.setAmount(new BigDecimal(cptyTxAmt));
		transaction.setLocalAmount(new BigDecimal(localAmount));
		transaction.setOriginatorAmount(new BigDecimal(origTxAmt));
		transaction.getPaymentRequest().setNarrative("Counterparty originator narrative");

		final String EXPECTED_CMF = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><MWMS><MWMH><MWMH1>"
				+ "<MsgType>REQUEST</MsgType>" + "<Format>CMF</Format>" + "<TransactionId/>" + "<MsgId>" + messageId
				+ "</MsgId>" + "<MsgSeqNum/>" + "<RespondTo>" + "<Queue>ECHANNEL_RESPONSE_QUEUE</Queue>"
				+ "</RespondTo>" + "<AccountingToken>ECHANNEL</AccountingToken>"
				+ "<SourceApplName>ECHANNEL</SourceApplName>" + "<SourceApplFunc/>" + "<SentDate>" + sentDate
				+ "</SentDate>" + "<RoutedDate>" + routedDate + "</RoutedDate>"
				// this will break after any change in prod code and needs
				// updating each time
				+ "<OriginalLength>1586</OriginalLength>" + "<UserInfo>" + "<UserIdentifier>WDC</UserIdentifier>"
				+ "<UserPassword>production</UserPassword>" + "</UserInfo>" + "<TargetCountry>MUS</TargetCountry>"
				+ "<OffshoreIndicator/>" + "<EncodedCountry>MU0</EncodedCountry>" + "<PropertyInfo>"
				+ "<Property><Name>ROUTE_QUEUE</Name><Value>%ROUTE_Q1_PUT_PARAMS%</Value></Property>"
				+ "<Property><Name>$GroupId</Name><Value>1000</Value></Property>"
				+ "<Property><Name>$UseAutoResponder</Name><Value>false</Value></Property>" + "</PropertyInfo>"
				+ "<Replay>FALSE</Replay>" + "<ProjectId/>" + "</MWMH1></MWMH><MWMB>"
				+ "<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<IFX Internal=\"true\" Version=\"2\">"
				+ "<BankSvcRq>" + "<MsgRqHdr>" + "<Timestamp>" + timestamp + "</Timestamp>" + "<Country>MU0</Country>"
				+ "</MsgRqHdr>" + "<PaymentRq>" + "<RqUID>1000-0</RqUID>" + "<Group><Id>1000</Id>"
				+ "<NumberOfPaymentsInGroup>" + paymentsInGroup + "</NumberOfPaymentsInGroup>" + "</Group>"
				+ "<ValueDate><ValueDays>3</ValueDays><ValueDateInd>1</ValueDateInd></ValueDate>"
				+ "<SourceSystem>BIR</SourceSystem>" + "<PaymentInfo><Payment>LOCAL</Payment></PaymentInfo>"
				+ "<Exchange><ExchangeOn>COUNTERPARTY</ExchangeOn></Exchange>" + "<SWIFT/>"
				+ "<PostDate>2016-05-09T12:12:12.100</PostDate>" + "<SourceLocationBranch>37</SourceLocationBranch>"
				+ "<TerminalNumber>80</TerminalNumber>" + "<OriginatorAcctId>" + "<AcctCur/>"
				+ "<BankInfo><BankId/></BankInfo>" + "<Narrative>Counterparty originator narrative</Narrative><LocalAmt>"
				+ "<CompositeCurAmtType>Debit</CompositeCurAmtType>"
				+ "<CurAmt><Amt>" + localAmount + "</Amt></CurAmt>" + "</LocalAmt>" + "<TransactionAmt>"
				+ "<CompositeCurAmtType>Debit</CompositeCurAmtType>" + "<CurAmt><Amt>" + origTxAmt
				+ "</Amt></CurAmt></TransactionAmt>" + "<RateInfo/>" + "<RemittanceInformation></RemittanceInformation>"
				+ "</OriginatorAcctId>" + "<CounterpartyAcctId>" + "<AcctId>" + accId + "</AcctId>" + "<BankInfo/>"
				+ "<Narrative>Counterparty originator narrative</Narrative><LocalAmt>" + "<CompositeCurAmtType>Credit</CompositeCurAmtType>" + "<CurAmt><Amt>" + cptyLocalAmt
				+ "</Amt><CurCode/></CurAmt></LocalAmt>" + "<TransactionAmt>"
				+ "<CompositeCurAmtType>Credit</CompositeCurAmtType>" + "<CurAmt><Amt>" + cptyTxAmt
				+ "</Amt></CurAmt></TransactionAmt>" + "<RateInfo/>" + "<DisplayCode/>"
				+ "<SWIFTCode/>" + "<OriginCode/>" + "<RemittanceInformation></RemittanceInformation>"
				+ "</CounterpartyAcctId>" + "<CompositeCurAmt><CurAmt><Amt>-100</Amt></CurAmt></CompositeCurAmt>"
				+ "</PaymentRq>" + "</BankSvcRq></IFX>]]></MWMB></MWMS>";

		String actual = sut.format(transaction).getCmfXml();

		Assert.assertEquals(EXPECTED_CMF, actual);
	}

	@Test
	public void format_convertsTransactionToCMFCorrectly_MissingCounterPartyNarrative() throws ParserConfigurationException, TransformerException {
		Transaction transaction = getBareBonesTransaction();

		String routedDate = DATEFORMAT.format(fixedDate), sentDate = routedDate, timestamp = routedDate,
				accId = "acc123", messageId = "messageId";

		int paymentsInGroup = 5, localAmount = 500, origTxAmt = 100, cptyLocalAmt = 500, cptyTxAmt = 10;

		transaction.setAccountNumber(accId);
		transaction.setValueDateInd("1");
		transaction.setValueDays("3");
		transaction.getPaymentRequest().getRequestHeader().setMessageId(messageId);
		transaction.getPaymentRequest().setTransactionsInGroup(paymentsInGroup);
		transaction.setAmount(new BigDecimal(cptyTxAmt));
		transaction.setLocalAmount(new BigDecimal(localAmount));
		transaction.setOriginatorAmount(new BigDecimal(origTxAmt));

		final String EXPECTED_CMF = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><MWMS><MWMH><MWMH1>"
				+ "<MsgType>REQUEST</MsgType>" + "<Format>CMF</Format>" + "<TransactionId/>" + "<MsgId>" + messageId
				+ "</MsgId>" + "<MsgSeqNum/>" + "<RespondTo>" + "<Queue>ECHANNEL_RESPONSE_QUEUE</Queue>"
				+ "</RespondTo>" + "<AccountingToken>ECHANNEL</AccountingToken>"
				+ "<SourceApplName>ECHANNEL</SourceApplName>" + "<SourceApplFunc/>" + "<SentDate>" + sentDate
				+ "</SentDate>" + "<RoutedDate>" + routedDate + "</RoutedDate>"
				// this will break after any change in prod code and needs
				// updating each time
				+ "<OriginalLength>1474</OriginalLength>" + "<UserInfo>" + "<UserIdentifier>WDC</UserIdentifier>"
				+ "<UserPassword>production</UserPassword>" + "</UserInfo>" + "<TargetCountry>MUS</TargetCountry>"
				+ "<OffshoreIndicator/>" + "<EncodedCountry>MU0</EncodedCountry>" + "<PropertyInfo>"
				+ "<Property><Name>ROUTE_QUEUE</Name><Value>%ROUTE_Q1_PUT_PARAMS%</Value></Property>"
				+ "<Property><Name>$GroupId</Name><Value>1000</Value></Property>"
				+ "<Property><Name>$UseAutoResponder</Name><Value>false</Value></Property>" + "</PropertyInfo>"
				+ "<Replay>FALSE</Replay>" + "<ProjectId/>" + "</MWMH1></MWMH><MWMB>"
				+ "<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<IFX Internal=\"true\" Version=\"2\">"
				+ "<BankSvcRq>" + "<MsgRqHdr>" + "<Timestamp>" + timestamp + "</Timestamp>" + "<Country>MU0</Country>"
				+ "</MsgRqHdr>" + "<PaymentRq>" + "<RqUID>1000-0</RqUID>" + "<Group><Id>1000</Id>"
				+ "<NumberOfPaymentsInGroup>" + paymentsInGroup + "</NumberOfPaymentsInGroup>" + "</Group>"
				+ "<ValueDate><ValueDays>3</ValueDays><ValueDateInd>1</ValueDateInd></ValueDate>"
				+ "<SourceSystem>BIR</SourceSystem>" + "<PaymentInfo><Payment>LOCAL</Payment></PaymentInfo>"
				+ "<Exchange><ExchangeOn>COUNTERPARTY</ExchangeOn></Exchange>" + "<SWIFT/>"
				+ "<PostDate>2016-05-09T12:12:12.100</PostDate>" + "<SourceLocationBranch>37</SourceLocationBranch>"
				+ "<TerminalNumber>80</TerminalNumber>" + "<OriginatorAcctId>" + "<AcctCur/>"
				+ "<BankInfo><BankId/></BankInfo>" + "<LocalAmt>" + "<CompositeCurAmtType>Debit</CompositeCurAmtType>"
				+ "<CurAmt><Amt>" + localAmount + "</Amt></CurAmt>" + "</LocalAmt>" + "<TransactionAmt>"
				+ "<CompositeCurAmtType>Debit</CompositeCurAmtType>" + "<CurAmt><Amt>" + origTxAmt
				+ "</Amt></CurAmt></TransactionAmt>" + "<RateInfo/>" + "<RemittanceInformation></RemittanceInformation>"
				+ "</OriginatorAcctId>" + "<CounterpartyAcctId>" + "<AcctId>" + accId + "</AcctId>" + "<BankInfo/>"
				+ "<LocalAmt>" + "<CompositeCurAmtType>Credit</CompositeCurAmtType>" + "<CurAmt><Amt>" + cptyLocalAmt
				+ "</Amt><CurCode/></CurAmt></LocalAmt>" + "<TransactionAmt>"
				+ "<CompositeCurAmtType>Credit</CompositeCurAmtType>" + "<CurAmt><Amt>" + cptyTxAmt
				+ "</Amt></CurAmt></TransactionAmt>" + "<RateInfo/>" + "<DisplayCode/>"
				+ "<SWIFTCode/>" + "<OriginCode/>" + "<RemittanceInformation></RemittanceInformation>"
				+ "</CounterpartyAcctId>" + "<CompositeCurAmt><CurAmt><Amt>-100</Amt></CurAmt></CompositeCurAmt>"
				+ "</PaymentRq>" + "</BankSvcRq></IFX>]]></MWMB></MWMS>";

		String actual = sut.format(transaction).getCmfXml();

		Assert.assertEquals(EXPECTED_CMF, actual);
	}
	
	
	//0.1 start
    @Test
    public void format_convertsTransactionToCMFCorrectlyWithOriginatorAddreess() throws ParserConfigurationException, TransformerException {
        Transaction transaction = getBareBonesTransactionWithOriginatorAddress();

        String routedDate = DATEFORMAT.format(fixedDate), sentDate = routedDate, timestamp = routedDate,
                accId = "acc123", messageId = "messageId";

        int paymentsInGroup = 5, localAmount = 500, origTxAmt = 100, cptyLocalAmt = 500, cptyTxAmt = 10;

        transaction.setAccountNumber(accId);
        transaction.setValueDateInd("1");
        transaction.setValueDays("3");
        transaction.getPaymentRequest().getRequestHeader().setMessageId(messageId);
        transaction.getPaymentRequest().setTransactionsInGroup(paymentsInGroup);
        transaction.setAmount(new BigDecimal(cptyTxAmt));
        transaction.setLocalAmount(new BigDecimal(localAmount));
        transaction.setOriginatorAmount(new BigDecimal(origTxAmt));
        transaction.setCounterPartyNarrative("Counterparty narrative");

        final String EXPECTED_CMF = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><MWMS><MWMH><MWMH1>"
                + "<MsgType>REQUEST</MsgType>" + "<Format>CMF</Format>" + "<TransactionId/>" + "<MsgId>" + messageId
                + "</MsgId>" + "<MsgSeqNum/>" + "<RespondTo>" + "<Queue>ECHANNEL_RESPONSE_QUEUE</Queue>"
                + "</RespondTo>" + "<AccountingToken>ECHANNEL</AccountingToken>"
                + "<SourceApplName>ECHANNEL</SourceApplName>" + "<SourceApplFunc/>" + "<SentDate>" + sentDate
                + "</SentDate>" + "<RoutedDate>" + routedDate + "</RoutedDate>"
                + "<OriginalLength>1636</OriginalLength>" + "<UserInfo>" + "<UserIdentifier>WDC</UserIdentifier>"
                + "<UserPassword>production</UserPassword>" + "</UserInfo>" + "<TargetCountry>MUS</TargetCountry>"
                + "<OffshoreIndicator/>" + "<EncodedCountry>MU0</EncodedCountry>" + "<PropertyInfo>"
                + "<Property><Name>ROUTE_QUEUE</Name><Value>%ROUTE_Q1_PUT_PARAMS%</Value></Property>"
                + "<Property><Name>$GroupId</Name><Value>1000</Value></Property>"
                + "<Property><Name>$UseAutoResponder</Name><Value>false</Value></Property>" + "</PropertyInfo>"
                + "<Replay>FALSE</Replay>" + "<ProjectId/>" + "</MWMH1></MWMH><MWMB>"
                + "<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<IFX Internal=\"true\" Version=\"2\">"
                + "<BankSvcRq>" + "<MsgRqHdr>" + "<Timestamp>" + timestamp + "</Timestamp>" + "<Country>MU0</Country>"
                + "</MsgRqHdr>" + "<PaymentRq>" + "<RqUID>1000-0</RqUID>" + "<Group><Id>1000</Id>"
                + "<NumberOfPaymentsInGroup>" + paymentsInGroup + "</NumberOfPaymentsInGroup>" + "</Group>"
                + "<ValueDate><ValueDays>3</ValueDays><ValueDateInd>1</ValueDateInd></ValueDate>"
                + "<SourceSystem>BIR</SourceSystem>" + "<PaymentInfo><Payment>LOCAL</Payment></PaymentInfo>"
                + "<Exchange><ExchangeOn>COUNTERPARTY</ExchangeOn></Exchange>" + "<SWIFT/>"
                + "<PostDate>2016-05-09T12:12:12.100</PostDate>" + "<SourceLocationBranch>37</SourceLocationBranch>"
                + "<TerminalNumber>80</TerminalNumber>" + "<OriginatorAcctId><Name>originatorName</Name><PostAddr><Addr1>address1</Addr1>"
                        + "<Addr2>address2</Addr2><Addr3>address3</Addr3></PostAddr>" + "<AcctCur/>"
                + "<BankInfo><BankId/></BankInfo>" + "<LocalAmt>" + "<CompositeCurAmtType>Debit</CompositeCurAmtType>"
                + "<CurAmt><Amt>" + localAmount + "</Amt></CurAmt>" + "</LocalAmt>" + "<TransactionAmt>"
                + "<CompositeCurAmtType>Debit</CompositeCurAmtType>" + "<CurAmt><Amt>" + origTxAmt
                + "</Amt></CurAmt></TransactionAmt>" + "<RateInfo/>" + "<RemittanceInformation></RemittanceInformation>"
                + "</OriginatorAcctId>" + "<CounterpartyAcctId>" + "<AcctId>" + accId + "</AcctId>" + "<BankInfo/>"
                + "<Narrative>Counterparty narrative</Narrative><LocalAmt>" + "<CompositeCurAmtType>Credit</CompositeCurAmtType>"
                + "<CurAmt><Amt>" + cptyLocalAmt
                + "</Amt><CurCode/></CurAmt></LocalAmt>" + "<TransactionAmt>"
                + "<CompositeCurAmtType>Credit</CompositeCurAmtType>" + "<CurAmt><Amt>" + cptyTxAmt
                + "</Amt></CurAmt></TransactionAmt>" + "<RateInfo/>" + "<DisplayCode/>"
                + "<SWIFTCode/>" + "<OriginCode/>" + "<RemittanceInformation></RemittanceInformation>"
                + "</CounterpartyAcctId>" + "<CompositeCurAmt><CurAmt><Amt>-100</Amt></CurAmt></CompositeCurAmt>"
                + "</PaymentRq>" + "</BankSvcRq></IFX>]]></MWMB></MWMS>";

        String actual = sut.format(transaction).getCmfXml();

        Assert.assertEquals(EXPECTED_CMF, actual);
    }
// 0.1 end
	private Transaction getBareBonesTransaction() {
		return new Transaction.Builder().setEnrichedFields(new EnrichedFields.Builder().setTimestamp(fixedDate).build())
				.setPaymentRequest(new PaymentRequest.Builder()
						.setRequestHeader(new RequestHeader.Builder().setUserIdentity("WDC")
								.setUserPassword("production").setTargetCountry("MUS").setEncodedCountry("MU0")
								.setSentDate(fixedDate).setPostDate("2016-05-09T12:12:12.100")
								.setRespondTo("ECHANNEL_RESPONSE_QUEUE").setAccountingToken("ECHANNEL")
								.setSourceApplName("ECHANNEL").setReplayFlag("FALSE").setRequestSource("BIR")
								.setTerminalNumber("80").setSourceLocationBranch("37").build())
						.setDebitCreditInd("D").setType("LOCAL").setGroupId("1000").setAmount(new BigDecimal(100))
						.setStage2Queue(new Stage2Queue("AQ.PPS.ROUTE.UK.01","%ROUTE_Q1_PUT_PARAMS%")).build())
				.setDealId("1234").setDebitCreditInd("C").setExchangeOn("COUNTERPARTY")
				.setLocalAmount(new BigDecimal(500)).setCalculatedLocalAmount(new BigDecimal(500))
				.setAmount(new BigDecimal(10)).setCalculatedAmount(new BigDecimal(10))
				.setOriginatorAmount(new BigDecimal(100)).setCalculatedOriginatorAmount(new BigDecimal(100))
				.setOriginatorLocalAmount(new BigDecimal(1000)).build();
	}
// 0.1 start
	private Transaction getBareBonesTransactionWithOriginatorAddress() {
        return new Transaction.Builder().setEnrichedFields(new EnrichedFields.Builder().setTimestamp(fixedDate).build())
                .setPaymentRequest(new PaymentRequest.Builder()
                        .setRequestHeader(new RequestHeader.Builder().setUserIdentity("WDC")
                                .setUserPassword("production").setTargetCountry("MUS").setEncodedCountry("MU0")
                                .setSentDate(fixedDate).setPostDate("2016-05-09T12:12:12.100")
                                .setRespondTo("ECHANNEL_RESPONSE_QUEUE").setAccountingToken("ECHANNEL")
                                .setSourceApplName("ECHANNEL").setReplayFlag("FALSE").setRequestSource("BIR")
                                .setTerminalNumber("80").setSourceLocationBranch("37").build())
                                .setOriginatorName("originatorName")
                                .setOriginatorAddress1("address1").setOriginatorAddress2("address2").setOriginatorAddress3("address3")
                        .setDebitCreditInd("D").setType("LOCAL").setGroupId("1000").setAmount(new BigDecimal(100))
                        .setStage2Queue(new Stage2Queue("AQ.PPS.ROUTE.UK.01","%ROUTE_Q1_PUT_PARAMS%")).build())
                .setDealId("1234").setDebitCreditInd("C").setExchangeOn("COUNTERPARTY")
                .setLocalAmount(new BigDecimal(500)).setCalculatedLocalAmount(new BigDecimal(500))
                .setAmount(new BigDecimal(10)).setCalculatedAmount(new BigDecimal(10))
                .setOriginatorAmount(new BigDecimal(100)).setCalculatedOriginatorAmount(new BigDecimal(100))
                .setOriginatorLocalAmount(new BigDecimal(1000)).build();
    }
// 0.1 end
}