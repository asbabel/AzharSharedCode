package com.barclays.ebox.pay.format.cmf;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.junit.Assert;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.barclays.ebox.pay.format.cmf.CMF;

public class CMFTest {
	@Test
	public void cmfCreatedFromXmlDoc_canGetAsFlatString() throws ParserConfigurationException, TransformerException {
		final String EXPECTED = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><MWMS><MWMH><MWMH1>MWMH1 Content</MWMH1></MWMH><MWMB><![CDATA[Hello from CDATA]]></MWMB></MWMS>";

		// Create input XML Document
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document xmlDoc = docBuilder.newDocument();
		Element mwms = xmlDoc.createElement("MWMS");
		Element mwmb = xmlDoc.createElement("MWMB");
		Element mwmh = xmlDoc.createElement("MWMH");
		Element mwmh1 = xmlDoc.createElement("MWMH1");
		mwmh1.appendChild(xmlDoc.createTextNode("MWMH1 Content"));
		mwmb.appendChild(xmlDoc.createCDATASection("Hello from CDATA"));
		mwms.appendChild(mwmh);
		mwmh.appendChild(mwmh1);
		mwms.appendChild(mwmb);
		xmlDoc.appendChild(mwms);

		CMF cmf = new CMF(xmlDoc);

		String actual = cmf.getCmfXml();
		Assert.assertEquals(EXPECTED, actual);
	}
}
