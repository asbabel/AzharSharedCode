package com.barclays.ebox.pay.formatter.refimpl;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.barclays.ebox.pay.domain.Transaction;
import com.barclays.ebox.pay.format.pain001.Pain001Payment;
import com.barclays.ebox.pay.formatter.TransactionFormatter;

public class Pain001FormatterTest {
	TransactionFormatter<Pain001Payment> sut;

	@Before
	public void setUp() {
		sut = new Pain001Formatter();
	}

	@Test
	public void formatMethod_returnsPain001() throws ParserConfigurationException, TransformerException {
		Transaction t = new Transaction.Builder().build();
		Object result = sut.format(t);
		Assert.assertTrue(result instanceof Pain001Payment);
	}
}
