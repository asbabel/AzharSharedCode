package com.barclays.ebox.pay.format.cmf;

import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;

import com.barclays.ebox.pay.format.DOMHelper;
import com.barclays.ebox.pay.format.Format;

/**
 * This object represents a "Common Message Format" (CMF) XML message
 * 
 * @author G01025860
 */
public class CMF implements Format {
	private String cmfXml;

	/**
	 * Creates a CMF from an XML Document
	 * 
	 * @param xmlDoc
	 *            The XML Doc to create a CMF object from
	 * @throws TransformerException
	 */
	public CMF(Document xmlDoc) throws TransformerException {
		setCmfXml(DOMHelper.getOneLinerXmlString(xmlDoc));
	}

	/**
	 * Creates a CMF from an XML String.
	 * 
	 * @param cmfXml
	 *            The XML String to create a CMF object from
	 */
	public CMF(String cmfXml) {
		setCmfXml(cmfXml);
	}

	/**
	 * @return String The CMF mesage as a String
	 */
	public String getCmfXml() {
		return cmfXml;
	}

	/**
	 * Sets the CMF XML String view of this object
	 * 
	 * @param cmfXml
	 *            The CMF XML String
	 */
	public void setCmfXml(String cmfXml) {
		this.cmfXml = cmfXml;
	}
}
