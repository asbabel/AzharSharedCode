package com.barclays.ebox.pay.format;

/**
 * Marker Interface for supported formatter formats.
 * 
 * @author g01025860
 */
public interface Format {
}
