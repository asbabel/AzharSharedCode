package com.barclays.ebox.pay.format.pain001;

import iso.std.iso._20022.tech.xsd.pain_001_001.ObjectFactory;
import iso.std.iso._20022.tech.xsd.pain_001_001.Document;

import com.barclays.ebox.pay.format.Format;

/**
 * Proof of Concept - PAIN_001 Payment Format
 * 
 * @author G01025860
 */
public class Pain001Payment implements Format {
	private Document pain001Document;

	/**
	 * Default Constructor
	 */
	public Pain001Payment() {
		pain001Document = new ObjectFactory().createDocument();
	}

	public Document getPain001Document() {
		return this.pain001Document;
	}

	public void setPain001Document(Document pain001Msg) {
		this.pain001Document = pain001Msg;
	}
}
