package com.barclays.ebox.pay.formatter.refimpl;

import org.springframework.stereotype.Component;

import com.barclays.ebox.pay.domain.Transaction;
import com.barclays.ebox.pay.format.pain001.Pain001Payment;
import com.barclays.ebox.pay.formatter.TransactionFormatter;

/**
 * This class converts a Transaction object into a Pain001Payment
 * 
 * @author G01025860
 */
@Component
public class Pain001Formatter implements TransactionFormatter<Pain001Payment> {
	@Override
	public Pain001Payment format(Transaction transaction) {
		// placeholder - Pain 001 formatting not required for initial deployment
		return new Pain001Payment();
	}
}
