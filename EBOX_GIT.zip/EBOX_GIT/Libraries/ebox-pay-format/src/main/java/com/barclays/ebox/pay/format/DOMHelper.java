package com.barclays.ebox.pay.format;

import java.io.StringWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;

/**
 * Utility methods for DOM
 * 
 * @author G01025860
 */
public final class DOMHelper {
	private DOMHelper() {
	}

	/**
	 * Returns a one-liner XML String for the given XML Document object
	 * 
	 * @param doc
	 *            the XML Document object to parse
	 * @return A one line String representation of the passed in Document
	 * @throws TransformerException
	 */
	public static String getOneLinerXmlString(Document doc) throws TransformerException {
		DOMSource domSource = new DOMSource(doc);
		StringWriter xmlString = new StringWriter();
		StreamResult stream = new StreamResult(xmlString);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer trans = tf.newTransformer();
		trans.transform(domSource, stream);

		return xmlString.toString();
	}
}
