package com.barclays.ebox.pay.format.pain001;

import iso.std.iso._20022.tech.xsd.pain_001_001.ObjectFactory;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

/**
 * Used to share an instance of JAXB context (expensive to create each use)
 * 
 * @author g01025860
 *
 */
public final class JAXBContextFactory {
	private static JAXBContext jaxbContext;

	private JAXBContextFactory() {
	}

	public static JAXBContext getCtx() throws JAXBException {
		if (jaxbContext == null) {
			createNewContext();
		}
		return jaxbContext;
	}

	private static synchronized void createNewContext() throws JAXBException {
		jaxbContext = JAXBContext.newInstance(ObjectFactory.class);
	}
}
