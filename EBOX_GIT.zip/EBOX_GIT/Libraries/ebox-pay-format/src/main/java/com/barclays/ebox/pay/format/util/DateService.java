package com.barclays.ebox.pay.format.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This class is used as a dependency of classes that require to generate a
 * Timestamp
 * 
 * The only purpose of this dependency is that it can be injected with a fake
 * "DateService" for the purpose of Unit Testing
 * 
 * @author g01025860
 *
 */
public class DateService {
	/**
	 * The standard Date format in eBOX Payments
	 */
	public static final SimpleDateFormat DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

	/**
	 * Returns the "current Date."
	 * 
	 * This might look useless... but in unit tests it is difficult to make
	 * asserts against "current Date" as this cannot be predicted.
	 * 
	 * This layer of abstraction allows "current Date" to be replaced in unit
	 * tests with a preset date.
	 * 
	 * @return A new Date Object.
	 */
	public Date newDate() {
		return new Date();
	}
}
