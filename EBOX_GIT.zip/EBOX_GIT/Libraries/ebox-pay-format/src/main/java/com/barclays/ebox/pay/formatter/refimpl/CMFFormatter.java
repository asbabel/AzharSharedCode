package com.barclays.ebox.pay.formatter.refimpl;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.barclays.ebox.pay.domain.EnrichedFields;
import com.barclays.ebox.pay.domain.PaymentRequest;
import com.barclays.ebox.pay.domain.RequestHeader;
import com.barclays.ebox.pay.domain.Transaction;
import com.barclays.ebox.pay.domain.codes.EboxPayCodes;
import com.barclays.ebox.pay.format.DOMHelper;
import com.barclays.ebox.pay.format.cmf.CMF;
import com.barclays.ebox.pay.format.util.DateService;
import com.barclays.ebox.pay.formatter.TransactionFormatter;

import static com.barclays.ebox.pay.format.util.DateService.DATEFORMAT;

/**
 * Given a fully populated Transaction Object, This class returns a CMF
 * representation of the Transaction Object complying with the
 * TransactionFormatter interface
 * 
 * @author g01025860
 */

/* 
* DATE      REFERENCE   WHO        VERSION     COMMENTS
* --------  ---------   ---        -------     ----------------------
* 05/06/17  WP714       Vaibhav Z   0.1        Enriched the instruction with the address data 
* */

@Component
public class CMFFormatter implements TransactionFormatter<CMF> {
	private static final String CREDIT = "Credit";
	private static final String DEBIT = "Debit";
	private static final String CUR_AMT = "CurAmt";
	private static final String COMPOSITE_CUR_AMT_TYPE = "CompositeCurAmtType";
	private static final String CUR_CODE = "CurCode";
	private DateService dateService = new DateService();

	@Override
	public CMF format(Transaction transaction) throws ParserConfigurationException, TransformerException {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

		Document d = docBuilder.newDocument();

		Element mwms = elem(d, "MWMS");
		Element mwmb = elem(d, "MWMB");
		Element mwmh = elem(d, "MWMH");

		String cdata = getCDATAString(docBuilder, transaction);
		String updatedCdata = fixEmptyRemittance(cdata);

		Element mwmh1 = createMWMH1(d, transaction, updatedCdata);

		mwmb.appendChild(d.createCDATASection(updatedCdata));
		mwms.appendChild(mwmh);
		mwmh.appendChild(mwmh1);
		mwms.appendChild(mwmb);
		d.appendChild(mwms);

		return new CMF(d);
	}

	void setDateService(DateService dateService) {
		this.dateService = dateService;
	}

	private Element createMWMH1(Document d, Transaction transaction, String cdata) {
		Element mwmh1 = elem(d, "MWMH1");

		Element msgType = elem(d, "MsgType");
		Element format = elem(d, "Format");
		Element transactionId = elem(d, "TransactionId");
		Element msgId = elem(d, "MsgId");
		Element msgSeqNum = elem(d, "MsgSeqNum");
		Element respondTo = elem(d, "RespondTo");
		Element queue = elem(d, "Queue");
		Element accountingToken = elem(d, "AccountingToken");
		Element sourceApplName = elem(d, "SourceApplName");
		Element sourceApplFunc = elem(d, "SourceApplFunc");
		Element sentDate = elem(d, "SentDate");
		Element routedDate = elem(d, "RoutedDate");
		Element originalLength = elem(d, "OriginalLength");
		Element userInfo = elem(d, "UserInfo");
		Element userIdentifier = elem(d, "UserIdentifier");
		Element userPassword = elem(d, "UserPassword");
		Element targetCountry = elem(d, "TargetCountry");
		Element offshoreIndicator = elem(d, "OffshoreIndicator");
		Element encodedCountry = elem(d, "EncodedCountry");
		Element propertyInfo = getPropertyInfoTag(d, transaction);
		Element replay = elem(d, "Replay");
		Element projectId = elem(d, "ProjectId");

		RequestHeader h = transaction.getPaymentRequest().getRequestHeader();

		msgType.appendChild(text(d, "REQUEST"));
		format.appendChild(text(d, "CMF"));
		transactionId.appendChild(text(d, h.getTransactionId()));
		msgId.appendChild(text(d, h.getMessageId()));
		msgSeqNum.appendChild(text(d, readStringValueFromInt(transaction.getTransactionCounter())));
		queue.appendChild(text(d, h.getRespondTo()));
		accountingToken.appendChild(text(d, h.getAccountingToken()));
		sourceApplName.appendChild(text(d, h.getSourceApplName()));
		sourceApplFunc.appendChild(text(d, h.getSourceApplFunc()));
		sentDate.appendChild(text(d, DATEFORMAT.format(h.getSentDate())));
		routedDate.appendChild(text(d, DATEFORMAT.format(dateService.newDate())));
		originalLength.appendChild(text(d, readStringValueFromInt(getCdataLength(cdata))));
		userIdentifier.appendChild(text(d, h.getUserIdentity()));
		userPassword.appendChild(text(d, h.getUserPassword()));
		targetCountry.appendChild(text(d, h.getTargetCountry()));
		offshoreIndicator.appendChild(text(d, readStringValueFromInt(h.getPropertyOffshoreInd())));
		encodedCountry.appendChild(text(d, h.getEncodedCountry()));
		replay.appendChild(text(d, h.getReplayFlag()));
		projectId.appendChild(text(d, h.getProjectId()));

		respondTo.appendChild(queue);
		multiAppend(userInfo, userIdentifier, userPassword);

		// Append main tags to mwmh1
		multiAppend(mwmh1, msgType, format, transactionId, msgId, msgSeqNum, respondTo, accountingToken, sourceApplName,
				sourceApplFunc, sentDate, routedDate, originalLength, userInfo, targetCountry, offshoreIndicator,
				encodedCountry, propertyInfo);
		appendIfNotEmpty(mwmh1, replay);
		mwmh1.appendChild(projectId);

		return mwmh1;
	}

	private int getCdataLength(String cdata) {
		return cdata.getBytes(Charset.forName("UTF-8")).length;
	}

	private String getCDATAString(DocumentBuilder docBuilder, Transaction transaction) throws TransformerException {
		return DOMHelper.getOneLinerXmlString(createCDATA(docBuilder, transaction));
	}

	private Document createCDATA(DocumentBuilder docBuilder, Transaction transaction) { // NOSONAR
		Document d = docBuilder.newDocument();

		Element ifx = elem(d, "IFX");
		Element bankSvcRq = elem(d, "BankSvcRq");
		Element msgRqHdr = elem(d, "MsgRqHdr");
		Element timestamp = elem(d, "Timestamp");
		Element country = elem(d, "Country");
		Element paymentRq = elem(d, "PaymentRq");
		Element rqUID = elem(d, "RqUID");
		Element userId = elem(d, "UserId");
		Element group = elem(d, "Group");
		Element id = elem(d, "Id");
		Element itemNumber = elem(d, "ItemNumber");
		Element numberOfPaymentsInGroup = elem(d, "NumberOfPaymentsInGroup");
		Element valueDate = elem(d, "ValueDate");
		Element valueDays = elem(d, "ValueDays");
		Element valueDateInd = elem(d, "ValueDateInd");
		Element settlementDays = elem(d, "SettlementDays");
		Element sourceSystem = elem(d, "SourceSystem");
		Element paymentInfo = elem(d, "PaymentInfo");
		Element payment = elem(d, "Payment");
		Element type = elem(d, "Type");
		Element exchange = elem(d, "Exchange");
		Element exchangeRate = elem(d, "ExchangeRate");
		Element exchangeRateFormat = elem(d, "ExchangeRateFormat");
		Element exchangeOn = elem(d, "ExchangeOn");
		Element exchangeDetails = elem(d, "ExchangeDetails");
		Element swift = elem(d, "SWIFT");
		Element sendersReference = elem(d, "SendersReference");
		Element relatedReference = elem(d, "RelatedReference");
		Element senderToReceiver = elem(d, "SenderToReceiver");
		Element preferredIntermediary = elem(d, "PreferredIntermediary");
		Element sameDayValueIndicator = elem(d, "SameDayValueIndicator");
		Element swiftValueDate = elem(d, "SWIFTValueDate");
		Element postDate = elem(d, "PostDate");
		Element sourceLocationBranch = elem(d, "SourceLocationBranch");
		Element terminalNumber = elem(d, "TerminalNumber");
		Element originatorAcctId = elem(d, "OriginatorAcctId");
		Element oAcctId = elem(d, "AcctId");
		Element oName = elem(d, "Name");
		Element oPostAddr = elem(d, "PostAddr");
		Element oAddr1 = elem(d, "Addr1");
		Element oAddr2 = elem(d, "Addr2");
		Element oAddr3 = elem(d, "Addr3");
		Element oAcctCur = elem(d, "AcctCur");
		Element oBankInfo = elem(d, "BankInfo");
		Element oBankId = elem(d, "BankId");
		Element oBranchId = elem(d, "BranchId");
		Element oNarrative = elem(d, "Narrative");
		Element oLocalAmt = elem(d, "LocalAmt");
		Element olCompositeCurAmtType = elem(d, COMPOSITE_CUR_AMT_TYPE);
		Element olCurAmt = elem(d, CUR_AMT);
		Element olAmt = elem(d, "Amt");
		Element olCurCode = elem(d, CUR_CODE);
		Element oTransactionAmt = elem(d, "TransactionAmt");
		Element otCompositeCurAmtType = elem(d, COMPOSITE_CUR_AMT_TYPE);
		Element otCurAmt = elem(d, CUR_AMT);
		Element otAmt = elem(d, "Amt");
		Element otCurCode = elem(d, CUR_CODE);
		Element oRateInfo = elem(d, "RateInfo");
		Element oRatePackage = elem(d, "RatePackage");
		Element oRate = elem(d, "Rate");
		Element oSellMarkup = elem(d, "SellMarkup");
		Element oBuyMarkup = elem(d, "BuyMarkup");
		Element oMidRate = elem(d, "MidRate");
		Element oRateStatus = elem(d, "RateStatus");
		Element oDisplayCode = elem(d, "DisplayCode");
		Element oOriginCode = elem(d, "OriginCode");
		Element oRemittanceInformation = elem(d, "RemittanceInformation");
		Element counterpartyAcctId = elem(d, "CounterpartyAcctId");
		Element cAcctId = elem(d, "AcctId");
		Element cName = elem(d, "Name");
		Element cPostAddr = elem(d, "PostAddr");
		Element cAddr1 = elem(d, "Addr1");
		Element cAddr2 = elem(d, "Addr2");
		Element cAddr3 = elem(d, "Addr3");
		Element cBankInfo = elem(d, "BankInfo");
		Element cBankId = elem(d, "BankId");
		Element cBranchId = elem(d, "BranchId");
		Element cRegionCode = elem(d, "RegionCode");
		Element cNarrative = elem(d, "Narrative");
		Element cLocalAmt = elem(d, "LocalAmt");
		Element clCompositeCurAmtType = elem(d, COMPOSITE_CUR_AMT_TYPE);
		Element clCurAmt = elem(d, CUR_AMT);
		Element clAmt = elem(d, "Amt");
		Element clCurCode = elem(d, CUR_CODE);
		Element cTransactionAmt = elem(d, "TransactionAmt");
		Element ctCompositeCurAmtType = elem(d, COMPOSITE_CUR_AMT_TYPE);
		Element ctCurAmt = elem(d, CUR_AMT);
		Element ctAmt = elem(d, "Amt");
		Element ctCurCode = elem(d, CUR_CODE);
		Element cRateInfo = elem(d, "RateInfo");
		Element cRatePackage = elem(d, "RatePackage");
		Element cRate = elem(d, "Rate");
		Element cSellMarkup = elem(d, "SellMarkup");
		Element cBuyMarkup = elem(d, "BuyMarkup");
		Element cMidRate = elem(d, "MidRate");
		Element cRateStatus = elem(d, "RateStatus");
		Element cDisplayCode = elem(d, "DisplayCode");
		Element cSwiftCode = elem(d, "SWIFTCode");
		Element cOriginCode = elem(d, "OriginCode");
		Element cRemittanceInformation = elem(d, "RemittanceInformation");
		Element compositeCurAmt = elem(d, "CompositeCurAmt");
		Element cCurAmt = elem(d, CUR_AMT);
		Element cAmt = elem(d, "Amt");
		Element cCurCode = elem(d, CUR_CODE);
		List<Element> additionalRef = getAdditionalRef(d, transaction);
		Element dealer = elem(d, "Dealer");
		Element dealerId = elem(d, "Id");
		Element dealerRate = elem(d, "Rate");
		Element memo = elem(d, "Memo");
		Element deferClientEntry = elem(d, "DeferClientEntry");
		Element marketSegment = elem(d, "MarketSegment");

		EnrichedFields ef = transaction.getEnrichedFields();
		PaymentRequest orig = transaction.getPaymentRequest();

		ifx.setAttribute("Version", "2");
		ifx.setAttribute("Internal", "true");
		timestamp.appendChild(text(d, DATEFORMAT.format(ef.getTimestamp())));

		country.appendChild(text(d, orig.getRequestHeader().getEncodedCountry()));
		rqUID.appendChild(text(d, orig.getGroupId() + "-" + transaction.getTransactionCounter()));
		userId.appendChild(text(d, orig.getUserId()));
		id.appendChild(text(d, orig.getGroupId()));
		itemNumber.appendChild(text(d, readStringValueFromInt(transaction.getTransactionCounter())));
		numberOfPaymentsInGroup.appendChild(text(d, readStringValueFromInt(orig.getTransactionsInGroup())));
		valueDays.appendChild(text(d, transaction.getValueDays()));
		valueDateInd.appendChild(text(d, transaction.getValueDateInd()));
		settlementDays.appendChild(text(d, ef.getSettlementDays()));
		sourceSystem.appendChild(text(d, orig.getRequestHeader().getRequestSource()));
		payment.appendChild(text(d, orig.getType()));
		type.appendChild(text(d, orig.getTypeDescription()));
		exchangeRate.appendChild(text(d, ef.getExchangeRate()));
		exchangeOn.appendChild(text(d, transaction.getExchangeOn()));
		exchangeDetails.appendChild(text(d, ef.getExchangeDetails()));
		exchangeRateFormat.appendChild(text(d, ef.getExchangeRateFormat()));
		sendersReference.appendChild(text(d, transaction.getSendersRef()));
		relatedReference.appendChild(text(d, transaction.getRelatedRef()));
		senderToReceiver.appendChild(text(d, transaction.getSenderToReceiver()));
		preferredIntermediary.appendChild(text(d, transaction.getPreferedIntermediary()));
		sameDayValueIndicator.appendChild(text(d, transaction.getSameDayValueInd()));
		swiftValueDate.appendChild(text(d, transaction.getSwiftValueDate()));
		postDate.appendChild(text(d, orig.getRequestHeader().getPostDate()));
		sourceLocationBranch.appendChild(text(d, orig.getRequestHeader().getSourceLocationBranch()));
		terminalNumber.appendChild(text(d, orig.getRequestHeader().getTerminalNumber()));

		oAcctId.appendChild(text(d, orig.getAccountNo()));
		oName.appendChild(text(d, orig.getOriginatorName()));
		oAddr1.appendChild(text(d, orig.getOriginatorAddress1()));
		oAddr2.appendChild(text(d, orig.getOriginatorAddress2()));
		oAddr3.appendChild(text(d, orig.getOriginatorAddress3()));
		oAcctCur.appendChild(text(d, orig.getCcy()));
		oBankId.appendChild(text(d, orig.getRequestHeader().getBankCode()));
		oBranchId.appendChild(text(d, orig.getBranchId()));
		oNarrative.appendChild(text(d, orig.getNarrative()));
		olCompositeCurAmtType.appendChild(text(d, ("D").equalsIgnoreCase(orig.getDebitCreditInd()) ? DEBIT : CREDIT));
		olAmt.appendChild(text(d, transaction.getCalculatedLocalAmount().toString()));
		olCurCode.appendChild(text(d, orig.getLocalCcy()));
		otCompositeCurAmtType.appendChild(text(d, ("D").equalsIgnoreCase(orig.getDebitCreditInd()) ? DEBIT : CREDIT));
		otAmt.appendChild(text(d, transaction.getCalculatedOriginatorAmount().toString()));
		otCurCode.appendChild(text(d, orig.getCcy()));
		oRatePackage.appendChild(text(d, ef.getOriginatorRatePackage()));
		oRate.appendChild(text(d, ef.getOriginatorRate()));
		oSellMarkup.appendChild(text(d, ef.getOriginatorSellMarkup()));
		oBuyMarkup.appendChild(text(d, ef.getOriginatorBuyMarkup()));
		oMidRate.appendChild(text(d, ef.getOriginatorMidRate()));
		oRateStatus.appendChild(text(d, transaction.getRateStatus()));
		oDisplayCode.appendChild(text(d, transaction.getDisplayCode()));
		oOriginCode.appendChild(text(d, orig.getOriginatorCode()));
		oRemittanceInformation.appendChild(text(d, orig.getRemittanceInformation()));

		cAcctId.appendChild(text(d, transaction.getAccountNumber()));
		cName.appendChild(text(d, transaction.getCounterPartyName()));
		cAddr1.appendChild(text(d, transaction.getCptyAddress1()));
		cAddr2.appendChild(text(d, transaction.getCptyAddress2()));
		cAddr3.appendChild(text(d, transaction.getCptyAddress3()));
		cBankId.appendChild(text(d, transaction.getBankCode()));
		cBranchId.appendChild(text(d, transaction.getBranchId()));
		cRegionCode.appendChild(text(d, transaction.getRegionCode()));
		cNarrative.appendChild(text(d, deriveNarrative(transaction)));
		clCompositeCurAmtType
				.appendChild(text(d, ("D").equalsIgnoreCase(transaction.getDebitCreditInd()) ? DEBIT : CREDIT));
		clAmt.appendChild(text(d, transaction.getCalculatedLocalAmount().toString()));
		clCurCode.appendChild(text(d, transaction.getPaymentRequest().getLocalCcy()));
		ctCompositeCurAmtType
				.appendChild(text(d, ("D").equalsIgnoreCase(transaction.getDebitCreditInd()) ? DEBIT : CREDIT));
		ctAmt.appendChild(text(d, transaction.getCalculatedAmount().toString()));
		ctCurCode.appendChild(text(d, transaction.getCcy()));
		cRatePackage.appendChild(text(d, ef.getCptyRatePackage()));
		cRate.appendChild(text(d, ef.getCptyRate()));
		cSellMarkup.appendChild(text(d, ef.getCptySellMarkup()));
		cBuyMarkup.appendChild(text(d, ef.getCptyBuyMarkup()));
		cMidRate.appendChild(text(d, ef.getCptyMidRate()));
		cRateStatus.appendChild(text(d, transaction.getRateStatus()));
		cDisplayCode.appendChild(text(d, transaction.getDisplayCode()));
		cSwiftCode.appendChild(text(d, transaction.getSwiftCode()));
		cOriginCode.appendChild(text(d, orig.getOriginatorCode()));
		cRemittanceInformation.appendChild(text(d, transaction.getRemittanceInfo()));
		if(transaction.getPaymentRequest().getDebitCreditInd().equalsIgnoreCase(EboxPayCodes.ORIGINATOR_ACCOUNT_DEBIT)){
			cAmt.appendChild(text(d, String.valueOf(orig.getAmount().negate())));
		} else {
			cAmt.appendChild(text(d, String.valueOf(orig.getAmount())));
		}
		
		cCurCode.appendChild(text(d, orig.getCcy()));
		dealerRate.appendChild(text(d, transaction.getDealRate()));
		dealerId.appendChild(text(d, transaction.getDealId()));
		memo.appendChild(text(d, transaction.getRemittanceInfo()));
		deferClientEntry.appendChild(text(d, ef.getDeferClientEntry()));
		marketSegment.appendChild(text(d,
				transaction.getMarketSegment() == null ? orig.getMarketSegment() : transaction.getMarketSegment()));

		msgRqHdr.appendChild(timestamp);
		msgRqHdr.appendChild(country);
		appendIfNotEmpty(group, id);
		appendIfNotEmpty(group, itemNumber);
		appendIfNotEmpty(group, numberOfPaymentsInGroup);
		valueDate.appendChild(valueDays);
		valueDate.appendChild(valueDateInd);
		appendIfNotEmpty(paymentInfo, payment);
		appendIfNotEmpty(paymentInfo, type);
		appendIfNotEmpty(exchange, exchangeOn);
		appendIfNotEmpty(exchange, exchangeRate);
		appendIfNotEmpty(exchange, exchangeRateFormat);
		appendIfNotEmpty(exchange, exchangeDetails);

		appendIfNotEmpty(swift, sendersReference);
		appendIfNotEmpty(swift, relatedReference);
		appendIfNotEmpty(swift, senderToReceiver);
		appendIfNotEmpty(swift, preferredIntermediary);
		appendIfNotEmpty(swift, sameDayValueIndicator);
		appendIfNotEmpty(swift, swiftValueDate);
		appendIfNotEmpty(oPostAddr, oAddr1);
		appendIfNotEmpty(oPostAddr, oAddr2);
		appendIfNotEmpty(oPostAddr, oAddr3);
		oBankInfo.appendChild(oBankId);
		appendIfNotEmpty(oBankInfo, oBranchId);
		appendIfNotEmpty(olCurAmt, olAmt);
		appendIfNotEmpty(olCurAmt, olCurCode);
		appendIfNotEmpty(oLocalAmt, olCompositeCurAmtType);
		oLocalAmt.appendChild(olCurAmt);
		appendIfNotEmpty(otCurAmt, otAmt);
		appendIfNotEmpty(otCurAmt, otCurCode);
		appendIfNotEmpty(oTransactionAmt, otCompositeCurAmtType);
		oTransactionAmt.appendChild(otCurAmt);
		appendIfNotEmpty(oRateInfo, oRatePackage);
		appendIfNotEmpty(oRateInfo, oRate);
		appendIfNotEmpty(oRateInfo, oSellMarkup);
		appendIfNotEmpty(oRateInfo, oBuyMarkup);
		appendIfNotEmpty(oRateInfo, oMidRate);
		appendIfNotEmpty(oRateInfo, oRateStatus);
		appendIfNotEmpty(originatorAcctId, oAcctId);
		appendIfNotEmpty(originatorAcctId, oName);
        if (oPostAddr.hasChildNodes()) {
            originatorAcctId.appendChild(oPostAddr);
        }
		originatorAcctId.appendChild(oAcctCur);
		originatorAcctId.appendChild(oBankInfo);
		appendIfNotEmpty(originatorAcctId, oNarrative);
		originatorAcctId.appendChild(oLocalAmt);
		originatorAcctId.appendChild(oTransactionAmt);
		originatorAcctId.appendChild(oRateInfo);
		appendIfNotEmpty(originatorAcctId, oDisplayCode);
		appendIfNotEmpty(originatorAcctId, oOriginCode);
		originatorAcctId.appendChild(oRemittanceInformation);

		cPostAddr.appendChild(cAddr1);
		cPostAddr.appendChild(cAddr2);
		cPostAddr.appendChild(cAddr3);

		appendIfNotEmpty(cBankInfo, cBankId);
		appendIfNotEmpty(cBankInfo, cBranchId);
		appendIfNotEmpty(cBankInfo, cRegionCode);
		clCurAmt.appendChild(clAmt);
		clCurAmt.appendChild(clCurCode);
		appendIfNotEmpty(cLocalAmt, clCompositeCurAmtType);
		cLocalAmt.appendChild(clCurAmt);
		appendIfNotEmpty(ctCurAmt, ctAmt);
		appendIfNotEmpty(ctCurAmt, ctCurCode);
		appendIfNotEmpty(cTransactionAmt, ctCompositeCurAmtType);
		cTransactionAmt.appendChild(ctCurAmt);
		appendIfNotEmpty(cRateInfo, cRatePackage);
		appendIfNotEmpty(cRateInfo, cRate);
		appendIfNotEmpty(cRateInfo, cSellMarkup);
		appendIfNotEmpty(cRateInfo, cBuyMarkup);
		appendIfNotEmpty(cRateInfo, cMidRate);
		appendIfNotEmpty(cRateInfo, cRateStatus);
		appendIfNotEmpty(counterpartyAcctId, cAcctId);
		appendIfNotEmpty(counterpartyAcctId, cName);
		appendIfNotEmpty(counterpartyAcctId, cPostAddr);
		counterpartyAcctId.appendChild(cBankInfo);
		appendIfNotEmpty(counterpartyAcctId, cNarrative);
		counterpartyAcctId.appendChild(cLocalAmt);
		counterpartyAcctId.appendChild(cTransactionAmt);
		counterpartyAcctId.appendChild(cRateInfo);
		counterpartyAcctId.appendChild(cDisplayCode);
		counterpartyAcctId.appendChild(cSwiftCode);
		counterpartyAcctId.appendChild(cOriginCode);
		counterpartyAcctId.appendChild(cRemittanceInformation);

		cCurAmt.appendChild(cAmt);
		appendIfNotEmpty(cCurAmt, cCurCode);
		compositeCurAmt.appendChild(cCurAmt);

		if (stringNotEmpty(dealerRate.getFirstChild().getNodeValue())
				|| stringNotEmpty(dealerId.getFirstChild().getNodeValue())) {
			dealer.appendChild(dealerRate);
			dealer.appendChild(dealerId);
		}

		paymentRq.appendChild(rqUID);
		appendIfNotEmpty(paymentRq, userId);
		paymentRq.appendChild(group);
		appendIfNotEmptyChildren(paymentRq, valueDate);
		appendIfNotEmpty(paymentRq, settlementDays);
		paymentRq.appendChild(sourceSystem);
		paymentRq.appendChild(paymentInfo);
		paymentRq.appendChild(exchange);
		paymentRq.appendChild(swift);
		appendIfNotEmpty(paymentRq, postDate);
		paymentRq.appendChild(sourceLocationBranch);
		paymentRq.appendChild(terminalNumber);
		paymentRq.appendChild(originatorAcctId);
		paymentRq.appendChild(counterpartyAcctId);
		paymentRq.appendChild(compositeCurAmt);

		for (Element addRef : additionalRef) {
			paymentRq.appendChild(addRef);
		}

		if (!("LOCAL").equalsIgnoreCase(transaction.getPaymentRequest().getType()) && dealer.getFirstChild() != null) {
			paymentRq.appendChild(dealer);
		}

		appendIfNotEmpty(paymentRq, memo);
		appendIfNotEmpty(paymentRq, deferClientEntry);
		appendIfNotEmpty(paymentRq, marketSegment);

		bankSvcRq.appendChild(msgRqHdr);
		bankSvcRq.appendChild(paymentRq);
		ifx.appendChild(bankSvcRq);
		d.appendChild(ifx);

		return d;
	}

	// JIRA EBOXCLP-263
	// counterparty narrative - copy from originator if not present.
	private String deriveNarrative(Transaction transaction) {
		if (stringNotEmpty(transaction.getCounterPartyNarrative())) {
			return transaction.getCounterPartyNarrative();
		} else if (stringNotEmpty(transaction.getPaymentRequest().getNarrative())) {
			return transaction.getPaymentRequest().getNarrative();
		} else {
			return "";
		}
	}

	private String readStringValueFromInt(int value) {
		return value == 0 ? "" : String.valueOf(value);
	}

	private void appendIfNotEmpty(Element parent, Element child) {
		if (stringNotEmpty(child.getFirstChild().getNodeValue())) {
			parent.appendChild(child);
		}
	}

	private void appendIfNotEmptyChildren(Element parent, Element child) {
		if ((child.getFirstChild() != null) && (child.getFirstChild().getFirstChild() != null) &&
			((stringNotEmpty(child.getFirstChild().getNodeValue()))
			|| (stringNotEmpty(child.getFirstChild().getFirstChild().getNodeValue())))) {
			parent.appendChild(child);
		}
	}

	private List<Element> getAdditionalRef(Document d, Transaction transaction) {
		Transaction cpty = transaction;
		EnrichedFields ef = transaction.getEnrichedFields();
		PaymentRequest originator = transaction.getPaymentRequest();

		Map<String, String> additionalRefs = new HashMap<>();
		addToMapIfNotEmpty(additionalRefs, "IBAN", originator.getIban());
		addToMapIfNotEmpty(additionalRefs, "CUSTOMER_NUMBER1", readStringValueFromInt(originator.getCustomerNo1()));
		addToMapIfNotEmpty(additionalRefs, "CUSTOMER_NUMBER2", readStringValueFromInt(originator.getCustomerNo2()));
		addToMapIfNotEmpty(additionalRefs, "SWIFT_CODE", cpty.getSwiftCode());
		addToMapIfNotEmpty(additionalRefs, "CHARGE_OPTION", cpty.getChargeOption());
		addToMapIfNotEmpty(additionalRefs, "ORIGINATOR_CODE", originator.getOriginatorCode());
		addToMapIfNotEmpty(additionalRefs, "ORIGINATOR_SERIAL_NUM", originator.getSerialNo());
		addToMapIfNotEmpty(additionalRefs, "COUNTERPARTY_SERIAL_NUM", cpty.getSerialNo());
		addToMapIfNotEmpty(additionalRefs, "LOCATION_CODE", originator.getLocationCode());
		addToMapIfNotEmpty(additionalRefs, "ORIGINATOR_STP_LIMIT", ef.getOriginatorStpLimit());
		addToMapIfNotEmpty(additionalRefs, "COUNTERPARTY_STP_LIMIT", ef.getCptyStpLimit());
		addToMapIfNotEmpty(additionalRefs, "BOP_CODE", cpty.getBopCode());
		addToMapIfNotEmpty(additionalRefs, "BOP_SUB_CODE", cpty.getBopSubCode());
		addToMapIfNotEmpty(additionalRefs, "REFER_CODE", originator.getReferCode());

		List<Element> elems = new ArrayList<>();

		for (Entry<String, String> prop : additionalRefs.entrySet()) {
			Element additionalRef = elem(d, "AdditionalRef");
			Element refName = elem(d, "RefName");
			Element refValue = elem(d, "RefValue");
			refName.appendChild(text(d, prop.getKey()));
			refValue.appendChild(text(d, prop.getValue()));
			multiAppend(additionalRef, refName, refValue);
			elems.add(additionalRef);
		}

		return elems;
	}

	private Element getPropertyInfoTag(Document d, Transaction transaction) {
		Element propertyInfo = elem(d, "PropertyInfo");
		RequestHeader header = transaction.getPaymentRequest().getRequestHeader();

		Map<String, String> propertyNvp = new HashMap<>();

		addToMapIfNotEmpty(propertyNvp, "$GroupId", transaction.getPaymentRequest().getGroupId());
		addToMapIfNotEmpty(propertyNvp, "$GroupItemNumber",
				readStringValueFromInt(transaction.getTransactionCounter()));
		addToMapIfNotEmpty(propertyNvp, "$UseAutoResponder", "false");

		addToMapIfNotEmpty(propertyNvp, "ROUTE_QUEUE", transaction.getPaymentRequest().getStage2Queue().getQRoute());
		addToMapIfNotEmpty(propertyNvp, "$offshoreInd", readStringValueFromInt(header.getPropertyOffshoreInd()));
		addToMapIfNotEmpty(propertyNvp, "$batch", header.getPropertyBatch());
		addToMapIfNotEmpty(propertyNvp, "$user_id", header.getPropertyUserId());
		addToMapIfNotEmpty(propertyNvp, "$check_account", header.getPropertyCheckAccount());
		addToMapIfNotEmpty(propertyNvp, "$adjust_balance", header.getPropertyAdjustBalance());
		addToMapIfNotEmpty(propertyNvp, "$check_originator_account_exists", header.getPropertyCheckOrigAccExists());
		addToMapIfNotEmpty(propertyNvp, "$check_originator_account_open", header.getPropertyCheckOrigAccOpen());
		addToMapIfNotEmpty(propertyNvp, "$check_originator_account_currency", header.getPropertyCheckOrigAccCurrency());
		addToMapIfNotEmpty(propertyNvp, "$check_originator_account_balance", header.getPropertyCheckOrigAccBalance());
		addToMapIfNotEmpty(propertyNvp, "$check_counterparty_account", header.getPropertyCheckCounterpartyAcc());

		for (Entry<String, String> prop : propertyNvp.entrySet()) {
			Element property = elem(d, "Property");
			Element name = elem(d, "Name");
			Element value = elem(d, "Value");
			name.appendChild(text(d, prop.getKey()));
			value.appendChild(text(d, prop.getValue()));
			multiAppend(property, name, value);
			propertyInfo.appendChild(property);
		}

		return propertyInfo;
	}

	private Element elem(Document xmlDoc, String tagName) {
		return xmlDoc.createElement(tagName);
	}

	private Node text(Document xmlDoc, String text) {
		String safeText = text == null ? "" : text;
		return xmlDoc.createTextNode(safeText);
	}

	private void multiAppend(Element parent, Element... children) {
		for (Element child : children) {
			parent.appendChild(child);
		}
	}

	private void addToMapIfNotEmpty(Map<String, String> map, String key, String value) {
		if (stringNotEmpty(value)) {
			map.put(key, value);
		}
	}

	private boolean stringNotEmpty(String value) {
		return (value != null) && (value.trim().length() > 0);
	}

	private String fixEmptyRemittance(String cdata) {
		return cdata.replace("<RemittanceInformation/>", "<RemittanceInformation></RemittanceInformation>");
	}
}
