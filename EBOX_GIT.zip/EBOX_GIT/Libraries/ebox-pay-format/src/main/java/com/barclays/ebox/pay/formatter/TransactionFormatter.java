package com.barclays.ebox.pay.formatter;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import com.barclays.ebox.pay.domain.Transaction;

/**
 * The input to a Transaction formatter is a Transaction object The output is
 * defined with the generic argument <T>. T should generally be an element in
 * the SupportedFormat enum
 * 
 * @author g01025860
 *
 * @param <T>
 *            The desired SupportedFormat output
 */
@FunctionalInterface
public interface TransactionFormatter<T> {
	/**
	 * Converts a Transaction into another object of generic type <T>.
	 * 
	 * @param transaction
	 *            The input transaction we want formatted
	 * @return <T> An object of a generic type.
	 * @throws ParserConfigurationException
	 * @throws TransformerException
	 */
	T format(Transaction transaction) throws ParserConfigurationException, TransformerException; //NOSONAR
}
