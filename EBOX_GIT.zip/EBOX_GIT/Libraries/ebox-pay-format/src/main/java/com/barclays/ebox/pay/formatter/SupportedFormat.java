package com.barclays.ebox.pay.formatter;

import com.barclays.ebox.pay.format.Format;
import com.barclays.ebox.pay.format.cmf.CMF;

/**
 * Supported CMF Format
 * 
 * @author abrma5s
 *
 */
public enum SupportedFormat {
	CMF(CMF.class);

	private Class<? extends Format> type;

	private SupportedFormat(Class<? extends Format> type) {
		this.type = type;
	}

	public Class<? extends Format> getType() {
		return this.type;
	}
}
